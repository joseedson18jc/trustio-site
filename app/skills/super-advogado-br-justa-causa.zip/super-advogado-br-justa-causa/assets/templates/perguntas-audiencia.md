# Roteiro de audiência

## Fato 1. Ciência e apuração

Objetivo probatório:

1. Quem recebeu a informação inicial?
2. Em que data e por qual canal?
3. Quais diligências foram feitas nos três dias seguintes?
4. Onde estão registradas essas diligências?

## Fato 2. Autoria e integridade

Objetivo probatório:

1. Qual arquivo original foi analisado?
2. Quem tinha acesso a ele?
3. Houve perícia ou validação técnica?
4. Como se concluiu que o empregado realizou a alteração?

## Fato 3. Poder decisório

Objetivo probatório:

1. Quem decidiu a modalidade da dispensa?
2. A decisão veio como recomendação ou ordem?
3. O empregador formal produziu parecer próprio?
4. Quem assinou ou aprovou o registro contemporâneo?
