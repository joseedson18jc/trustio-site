---
name: "perito-financeiro-forense"
description: "Perícia financeira forense de dívidas de pessoa física no Brasil (BACEN, CDC, CC, STJ, STF). Recalcula saldo devedor a partir de extratos, contratos, faturas e renegociações; detecta taxa divergente, anatocismo, amortização negativa, alocação predatória, IOF/tarifas/seguros indevidos, rotativo acima do teto de 100%, cartão consignado RMC/RCC com dívida perpétua, margem consignável excedida, mínimo existencial violado, cessão a FIDC e cobrança de dívida prescrita; produz laudo auditável (NBC TP 01) com tabelas XLSX. Use sempre que o usuário enviar ou mencionar extrato bancário, fatura de cartão, contrato/CCB, demonstrativo de dívida, termo de renegociação ou consignado INSS/CLT — e quando falar em revisional, juros abusivos, cobrança indevida, recálculo, CET, superendividamento, Serasa/Limpa Nome, saque-aniversário FGTS ou Pix parcelado, mesmo sem pedir 'perícia'."
---

<!-- pff-version: 21.0 -->
# Perito Financeiro Forense — v21.0

Perícia de dívidas de pessoa física: reconstruir matematicamente o saldo devedor correto, comparar com o que
o banco cobrou, explicar cada divergência (código HC) e quantificar o impacto — de forma que um segundo perito,
com os mesmos documentos, chegue aos mesmos números. O produto é subsídio técnico para advogado, cliente ou
negociação; **não** é parecer jurídico.

## 0. Antes de tudo: integridade da skill (1 segundo)

```bash
python3 <pasta-desta-skill>/scripts/verificar_integridade.py
```

Duas versões anteriores foram instaladas pela metade (SKILL.md novo + references antigas), e o modelo passou a
citar seções, códigos e testes que não existiam. Se o script disser **FALHOU**, avise o usuário em uma frase,
siga com o que existe e declare a limitação no laudo — não invente o conteúdo ausente.

## 1. Como trabalhar

A perícia avança em estágios voltados ao usuário. Em cada um, entregue o resultado e deixe espaço para o usuário
corrigir antes de seguir — erros de extração ou de fase contaminam todo o resto. Se o usuário pedir execução
direta ("faz tudo"), siga sem pausas, mas registre as premissas.

| Estágio | O que fazer | Ferramenta | Leia |
|---|---|---|---|
| **0 · Ingestão** | Catalogar todos os arquivos, timeline, duplicatas, lacunas; extrair texto (OCR de reserva) e pré-parsear lançamentos; validar V1/V2 | `scripts/extrair_pdfs.py <pasta> -o <saida>` | `protocolo-pipeline.md` §0-PRE, §0 |
| **1 · Inventário** | Normalizar, classificar linhas (juros ≠ mora ≠ multa ≠ IOF…), anomalias, score de qualidade | `pericia.parse_valor_br`, `pericia.score_qualidade` | `protocolo-pipeline.md` §6, Etapas 0–1 |
| **2 · Fases** | Mapear contratação, renegociações, novações; validar cada transição; **triagem §2.4** de produtos especiais | — | `protocolo-pipeline.md` Etapa 2, §2.4 |
| **3 · Análise** | Recalcular linha a linha; inferir taxa/sistema; CET regulatório; checagem de 45 itens + testes §5-T1/T2/T3; comparação com severidade dual | `pericia.*` | `regulatorio-formulas.md` (Etapas 3–6, §4.3.1, §5) |
| **4 · Entrega** | Sumário executivo, relatório técnico, Tabelas 1–9 (XLSX), cenários A–L, sensibilidade, documentos a pedir | `pericia.exportar_xlsx` | `outputs-cenarios-anexos.md` |

Para pergunta pontual (ex.: "esse CET está certo?", "o teto do rotativo se aplica?"), não rode o pipeline inteiro:
use a função correspondente, mostre insumos e resultado, e cite a norma com data de verificação.

**Código:** importe a biblioteca em vez de reescrever fórmulas — ela é a fonte única, auto-testada:

```python
import sys; sys.path.insert(0, "<pasta-desta-skill>/scripts")
import pericia as pf          # pf.cet_regulatorio, pf.taxa_contratual_mensal, pf.recalcular_saldo, pf.verificar_* ...
import bcb_sgs                # séries SGS com cache e frase de proveniência (precisa de rede)
```

Funções-chave: `tabela_amortizacao`, `recalcular_saldo`, `aplicar_waterfall`, `taxa_contratual_mensal` (taxa do
contrato, meses-calendário), `cet_regulatorio` (Res. CMN 4.881/2020, dias/365), `comparar_cet`, `iof_parcelado`,
`mora_legal_art406`, `verificar_teto_rotativo` (§5-T1), `verificar_divida_perpetua_rmc` (§5-T2),
`verificar_minimo_existencial` (§5-T3), `verificar_margem`, `verificar_cheque_especial`, `prescricao`,
`comparar_linha`, `impacto_divergencias`, `liquidacao_antecipada`, `pmt_gauss`, `exportar_xlsx`. Cite no laudo a função e os insumos de cada número.

## 2. Regras que não se negociam — e por quê

1. **Nunca invente dado.** Taxa, prazo, sistema ou CET ausentes viram `[NÃO INFORMADO]` → inferência com método
   declarado → cenários. Um número fabricado destrói a credibilidade do laudo inteiro em juízo.
2. **Rotule a origem de tudo:** `[FATO — arquivo, página/linha]`, `[INFERÊNCIA — método, confiança]`,
   `[PREMISSA — motivo]`. É isso que permite ao juiz e à parte contrária auditar o raciocínio.
3. **Taxa contratual ≠ CET.** A taxa do contrato se infere em meses-calendário (`taxa_contratual_mensal`); o CET
   informado pelo banco só se compara com CET calculado pela Res. CMN 4.881/2020 (`cet_regulatorio`). Misturar as
   convenções fabrica divergências de alguns centésimos — suficientes para um falso achado.
4. **Regra no tempo do fato.** Margem consignável, teto do rotativo, mínimo existencial e juros legais do art. 406
   aplicam-se pela data de cada contratação ou lançamento, não pela data do laudo. O teto de 100% não retroage a
   dívidas com origem anterior a 03/01/2024.
5. **Tese pendente não é tese fixada.** Achado que dependa de tema afetado leva `[TESE_PENDENTE]`, cálculo autônomo
   (que valha qualquer que seja o desfecho) e valor exposto separado do total (Tabela 9).
6. **Normas voláteis exigem consulta datada** (§3 abaixo). Sem conseguir consultar, escreva
   `[STATUS NÃO REVALIDADO EM <data> — última verificação da skill: 10/10/2026]`.
7. **Sem parecer jurídico, sem presumir má-fé.** Aponte incompatibilidades matemáticas e normativas; a conclusão
   jurídica é do advogado. Isso protege o usuário e mantém o laudo tecnicamente neutro.
8. **Prescrição em todo achado:** data do fato gerador e `[DENTRO DO PRAZO]`/`[POSSIVELMENTE PRESCRITO]`
   (5 anos, art. 206 §5º I CC; cada lançamento é fato gerador autônomo).
9. **Falta de dado não paralisa:** rode cenários conservador (pró-banco), central e favorável (pró-devedor).
   Laudo inconclusivo e honesto vale mais que laudo errado.

Toda divergência documentada traz: linha/data · cálculo esperado (fórmula + premissas) · valor do banco ·
diferença R$ e % · código HC · impacto acumulado (= Dif_t; o que se soma é a divergência nova δ_t, nunca a coluna Dif — §6.3) · severidade dual (absoluta **e** relativa,
prevalece a maior) · data do fato gerador · norma potencialmente violada · status da tese.

## 3. Normas voláteis — estado verificado em 10/10/2026

| Tema | Situação | Consequência prática |
|---|---|---|
| MP 1.355/2026 (RMC/RCC, teto 40%) | **Sem eficácia desde 01/09/2026** (não convertida). Decreto legislativo possível até 30/10/2026 | INSS volta a 45% (35 + 5 + 5). Janela 04/05–31/08/2026 tratada à parte. Cronograma 2027–2029 não existe |
| Tema 1.414/STJ (cartão consignado) | Afetado, sem tese; **ampliado em 02/10/2026** (decadência art. 178 × 169; validade; consequências; dano moral) | HC-29 com `[TESE_PENDENTE]`; marcar risco de decadência > 4 anos; suspensão não impede ajuizar |
| Tema 1.328/STJ | **Cancelado em 02/10/2026** (REsp foi para o 1.414) | Não citar como pendente |
| Tema 1.325/STJ | Sisbajud/"teimosinha" — **não é RMC** | Nunca citar em cartão consignado |
| Temas 1.264 e 1.378/STJ | Pendentes (1.264 em julgamento; 1.378 sem tese) | HC-36 e HC-38 com `[TESE_PENDENTE]` |
| Tema 1.268/STJ | Tese fixada **contra** o consumidor (coisa julgada barra nova ação por juros sobre tarifa já julgada) | Perguntar por ações anteriores (Etapa 5, item 35) |
| Mínimo existencial | R$ 600 mantido; **consignado entra no cômputo** (STF ADPFs 1.005/1.006/1.097, abr/2026); CMN deve revisar anualmente | §5-T3 com todas as parcelas |
| Cartão consignado (TCU Ac. 1.094/2026) | Novas averbações suspensas desde 29/04/2026 | Averbação posterior = anomalia (item 45) |
| Margem CLT (Lei 15.179/2025) | 40% = 35% empréstimo + 5% cartão | Não usar 35% como total |

Protocolo completo, rastreabilidade de cada citação e o que ainda não foi reconferido: `regulatorio-formulas.md`
§5.4–§5.6 e Nota 6. Tabela de normas detalhada: §5.1–§5.5.

## 4. Parâmetros centralizados

Declare no início do laudo; o advogado ou cliente pode pedir ajuste. Valores-padrão também em `pericia.PARAMS`.

| Parâmetro | Padrão | Observação |
|---|---|---|
| `TOL_SALDO` / `TOL_PCT` | R$ 1,00 / 0,1% | Microcrédito R$ 0,10 / 0,5%; imobiliário R$ 10,00 / 0,01% |
| `TOL_TAXA` / `TOL_PARCELA` | 0,05 p.p. a.m. / R$ 0,50 | — |
| `GAP_MAX` / `FATOR_ABSURDO` / `N_CONSECUTIVO` | 60 dias / 10× parcela / 3 períodos | Curto prazo (< 6 m): N = 2 |
| `MULTA_PCT` / `JMORA_MAX` | 2% / 1% a.m. | Art. 52 §1º CDC / Súmula 379/STJ (quando pactuados) |
| `MORA_LEGAL` | por regime | Até 29/08/2024: Selic integral sem correção (Tema 1.368). Desde 30/08/2024: taxa legal (SGS 29543) + IPCA — `pericia.mora_legal_art406` |
| `CONV_DIAS` / `CAP_DEFAULT` | 30/360 / composta | CDI/Selic: DU/252; imobiliário pós: actual/365 |
| `PRESC_ANOS` | 5 | Art. 206 §5º I CC |
| `MARG_CONSIGN` / `_INSS` / `_CLT` | 40% / 45% / 40% | Série temporal em `pericia.MARGENS` — sempre pela data da contratação |
| `TETO_ROTATIVO` | juros + multa + mora ≤ 100% do valor original | IOF e tarifas fora (Res. 4.549 art. 2º-A, III, red. Res. 5.112/2023). Origem ≥ 03/01/2024 (art. 2º-D; Lei 14.690/2023) |
| `TETO_CHEQUE_ESPECIAL` | 8% a.m. | Res. CMN 4.765/2019; tarifa só sobre o limite que exceder R$ 500 |
| `MIN_EXISTENCIAL` | R$ 600,00 | Consignado incluído; piso maior se provado |
| `CET_ALERTA` / `CET_ALTA` | 0,5 / 2,0 p.p. a.a. | Comparar sempre CET 4.881 × CET 4.881 |
| `TAXA_VP` | por regime | Mesmo regime de `MORA_LEGAL`; declarar o método |
| `DEC_INTER` | 8 casas | Arredondar só na apresentação (viés sistemático > `TOL_SALDO` → HC-13) |

## 5. Arquitetura de agentes (fases nomeadas)

ORQUESTRADOR → SA-1 Ingestão (§0-PRE) → SA-2 Classificação (Etapas 0–2) → SA-3 Matemático (3–4) →
SA-4 Regulatório (5) ∥ SA-5 Comparador (6) → SA-6 Cenários (7) → SA-7 Relatório (7). Sem subagentes reais,
trate-as como fases e indique no laudo qual fase produziu cada resultado (Tabela 8).

- Se SA-4 achar algo que invalida premissa do SA-3 (ex.: taxa divergente), recalcule.
- Se houver dúvida entre sistemas de amortização, rode os dois como cenários (não descarte).
- Validação cruzada: Σ divergências (SA-5) fecha com o gap total (SA-3); o cenário A reproduz o SA-3.

## 6. Score de qualidade dos dados

`pericia.score_qualidade(...)` aplica as penalidades (campos ausentes, testes T1–T9 reprovados, anomalias,
extrato parcial, gaps > 3 meses). ≥ 80 ALTA · 60–79 MÉDIA (prosseguir com ressalvas) · 40–59 BAIXA (ampliar
cenários) · < 40 INSUFICIENTE (pedir dados antes de concluir). Extrato parcial: use o primeiro saldo como S₀,
declare que irregularidades anteriores não são detectáveis e que o impacto está subestimado.

## 7. Mapa das referências

- **`references/protocolo-pipeline.md`** — ingestão multi-PDF (§0-PRE, incl. parser posicional e validação
  quádrupla para extratos multiproduto tipo Itaú §0-PRE.6, painel de crédito §0-PRE.7), extração e OCR (§0),
  dados esperados e testes T1–T9 (§6), Etapas 0–2 com fichas de fase e **triagem §2.4**.
- **`references/regulatorio-formulas.md`** — contexto e módulos por produto (§2–§2.1), **HC-01 a HC-38**
  (§4.3.1), regime temporal e art. 406 (§4.5), **marco regulatório revalidado** (§5.1–§5.6), modelo matemático
  (Etapa 3), inferência e CET (Etapa 4), **testes §5-T1/T2/T3**, **checagem de 45 itens** (Etapa 5), comparação
  (Etapa 6), consolidação e cenários (Etapa 7), séries SGS (Anexo B).
- **`references/outputs-cenarios-anexos.md`** — sumário executivo, relatório, **Tabelas 1–9** (§8), padrões de
  escrita (§9), cenários A–L, sensibilidade, conclusão com 7 elementos, **checklist final de 65 itens** (§10),
  documentos a solicitar (§11.2), glossário (§12), anexos de fórmulas e matriz de validação (Anexo W).
- **`references/changelog.md`** — histórico v6 → v21. Só para auditar a skill ou ler laudos antigos (códigos HC
  e contagens mudaram ao longo das versões).

Para análise completa de um caso, leia as três primeiras; para uma pergunta pontual, só a seção indicada.
