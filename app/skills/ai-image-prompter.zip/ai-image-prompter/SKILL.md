---
name: ai-image-prompter
description: |
  Craft effective prompts for AI image generators (Midjourney, DALL-E, Stable Diffusion). Transform vague ideas into detailed, well-structured prompts with style, composition, and technical parameters.
  TRIGGERS: image prompt, midjourney, dall-e, stable diffusion, AI art, generate image prompt, text-to-image, image generation, art prompt, visual prompt
---

# AI Image Prompter

Transform ideas into effective image generation prompts.

## Prompt Structure

```
[Subject] + [Style] + [Composition] + [Lighting] + [Technical] + [Modifiers]
```

## Building Prompts

### 1. Subject (Required)
Be specific:
- Bad: "a cat"
- Good: "a fluffy orange tabby cat with green eyes, sitting on a velvet cushion"

### 2. Style
| Category | Examples |
|----------|----------|
| Art movements | impressionist, art nouveau, baroque, minimalist |
| Artists | in the style of Monet, Ghibli-inspired, Wes Anderson aesthetic |
| Media | oil painting, watercolor, digital art, 3D render, photograph |
| Era | 1920s vintage, 80s retro, futuristic, medieval |

### 3. Composition
- Framing: close-up, wide shot, bird's eye view, Dutch angle
- Focus: shallow depth of field, bokeh, sharp focus
- Layout: rule of thirds, centered, symmetrical

### 4. Lighting
- Natural: golden hour, overcast, harsh midday sun
- Artificial: neon lights, candlelit, studio lighting
- Mood: dramatic shadows, soft diffused, rim lighting

### 5. Technical Parameters

**Midjourney:**
```
--ar 16:9    # Aspect ratio
--v 6        # Version
--s 250      # Stylize (0-1000)
--c 10       # Chaos (0-100)
--no text    # Negative prompt
```

**Stable Diffusion:**
```
Steps: 30-50
CFG Scale: 7-12
Sampler: DPM++ 2M Karras
```

### 6. Quality Modifiers
Add at end: `highly detailed, 8k, professional photography, award-winning, masterpiece`

## Prompt Formulas

### Portrait
```
[adjective] portrait of [subject], [expression], [clothing],
[background], [lighting], [camera angle], [art style], [quality]
```

### Landscape
```
[time of day] [location], [key features], [weather/atmosphere],
[foreground elements], [style], [mood], [quality]
```

### Character Design
```
full body character design of [description], [pose], [outfit],
[accessories], [art style], character sheet, multiple views
```

## Examples

**Cozy Scene:**
```
A cozy reading nook with floor-to-ceiling bookshelves, warm afternoon
sunlight streaming through a rain-spattered window, plush armchair
with knitted blanket, steaming cup of tea, cats sleeping nearby,
watercolor illustration, soft warm colors --ar 3:4 --v 6
```

**Portrait:**
```
Portrait of an elderly fisherman, weathered face with deep wrinkles,
salt-and-pepper beard, worn cable-knit sweater, golden hour lighting,
shallow depth of field, shot on medium format film, photorealistic
--ar 4:5
```

## Negative Prompts (for Stable Diffusion)

```
ugly, deformed, blurry, low quality, text, watermark, signature,
cropped, worst quality, extra fingers, poorly drawn hands, mutation
```

## Tips

1. **Order matters**: Important elements first
2. **Be specific**: Vague = random results
3. **Use references**: "in the style of [artist]"
4. **Iterate**: Start simple, add details
5. **Aspect ratio**: Match use case (16:9 desktop, 9:16 mobile)
