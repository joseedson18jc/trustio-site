# Plugin: Juizados Especiais Cíveis (Lei 9.099/95) e Consumo de Varejo e Plataformas

> **Base verificada em 07/10/2026** (planalto.gov.br, stj.jus.br, stf.jus.br, cnj.jus.br). 🔄 = volátil, confirmar antes de usar. ⛔ = erro comum. 🔴 = tema afetado/suspenso. **C3 — verificar** = entendimento descrito sem número confirmado: não citar como fonte.
> Não repete o conteúdo bancário: fraudes, Pix, juros, RMC, superendividamento e cálculo de juros/correção (Lei 14.905/2024) estão em `plugin-consumidor-bancario.md`.

## Quando carregar
Ação de pequeno valor ou rito sumaríssimo no JEC; Juizado da Fazenda Pública ou Federal (só diferenças); recurso inominado, embargos, MS ou reclamação no sistema dos juizados; defeito ou vício de produto de varejo; produto que causa dano a pessoa ou bens (ex.: embalagem que explode); responsabilidade de aplicativo de entrega, marketplace ou intermediador; notificação extrajudicial, Procon e consumidor.gov.br antes de ajuizar.

---

## A. RITO DO JEC (Lei 9.099/1995)

### A.1 Competência — checar nesta ordem
1. **Valor**: até **40 salários mínimos** (art. 3º, I). Também as causas do **art. 275, II, do CPC/73** (art. 3º, II), mantidas pelo **art. 1.063 do CPC**, na redação da **Lei 14.976/2024** (que retirou o "até a edição de lei específica"); despejo para uso próprio; possessórias de imóvel até o teto.
   - 🔄 **Salário mínimo 2026: R$ 1.621,00** (Decreto 12.797/2025) → teto de 40 SM = **R$ 64.840,00**; 20 SM = **R$ 32.420,00**. Conferir o valor **na data do ajuizamento**.
   - Optar pelo JEC **renuncia ao excedente**, salvo conciliação (art. 3º, §3º). A sentença é **ineficaz** na parte que exceder a alçada (art. 39).
   - **Advogado**: dispensável até 20 SM; obrigatório acima disso (art. 9º) e **sempre no recurso** (art. 41, §2º).
   - **Trato sucessivo**: a soma de 12 parcelas vincendas e das vencidas não pode passar do teto (FONAJE 175).
   - **Dano moral**: não se exige quantificação (CPC art. 292, V afastado), mas se o autor atribuir valor, ele soma ao dano material para alçada e custas (FONAJE 170).
2. **Matérias excluídas** (art. 3º, §2º): natureza alimentar, falimentar, fiscal, de interesse da Fazenda Pública, acidente de trabalho, resíduos, estado e capacidade das pessoas. Procedimentos especiais não são admitidos (FONAJE 8). Demandas multitudinárias e coletivas também ficam fora (FONAJE 139).
3. **Complexidade**: é aferida pelo **objeto da prova**, não pelo direito material (FONAJE 54). Dano moral não é complexo por si só (FONAJE 69). Revisão de contrato e ilegalidade de juros cabem, **salvo se exigirem perícia contábil** (FONAJE 70 e 94). O juiz pode ouvir técnico de sua confiança e as partes podem juntar parecer técnico (art. 35). Se a causa exigir **perícia formal**, o processo é extinto sem mérito (art. 51, II).
4. **Foro** (art. 4º): domicílio do réu ou local de atividade/filial; local de cumprimento da obrigação; **domicílio do autor ou local do fato** nas ações de reparação de dano. O foro do inciso I é sempre possível. O consumidor também tem o art. 101, I, do CDC. A incompetência territorial **extingue** o processo (art. 51, III) e pode ser reconhecida de ofício (FONAJE 89).
5. **Partes** (art. 8º): não podem ser parte o incapaz, o preso, a pessoa jurídica de direito público, a empresa pública da União, a massa falida e o insolvente civil. **Autores admitidos** (§1º): pessoa física capaz (exceto cessionário de PJ), **MEI, ME e EPP** (LC 123/2006, redação da LC 147/2014), OSCIP e sociedade de crédito ao microempreendedor.
   - ME/EPP deve **comprovar o enquadramento** com documento idôneo (FONAJE 135) e ser representada pelo empresário ou sócio dirigente (FONAJE 141).
   - Empresa de grupo econômico cuja receita supere o limite de EPP não pode demandar (FONAJE 172).
   - Não cabe intervenção de terceiros; cabe litisconsórcio (art. 10). O incidente de desconsideração da PJ é admitido (CPC art. 1.062).

### A.2 Fluxo
- **Pedido** escrito ou oral na Secretaria (art. 14). Admite pedido genérico (§2º), mas a **sentença tem de ser líquida** (art. 38, parágrafo único). A sessão de conciliação deve ser marcada em até 15 dias (art. 16).
- **Citação** por AR em mão própria; PJ pelo encarregado da recepção, identificado; **não há citação por edital** (art. 18, §2º). A citação deve advertir sobre a possibilidade de inversão do ônus da prova (FONAJE 53).
- **Conciliação**: conduzida pelo juiz ou conciliador. É possível conciliação **não presencial**, por áudio e vídeo em tempo real (art. 22, §2º, Lei 13.994/2020).
- **AIJ** (arts. 27–28): a contestação, oral ou escrita, traz toda a defesa (art. 30). **Não há reconvenção**, mas cabe pedido contraposto fundado nos mesmos fatos (art. 31). No máximo 3 testemunhas por parte; o pedido de intimação deve ser feito 5 dias antes da audiência (art. 34). Toda prova é produzida em audiência (art. 33). O aditamento do pedido é possível até a AIJ (FONAJE 157).
- **Sentença**: sem relatório (art. 38). **Não cabe ação rescisória** (art. 59).
- **Recurso inominado** (arts. 41–43):
  - prazo de **10 dias** da ciência da sentença;
  - **preparo em 48 horas** da interposição, **independentemente de intimação**, sob pena de **deserção** (art. 42, §1º). Não se admite complementação tardia (FONAJE 80) e o art. 1.007 do CPC não se aplica (FONAJE 168);
  - efeito **somente devolutivo**; o juiz pode dar efeito suspensivo para evitar dano irreparável (art. 43);
  - julgado por **turma de 3 juízes togados** de primeiro grau (art. 41, §1º). Se confirmada pelos próprios fundamentos, a súmula do julgamento serve de acórdão (art. 46);
  - não cabe recurso adesivo (FONAJE 88). Agravo só nas hipóteses dos arts. 1.021 e 1.042 do CPC (FONAJE 15);
  - o juízo prévio de admissibilidade é feito em primeiro grau (FONAJE 166).
- **Embargos de declaração**: nos casos do CPC (art. 48, redação do CPC/2015), em **5 dias** (art. 49). **Interrompem** o prazo (art. 50, redação do CPC/2015). Não cabem só para prequestionar contra súmula de julgamento do art. 46 (FONAJE 125).
- **Prazos em dias úteis**: o **art. 12-A**, incluído pela **Lei 13.728/2018** (vigente desde a publicação, DOU 01/11/2018), vale para qualquer ato, inclusive recursos. O prazo conta da **intimação/ciência**, não da juntada (FONAJE 13). 🔄 A contagem das "48 horas" do preparo (hora a hora ou em dia útil) varia entre turmas — **C3 — verificar** no regimento local.

### A.3 Depois da turma recursal — o que cabe
- **Recurso especial: não cabe.** **Súmula 203/STJ** (Corte Especial, redação alterada em 23/05/2002, DJ 03/06/2002).
- **Recurso extraordinário: cabe** contra acórdão de turma recursal (**Súmula 640/STF**, Plenário, 24/09/2003). A admissibilidade é do Presidente da Turma, salvo disposição em contrário (FONAJE 84).
- **Reclamação**: a **Res. STJ 3/2016** atribuiu às **Câmaras Reunidas ou Seção Especializada do TJ** a reclamação contra acórdão de turma recursal **estadual** que contrarie jurisprudência do STJ firmada em IAC, IRDR, REsp repetitivo ou súmula. Fontes oficiais:
  - *Jurisprudência em Teses* do STJ, ed. 277 (2026), tese 7, com precedentes até **EDcl no AgInt no AREsp 2.230.425/MG**, 4ª T., DJEN 16/09/2025 → **o STJ não conhece da reclamação direta**;
  - cabem honorários nessa reclamação (tese 9);
  - **não cabe reclamação ao STJ contra turma recursal de JEF** (tese 11; ex.: AgInt na Rcl 49.579/SP, 1ª Seção, DJEN 02/03/2026).
  - 🔄 A **Lei 15.484, de 04/08/2026** (relevância do REsp), alterou o art. 988 do CPC (inciso V; §5º com indeferimento liminar e esgotamento de instância). Seu reflexo sobre a reclamação da Res. 3/2016 está sem jurisprudência — **C3 — verificar**.
  - O IRDR do TJ vincula os juizados do Estado (CPC art. 985, I).
- **Mandado de segurança**:
  - contra **decisão interlocutória** do JEC, **não cabe** (**STF, Tema 77**, RE 576.847, Rel. Min. Eros Grau; RG reconhecida em 2008; trânsito em julgado em 14/08/2009);
  - contra ato do juizado, a competência é da **turma recursal** (**Súmula 376/STJ**, Corte Especial, 18/03/2009);
  - **exceção**: MS no **TJ** só para **controle de competência** do juizado, sem reexame de mérito (**RMS 17.524/BA**, Corte Especial, Rel. Min. Nancy Andrighi, 2006). **Não cabe** depois do trânsito em julgado (**RMS 69.603/SP**, 1ª T., Rel. Min. Paulo Sérgio Domingues, j. 14/10/2025, Informativo 868) → impetrar **antes** de transitar;
  - não cabe recurso ordinário contra decisão de turma em MS (FONAJE 124).
- Tutela antecedente (CPC arts. 303–310) é incompatível com o JEC (FONAJE 163). Pedir tutela **incidental** na inicial.

### A.4 Ausências, revelia e custas
- **Réu ausente** a qualquer audiência → **revelia**: presumem-se verdadeiros os fatos, salvo convicção contrária do juiz (art. 20). O juiz sentencia (art. 23).
  - Apresentar resposta **não dispensa** o comparecimento pessoal (FONAJE 78; ver FONAJE 20).
  - PJ pode mandar **preposto com carta de preposição** e poderes para transigir, sem vínculo empregatício (art. 9º, §4º). A mesma pessoa não pode ser preposto e advogado ao mesmo tempo (FONAJE 98).
  - Acima de 20 SM, a falta de contestação gera revelia mesmo com o réu presente (FONAJE 11).
- **Autor ausente** a qualquer audiência → **extinção** sem mérito (art. 51, I), sem necessidade de intimação pessoal prévia (§1º). Há **condenação em custas** (FONAJE 28), salvo força maior comprovada (§2º).
- **Primeiro grau sem custas** (art. 54). O preparo do recurso cobre todas as despesas (parágrafo único).
- Não há honorários na sentença, **salvo má-fé**. O **recorrente vencido** paga custas e **honorários de 10% a 20%** (art. 55). A condenação independe de contrarrazões (FONAJE 96) e se aplica também ao recurso não conhecido (FONAJE 122).

### A.5 Execução
- O cumprimento de sentença corre no próprio juizado, aplicando o CPC com as adaptações do **art. 52**: sentença líquida, cálculo feito por servidor e embargos limitados às matérias do art. 52, IX (FONAJE 121).
- **Título extrajudicial** até 40 SM (art. 53). Se o devedor não for encontrado ou não houver bens, o processo é **extinto** (§4º); FONAJE 75 estende isso ao título judicial, com certidão de crédito.
- **Multa do art. 523, §1º, do CPC**: incide os **10%** mesmo que o total passe do teto, mas **não** os honorários de 10% (FONAJE 97). 🔄 Há turmas que aplicam honorários — **C3 — verificar** a orientação local.
- A **astreinte** não fica limitada a 40 SM (FONAJE 144).
- Embargos à execução exigem **juízo garantido** (FONAJE 117). No título judicial, o prazo é de 15 dias da intimação da penhora (FONAJE 142).

### A.6 Fazenda Pública (Lei 12.153/2009) e Federal (Lei 10.259/2001) — só as diferenças
| Ponto | JEFAZ (Lei 12.153) | JEF (Lei 10.259) |
|---|---|---|
| Teto | 60 SM (art. 2º) | 60 SM (art. 3º) |
| Competência | **absoluta** onde instalado (art. 2º, §4º) | **absoluta** onde instalada a vara (art. 3º, §3º) |
| Autores | pessoa física, ME, EPP (art. 5º) | pessoa física, ME, EPP (art. 6º) |
| Réus | Estados, DF, Municípios e suas autarquias, fundações e empresas públicas (art. 5º) | União, autarquias, fundações e empresas públicas federais (art. 6º) |
| Prazos e reexame | sem prazo diferenciado; citação ≥ 30 dias antes da audiência (art. 7º); sem reexame (art. 11) | idem (arts. 9º e 13) |
| Interlocutória | recorrível só na tutela cautelar/antecipatória (arts. 3º–4º) | idem (arts. 4º–5º) |
| Pagamento | RPV em 60 dias, sob pena de sequestro (art. 13) | RPV em 60 dias (art. 17) |
| Uniformização | arts. 18–19 (STJ, se contrariar súmula sua) | art. 14 (Turma de Uniformização; STJ pelo §4º) |

O teto de 60 SM **não** se aplica ao JEC (FONAJE 133).

### A.7 FONAJE — papel
São orientações do Fórum Nacional de Juizados Especiais, **sem força vinculante** (não estão no rol do art. 927 do CPC). Na prática, guiam turmas e juízes. Citar sempre com o número **e** a nota de redação.
- Base oficial: cnj.jus.br, página "Enunciados Cíveis" (atualizada em 01/10/2026).
- 🔄 Enunciados são renumerados, cancelados e substituídos (ex.: 102 e 103 revogados no 55º Encontro). **Conferir a redação vigente antes de citar.**

---

## B. CONSUMO DE VAREJO E PLATAFORMAS (CDC — Lei 8.078/1990)

### B.1 Fato x vício — decide prazo, réu e prova
| | **Fato do produto** (acidente de consumo) | **Vício do produto** |
|---|---|---|
| O que é | defeito de **segurança** que causa dano à pessoa ou ao patrimônio (art. 12, §1º) | inadequação de qualidade ou quantidade (art. 18) |
| Quem responde | fabricante, produtor, construtor e importador, **objetivamente** (art. 12). O **comerciante** responde **só** nas hipóteses do **art. 13** (fabricante não identificável; produto sem identificação clara; perecível mal conservado), com regresso (parágrafo único) | **todos** os fornecedores, **solidariamente** (art. 18) |
| Remédio | indenização integral (art. 6º, VI) | prazo de 30 dias para sanar; depois, substituição, restituição ou abatimento (art. 18, §1º). Uso imediato se o vício for grave ou o produto essencial (§3º) |
| Prazo | **prescrição de 5 anos** contados do conhecimento do dano e da autoria (**art. 27**) | **decadência**: 30 dias (não durável) ou 90 dias (durável) (**art. 26**). Vício oculto: conta de quando se manifesta (§3º) |
| Vítima | **todas** as vítimas do evento são consumidoras (art. 17 — *bystander*) | consumidor (art. 2º) |

- **Excludentes do fabricante** (art. 12, §3º): não ter colocado o produto no mercado, **inexistência do defeito**, culpa exclusiva do consumidor ou de terceiro. Quem tem de provar é o fornecedor.
- **Solidariedade na cadeia**: arts. 7º, parágrafo único, e 25, §1º; atos de prepostos e representantes (art. 34).

### B.2 Produto que causa dano (ex.: garrafa ou embalagem que explode, aparelho que danifica bens)
- **Regime**: fato do produto (art. 12). Responsabilidade **objetiva**. Basta provar dano + nexo com o produto; o **defeito se presume**.
- **STJ — explosão de garrafa**: **REsp 1.288.008/MG**, 3ª T., Rel. Min. Paulo de Tarso Sanseverino, j. 04/04/2013, DJe 11/04/2013.
  - Garrafa de cerveja estourou nas mãos de um comerciante → ele é consumidor por equiparação (art. 17);
  - nexo reconhecido;
  - o **ônus de provar a inexistência do defeito é do fabricante**, por força do art. 12, §3º, II. A inversão é **ope legis**: não depende de decisão judicial.
  - Referência confirmada em acórdão do STJ: REsp 1.787.318/RJ, mesmo relator.
- **Inversão ope judicis** (art. 6º, VIII): verossimilhança **ou** hipossuficiência. É útil para provar o **nexo** e a extensão do dano. Pedir na inicial.
- **Corpo estranho em alimento**: **REsp 1.899.304/SP**, 2ª Seção, Rel. Min. Nancy Andrighi, DJe 04/10/2021.
  - Uniformizou a 3ª e a 4ª Turmas: a **ingestão é irrelevante** para configurar o dano moral, pois a exposição a risco concreto basta;
  - a ingestão pesa no **valor** da indenização;
  - aplicado depois, ex.: AgInt no REsp 2.160.785/SP, publicado em 06/03/2026.
- **Prova a montar**: fotos e vídeos imediatos; **guardar os restos do produto e da embalagem** (lote, validade); nota fiscal ou comprovante do pedido; laudo ou orçamento dos bens danificados; atendimento médico, se houver; protocolos de reclamação; testemunhas.
  - Se o fornecedor pedir o produto para análise, entregar **com termo de recebimento** e fotos do estado.
  - Perícia complexa pode tirar a causa do JEC (A.1.3). Avaliar se o caso se resolve com parecer técnico do art. 35.
- **Danos**: material (bens danificados, despesas, lucros cessantes) + moral. Correção do dano moral **desde o arbitramento** (**Súmula 362/STJ**, Corte Especial, 15/10/2008). Juros na responsabilidade extracontratual contam do evento danoso — **C3 — verificar o número da súmula**. Taxas e índices: ver o plugin bancário, §3.3.

### B.3 Aplicativos de entrega, marketplaces e intermediadores
- **Marketplace / plataforma de intermediação**: **REsp 1.978.268/SP**, 3ª T., Rel. Min. Humberto Martins, j. 11/05/2026, DJEN 15/05/2026.
  - A plataforma é **fornecedora de serviços** (art. 3º, §2º), **integra a cadeia de consumo** e responde **objetiva e solidariamente** (arts. 14, 25, §1º, e 30);
  - a promessa de "dinheiro de volta" ou "compra garantida" integra o contrato;
  - 🔄 acórdão recente: conferir trânsito e eventuais embargos.
- **Limites (distinguishing)**:
  - **fraude fora da plataforma**: não há responsabilidade do site (REsp 1.880.344/SP, 3ª T., Rel. Min. Nancy Andrighi; notícia STJ de 08/04/2021);
  - **site de classificados / provedor de conteúdo** não integra a cadeia de fornecimento do bem anunciado (REsp 2.102.442/GO, 3ª T., j. 14/05/2024).
  - Fixar na inicial **como** a plataforma participou: pagamento, logística, garantia, comissão, marca.
- **Aplicativo de entrega (delivery)**: **não localizei precedente do STJ confirmado** sobre a responsabilidade do app perante o consumidor final — **C3 — verificar**.
  - A tese usual nos tribunais estaduais é a solidariedade da cadeia (arts. 7º, parágrafo único, e 25, §1º), quando o app intermedeia, cobra e/ou entrega.
  - Leitura possível (inferência, não precedente): no **fato do produto**, o app que só intermedeia se aproxima do comerciante (art. 13). Se o app **transporta ou acondiciona**, pode responder por **defeito do próprio serviço** (art. 14).
  - Recomendação: incluir **fabricante + vendedor + plataforma** no polo passivo e explicar o papel de cada um.

### B.4 Antes de ajuizar: notificação, Procon, consumidor.gov.br
- **Notificação extrajudicial**: **não é exigida** pelo CDC. Serve para:
  - **obstar a decadência** do vício (art. 26, §2º, I): a reclamação comprovada ao fornecedor suspende o prazo até a **resposta negativa inequívoca**;
  - constituir prova de boa-fé e de recusa;
  - fixar o valor pedido e preservar a prova (pedir que o fornecedor não alegue descarte).
  - ⛔ Ela **não** interrompe a **prescrição** do art. 27. No CC, a interrupção extrajudicial só ocorre por ato inequívoco de **reconhecimento** do devedor (art. 202, VI), e se interrompe uma única vez.
- **consumidor.gov.br**: plataforma oficial da administração federal para autocomposição (Decreto 8.573/2015, art. 1º-A, incluído pelo **Decreto 10.197/2020**). O Procon é a via administrativa estadual ou municipal. Guardar protocolos e respostas.
- 🔴 **Tema 1.396/STJ** (REsp 2.209.304/MG, Corte Especial, Rel. Min. Ricardo Villas Bôas Cueva, afetado em 25/11/2025, **status: afetado**):
  - definirá se a **prévia tentativa extrajudicial** é exigível para o interesse de agir nas ações prestacionais de consumo;
  - há suspensão de REsp e AREsp **na segunda instância e no STJ** (art. 256-L do RISTJ);
  - **até a tese, tentar sempre** a via extrajudicial e documentá-la. Isso neutraliza a preliminar.

### B.5 Dano moral
- **Parâmetros usuais**: gravidade, extensão, risco à saúde, conduta do fornecedor depois da reclamação, reincidência, capacidade econômica, vedação ao enriquecimento sem causa. O STJ costuma adotar critério **bifásico** de arbitramento — **C3 — verificar o precedente** antes de citar número.
- **"Mero aborrecimento"**: vício ou inadimplemento, sozinhos, tendem a não gerar dano moral. O dano precisa vir de **risco à segurança**, humilhação, privação relevante ou descaso qualificado. Nos casos de **corpo estranho**, o risco basta (B.2).
- **Desvio produtivo do consumidor** (tempo útil perdido):
  - **não há tese repetitiva que o adote**;
  - **Tema 1.156/STJ** (REsp 1.962.275, 2ª Seção, Rel. Min. Ricardo Villas Bôas Cueva, 2024): o simples descumprimento de prazo legal de atendimento bancário **não gera dano moral in re ipsa**. Exige prova da postura leniente do fornecedor e do nexo;
  - a 3ª Turma a aplica **só em relação de consumo** (REsp 2.017.194, Rel. Min. Nancy Andrighi, notícia STJ de 03/02/2023) e já a usou no dever do comerciante de intermediar o reparo (REsp 1.634.851, 3ª T.);
  - **uso prudente**: alegar com **prova da via-crúcis**: datas, protocolos, número de contatos, deslocamentos, horas gastas.

---

## C. Checklists

**C.1 Petição inicial no JEC**
- [ ] Competência: valor ≤ 40 SM **no ajuizamento**, sem matéria excluída, sem perícia complexa e foro correto (art. 4º / CDC art. 101, I).
- [ ] Legitimidade: autor do art. 8º, §1º (ME/EPP com prova do enquadramento) e todos os réus da cadeia, com a função de cada um.
- [ ] Fatos em ordem cronológica, com data, hora, lote e nº do pedido. Distinguir **fato** (art. 12) e **vício** (art. 18).
- [ ] Provas anexadas: nota ou pedido, fotos e vídeos, produto preservado, orçamentos e laudos, protocolos (fornecedor, Procon, consumidor.gov.br), notificação.
- [ ] Pedidos **líquidos** (art. 38, parágrafo único): dano material item a item, dano moral com valor sugerido somado à alçada (FONAJE 170), inversão do ônus (art. 6º, VIII, e art. 12, §3º), tutela **incidental** se houver urgência.
- [ ] **Valor da causa** igual à soma dos pedidos. Se ultrapassar o teto, decidir conscientemente entre **renunciar ao excedente** (art. 3º, §3º) ou ir para a vara comum.
- [ ] Testemunhas (até 3) e pedido de intimação com 5 dias de antecedência.

**C.2 Audiência de conciliação**
- [ ] Comparecimento **pessoal** da parte (art. 51, I, e FONAJE 20); preposto com carta e poderes para transigir (réu PJ).
- [ ] Piso e teto de acordo definidos com o cliente; cálculo atualizado; prazo de pagamento e **multa por descumprimento** na minuta.
- [ ] Se for por vídeo: testar o link; ter os documentos em PDF; saber que a recusa do réu leva à sentença (art. 23).
- [ ] Sem acordo: verificar se a AIJ será imediata (art. 27) e levar as testemunhas.

**C.3 Recurso inominado**
- [ ] Contar **10 dias úteis** da ciência (arts. 42 e 12-A).
- [ ] Recolher o **preparo integral em até 48 horas** da interposição, sem esperar intimação, e juntar a guia + comprovante (FONAJE 80).
- [ ] Gratuidade: pedir com prova de insuficiência (FONAJE 116). Se for indeferida, há 48 horas para preparar (FONAJE 115).
- [ ] Efeito suspensivo: pedir de forma fundamentada (art. 43).
- [ ] Prequestionar matéria **constitucional** se houver chance de RE. Recurso especial não cabe.
- [ ] Contrarrazões em 10 dias (art. 42, §2º).

## D. Pontos de verificação obrigatória
1. **Salário mínimo vigente** na data do ajuizamento (2026: R$ 1.621,00 — Decreto 12.797/2025). Recalcular os tetos de 20, 40 e 60 SM.
2. **Regimento interno da turma recursal do Estado**: forma e contagem do preparo, sustentação oral, sessões virtuais, uniformização entre turmas, e qual órgão do TJ julga a reclamação da Res. STJ 3/2016.
3. **Enunciados estaduais** (turmas recursais e Encontros de Juízes) e **súmulas das turmas**, que podem divergir do FONAJE (ex.: honorários no art. 523).
4. **Tabela de custas do preparo** do TJ local (🔄 anual).
5. **FONAJE**: redação vigente no portal do CNJ.
6. **Tema 1.396/STJ** e **REsp 1.978.268/SP**: conferir status.
7. Regras locais de **processo eletrônico** e **audiência por vídeo**.

## E. Erros comuns ⛔
- Ajuizar no JEC causa que **exige perícia formal** → extinção (art. 51, II) depois de meses perdidos.
- Faltar à audiência → **extinção com custas** (autor) ou **revelia** (réu). Mandar só o advogado não supre a presença da parte (FONAJE 78).
- Esperar intimação para o preparo, ou recolher valor parcial → **deserção**.
- Interpor **REsp** contra acórdão de turma recursal (Súmula 203/STJ) ou **reclamação direta ao STJ** (Res. 3/2016).
- Impetrar **MS contra interlocutória** do JEC (Tema 77/STF), ou MS de competência **depois do trânsito** (RMS 69.603/SP).
- Pedir valor **acima do teto** sem perceber que o excedente é renunciado (art. 3º, §3º; art. 39).
- Tratar acidente de consumo como **vício** e aplicar o prazo de 30/90 dias do art. 26 em vez dos 5 anos do art. 27, ou o contrário.
- Processar **só o comerciante** em fato do produto fora das hipóteses do art. 13.
- **Descartar o produto** defeituoso ou entregá-lo ao fornecedor sem termo e sem fotos.
- Achar que a notificação extrajudicial **interrompe a prescrição**.
- Citar enunciado do FONAJE como precedente vinculante, ou citar enunciado **cancelado ou renumerado**.
- Copiar parâmetro de dano moral de caso bancário: o regime bancário tem Súmula 479 e temas próprios (ver o plugin bancário).
