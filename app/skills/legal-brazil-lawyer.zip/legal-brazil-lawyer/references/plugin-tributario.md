# Plugin: Direito Tributário Avançado

## Ativar quando
Pedido envolver tributos, planejamento fiscal, contencioso tributário, execução fiscal, teses tributárias, impacto tributário em contratos ou operações societárias.

## Raciocínio especializado

### Sequência obrigatória de análise
1. Identificar o tributo (federal/estadual/municipal, direto/indireto)
2. Verificar fato gerador, base de cálculo, alíquota, sujeito passivo
3. Checar imunidades, isenções e benefícios aplicáveis
4. Mapear obrigações acessórias envolvidas
5. Identificar teses tributárias relevantes (STF/STJ/CARF)
6. Avaliar risco de autuação e prognóstico contencioso

### Tributos federais — referência rápida
- **IRPJ/CSLL**: RIR/99, Lei 9.430/96, Lei 12.973/14
- **PIS/COFINS**: Leis 10.637/02 e 10.833/03 (não-cumulativo); Lei 9.718/98 (cumulativo)
- **IPI**: RIPI (Decreto 7.212/10)
- **IOF**: Decreto 6.306/07
- **CIDE**: Lei 10.168/00, Lei 10.336/01
- **Contribuições previdenciárias**: Lei 8.212/91

### Tributos estaduais
- **ICMS**: LC 87/96 (Lei Kandir), convênios CONFAZ, legislação estadual
- **ITCMD**: legislação estadual; RE 851.108 (STF — competência em doações exterior)
- **IPVA**: legislação estadual

### Tributos municipais
- **ISS**: LC 116/03 e LC 157/16; lista de serviços
- **IPTU**: CTN arts. 32-34; lei municipal
- **ITBI**: CTN arts. 35-42; RE 1.294.969 (STF — base de cálculo)

### Teses tributárias de alta relevância (2020–2025)
- **Exclusão do ICMS da base do PIS/COFINS**: RE 574.706 (Tema 69 STF) — transitado
- **TUST/TUSD na base do ICMS energia**: Tema 956 STJ — incluídos
- **CSLL na base do IRPJ**: pacificado pela negativa
- **Subvenções para investimento (ICMS)**: EREsp 1.517.492; Lei 14.789/23 — atenção à nova sistemática
- **PIS/COFINS sobre receitas financeiras**: REsp 1.987.158 (alíquota zero)
- **IRPJ/CSLL sobre Selic na repetição do indébito**: RE 1.063.187 (Tema 962 STF) — incide
- **DIFAL ICMS EC 87/15**: ADI 5.469 e RE 1.287.019
- **ISS exportação de serviços**: LC 116/03 art. 2º; critério resultado

### Contencioso administrativo federal
- **CARF**: Decreto 70.235/72; Portaria MF 343/15
- **Câmaras e turmas**: ordinária, especial, CSRF
- **Voto de qualidade**: Lei 13.988/20 (art. 19-E) — pró-contribuinte
- **Transação tributária**: Lei 13.988/20; Portarias PGFN e RFB

### Execução fiscal
- **Lei 6.830/80** (LEF)
- **Redirecionamento**: art. 135 CTN; Tema 981 STJ (encerramento irregular)
- **Exceção de pré-executividade**: cabível para matérias de ordem pública
- **Parcelamentos**: PERT (Lei 13.496/17), parcelamentos ordinários (Lei 10.522/02)

### Planejamento tributário — critérios de validade
- **Propósito negocial**: ausência não invalida automaticamente (RE 629.610)
- **Elisão vs. evasão**: anterioridade do ato à ocorrência do fato gerador
- **Norma geral antielisiva**: art. 116 parágrafo único CTN (regulamentação pendente)
- **Distribuição disfarçada de lucros**: arts. 60-62 DL 1.598/77
- **Preços de transferência**: Lei 14.596/23 (nova metodologia OCDE a partir de 2024)

### Formato de saída preferencial
- Parecer tributário: questão → norma → tese → aplicação → risco → recomendação
- Matriz de contingência: tributo | base | valor estimado | probabilidade | provisão sugerida
- Checklist de obrigações acessórias por regime tributário
- Análise de impacto tributário em contratos: cláusulas de gross-up, retenção na fonte, responsabilidade solidária

### Avisos obrigatórios em tributário
- Sempre verificar legislação estadual/municipal quando ICMS/ISS/ITBI/ITCMD envolvidos
- Teses tributárias mudam com frequência — confirmar status no e-CAC ou portais oficiais
- Planejamento tributário: validar com advogado tributarista antes de implementar
- Preços de transferência (Lei 14.596/23): nova metodologia OCDE vigente — atenção a contratos internacionais
