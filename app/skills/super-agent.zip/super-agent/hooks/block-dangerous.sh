#!/usr/bin/env bash
# PreToolUse guard: block destructive commands with unbounded or unverified scope.
# Matcher: Bash
set -uo pipefail

payload="$(cat)"

check() {
  if printf '%s' "$payload" | grep -qiE "$1"; then
    printf 'BLOCKED: %s\n\n' "$2" >&2
    printf 'Matched pattern: %s\n' "$1" >&2
    cat >&2 << 'MSG'

Required before any destructive operation:
  1. Verify the target read-only first (SELECT COUNT(*), ls, git status).
  2. Confirm the affected count is what you expect.
  3. Confirm a revert path exists.
  4. Get explicit user authorization for this specific action.
MSG
    exit 2
  fi
}

# rm -rf against root, home, a variable, or a glob
check 'rm[[:space:]]+(-[a-zA-Z]*[rf][a-zA-Z]*[[:space:]]+)+(/[[:space:]]*$|/\*|~|\$[A-Za-z_{])' \
      'rm -rf with unbounded or variable scope (an unset variable expands to /)'
check 'rm[[:space:]]+-[a-zA-Z]*[rf]' \
      'recursive/forced delete — verify the exact path with ls first, then ask'

# git operations that destroy work or rewrite shared history
check 'git[[:space:]]+push[[:space:]]+[^|;&]*--force(-with-lease)?[^|;&]*(main|master|prod|release)' \
      'force-push to a protected branch'
check 'git[[:space:]]+reset[[:space:]]+--hard' \
      'git reset --hard discards uncommitted work irrecoverably'
check 'git[[:space:]]+clean[[:space:]]+-[a-zA-Z]*f' \
      'git clean -f deletes untracked files irrecoverably'
check 'git[[:space:]]+(checkout|restore)[[:space:]]+\.[[:space:]]*$' \
      'discards all uncommitted changes in the working tree'

# SQL with unbounded scope
check 'DROP[[:space:]]+(TABLE|DATABASE|SCHEMA|INDEX)' 'DROP statement'
check 'TRUNCATE[[:space:]]' 'TRUNCATE removes all rows and is not transactional on all engines'
check '(DELETE|UPDATE)[[:space:]]+(FROM[[:space:]]+)?[A-Za-z_."]+[[:space:]]*(;|$)' \
      'DELETE/UPDATE with no WHERE clause'

# infrastructure
check 'terraform[[:space:]]+destroy' 'terraform destroy'
check 'kubectl[[:space:]]+delete[[:space:]]+(ns|namespace|deploy|statefulset|pvc)' \
      'kubectl delete on a durable resource'
check 'DROP[[:space:]]+ROLE|DROP[[:space:]]+USER' 'dropping a database principal'

exit 0
