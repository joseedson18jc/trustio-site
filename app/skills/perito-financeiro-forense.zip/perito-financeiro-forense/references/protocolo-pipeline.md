<!-- pff-version: 21.0 -->
# Protocolo de Extração + Dados Esperados + Pipeline Operacional

**Sumário:** §0-PRE Ingestão multi-PDF (0-PRE.1–0-PRE.7) · §0 Extração · §6 Dados esperados · §7 Etapas 0–2 (inventário, classificação, fases, triagem §2.4)

## § 0-PRE. INGESTÃO MULTI-PDF — PROTOCOLO DE RECEBIMENTO

> **REGRA FUNDAMENTAL DE INGESTÃO:** casos reais costumam trazer **dezenas de PDFs** (extratos de vários meses, contratos,
> aditivos, faturas) — mas um único contrato + demonstrativo também é uma perícia válida. O protocolo garante que
> **nenhum dado seja perdido** antes da análise, qualquer que seja o volume.
>
> **Comece pelo script:** `python3 scripts/extrair_pdfs.py <pasta> -o <saida>` gera em segundos o catálogo, a timeline,
> o texto integral por página (com OCR de reserva), os lançamentos pré-parseados, as linhas de tabela
> (`*.tabela.csv`, com o cabeçalho para mapear colunas), duplicatas e os testes V1/V2. Use o resultado como
> ponto de partida e **confira**: o pré-parse é genérico; quando V1/V2 reprovam, passe ao parser posicional (§0-PRE.6)
> ou à leitura visual da página.

### 0-PRE.1 Recebimento e Catalogação

Ao receber os arquivos do usuário, execute IMEDIATAMENTE:

1. **Inventário completo dos uploads:**
   ```
   CATÁLOGO DE ARQUIVOS RECEBIDOS
   ├── Total de arquivos: [N]
   ├── Formatos: [PDF: N, XLSX: N, CSV: N, OFX: N, Outros: N]
   ├── Tamanho total: [X MB]
   └── Lista:
       ├── [001] arquivo_1.pdf — [N páginas] — [X KB]
       ├── [002] arquivo_2.pdf — [N páginas] — [X KB]
       └── ...
   ```

2. **Classificação por tipo de documento:**

   | Tipo | Exemplos | Prioridade de Processamento |
   |---|---|---|
   | Extrato consolidado / Demonstrativo de evolução | Evolução da dívida, extrato mensal, demonstrativo | 1ª (crítico — base da auditoria) |
   | Contrato original | Cédula de crédito, contrato de empréstimo | 2ª (parâmetros contratuais) |
   | Aditivo / Termo de renegociação / Novação | Termo aditivo, renegociação, composição de dívida | 3ª (fases e transições) |
   | Comprovante de pagamento | Boleto pago, comprovante PIX/TED | 4ª (validação cruzada) |
   | Outros (judicial, correspondência, simulação) | Petição, notificação, simulação do banco | 5ª (contexto complementar) |

3. **Detecção de lacunas:** Após catalogar, verifique se o conjunto é minimamente completo:
   - [ ] Existe pelo menos 1 extrato ou demonstrativo de evolução?
   - [ ] O período coberto é contínuo (sem gaps > 3 meses entre extratos)?
   - [ ] Existe contrato original ou, na ausência, pelo menos um documento com taxa/prazo?
   - Se lacunas críticas: **informe o usuário** mas NÃO PARE. Prossiga com cenários e declare `[PREMISSA — dados faltantes: X]`.

### 0-PRE.2 Ordenação Cronológica Global

**ANTES de qualquer extração de dados**, ordene TODOS os documentos cronologicamente:

1. **Identificar a data-referência de cada documento:**
   - Para extratos: data inicial e final do período coberto.
   - Para contratos: data de assinatura.
   - Para aditivos/renegociações: data do evento (novação/renegociação).
   - Para comprovantes: data do pagamento.

   Método: ler as primeiras 2 páginas de cada PDF (parsing rápido ou LLM multimodal) para extrair datas.

2. **Construir timeline cronológica:**
   ```
   TIMELINE CRONOLÓGICA DOS DOCUMENTOS
   ═══════════════════════════════════════════════════════
   [DD/MM/AAAA] Contrato original — arquivo_X.pdf
   [DD/MM/AAAA]-[DD/MM/AAAA] Extrato período 1 — arquivo_Y.pdf
   [DD/MM/AAAA]-[DD/MM/AAAA] Extrato período 2 — arquivo_Z.pdf
   [DD/MM/AAAA] 1ª Renegociação — arquivo_W.pdf
   [DD/MM/AAAA]-[DD/MM/AAAA] Extrato período 3 — arquivo_V.pdf
   ...
   ═══════════════════════════════════════════════════════
   Período total: [data_mais_antiga] a [data_mais_recente] = [N] meses
   Gaps detectados: [listar ou "nenhum"]
   ```

3. **Detectar sobreposições e duplicatas:**
   - Dois extratos cobrindo o mesmo período: comparar totais; se idênticos = duplicata → descartar um com log.
   - Se parcialmente sobrepostos: manter ambos, deduplicar linhas na extração.

### 0-PRE.3 Estratégia de Extração Dual (Parsing + OCR)

> **PRINCÍPIO DE EXTRAÇÃO INFALÍVEL:** Para cada PDF, aplique AMBOS os métodos (parsing direto E OCR/visão) e compare os resultados. A extração dual garante que nenhum dado seja perdido, mesmo em PDFs degradados ou com formatação inconsistente.

**Pipeline de extração por arquivo:**

```
┌─────────────────────┐
│  PDF recebido       │
└──────────┬──────────┘
           │
     ┌─────▼─────┐
     │ Classificar│ (nativo / scan / misto / protegido)
     └─────┬─────┘
           │
    ┌──────▼──────────────────────┐
    │  CAMINHO A: Parsing Direto  │  (pdfplumber + camelot + tabula-py)
    │  Extrai texto, tabelas,     │  → DataFrame_A
    │  mantém posição e layout    │
    └──────┬──────────────────────┘
           │
    ┌──────▼──────────────────────┐
    │  CAMINHO B: OCR/Visão       │  (Tesseract + LLM multimodal)
    │  Renderiza páginas como     │  → DataFrame_B
    │  imagem, extrai por OCR     │
    └──────┬──────────────────────┘
           │
    ┌──────▼──────────────────────┐
    │  RECONCILIAÇÃO A ∩ B        │
    │  • Linhas em A e B: OK      │
    │  • Linhas em A mas não B:   │
    │    verificar manualmente    │
    │  • Linhas em B mas não A:   │
    │    verificar manualmente    │
    │  • Valores divergentes:     │
    │    adotar A se nativo,      │
    │    B se scan; log ambos     │
    └──────┬──────────────────────┘
           │
    ┌──────▼──────────────────────┐
    │  DataFrame_FINAL            │  → Consolidado validado
    │  + Log de Reconciliação     │
    └─────────────────────────────┘
```

**Regras de reconciliação:**

| Situação | Ação |
|---|---|
| A e B concordam (valor idêntico ±R$0,01) | Adotar A (mais preciso em PDF nativo) |
| A e B discordam em valor | Se PDF nativo: adotar A. Se scan: comparar visualmente com o PDF, adotar o correto. Registrar no log. |
| Linha presente em A, ausente em B | Verificar no PDF visual. Se existe: manter. Se artefato: descartar com log. |
| Linha presente em B, ausente em A | Verificar no PDF visual. Se existe: incluir. Se artefato OCR: descartar com log. |
| Ambos falham na mesma região | Marcar como `[EXTRAÇÃO INCERTA]`. Tentar 3ª ferramenta ou solicitar ao usuário. |

**Para PDFs nativos de boa qualidade:** o Caminho B (OCR) serve como validação. Se A e B concordam em ≥99% das linhas, a extração A é confiável.

**Para PDFs escaneados:** o Caminho A geralmente falha; B é primário. Executar B com 2 engines diferentes (ex: Tesseract + LLM multimodal) e reconciliar entre elas.

### 0-PRE.4 Consolidação Multi-Arquivo

Após extrair cada PDF individualmente:

1. **Concatenar DataFrames na ordem cronológica** (conforme timeline §0-PRE.2).
2. **Deduplicar linhas de sobreposição:**
   - Matching key: `(Data, Valor, Descrição_normalizada)`.
   - Se duplicata exata: manter 1, registrar no log.
   - Se quase-duplicata (mesmo valor, data ±1 dia): verificar manualmente.
3. **Validar continuidade entre arquivos:**
   - `Saldo_Final_Arquivo_k ≈ Saldo_Inicial_Arquivo_(k+1)` (tolerância: `TOL_SALDO`).
   - Se gap > `TOL_SALDO`: registrar como **GAP_ENTRE_EXTRATOS** com severidade ALTA.
4. **Produzir DataFrame Consolidado Único** com coluna `Arquivo_Origem` para rastreabilidade.
5. **Gerar log de consolidação:**
   ```
   LOG DE CONSOLIDAÇÃO MULTI-PDF
   ├── Arquivos processados: [N] de [N_total]
   ├── Total de linhas brutas (pré-dedup): [N]
   ├── Duplicatas removidas: [N]
   ├── Linhas incertas [EXTRAÇÃO INCERTA]: [N]
   ├── Total de linhas consolidadas: [N]
   ├── Período consolidado: [data_ini] a [data_fim]
   ├── Gaps entre arquivos: [listar ou "nenhum"]
   ├── Saldo_Inicial (1º arquivo): R$ [X]
   ├── Saldo_Final (último arquivo): R$ [X]
   └── Status: [COMPLETO / PARCIAL — razão]
   ```

### 0-PRE.5 Filtragem para Escopo da Auditoria

Do DataFrame consolidado, **filtre apenas os dados necessários para o escopo**:

1. **Dados incluídos (escopo da auditoria):**
   - Todas as linhas de extrato de empréstimo / crédito pessoal / consignado / cartão / cheque especial / veículo.
   - Todos os lançamentos de juros, multa, mora, IOF, tarifas, seguros, correção, comissão de permanência.
   - Todos os pagamentos (parcelas, amortizações extraordinárias, liquidação).
   - Eventos de renegociação, novação, portabilidade.

2. **Dados excluídos (fora do escopo):**
   - Movimentações de conta corrente não relacionadas ao crédito auditado (salário, pix pessoal, compras).
   - Investimentos, aplicações, resgates não vinculados.
   - Outros produtos bancários não relacionados.

3. **Critério de inclusão/exclusão:**
   - Vincular por contrato/operação (se disponível no extrato).
   - Se contrato não identificável: usar heurísticas de descrição + valor + periodicidade.
   - Classificar casos ambíguos como `[INCLUSÃO_INCERTA]` — incluir com flag, analisar na Etapa 1.

4. **Gerar DataFrame Filtrado** + **DataFrame Excluído** (com justificativa por linha).

> **REGRA DE OURO DA FILTRAGEM:** Na dúvida, INCLUA. É preferível analisar uma linha desnecessária do que perder uma linha relevante. A Etapa 1 (classificação semântica) refinará a seleção.

### 0-PRE.6 Extrato Mensal Multiproduto — Parser Posicional e Validação Quádrupla

> **Contexto:** Frequentemente o caso não traz demonstrativo dedicado da dívida, e sim **extratos mensais de conta corrente multiproduto** (estrutura típica Itaú e similares: capa/resumo com totais impressos → seção Movimentação → totalizador de aplicações → seção Crédito → notas/legenda). Este protocolo, validado em campo, extrai e valida esses extratos sem perda.

**Parser posicional (Caminho A preferencial para PDFs nativos):**

1. Âncoras por **coluna do cabeçalho** (posições de Data / lançamento / valor), não regex livre sobre a linha inteira.
2. Recorte **ESTRITO** da seção Movimentação: somente entre "Saldo anterior" e "Saldo final". O que está fora (resumo da capa, gráficos, notas) NÃO é lançamento.
3. Data `dd/mm` com *carry-forward* (linhas subsequentes do mesmo dia omitem a data); ano herdado do mês do extrato (virada dez→jan: ano − 1).
4. Valores BR (`1.234,56`) com sufixo `-` = débito. Legenda lateral pode contaminar linhas em layout de 2 colunas — remover prefixos de legenda (`D = débito a compensar`, `G = aplicação programada`, ...) antes do parse.

**Validação quádrupla POR MÊS (executar TODAS):**

| # | Teste | Critério de aprovação |
|---|---|---|
| V1 | Fechamento em cadeia C/C | `Saldo_anterior + Σ movimentos = Saldo_final` com resíduo zero (± TOL_SALDO) |
| V2 | Continuidade entre meses | `Saldo_final(k) = Saldo_anterior(k+1)` exato |
| V3 | Totais impressos | `Σ entradas extraídas = total_entradas_capa + aplic_entradas` e `Σ saídas extraídas = −(total_saídas_capa) − aplic_saídas` (linha "na conta corrente (1)" do totalizador de aplicações) |
| V4 | Diff contra consolidado auditado | Zero divergências linha a linha contra gabarito, quando existir |

**Armadilhas catalogadas `[CAMPO — caso real]`:**

1. **Regex de "total" da capa captura o bloco errado.** A capa imprime ≥ 2 linhas `total` (entradas e saídas); meses com tabelas intermediárias imprimem 4+; e o parser de layout pode reordenar a coluna direita. Capturar os totais **aos pares e restritos à página 1**. Diagnóstico: se V1, V2 e V4 fecham a zero e **apenas V3** diverge, o erro está na captura dos totais impressos — não nos dados. Deltas na forma `±(aplic_entradas − aplic_saídas)` denunciam captura trocada do totalizador.
2. **Totalizador de aplicações:** extrair da linha específica `na conta corrente (1)   X   Y-` (entrada, saída).
3. **Reimpressão de blocos** (resumo repetido em páginas seguintes): deduplicar por `(data, descrição, valor)` com log.
4. **Mês inicial sem extrato próprio:** usar o "Saldo anterior" do primeiro PDF como seed, declarado como `[FATO — saldo anterior impresso]`.

### 0-PRE.7 Painel de Crédito ("Crédito | Contratado") como Série Temporal

Extratos multiproduto trazem seção de Crédito com painel por contrato: produto, valor da parcela, saldo pendente, vencimento final, nº do contrato/operação, parcelas pagas (`NNN/NNN`).

1. **Extrair o painel de TODOS os meses** → série temporal por contrato. Na ausência de demonstrativo dedicado, esta série é o backbone do recálculo.
2. **T8-painel:** `Σ saldos do painel = total impresso da seção Crédito` (± TOL_SALDO). Reprovação = erro de extração; reprocessar antes de prosseguir.
3. **Sinais forenses do painel:**
   - Contrato **desaparece** do painel sem trilha de liquidação → evento de transição (novação/renegociação/migração para fatura); investigar composição do saldo sucessor (`HC-25`; validação de transição §2.2).
   - `parcelas_pagas` **congelado** com saldo **subindo** → mora acruando sem decomposição; base para checagem dos limites moratórios (`HC-27`).
   - Painel **zera** e nova geração de contratos surge com saldo maior → cadeia de rolagem; verificar anatocismo na transição (`HC-07`) e recorrência de renegociações em intervalo curto (`HC-26`).
   - Novos contratos surgem **sem lastro no extrato da conta** → a dívida provavelmente transitou por **fatura de cartão** (invisível ao extrato). Solicitar faturas do período (§11.2, item 14) e declarar `[PREMISSA]` enquanto ausentes.
4. **Inferência de taxa via painel:** ver `regulatorio-formulas.md` Etapa 4.4.

---

## § 0. PRÉ-REQUISITO — EXTRAÇÃO DE DADOS DOS DOCUMENTOS

> **REGRA FUNDAMENTAL:** Todos os documentos fornecidos para análise devem estar em formato **PDF**. O sistema deve extrair os dados utilizando a melhor ferramenta disponível de OCR e extração tabular, garantindo máxima fidelidade na conversão de dados visuais para dados estruturados. Erros de extração comprometem toda a auditoria.

### 0.1 Formato Obrigatório de Entrada

- **PDF é o formato obrigatório.** Se o usuário fornecer documentos em outro formato (imagem, foto, scan), converter para PDF antes de prosseguir.
- Se o usuário fornecer XLSX/CSV já estruturados, aceitar diretamente (pular para §0.3 — Validação).
- Se o usuário fornecer OFX (XML bancário), parser nativo (pular para §0.3).

### 0.2 Protocolo de Extração em 3 Estágios

**ESTÁGIO 1 — Classificação do PDF:**

| Tipo | Característica | Ferramenta recomendada |
|---|---|---|
| PDF nativo (digital) | Texto selecionável, gerado por sistema do banco. | Extração direta de texto (pdfplumber, PyMuPDF). Mais confiável — preferir sempre. |
| PDF escaneado (imagem) | Imagem de documento físico, texto NÃO selecionável. | OCR obrigatório (Tesseract, AWS Textract, Google Document AI, Azure Form Recognizer). |
| PDF misto | Algumas páginas nativas, outras escaneadas. | Processar página a página: nativas por extração direta, escaneadas por OCR. |
| PDF protegido | Com senha ou restrição de cópia. | Solicitar versão sem proteção ao usuário ou ao banco. NÃO tente quebrar senha. |

**ESTÁGIO 2 — Extração e Estruturação:**

Para **PDFs nativos** (preferencial):

1. Use extração tabular (pdfplumber, camelot, tabula-py) para identificar tabelas.
2. Preserve a estrutura de colunas e linhas exatamente como no documento original.
3. Se o PDF contém texto corrido (não tabular), identifique padrões de Data/Descrição/Valor por regex.

Para **PDFs escaneados** (OCR obrigatório):

1. Pré-processamento da imagem: rotação automática (deskew), remoção de ruído, binarização, aumento de contraste.
2. Execute OCR com a melhor engine disponível. Prioridade: (a) modelos de visão/document AI do ambiente; (b) Tesseract com configuração para português (lang=por); (c) serviços cloud (AWS Textract, Google Document AI).
3. Para tabelas em scans: use extração tabular pós-OCR ou detecção de layout (Layout Parser, Form Recognizer).
4. **ATENÇÃO ESPECIAL a confusões comuns de OCR em extratos bancários:**
   - `0` (zero) vs. `O` (letra O).
   - `1` (um) vs. `l` (L minúsculo) vs. `I` (I maiúsculo).
   - `,` (vírgula — separador decimal BR) vs. `.` (ponto — separador de milhar BR).
   - `R$` reconhecido como `RS`, `R5`, `R§`.
   - Valores negativos: `-` (hífen) vs. `–` (en dash) vs. sinais de débito (D/C).
   - Datas: `01/01/2024` confundido com `01/01/2O24` (O em vez de 0).

**ESTÁGIO 3 — Validação Pós-Extração (OBRIGATÓRIO antes de prosseguir):**

Execute TODOS os 6 testes de §6.3. Adicionalmente, para dados extraídos por OCR:

**TESTE 7 — Amostragem visual:** Selecione aleatoriamente 5% das linhas (mínimo 10 linhas). Compare visualmente cada uma com o PDF original. Se > 1 erro detectado na amostra: rejeitar a extração e reprocessar com configuração diferente ou ferramenta alternativa.

**TESTE 8 — Validação de totais impressos:** Muitos extratos bancários imprimem totais no rodapé ou cabeçalho. Compare com os totais calculados a partir dos dados extraídos. Tolerância: `TOL_SALDO`.

**TESTE 9 — Consistência de formato:** Verificar que TODOS os valores numéricos seguem o mesmo formato (vírgula decimal, ponto milhar) e que NÃO há mistura de convenções dentro do mesmo extrato.

> **NOTA SOBRE EXTRAÇÃO MODERNA:** Para extratos complexos, considerar ferramentas de visão computacional (LLM multimodal) como alternativa ao OCR tradicional, especialmente para layouts não-tabulares. Essas ferramentas podem capturar semântica e contexto visual que OCR convencional falha em processar.

Resultados da extração devem ser registrados:

```
LOG DE EXTRAÇÃO
├── Fonte: [nome do arquivo PDF]
├── Tipo: [nativo / escaneado / misto]
├── Nº de páginas: [N]
├── Ferramenta utilizada: [nome e versão]
├── Configuração OCR (se aplicável): [idioma, modo, pré-processamento]
├── Nº de linhas extraídas: [N]
├── Testes T1-T6: [APROVADO / REPROVADO + detalhes]
├── Teste T7 (amostragem visual): [N linhas verificadas, N erros, taxa de erro]
├── Teste T8 (totais impressos): [APROVADO / REPROVADO / NÃO DISPONÍVEL]
├── Teste T9 (consistência formato): [APROVADO / REPROVADO]
├── Score de confiança da extração: [ALTA / MÉDIA / BAIXA]
└── Ação: [prosseguir / reprocessar / solicitar arquivo melhor]
```

Se a extração falhar repetidamente, solicite ao usuário: (a) PDF nativo gerado pelo internet banking (preferível a scan); (b) arquivo CSV/XLSX do banco; (c) OFX.

### 0.3 Contratos e Documentos Acessórios

Contratos, termos de renegociação e demais documentos acessórios (também em PDF) devem ser lidos para extrair:

- Taxa de juros contratada (mensal e/ou anual, nominal ou efetiva).
- Sistema de amortização.
- CET informado.
- Presença ou ausência de cláusula de capitalização.
- Presença ou ausência de seguros e tarifas.
- Tipo de spread (se pós-fixada): multiplicativo ou aditivo.
- Cláusulas de mora (taxa, multa, comissão de permanência).

Para contratos em PDF escaneado: aplicar OCR conforme Estágio 2. Para cláusulas ambíguas: transcrever o texto literal e classificar como `[FATO — texto do contrato]`.

---

## § 6. DADOS ESPERADOS (PDF/EXCEL/CSV/OFX)

### 6.1 Colunas a Identificar (ou equivalentes)

| Campo | Criticidade | Fallback |
|---|---|---|
| Data da Transação | OBRIGATÓRIO | Interrompa e solicite. |
| Histórico/Descrição | OBRIGATÓRIO | Classifique como `[SEM DESCRIÇÃO]`. |
| Valor (Débito/Crédito ou com sinal) | OBRIGATÓRIO | Interrompa e solicite. |
| Saldo Resultante | DESEJÁVEL | Recalcule a partir do saldo inicial; se saldo inicial também ausente, solicite. |
| Identificador do Contrato/Negociação | DESEJÁVEL | Infira por agrupamento semântico-temporal (Etapa 1.3). |
| Data de Vencimento (da parcela) | DESEJÁVEL | Assuma = Data da Transação `[PREMISSA]`. |
| Taxa de Juros (mensal/anual) | DESEJÁVEL | Infira (Etapa 4). |
| CET | DESEJÁVEL | Calcule via TIR/XIRR (Etapa 4.3). |
| Sistema de Amortização | DESEJÁVEL | Infira (Etapa 4.1). |
| Indexador de Correção | DESEJÁVEL | Verifique padrão da modalidade. |
| Tipo de Taxa (pré/pós) | DESEJÁVEL | Infira pela presença de indexador nos lançamentos. |
| Forma de Pagamento | DESEJÁVEL | Infira pela descrição (boleto/pix/consignação/débito automático). |

### 6.2 Formatos de Entrada Comuns

- **CSV/XLSX:** Atenção a encoding (UTF-8 vs. ISO-8859-1), separador decimal (vírgula vs. ponto), e separador de coluna (`;` vs. `,`).
- **PDF bancário:** Extraia via ferramentas de extração de tabelas. Execute contra-verificação (§6.3) imediatamente.
- **OFX:** Parse XML nativo (padrão Open Financial Exchange). Mapeie tags para colunas padronizadas.
- Se nomes de colunas divergirem, crie um **Dicionário de Colunas** mapeando [Nome_Original → Nome_Padronizado].

### 6.3 Contra-Verificação de Extração

Antes de prosseguir, execute:

**TESTE 1 — Verificação de saldo:**
```
Saldo_Inicial + Σ(Encargos_lançados) − Σ(Pagamentos_lançados) ≈ Saldo_Final_Extrato?
```
Tolerância: ± `TOL_SALDO`.

**TESTE 2 — Contagem de linhas:** Nº de linhas extraídas = Nº esperado (contar páginas × linhas/página)?

**TESTE 3 — Período:** Primeira e última datas extraídas são coerentes com o período declarado?

**TESTE 4 — Valores absurdos:**
- a) Parcela isolada > `FATOR_ABSURDO` × parcela típica (EXCETO última parcela ou liquidação antecipada).
- b) Juros negativos em conta devedora.
- c) Saldo devedor negativo persistente (> 2 períodos) sem explicação.

**TESTE 5 — Codificação:** Caracteres especiais corretamente decodificados (R$, acentos, cedilha)?

**TESTE 6 — Completude:** Campos OBRIGATÓRIOS (§6.1) presentes em ≥ 95% das linhas.

Se qualquer teste falhar, sinalize e tente reextração antes de prosseguir.

---

## § 7. PIPELINE OPERACIONAL (ETAPAS 0–7)

### ETAPA 0 — INVENTÁRIO & QUALIDADE DOS DADOS

#### 0.1 Ordenação e Padronização

- Ordene por Data (critério de desempate: ordem original no extrato).
- Padronize: formato de data (DD/MM/AAAA), moeda (R$), separador decimal (vírgula → ponto internamente), sinais (§4.2).
- Trate feriados e fins de semana: se data de movimentação cai em dia não útil, registre o fato mas não ajuste a data.

#### 0.2 Detecção de Anomalias

| Anomalia | Critério de Detecção | Severidade |
|---|---|---|
| Duplicidade | Mesma data + mesmo valor + mesma descrição. | MÉDIA |
| Linha incompleta | Sem valor OU sem data. | ALTA |
| Salto de saldo | \|Saldo_t − Saldo_{t−1} − Movimento_t\| > `TOL_SALDO`. | ALTA |
| Data fora de ordem | Data_t < Data_{t−1} (após ordenação). | MÉDIA |
| Gap temporal | Data_t − Data_{t−1} > `GAP_MAX` em conta com parcelas mensais. | BAIXA |
| Saldo negativo inesperado | Saldo_t < 0 em conta sem cheque especial (por > 2 períodos). | MÉDIA |
| Pagamento sem referência | Crédito sem descrição identificável. | BAIXA |
| Juros sem base | Lançamento de juros sem saldo devedor prévio. | ALTA |
| Valor absurdo | Lançamento > `FATOR_ABSURDO` × parcela típica (EXCETO liquidação/balloon). | ALTA |

#### 0.3 Colunas Auxiliares (criar)

- `Tipo_Transação` (Pagamento, Juros_Remuneratórios, Juros_Moratórios, Multa, IOF, Principal, Renegociação, Estorno, Tarifa, Seguro, Comissão_Permanência, Correção_Monetária, Liquidação_Antecipada, Consignação, Outros).
- `Contrato_Fase` (F0, F1, F2…).
- `Evento_Fase` (ORIGEM, NOV, REN, PORT, LIQ, CONS, INDET).
- `Valor_Amortização`, `Valor_Juros_Teórico`, `Saldo_Recalculado`, `Saldo_Banco`, `Diferença`, `Diferença_Pct`, `Flag_Anomalia`, `Flag_Amort_Neg`, `Classificação_Origem`, `Data_Fato_Gerador`.

#### 0.4 Registros Excluídos

Linhas removidas → tabela separada **Registros_Excluídos** com: [Linha_Original | Data | Descrição | Valor | Motivo_Exclusão].

#### 0.5 Log de Inconsistências

Para cada anomalia: [Data | Linha | Código_Anomalia | Descrição | Severidade | Ação_Tomada].

#### 0.6 Resumo Estatístico (gerar antes de prosseguir)

```
RESUMO ESTATÍSTICO DO EXTRATO
├── Período: [data_primeira] a [data_última] ([N_dias] dias, [N_meses] meses)
├── Nº total de linhas: [N]
├── Nº de fases identificadas: [F]
├── Score de Qualidade dos Dados: [score]/100 — [classificação]
├── PAGAMENTOS:
│   ├── Quantidade: [N_pgto]
│   ├── Total: R$ [soma]
│   ├── Mínimo / Mediana / Máximo: R$ [min] / R$ [med] / R$ [max]
│   └── Frequência modal: [mensal / quinzenal / irregular]
├── ENCARGOS:
│   ├── Juros remuneratórios lançados: R$ [soma] ([N] linhas)
│   ├── Juros moratórios lançados: R$ [soma] ([N] linhas)
│   ├── Multas lançadas: R$ [soma] ([N] linhas)
│   ├── IOF lançado: R$ [soma] ([N] linhas)
│   ├── Tarifas lançadas: R$ [soma] ([N] linhas)
│   ├── Seguros lançados: R$ [soma] ([N] linhas)
│   └── Total de encargos: R$ [soma]
├── SALDO:
│   ├── Saldo inicial (banco): R$ [valor]
│   ├── Saldo final (banco): R$ [valor]
│   ├── Variação: R$ [delta] ([pct]%)
│   └── Saldo máximo atingido: R$ [max] em [data]
├── MÉTRICAS DERIVADAS:
│   ├── Ratio pagamentos/encargos: [x:1]
│   ├── % dos pagamentos que amortizaram principal: [pct]% [ESTIMATIVA]
│   └── Taxa implícita média (se inferível): [x,xx]% a.m.
└── ANOMALIAS: [N_alta] ALTA, [N_media] MÉDIA, [N_baixa] BAIXA
```

---

### ETAPA 1 — CLASSIFICAÇÃO SEMÂNTICA DAS LINHAS

#### 1.1 Regras de Classificação (palavras-chave + regex)

| Tipo | Palavras-chave / Regex | Sinal Esperado |
|---|---|---|
| Pagamento | pgto, pagamento, liquidação, quitação, amortização, boleto, pix, ted, débito automático, desconto folha, consignação, `/\bpag(to\|amento)?\b/i` | Crédito (−saldo) |
| Juros Remuneratórios | juros remun, encargos, rentab, remuneração, jrs rem, `/\bjuros?\s*remun/i` | Débito (+saldo) |
| Juros Moratórios | juros mora, jrs mora, encargos mora, `/\bjuros?\s*mora/i` | Débito (+saldo) |
| Multa Moratória | multa, penalidade, `/\bmulta\b/i` | Débito (+saldo) |
| Mora (composto) | mora, atraso, inadimpl — usar somente quando não decomponível | Débito (+saldo) |
| IOF | iof, imposto operação, `/\biof\b/i` | Débito (+saldo) |
| Tarifa | tarifa, tar, taxa adm, cadastro, manutenção, avaliação | Débito (+saldo) |
| Seguro | seguro, proteção, cobertura, prestamista, MIP, DFI | Débito (+saldo) |
| Comissão de Permanência | comissão, permanência, com.perm, `/\bcom\.?\s*perm/i` | Débito (+saldo) |
| Correção Monetária | correção, atualização, igpm, ipca, inpc, tr, `/\bcorr\.?\s*monet/i` | Débito (+saldo) |
| Renegociação | renegociação, acordo, novação, consolidação, saldo anterior, novo saldo, refinanciamento, reparcelamento, composição | Varia |
| Estorno | estorno, devolução, cancelamento, reversão, crédito ref. | Crédito (−saldo) |
| Principal/Saldo | saldo devedor, principal, capital, liberação, desembolso | Varia |
| Liquidação Antecipada | liquidação antecipada, quitação antecipada, antecipação, prepagamento | Crédito (−saldo) |

#### 1.2 Critérios de Desambiguação (hierarquia)

1. Se múltiplas palavras-chave: priorize a mais específica.
2. Se ambiguidade persistir: use o sinal do valor.
3. Se "mora" genérico e não decomponível: classifique como `[Mora_Composto]` e tente alocar proporcionalmente.
4. Se ainda ambíguo: classifique como `[Outros — revisão necessária]`.
5. Liste TODAS as regras usadas para auditoria do próprio método.

#### 1.3 Agrupamento por Contrato

- Use identificador quando disponível.
- Se ausente: agrupe por similaridade textual + proximidade temporal + padrão de valores.

#### 1.4 Tratamento de Estornos

- Estornos DEVEM ser vinculados à transação original.
- No cálculo do saldo, estornos anulam o lançamento original — NÃO geram duplicidade.
- Se estorno parcial: registre valor remanescente.

---

### ETAPA 2 — MAPEAMENTO DAS FASES (NEGOCIAÇÕES/RENEGOCIAÇÕES)

#### 2.1 Identificação de Eventos de Transição

| Código | Evento | Característica |
|---|---|---|
| `ORIGEM` | Contratação original | Primeiro desembolso / liberação |
| `NOV` | Novação | Novo contrato; saldo anterior extinto (Arts. 360–367 CC) |
| `REN` | Renegociação | Aditivo; mesma obrigação, condições alteradas |
| `PORT` | Portabilidade | Transferência entre instituições (Res. CMN 5.057/2022, que revogou Res. 4.292/2013) |
| `LIQ` | Liquidação | Quitação total (antecipada ou no vencimento) |
| `CONS` | Consolidação | Unificação de múltiplas dívidas em uma |
| `INDET` | Indeterminado | Insuficiência de informação — executar AMBOS os cenários (novação e renegociação) |

#### 2.2 Ficha de Cada Fase

```text
FASE: [código — F0, F1, F2, ...]
├── Data de início: [DD/MM/AAAA]
├── Data de término: [DD/MM/AAAA ou "em aberto"]
├── Tipo de evento: [ORIGEM | NOV | REN | PORT | CONS | INDET]
├── Evento gatilho: [descrição literal da linha no extrato]
├── Data de desembolso/liberação (se diferente de data de contrato): [DD/MM/AAAA]
├── Saldo inicial (banco): R$ [valor]
├── Saldo inicial (recalculado): R$ [valor]
├── Tipo de taxa: [PRÉ-FIXADA | PÓS-FIXADA (indexador + spread)]
├── Tipo de taxa (nominal vs efetiva): [NOMINAL PROPORCIONAL | EFETIVA EQUIVALENTE | NÃO INFORMADO]
├── Taxa nominal informada: [x,xx%] a.[m/a] | [NÃO INFORMADO → ver Etapa 4]
├── Spread (se pós-fixada): [y,yy%] a.[m/a] sobre [CDI/Selic/IPCA/TR]
├── Forma de aplicação do spread: [MULTIPLICATIVO | ADITIVO | NÃO INFORMADO]
├── Taxa efetiva equivalente mensal: [z,zzzz%] a.m.
├── Taxa efetiva equivalente anual: [w,zzzz%] a.a.
├── Forma de capitalização: [SIMPLES | COMPOSTA | NÃO INFORMADO]
├── Indexador de correção: [IGPM | IPCA | INPC | TR | Nenhum | NÃO INFORMADO]
├── CET informado: [%] a.a. | [NÃO INFORMADO → calcular via TIR/XIRR]
├── Prazo total: [n] meses | [NÃO INFORMADO → inferir]
├── Carência: [k] meses | Nenhuma
├── Parcela nominal: R$ [valor] | [NÃO INFORMADO → calcular]
├── Sistema de amortização: [Price | SAC | SAM | Americano | Bullet | NÃO INFORMADO → inferir]
├── Forma de pagamento: [boleto | débito automático | consignação | pix | outro]
├── Margem consignável: [limite vigente na data da contratação — 35%/40%/45% INSS/40% janela MP 1.355/2026/CLT 40% (35+5)] (`pericia.margem_vigente`; série §2.1 de regulatorio-formulas.md)
├── Nº parcelas pagas nesta fase: [x] de [n]
├── Total pago nesta fase: R$ [valor]
├── VALIDAÇÃO DE TRANSIÇÃO F(n−1) → F(n):
│   ├── Saldo final recalculado de F(n−1): R$ [valor]
│   ├── Parcelas em atraso ao final de F(n−1): [x] parcelas, R$ [valor total]
│   ├── Encargos moratórios acumulados em F(n−1): R$ [valor]
│   ├── Saldo inicial declarado em F(n): R$ [valor]
│   ├── Gap de transição: R$ [Saldo_inicial_F(n) − Saldo_final_recalc_F(n−1)]
│   ├── Gap tolerável? [SIM se |gap| < TOL_SALDO | NÃO]
│   ├── Composição declarada do novo saldo (se disponível):
│   │   ├── Principal remanescente: R$ [...]
│   │   ├── Juros incorporados: R$ [...]
│   │   ├── Multa/Mora incorporados: R$ [...]
│   │   ├── IOF adicionado: R$ [...]
│   │   ├── Tarifas/Seguros: R$ [...]
│   │   └── Total declarado: R$ [...]
│   ├── Análise de anatocismo na transição: [juros incorporados ao novo principal SIM/NÃO]
│   └── CONCLUSÃO: [gap justificado | gap injustificado (HC-07) | dados insuficientes]
└── Observações: [...]
```

> **PONTO CRÍTICO — Transição entre fases:** Divergências no gap de transição são frequentemente o maior achado da auditoria.

#### 2.3 Tratamento de Carência

- Durante período de carência: somente juros incidem (sem amortização do principal).
- Se o banco cobrar amortização durante carência: `HC-11`.
- Se o banco capitalizar juros durante carência sem previsão contratual: `HC-14`.
- **Carência em novação:** Verifique se juros da carência são calculados sobre o saldo CORRETO da nova obrigação.

---

#### 2.4 Triagem de produtos e eventos especiais

Executar **em toda fase**, antes de passar à Etapa 3. Os testes citados estão em `scripts/pericia.py`. Cada item abaixo é um gatilho: se a
resposta for "sim" ou "não sei", registre o HC candidato e o documento a solicitar.

| # | Verificar | Se positivo | HC candidato |
|---|---|---|---|
| 2.4.1 | A fase envolve cartão consignado (RMC/RCC)? Há desconto fixo em benefício sem quitação visível? | Rodar teste §5-T2 (dívida perpétua); registrar a data de cada contratação (decadência — Tema 1.414, item I) e se a averbação é posterior a 29/04/2026 (suspensão do TCU). Solicitar faturas, histórico do eConsignado e extrato do Meu INSS | `HC-29` |
| 2.4.2 | Houve antecipação de saque-aniversário do FGTS? | Requerer prova de adesão pelo app FGTS. Ausência de prova → achado | `HC-32` |
| 2.4.3 | Houve IOF em renegociação? | Classificar novação × renegociação. Renegociação interna sem nova liberação e IOF já no teto → achado | `HC-33` |
| 2.4.4 | O crédito foi cedido a FIDC ou terceiro? | Verificar notificação do devedor e taxa aplicada pelo cessionário × contratada | `HC-30` |
| 2.4.5 | Há indício de superendividamento? | Rodar teste §5-T3: renda − todas as parcelas (**consignado incluído** — STF ADPFs 1.005/1.006/1.097) < R$ 600 (Dec. 11.567/2023) ou < piso provado → achado + cenário K | `HC-21`, `HC-37` |
| 2.4.6 | Saldo de cheque especial migrou para empréstimo pessoal? | Verificar manifestação inequívoca do consumidor | `HC-35` |
| 2.4.7 | Há Pix parcelado ou crédito lançado em fatura sem discriminação? | Verificar informação de CET e discriminação do lançamento | `HC-31` |
| 2.4.8 | Há tarifa incorporada ao principal? | Verificar se a tarifa passou a gerar juros | `HC-34` |
| 2.4.9 | Há saldo rotativo/parcelamento de fatura? Qual a data de origem? | Origem ≥ 03/01/2024 → teste §5-T1 com juros + multa + mora (**sem IOF e tarifas**) + cenário L. Origem anterior → teto NÃO APLICÁVEL (não retroage) | `HC-17` |
| 2.4.10 | Há inscrição em SCR/Serasa ou cobrança de dívida antiga? | Verificar notificação prévia e prescrição (5 anos) | `HC-28`, `HC-36` |
| 2.4.11 | A fase tem mora sem taxa pactuada atravessando 30/08/2024? | Segmentar a mora legal nos dois regimes do art. 406 CC (§4.5) | `HC-04`, `HC-27` |

**Regra de registro:** itens sem dados suficientes entram na lista de documentos a solicitar
(§11.2) e **não** podem ser silenciosamente marcados como inaplicáveis — use `SEM DADOS`.

---

### ETAPAS 3–6: Ver `references/regulatorio-formulas.md`

As Etapas 3 (Modelo Matemático), 4 (Inferência), 5 (Checagem de Encargos) e 6 (Comparação) estão detalhadas em `references/regulatorio-formulas.md` junto com o marco regulatório e fórmulas.

### ETAPA 7 — CONSOLIDAÇÃO E RELATÓRIO FINAL: Ver `references/regulatorio-formulas.md` §7 e `references/outputs-cenarios-anexos.md` §8–§12

A Etapa 7 (Consolidação) unifica os achados das etapas anteriores e gera os outputs finais conforme §8–§12.
