# Typography Pairings Reference

25 curated Google Font pairings with usage context, size scales, and CDN import links.

## Table of Contents
1. [SaaS & Dashboard Pairings](#saas--dashboard)
2. [Fintech & Professional](#fintech--professional)
3. [Creative & Bold](#creative--bold)
4. [Editorial & Content](#editorial--content)
5. [E-commerce & Conversion](#e-commerce--conversion)
6. [Type Scale System](#type-scale-system)

---

## SaaS & Dashboard

### 1. Inter + JetBrains Mono
- **Use**: Data-heavy dashboards, developer tools, analytics
- **Display**: Inter 600/700 for headings
- **Body**: Inter 400 for content
- **Mono**: JetBrains Mono for code, data, tables
```html
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
```

### 2. Plus Jakarta Sans + Inter
- **Use**: Modern SaaS, clean dashboards, product interfaces
- **Display**: Plus Jakarta Sans 700/800 — geometric, friendly
- **Body**: Inter 400/500 — neutral, readable
```html
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@500;600;700;800&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

### 3. Outfit + DM Sans
- **Use**: Contemporary SaaS, onboarding flows, marketing pages
- **Display**: Outfit 600/700 — modern geometric
- **Body**: DM Sans 400/500 — clean humanist
```html
<link href="https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

### 4. Sora + Inter
- **Use**: AI/tech products, futuristic dashboards
- **Display**: Sora 600/700 — geometric, tech-forward
- **Body**: Inter 400/500
```html
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

---

## Fintech & Professional

### 5. DM Serif Display + DM Sans
- **Use**: Banking, financial reports, institutional sites
- **Display**: DM Serif Display 400 — classic authority
- **Body**: DM Sans 400/500 — modern complement
```html
<link href="https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

### 6. Fraunces + Inter
- **Use**: Premium fintech, investment platforms
- **Display**: Fraunces 600/700 — distinctive serif with character
- **Body**: Inter 400/500
```html
<link href="https://fonts.googleapis.com/css2?family=Fraunces:wght@600;700;900&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

### 7. Bricolage Grotesque + Source Sans 3
- **Use**: Modern banking, fintech startups
- **Display**: Bricolage Grotesque 600/700 — distinctive, trustworthy
- **Body**: Source Sans 3 400/600 — professional, readable
```html
<link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:wght@500;600;700&family=Source+Sans+3:wght@400;500;600&display=swap" rel="stylesheet">
```

### 8. Manrope + IBM Plex Sans
- **Use**: Enterprise dashboards, B2B platforms
- **Display**: Manrope 600/700 — geometric, professional
- **Body**: IBM Plex Sans 400/500 — corporate, readable
```html
<link href="https://fonts.googleapis.com/css2?family=Manrope:wght@500;600;700&family=IBM+Plex+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

---

## Creative & Bold

### 9. Space Grotesk + Outfit
- **Use**: Creative agencies, tech portfolios, startup landing pages
- **Display**: Space Grotesk 700 — futuristic, bold
- **Body**: Outfit 400/500 — clean, modern
```html
<link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@500;600;700&family=Outfit:wght@400;500;600&display=swap" rel="stylesheet">
```

### 10. Unbounded + DM Sans
- **Use**: Gaming, creative platforms, bold branding
- **Display**: Unbounded 700/900 — experimental, loud
- **Body**: DM Sans 400/500 — grounding contrast
```html
<link href="https://fonts.googleapis.com/css2?family=Unbounded:wght@700;900&family=DM+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

### 11. Cabinet Grotesk + Inter (self-hosted alternative: Satoshi + Inter)
- **Use**: Design studios, modern portfolios
- **Display**: Bold, distinctive geometric
- **Body**: Clean, neutral complement
- **Note**: Cabinet Grotesk via fontshare.com; fallback to Sora on Google Fonts

### 12. Clash Display + General Sans (self-hosted)
- **Use**: Fashion, luxury creative, editorial portfolios
- **Note**: Available via fontshare.com; Google Fonts fallback: Outfit + DM Sans

---

## Editorial & Content

### 13. Playfair Display + Source Serif 4
- **Use**: Magazines, blogs, long-form content, literary sites
- **Display**: Playfair Display 700 — elegant, editorial
- **Body**: Source Serif 4 400/600 — readable serif
```html
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@700;900&family=Source+Serif+4:wght@400;500;600&display=swap" rel="stylesheet">
```

### 14. Libre Baskerville + Source Sans 3
- **Use**: Academic, professional publishing, documentation
- **Display**: Libre Baskerville 700 — traditional authority
- **Body**: Source Sans 3 400/600 — clean sans contrast
```html
<link href="https://fonts.googleapis.com/css2?family=Libre+Baskerville:wght@400;700&family=Source+Sans+3:wght@400;500;600&display=swap" rel="stylesheet">
```

### 15. Newsreader + Inter
- **Use**: News sites, editorial platforms, journalism
- **Display**: Newsreader 600/700 — purpose-built for news
- **Body**: Inter 400/500 — modern, scannable
```html
<link href="https://fonts.googleapis.com/css2?family=Newsreader:wght@400;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

---

## E-commerce & Conversion

### 16. Poppins + Open Sans
- **Use**: General e-commerce, product pages, marketplaces
- **Display**: Poppins 600/700 — friendly, approachable
- **Body**: Open Sans 400/600 — universally readable
```html
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500;600;700&family=Open+Sans:wght@400;500;600&display=swap" rel="stylesheet">
```

### 17. Montserrat + Lato
- **Use**: Fashion, lifestyle, visual-heavy commerce
- **Display**: Montserrat 700/800 — geometric, stylish
- **Body**: Lato 400/700 — warm, readable
```html
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@600;700;800&family=Lato:wght@400;700&display=swap" rel="stylesheet">
```

### 18. Lexend + Inter
- **Use**: Accessibility-focused commerce, readable product descriptions
- **Display**: Lexend 600/700 — designed for readability
- **Body**: Inter 400/500
```html
<link href="https://fonts.googleapis.com/css2?family=Lexend:wght@500;600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
```

---

## Type Scale System

Use this modular scale for consistent typography hierarchy:

### Desktop Scale (base: 16px, ratio: 1.25 — Major Third)
```css
--text-xs:   0.75rem;   /* 12px — captions, labels */
--text-sm:   0.875rem;  /* 14px — secondary text, metadata */
--text-base: 1rem;      /* 16px — body text */
--text-lg:   1.125rem;  /* 18px — lead paragraphs */
--text-xl:   1.25rem;   /* 20px — h5, card titles */
--text-2xl:  1.5rem;    /* 24px — h4, section headers */
--text-3xl:  1.875rem;  /* 30px — h3 */
--text-4xl:  2.25rem;   /* 36px — h2, page titles */
--text-5xl:  3rem;      /* 48px — h1, hero headings */
--text-6xl:  3.75rem;   /* 60px — display, hero splash */
```

### Fluid Typography with clamp()
```css
h1 { font-size: clamp(2rem, 1.5rem + 2.5vw, 3.75rem); }
h2 { font-size: clamp(1.5rem, 1.2rem + 1.5vw, 2.25rem); }
h3 { font-size: clamp(1.25rem, 1.1rem + 0.75vw, 1.875rem); }
h4 { font-size: clamp(1.125rem, 1rem + 0.5vw, 1.5rem); }
body { font-size: clamp(0.9rem, 0.85rem + 0.25vw, 1rem); }
```

### Line Heights
```
Headings (display): 1.1 – 1.2
Headings (section): 1.2 – 1.3
Body text: 1.5 – 1.75
UI labels: 1.2 – 1.4
Code: 1.5 – 1.7
```

### Letter Spacing
```
Large headings (>36px): -0.02em to -0.04em (tighten)
Section headings: -0.01em to -0.02em
Body text: 0 (normal)
All-caps labels: 0.05em to 0.1em (loosen)
Monospace/code: 0 (normal)
```
