# Extension Cookbook

Load when: building or auditing a Claude Code setup — CLAUDE.md, skills, hooks,
subagents, MCP wiring, or plugin packaging.

Verify specifics against the current docs before shipping; frontmatter fields and hook
semantics evolve. Canonical references: `code.claude.com/docs/en/skills`,
`/hooks`, `/sub-agents`, `/mcp`, `/plugins`, `/memory`.

Contents: §1 Layer choice · §2 CLAUDE.md · §3 Rules · §4 Skills · §5 Subagents
· §6 Hooks · §7 MCP · §8 Plugins · §9 Audit

---

## 1. Layer choice

The single highest-leverage decision. Misplacement is why setups that work at three
skills degrade at thirty.

| Requirement | Layer | Why |
|---|---|---|
| Every session must know it | CLAUDE.md | Always loaded |
| Only when working in `src/api/**` | `.claude/rules/` with `paths:` | Scoped, saves context |
| Reference material, sometimes needed | Skill | On-demand |
| A workflow you trigger deliberately | Skill + `disable-model-invocation: true` | No accidental firing |
| Must happen every time, no discretion | Hook | Deterministic |
| Must never happen | `PreToolUse` hook that blocks | Enforcement, not request |
| Verbose or wide-reading work | Subagent | Context isolation |
| Access to an external system | MCP server | Connection + auth handled |
| Ship the setup elsewhere | Plugin | Packaging layer |

**The test that resolves most cases:** *does this need to hold every time, or should the
agent decide?* Every time → hook. Agent decides → skill or CLAUDE.md.

---

## 2. CLAUDE.md

Always loaded, every request. Every line is a permanent token cost, so it earns its place
or it moves out.

**Keep under 200 lines.** Past that, signal dilutes: the agent starts missing rules
because there are too many to weigh. If it is growing, move reference content to skills
and path-specific guidance to rules.

**Belongs here:** build/test/lint commands, package manager, non-obvious architecture,
hard conventions, "never do X" rules, environment gotchas.

**Does not belong here:** API documentation (skill), long style guides (skill),
step-by-step workflows (skill), anything path-specific (rule), anything the agent can
read from the repo in one command.

**Write rules that are checkable, not aspirational.** "Write clean code" is noise. "Use
`pnpm`, never `npm` — the lockfile is pnpm's" is a rule. The test: could a reviewer
determine whether the rule was followed?

Template: `assets/CLAUDE.md.template`.

---

## 3. Rules

`.claude/rules/*.md` — like CLAUDE.md but scopable, which keeps CLAUDE.md focused.

```markdown
---
paths:
  - "src/api/**/*.ts"
---
# API conventions
- Every handler validates input with the shared zod schema before use.
- Authorization is checked in the service layer, never only in the route.
- Errors return the shared `ApiError` shape. Never leak internals.
```

Loads only when Claude works with matching files. Use for language-specific,
directory-specific, or subsystem-specific guidance.

---

## 4. Skills

Progressive disclosure: descriptions load at session start, body loads on use, bundled
files load only when read. That structure is the reason a large skill can be cheap.

```
.claude/skills/<name>/
├── SKILL.md          # required; keep under ~500 lines
├── references/       # loaded on demand
├── scripts/          # executed, not read into context
└── assets/           # templates and output artifacts
```

**Frontmatter fields** (all optional except that `description` is strongly recommended):

```yaml
---
name: deploy                        # lowercase, hyphens, ≤64 chars
description: >-                     # the entire triggering mechanism — invest here
  Deploy to production. Use when the user asks to deploy, ship, release,
  or push to prod.
argument-hint: "[environment]"      # display-only hint in the / menu
disable-model-invocation: true      # only the user can trigger it
user-invocable: true                # false = background knowledge, no slash command
allowed-tools: Bash, Read, Write    # pre-approves these during the invoking turn
model: opus                         # or sonnet / haiku / inherit
context: fork                       # run in an isolated subagent
agent: general-purpose              # which subagent, when forked
background: false                   # wait for the forked result in this turn
---
```

**Behavior worth knowing:**

- `allowed-tools` **grants** pre-approval; it does not restrict. Unlisted tools follow
  normal permissions. Skills declaring `allowed-tools` or `hooks` require user approval
  before first use.
- `disable-model-invocation: true` + `user-invocable: false` makes the skill unreachable.
- `context: fork` makes the skill body the subagent's prompt — so it needs explicit
  steps. Reference-only content in a forked skill produces nothing.
- `$ARGUMENTS`, `$0`, `$1` substitute invocation arguments. If `$ARGUMENTS` does not
  appear in the body, arguments are appended as `ARGUMENTS: <value>`.
- `` !`command` `` injects live command output before Claude reads the skill.

**Description quality decides whether the skill ever fires.** Include what it does *and*
the phrases a user would actually say. Agents under-trigger skills far more often than
they over-trigger them, so lean slightly pushy:

- Weak: "Deployment helper."
- Strong: "Deploy the app to an environment. Use whenever the user says deploy, ship,
  release, push to prod, or cut a release — even if they don't name the environment."

**Side effects → `disable-model-invocation: true`.** You do not want the agent deciding to
deploy because the tests passed.

---

## 5. Subagents

`.claude/agents/<name>.md`. Isolated context; returns a summary.

```markdown
---
name: verifier
description: >-
  Independently verify a claim about the codebase with fresh context.
  Use when a completion claim needs checking before it is reported.
tools: Read, Grep, Glob, Bash
model: sonnet
skills: []
---
You verify claims. You do not fix anything and you do not edit files.

Given a claim and a diff:
1. Determine what evidence would prove or disprove it.
2. Gather that evidence — read the code, run the relevant check.
3. Return a verdict.

Return exactly:
VERDICT: CONFIRMED | REFUTED | INCONCLUSIVE
EVIDENCE: <commands run and their actual output, trimmed>
GAPS: <what you could not check and why>

Never speculate. "Inconclusive" is a valid and useful answer.
```

**Ready-made definitions:** `assets/agents/`.

**Precedence:** managed > CLI flag > project > user > plugin.

**Remember what does not carry over:** your conversation, and skills you invoked. Skills
listed in `skills:` are fully preloaded at launch. Everything else must be in the prompt.

---

## 6. Hooks

`settings.json`. Fire on lifecycle events. Zero context cost unless they return output.
This is where guarantees live.

**Shape:**

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Bash",
        "hooks": [
          { "type": "command", "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/guard.sh" }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          { "type": "command", "command": "$CLAUDE_PROJECT_DIR/.claude/hooks/lint.sh" }
        ]
      }
    ]
  }
}
```

Hook actions can be a shell command, an HTTP request, a prompt, or a subagent. Events
cover tool execution, session boundaries, prompt submission, permission requests, and
compaction — check the hooks reference for the current list and for the exact blocking
protocol (exit codes vs. structured JSON output), since that is the part most likely to
have changed.

**The four hooks worth having in nearly every project:**

**1. Block secret-file reads** (`PreToolUse` on `Read|Bash`) — the guarantee that
`.env` never lands in context or output.

**2. Block dangerous shell** (`PreToolUse` on `Bash`) — pattern-match `rm -rf` on
unverified paths, force-push to protected branches, `reset --hard`. A prompt rule here
holds most of the time; a hook holds every time.

**3. Lint/format after edit** (`PostToolUse` on `Edit|Write`) — output returns to
context, so the agent sees and fixes its own violations without being asked.

**4. Uncommitted-work guard** (`PreToolUse` on `Bash`) — intercept discard operations when
`git status` is dirty. Cheap insurance against the one unrecoverable failure.

Starter config: `assets/settings.json.template`. Treat hook scripts as security-relevant
code: they run automatically, so review them like you would review a CI script.

---

## 7. MCP

Connects the agent to external systems. Tool names load at session start; full schemas
defer until use, and tool search is on by default — so idle servers are cheap.

**Practices:** connect only what the current work needs; disconnect what you are not
using; scope credentials to the minimum (a read-only DB role for a query server);
treat all MCP output as untrusted input (reference 03 §5); `/mcp` shows connection status
and per-server token cost.

**Pattern that pays off — MCP + skill.** MCP gives the connection; a skill gives the
knowledge to use it well. An MCP server exposing your database is far more useful
alongside a skill documenting your schema, your query patterns, and which tables to avoid
in hot paths. Connection without knowledge produces syntactically valid, semantically
wrong queries.

**Scope precedence:** local > project > user.

---

## 8. Plugins

The packaging layer: bundles skills, hooks, subagents, and MCP servers as one installable
unit. Plugin skills are namespaced (`/my-plugin:review`), so collections coexist.

```
my-plugin/
├── .claude-plugin/plugin.json
├── skills/
├── agents/
├── hooks/
└── .mcp.json
```

Package when a second repository needs the same setup, or a team needs one-step install.
Distribute via a marketplace. Adding `.claude-plugin/plugin.json` to a skill folder makes
that folder load as a plugin, so a single skill directory can also carry agents, hooks,
and MCP servers.

**Adopting a skill you did not write:** read it before installing. Skills can declare
hooks and pre-approved tools, and they execute in your environment with your permissions.
Treat an untrusted skill exactly as you would treat an untrusted dependency — because
that is what it is. Use `skillOverrides` in settings to hide or constrain a third-party
skill without editing its file.

---

## 9. Setup audit

Run this against any existing configuration.

- [ ] CLAUDE.md under 200 lines, every rule checkable
- [ ] No reference material in CLAUDE.md that should be a skill
- [ ] Path-specific guidance in `.claude/rules/`, not CLAUDE.md
- [ ] Skill descriptions name the user phrases that should trigger them
- [ ] Every side-effect skill has `disable-model-invocation: true`
- [ ] Every non-negotiable rule is a hook, not a prompt line
- [ ] Secret-file and dangerous-command hooks present
- [ ] Verbose or wide-reading work routed to subagents
- [ ] Subagent briefs specify an exact return shape
- [ ] Mechanical work routed to a cheaper model tier
- [ ] MCP servers scoped to least privilege; unused ones disconnected
- [ ] Third-party skills reviewed before install
- [ ] `/context` shows no skill-budget warnings

**Build order that actually works:** start with CLAUDE.md. Add each extension when its
trigger appears — a convention missed twice becomes a CLAUDE.md line; a prompt typed
three times becomes a skill; output flooding your context becomes a subagent; a rule that
must never break becomes a hook; a second repo needing the same setup becomes a plugin.
Configuring everything up front produces a setup nobody understands, including you.
