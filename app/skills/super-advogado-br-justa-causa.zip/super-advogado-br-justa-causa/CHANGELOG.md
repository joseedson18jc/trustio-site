# Changelog

## 1.0.0. 2026-07-31

- Lançamento inicial.
- Auditoria de justa causa em 16 gates.
- Matriz completa do art. 482 da CLT.
- Pesquisa jurisprudencial com hierarquia e controle contra alucinação.
- Jurisprudência semente do TST, incluindo a desafetação do antigo Tema 196 em 10/04/2026.
- Módulos de prova digital, atestado médico, EOR/tomadora, estabilidade, discriminação e LGPD.
- Scripts de hash, cronologia, validação de caso e validação estrutural da skill.
- Evals positivos, negativos e adversariais.
