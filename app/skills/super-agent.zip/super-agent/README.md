# Claude Code Super Agent — v2.1

Engineering operating doctrine for Claude Code, packaged as an installable skill with
enforced safety guards.

**v1 was an encyclopedia. v2 is an operating system. v2.1 makes it actually installable.**

---

## Install

### 1 — Claude Code (the real target)

```bash
bash install.sh              # project scope → ./.claude/
bash install.sh --user       # user scope    → ~/.claude/
bash doctor.sh               # verify it worked
```

Installs the skill, three subagents, four hook guards, and merges the hook wiring into
`settings.json`. Idempotent, backs up anything it overwrites, and reversible with
`bash install.sh --uninstall`.

Other flags: `--dry-run` (change nothing), `--skill-only` (no hooks or agents).

### 2 — claude.ai / Claude app

Upload `super-agent.zip` (as downloaded, without unzipping) in the Skills area of the settings. The doctrine and
references apply in chat; `hooks/` and `install.sh` are Claude Code artifacts and are
simply inert there.

---

## What v2.1 added

v2 shipped doctrine that *described* enforcement without providing it. The hook scripts
existed only as comment-arrays inside a JSON template — unrunnable, and a violation of
the skill's own Law 1 (evidence over assertion).

| | v2 | v2.1 |
|---|---|---|
| Hook scripts | Pseudo-code in JSON comments | 4 real executables in `hooks/`, syntax-checked |
| Guard coverage | Described | **31 test cases executed, 31 passing** |
| Installation | Manual `cp` instructions | `install.sh` — idempotent, backup, uninstall, dry-run |
| Verification | None | `doctor.sh` — 15 structural checks + 4 live behavioral probes |
| Packaging | Directory only | `.claude-plugin/plugin.json` + `.skill` bundle |
| settings.json | Hand-merge | Automatic merge that preserves existing user config |

### The guards, and what they were tested against

| Guard | Event | Blocks | Verified |
|---|---|---|---|
| `block-secrets.sh` | `PreToolUse` on Read/Bash/Grep/Edit | `.env*`, `secrets.*`, `*.pem`, `id_rsa`, service-account JSON, `.npmrc`, `.pypirc` | 9 cases — blocks reads, allows `test -n "$VAR"` presence checks |
| `block-dangerous.sh` | `PreToolUse` on Bash | `rm -rf` on `/`/`~`/variables, force-push to protected branches, `reset --hard`, `clean -f`, `DROP`, `TRUNCATE`, `DELETE`/`UPDATE` without `WHERE`, `terraform destroy`, `kubectl delete` on durable resources | 16 cases — including 5 false-positive checks (`DELETE ... WHERE`, `terraform plan`, `npm test` all pass through) |
| `guard-uncommitted.sh` | `PreToolUse` on Bash | discard operations while `git status` is dirty | 6 cases in a real repo, clean and dirty |
| `lint-changed.sh` | `PostToolUse` on Edit/Write | nothing — non-blocking; feeds lint/type output back so the agent self-corrects | runs clean, exits 0 |

**Tuning note:** `block-dangerous.sh` blocks *all* `rm -r`, which includes
`rm -rf node_modules`. That is deliberate — the conservative default — but it is real
friction. To relax it, comment out the second `check()` call in the script; the
unbounded-scope check above it (`/`, `~`, `$VAR`) keeps firing.

---

## Why v2 replaced v1

v1 (Feb 2026) was one monolithic prompt of ~200 sections, mostly a capability
inventory: *"I am proficient with PyMuPDF, pdfplumber, reportlab, camelot…"*

Two problems. **It told the model things it already knew** — listing libraries changes
no behavior; the model knows `pdfplumber` exists. What it does *not* reliably do under
pressure is refuse to say "this should work" without running it. **And it was
architecturally wrong for Claude Code** — a monolith as always-on context is a permanent
token tax, when skills exist precisely so doctrine can load on demand.

v2 keeps the domain depth but subordinates it to what changes behavior:

**Evidence tagging** — every claim is VERIFIED / ASSUMED / UNVERIFIABLE, with "should
work" and "I've tested" banned absent a cited command. Phantom verification is the
failure that lets every other failure ship.

**15 failure modes** with self-detection tests — test theater, scope creep, hallucinated
API surface, loop thrash, sycophantic drift, completion theater. All of them feel like
competence from the inside, which is why each gets a detection test rather than a warning.

**Context economics** — numeric thresholds instead of judgment calls, a subagent briefing
template, the verifier pattern, compaction-survival checkpointing. Context degradation is
gradual and invisible from within.

**Enforcement placement** — *a rule in a prompt is a request; a rule in a hook is a
guarantee.* v1 wrote "NEVER do X" in prose and hoped. v2.1 ships the hooks.

---

## Contents

```
claude-code-super-agent/
├── SKILL.md                          # Five Laws, task intake, execution loop,
│                                     # verification standard, Definition of Done,
│                                     # context triggers, safety invariants, reporting
├── install.sh                        # idempotent installer (+ --uninstall, --dry-run)
├── doctor.sh                         # 15 structural checks + 4 live hook probes
├── references/
│   ├── 01-execution-protocol.md      # orient→plan→execute→verify; diagnostic loop;
│   │                                 # refactor, migration, review, incident protocols
│   ├── 02-context-and-delegation.md  # budget thresholds, subagent briefing, agent
│   │                                 # teams, model routing, compaction survival
│   ├── 03-safety-and-permissions.md  # enforcement placement, secrets, destructive ops,
│   │                                 # prod, prompt injection, dependencies, refusals
│   ├── 04-domain-playbooks.md        # 14 domains: API, data, DevOps, security, testing,
│   │                                 # perf, data eng, ML/LLM, o11y, PDF, mobile, cost,
│   │                                 # a11y, LGPD/GDPR
│   ├── 05-failure-modes.md           # 15 anti-patterns + pre-completion self-check
│   └── 06-extension-cookbook.md      # CLAUDE.md, rules, skills, subagents, hooks, MCP,
│                                     # plugins, setup audit
├── hooks/
│   ├── block-secrets.sh              # secret-file access guard
│   ├── block-dangerous.sh            # destructive-command guard
│   ├── guard-uncommitted.sh          # uncommitted-work guard
│   └── lint-changed.sh               # post-edit lint feedback
└── assets/
    ├── CLAUDE.md.template            # project constitution, <200 lines
    ├── settings.json.template        # hook wiring
    └── agents/
        ├── verifier.md               # independent claim verification
        ├── explorer.md               # codebase mapping without context flood
        └── security-reviewer.md      # ranked findings with exploit paths
```

---

## After installing

1. `bash doctor.sh` — confirm structure and live guard behavior
2. `cp assets/CLAUDE.md.template ./CLAUDE.md` and **fill in the placeholders** —
   `doctor.sh` will flag an unfilled template, because one is worse than none
3. Start Claude Code, run `/context` to confirm the skill is discovered
4. `/super-agent`

The `verifier` subagent earns its keep fastest. The agent that wrote the code is the
worst judge of whether it works, for the same reason authors miss their own typos — a
clean-context verifier given only the diff and the requirement catches what the author
rationalized.

---

## Design notes

**Why references instead of one file.** Progressive disclosure: descriptions load at
session start, the body on invocation, references only when read. A 5,000-line monolith
costs its full weight every request; this costs the body plus what the task needs.

**Why the playbooks are thin on libraries.** Library lists age badly and teach the model
nothing. What costs real time is choosing wrong and finding out late — so the playbooks
carry decision rules and failure modes. The PDF section is the clearest case: the useful
content is not *which* library, it is *"PDF is a rendering format, not a data format —
every extraction is an inference."*

**Why the tone changed.** v1 closed with "Let's build something great." Motivational
framing in a system prompt spends context and biases toward enthusiastic reporting —
the substrate of completion theater (ref 05 §15).

**Adapting it.** Rename the skill if `/super-agent` collides. Prune domains you never
touch — unread lines still cost description weight. Extend
`references/04-domain-playbooks.md` with your stack's specifics; it is built for that.

---

*v2.1 — July 2026. Grounded against current Claude Code extension documentation
(`code.claude.com/docs/en/features-overview`, `/skills`, `/hooks`, `/sub-agents`,
`/mcp`, `/plugins`). Hook blocking semantics (exit 2) and skill frontmatter fields
evolve — re-verify against the docs before depending on them in production.*
