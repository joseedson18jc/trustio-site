---
name: markitdown
description: |
  Convert files and documents to clean Markdown for LLMs using Microsoft MarkItDown — PDF, Word, PowerPoint, Excel, images (OCR), audio (transcription), HTML, CSV/JSON/XML, EPUB, ZIP, and YouTube URLs. Use after downloading a file from the web, or to turn any document into LLM-ready text.
  TRIGGERS: markitdown, convert to markdown, pdf to markdown, docx to markdown, pptx to markdown, xlsx to text, extract text from document, ocr image to text, file to markdown, document to markdown
---

# MarkItDown — files/documents to LLM-ready Markdown

MarkItDown turns documents into structure-preserving Markdown (headings, lists, tables, links). Ideal companion to a web scraper: scrape or download a file, then convert it to text an LLM can read.

## When to use this vs. alternatives
- **Use markitdown** when you already have a *file* (PDF/DOCX/PPTX/XLSX/image/audio) or a downloaded document.
- Use `crawl4ai` / `firecrawl` to fetch *web pages* into Markdown.
- Chain them: `firecrawl scrape ... -o file` or `curl` a PDF, then `markitdown file.pdf`.

## Setup (once)
```bash
pip install 'markitdown[all]'      # all optional format handlers
# or a subset:  pip install 'markitdown[pdf, docx, pptx]'
```

## Fast path — CLI
```bash
markitdown report.pdf > report.md
markitdown deck.pptx -o deck.md
markitdown data.xlsx                 # tables -> Markdown to stdout
markitdown --list-plugins
```

## Runnable helper (recommended)
`scripts/to_markdown.py` converts one file or a whole folder, with optional LLM image captions.
```bash
python scripts/to_markdown.py report.pdf                 # print Markdown
python scripts/to_markdown.py report.pdf -o report.md     # save
python scripts/to_markdown.py ./docs --out-dir ./md_out   # batch a folder
```

## Python API
```python
from markitdown import MarkItDown
md = MarkItDown()                       # or MarkItDown(enable_plugins=True)
result = md.convert("document.pdf")
print(result.text_content)              # Markdown string
```

### Optional: LLM image descriptions
```python
from markitdown import MarkItDown
from openai import OpenAI
md = MarkItDown(llm_client=OpenAI(), llm_model="gpt-4o")
print(md.convert("scanned.pdf").text_content)   # images get captions
```

## Supported inputs
PDF · Word · PowerPoint · Excel · Images (EXIF + OCR) · Audio (EXIF + transcription) · HTML · CSV/JSON/XML · EPUB · ZIP (iterates contents) · YouTube URLs.

## Good practices
- Security: MarkItDown reads with the current process's privileges. In untrusted contexts prefer the narrowest call (`convert_stream`, `convert_local`) and sanitize inputs.
- Install only the format extras you need to keep the footprint small.
- For scanned/handwritten docs, add an LLM client for OCR-quality captions.
