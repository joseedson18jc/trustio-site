---
name: scrapy
description: |
  Build fast, structured, rule-based web crawlers with Scrapy — spiders, selectors (CSS/XPath), item pipelines, pagination, concurrency, and export to JSON/CSV. Use for large or repeatable crawls where you extract specific fields across many pages.
  TRIGGERS: scrapy, spider, crawl many pages, xpath selector, css selector, scrape a list of items, pagination crawl, export json csv from site, structured web scraping, runspider
---

# Scrapy — structured, large-scale crawling

Scrapy is a batteries-included crawling framework. Reach for it when you need to extract *specific fields* (price, title, rating…) across *many* pages, follow pagination, and export clean JSON/CSV — not just dump one page to Markdown.

## When to use this vs. alternatives
- **Use scrapy** for repeatable, high-volume, field-level extraction with your own rules.
- Use `crawl4ai` / `firecrawl` for quick page-to-Markdown or JS-render + one-off scrapes.
- Use `markitdown` for converting downloaded files.

## Setup (once)
```bash
pip install scrapy
```

## Fast path — single-file spider
`scripts/quote_spider.py` is a complete, runnable example (quotes.toscrape.com) with pagination + JSON export.
```bash
python -m scrapy runspider scripts/quote_spider.py -o quotes.jsonl
# or, if scrapy is on PATH:
scrapy runspider scripts/quote_spider.py -o quotes.jsonl
```

## Adapt the spider (the 20% you edit)
```python
import scrapy

class MySpider(scrapy.Spider):
    name = "my"
    start_urls = ["https://example.com/list"]

    def parse(self, response):
        for row in response.css("div.item"):           # each record
            yield {
                "title": row.css("h2::text").get(),
                "price": row.css(".price::text").get(),
                "url": row.css("a::attr(href)").get(),
            }
        next_page = response.css("a.next::attr(href)").get()
        if next_page:
            yield response.follow(next_page, self.parse)  # pagination
```

## Interactive selector testing
```bash
scrapy shell "https://example.com/list"     # then: response.css("h2::text").getall()
scrapy view "https://example.com/list"       # open the page Scrapy actually sees
```

## Full project (when it grows)
```bash
scrapy startproject myproject
scrapy genspider example example.com
scrapy crawl example -o out.json
```

## Good practices
- Respect `robots.txt` (`ROBOTSTXT_OBEY = True`), set a real `USER_AGENT`, and throttle with `DOWNLOAD_DELAY` / `AUTOTHROTTLE_ENABLED`.
- Build selectors in `scrapy shell` before wiring them into `parse`.
- Yield plain dicts (or `Item`s) and export with `-o file.jsonl`; use pipelines for cleaning/dedup.
- For JS-rendered pages, pair with a headless renderer (scrapy-playwright) or fall back to `crawl4ai`/`firecrawl`.
