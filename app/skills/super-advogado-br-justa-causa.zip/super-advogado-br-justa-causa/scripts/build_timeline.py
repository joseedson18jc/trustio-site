#!/usr/bin/env python3
"""Converte a planilha CSV de cronologia em tabela Markdown ordenada."""
from __future__ import annotations
import argparse, csv, sys
from datetime import datetime
from pathlib import Path

FIELDS = ['data_hora','evento','fonte','autor','destinatario','status_probatorio','contradicao','consequencia_juridica']

def parse_dt(value: str):
    value = (value or '').strip()
    if not value:
        return (1, '')
    try:
        return (0, datetime.fromisoformat(value.replace('Z','+00:00')))
    except ValueError:
        return (0, value)

def esc(v: str) -> str:
    return (v or '').replace('|', '\\|').replace('\n', '<br>')

def main() -> int:
    ap = argparse.ArgumentParser(description='Gera cronologia Markdown a partir de CSV.')
    ap.add_argument('input')
    ap.add_argument('--output', default='cronologia.md')
    args = ap.parse_args()
    inp, out = Path(args.input), Path(args.output)
    try:
        with inp.open(encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            missing = [x for x in FIELDS if x not in (reader.fieldnames or [])]
            if missing:
                print('Erro: colunas ausentes: ' + ', '.join(missing), file=sys.stderr)
                return 3
            rows = list(reader)
    except OSError as exc:
        print(f'Erro: {exc}', file=sys.stderr); return 2
    rows.sort(key=lambda r: parse_dt(r.get('data_hora','')))
    lines = ['# Cronologia probatória','', '| Data/hora | Evento | Fonte | Autor | Destinatário | Status | Contradição | Consequência |', '|---|---|---|---|---|---|---|---|']
    for r in rows:
        lines.append('| ' + ' | '.join(esc(r.get(k,'')) for k in FIELDS) + ' |')
    out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    print(f'{len(rows)} evento(s) gravados em {out}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
