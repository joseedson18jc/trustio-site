# Chart Patterns Reference

Code snippets for common chart implementations. Covers Recharts (React), Chart.js (vanilla/React), and inline SVG for lightweight indicators.

## Table of Contents
1. [Recharts Patterns (React)](#recharts-patterns)
2. [Chart.js Patterns (Vanilla/React)](#chartjs-patterns)
3. [Inline SVG Patterns](#inline-svg-patterns)
4. [KPI Card Patterns](#kpi-card-patterns)
5. [Chart Selection Guide](#chart-selection-guide)

---

## Recharts Patterns

### Line Chart with Area Fill (Trend Data)
```jsx
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

const TrendChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={300}>
    <AreaChart data={data}>
      <defs>
        <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
        </linearGradient>
      </defs>
      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
      <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
      <YAxis stroke="#94a3b8" fontSize={12} />
      <Tooltip
        contentStyle={{
          background: '#1e293b', border: 'none',
          borderRadius: '8px', color: '#f1f5f9'
        }}
      />
      <Area type="monotone" dataKey="value" stroke="#6366f1"
        strokeWidth={2} fill="url(#colorValue)" />
    </AreaChart>
  </ResponsiveContainer>
);
```

### Bar Chart (Comparison)
```jsx
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const ComparisonChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={300}>
    <BarChart data={data} barGap={4}>
      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" vertical={false} />
      <XAxis dataKey="name" stroke="#94a3b8" fontSize={12} />
      <YAxis stroke="#94a3b8" fontSize={12} />
      <Tooltip />
      <Bar dataKey="current" fill="#6366f1" radius={[4,4,0,0]} />
      <Bar dataKey="previous" fill="#e2e8f0" radius={[4,4,0,0]} />
    </BarChart>
  </ResponsiveContainer>
);
```

### Donut Chart (Part-of-Whole)
```jsx
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';

const COLORS = ['#6366f1', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'];

const DonutChart = ({ data }) => (
  <ResponsiveContainer width="100%" height={250}>
    <PieChart>
      <Pie data={data} cx="50%" cy="50%"
        innerRadius={60} outerRadius={90}
        paddingAngle={3} dataKey="value">
        {data.map((_, i) => (
          <Cell key={i} fill={COLORS[i % COLORS.length]} />
        ))}
      </Pie>
      <Tooltip />
    </PieChart>
  </ResponsiveContainer>
);
```

---

## Chart.js Patterns

### Line Chart (Vanilla JS)
```html
<canvas id="trendChart" width="400" height="200"></canvas>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.1/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('trendChart'), {
  type: 'line',
  data: {
    labels: ['Jan','Feb','Mar','Apr','May','Jun'],
    datasets: [{
      label: 'Revenue',
      data: [30, 45, 35, 60, 55, 80],
      borderColor: '#6366f1',
      backgroundColor: 'rgba(99,102,241,0.1)',
      fill: true,
      tension: 0.4,
      borderWidth: 2,
      pointRadius: 3,
      pointBackgroundColor: '#6366f1'
    }]
  },
  options: {
    responsive: true,
    plugins: {
      legend: { display: false },
      tooltip: {
        backgroundColor: '#1e293b',
        titleColor: '#f1f5f9',
        bodyColor: '#f1f5f9',
        cornerRadius: 8,
        padding: 12
      }
    },
    scales: {
      x: { grid: { display: false }, ticks: { color: '#94a3b8' } },
      y: { grid: { color: '#f1f5f9' }, ticks: { color: '#94a3b8' } }
    }
  }
});
</script>
```

### Horizontal Bar Chart
```javascript
new Chart(ctx, {
  type: 'bar',
  data: {
    labels: ['Product A', 'Product B', 'Product C', 'Product D'],
    datasets: [{
      data: [85, 72, 63, 45],
      backgroundColor: ['#6366f1', '#06b6d4', '#10b981', '#f59e0b'],
      borderRadius: 6,
      barThickness: 24
    }]
  },
  options: {
    indexAxis: 'y',
    plugins: { legend: { display: false } },
    scales: {
      x: { grid: { color: '#f1f5f9' }, max: 100 },
      y: { grid: { display: false } }
    }
  }
});
```

---

## Inline SVG Patterns

### Sparkline (Tiny Trend Indicator)
```html
<svg width="80" height="24" viewBox="0 0 80 24" fill="none">
  <polyline
    points="0,20 10,16 20,18 30,12 40,14 50,8 60,10 70,4 80,6"
    stroke="#10b981" stroke-width="2" fill="none"
    stroke-linecap="round" stroke-linejoin="round"/>
  <circle cx="80" cy="6" r="2.5" fill="#10b981"/>
</svg>
```

### Progress Ring
```html
<svg width="60" height="60" viewBox="0 0 60 60">
  <!-- Background ring -->
  <circle cx="30" cy="30" r="24" fill="none"
    stroke="#e2e8f0" stroke-width="6"/>
  <!-- Progress ring (75%) -->
  <circle cx="30" cy="30" r="24" fill="none"
    stroke="#6366f1" stroke-width="6"
    stroke-dasharray="150.8" stroke-dashoffset="37.7"
    stroke-linecap="round"
    transform="rotate(-90 30 30)"/>
  <!-- Center text -->
  <text x="30" y="34" text-anchor="middle"
    font-size="14" font-weight="600" fill="#1e293b">75%</text>
</svg>
<!-- Formula: dashoffset = circumference × (1 - progress/100) -->
<!-- circumference = 2 × π × r = 2 × 3.14159 × 24 = 150.8 -->
```

### Mini Bar Chart
```html
<svg width="60" height="24" viewBox="0 0 60 24">
  <rect x="0" y="10" width="8" height="14" rx="2" fill="#c7d2fe"/>
  <rect x="12" y="6" width="8" height="18" rx="2" fill="#a5b4fc"/>
  <rect x="24" y="2" width="8" height="22" rx="2" fill="#818cf8"/>
  <rect x="36" y="8" width="8" height="16" rx="2" fill="#a5b4fc"/>
  <rect x="48" y="0" width="8" height="24" rx="2" fill="#6366f1"/>
</svg>
```

### Trend Arrow Up
```html
<svg width="16" height="16" viewBox="0 0 16 16" fill="#10b981">
  <path d="M8 3l5 5h-3v5H6V8H3l5-5z"/>
</svg>
```

### Trend Arrow Down
```html
<svg width="16" height="16" viewBox="0 0 16 16" fill="#ef4444">
  <path d="M8 13l-5-5h3V3h4v5h3l-5 5z"/>
</svg>
```

---

## KPI Card Patterns

### Stat Card with Trend
```html
<div style="background:white; border-radius:12px; padding:24px;
  box-shadow:0 1px 3px rgba(0,0,0,0.1); min-width:200px;">
  <div style="display:flex; justify-content:space-between; align-items:start;">
    <div>
      <p style="color:#64748b; font-size:14px; margin:0;">Revenue</p>
      <h3 style="font-size:28px; font-weight:700; margin:8px 0 4px;">$48,200</h3>
      <div style="display:flex; align-items:center; gap:4px;">
        <span style="color:#10b981; font-size:13px; font-weight:600;">↑ 12.5%</span>
        <span style="color:#94a3b8; font-size:12px;">vs last month</span>
      </div>
    </div>
    <!-- Sparkline SVG here -->
  </div>
</div>
```

### Metric with Progress Bar
```html
<div style="background:white; border-radius:12px; padding:20px;">
  <div style="display:flex; justify-content:space-between; margin-bottom:8px;">
    <span style="color:#64748b; font-size:14px;">Storage Used</span>
    <span style="font-weight:600;">75%</span>
  </div>
  <div style="background:#e2e8f0; border-radius:999px; height:8px; overflow:hidden;">
    <div style="background:linear-gradient(90deg,#6366f1,#8b5cf6);
      width:75%; height:100%; border-radius:999px;
      transition: width 1s ease-out;"></div>
  </div>
  <p style="color:#94a3b8; font-size:12px; margin-top:8px;">7.5 GB of 10 GB</p>
</div>
```

---

## Chart Selection Guide

| Data Question | Chart Type | Min Data Points | Max Categories |
|--------------|-----------|-----------------|----------------|
| How does X change over time? | Line / Area | 5+ | 3-4 series |
| How do items compare? | Horizontal Bar | 3+ | 15 max |
| What's the distribution? | Histogram | 20+ | N/A |
| What portion of the whole? | Donut | N/A | 5 max |
| Is there a correlation? | Scatter | 15+ | 3-4 series |
| What's the current status? | Gauge / Ring | 1 | 1 |
| What's the quick trend? | Sparkline | 5+ | 1 |
| What's the ranking? | Horizontal bar (sorted) | 3+ | 10 max |
| Geographic distribution? | Choropleth map | 5+ | N/A |
| Hierarchical breakdown? | Treemap | 5+ | 20 max |

### Color Assignments for Charts
```
Positive/Up:    #10b981 (green)
Negative/Down:  #ef4444 (red)
Neutral:        #6366f1 (indigo)
Secondary:      #06b6d4 (cyan)
Warning:        #f59e0b (amber)
Series colors:  #6366f1, #06b6d4, #10b981, #f59e0b, #ef4444, #ec4899, #8b5cf6
```
