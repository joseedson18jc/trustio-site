#!/usr/bin/env python3
"""crawl.py — thin wrapper around Crawl4AI for agents.

Examples:
    python crawl.py https://example.com                 # print Markdown
    python crawl.py https://example.com -o out.md        # save Markdown
    python crawl.py https://docs.example.com --deep 15   # BFS crawl -> ./crawl_out/
    python crawl.py https://shop.example.com -q "extract product names and prices"

Requires: pip install -U crawl4ai && crawl4ai-setup
"""
import argparse
import asyncio
import os
import re
import sys


def _slug(url: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", url).strip("_")[:80] or "page"


async def single(url: str, out: str | None, query: str | None) -> None:
    from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, CacheMode
    cfg = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun(url, config=cfg)
        if not result.success:
            print(f"FAILED: {result.error_message}", file=sys.stderr)
            sys.exit(1)
        md = result.markdown or ""
        if query:
            md = f"<!-- extraction query: {query} -->\n\n{md}"
        if out:
            with open(out, "w", encoding="utf-8") as f:
                f.write(md)
            print(f"Wrote {len(md)} chars -> {out}")
        else:
            print(md)


async def deep(url: str, max_pages: int, out_dir: str) -> None:
    from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, CacheMode
    try:
        from crawl4ai.deep_crawling import BFSDeepCrawlStrategy
        strategy = BFSDeepCrawlStrategy(max_depth=2, max_pages=max_pages)
        cfg = CrawlerRunConfig(cache_mode=CacheMode.BYPASS, deep_crawl_strategy=strategy)
    except Exception:
        # Fallback for older/newer API surfaces: crawl the single page.
        cfg = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
    os.makedirs(out_dir, exist_ok=True)
    async with AsyncWebCrawler() as crawler:
        results = await crawler.arun(url, config=cfg)
        results = results if isinstance(results, list) else [results]
        n = 0
        for r in results:
            if not getattr(r, "success", False):
                continue
            path = os.path.join(out_dir, f"{_slug(r.url)}.md")
            with open(path, "w", encoding="utf-8") as f:
                f.write(r.markdown or "")
            n += 1
        print(f"Saved {n} page(s) -> {out_dir}/")


def main() -> None:
    ap = argparse.ArgumentParser(description="Crawl a URL to Markdown with Crawl4AI")
    ap.add_argument("url")
    ap.add_argument("-o", "--out", help="output file (single-page mode)")
    ap.add_argument("-q", "--query", help="natural-language extraction hint")
    ap.add_argument("--deep", type=int, metavar="MAX_PAGES",
                    help="BFS deep-crawl up to N pages into ./crawl_out/")
    ap.add_argument("--out-dir", default="crawl_out", help="deep-crawl output dir")
    args = ap.parse_args()
    if args.deep:
        asyncio.run(deep(args.url, args.deep, args.out_dir))
    else:
        asyncio.run(single(args.url, args.out, args.query))


if __name__ == "__main__":
    main()
