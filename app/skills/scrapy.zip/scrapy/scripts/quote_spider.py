"""Exemplo completo de spider Scrapy: coleta citações de quotes.toscrape.com
(site feito para treinar raspagem), segue a paginação e exporta em JSON Lines.

    python -m scrapy runspider scripts/quote_spider.py -o quotes.jsonl
"""
import scrapy


class QuoteSpider(scrapy.Spider):
    name = "quotes"
    start_urls = ["https://quotes.toscrape.com/"]
    custom_settings = {
        "ROBOTSTXT_OBEY": True,
        "AUTOTHROTTLE_ENABLED": True,
        "DOWNLOAD_DELAY": 0.5,
        "USER_AGENT": "quote-spider-example (+https://docs.scrapy.org)",
        "FEED_EXPORT_ENCODING": "utf-8",
    }

    def parse(self, response):
        for quote in response.css("div.quote"):
            yield {
                "text": quote.css("span.text::text").get(),
                "author": quote.css("small.author::text").get(),
                "tags": quote.css("div.tags a.tag::text").getall(),
                "url": response.url,
            }
        next_page = response.css("li.next a::attr(href)").get()
        if next_page:
            yield response.follow(next_page, self.parse)
