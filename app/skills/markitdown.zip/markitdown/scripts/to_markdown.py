#!/usr/bin/env python3
"""to_markdown.py — convert a file or folder to Markdown with MarkItDown.

Examples:
    python to_markdown.py report.pdf                 # print Markdown
    python to_markdown.py report.pdf -o report.md     # save
    python to_markdown.py ./docs --out-dir ./md_out   # batch a folder

Requires: pip install 'markitdown[all]'
"""
import argparse
import os
import sys


def _convert(md, path: str) -> str:
    return md.convert(path).text_content


def main() -> None:
    ap = argparse.ArgumentParser(description="Convert file/folder to Markdown")
    ap.add_argument("path", help="file or directory")
    ap.add_argument("-o", "--out", help="output file (single-file mode)")
    ap.add_argument("--out-dir", help="output dir (folder mode)")
    ap.add_argument("--plugins", action="store_true", help="enable 3rd-party plugins")
    args = ap.parse_args()

    try:
        from markitdown import MarkItDown
    except ImportError:
        sys.exit("Install first: pip install 'markitdown[all]'")
    md = MarkItDown(enable_plugins=args.plugins)

    if os.path.isdir(args.path):
        out_dir = args.out_dir or "md_out"
        os.makedirs(out_dir, exist_ok=True)
        n = 0
        for name in sorted(os.listdir(args.path)):
            src = os.path.join(args.path, name)
            if not os.path.isfile(src):
                continue
            try:
                text = _convert(md, src)
            except Exception as e:  # noqa: BLE001
                print(f"skip {name}: {e}", file=sys.stderr)
                continue
            dst = os.path.join(out_dir, os.path.splitext(name)[0] + ".md")
            open(dst, "w", encoding="utf-8").write(text)
            n += 1
        print(f"Converted {n} file(s) -> {out_dir}/")
    else:
        text = _convert(md, args.path)
        if args.out:
            open(args.out, "w", encoding="utf-8").write(text)
            print(f"Wrote {len(text)} chars -> {args.out}")
        else:
            print(text)


if __name__ == "__main__":
    main()
