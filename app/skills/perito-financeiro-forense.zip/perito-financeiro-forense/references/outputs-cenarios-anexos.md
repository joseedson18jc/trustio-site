<!-- pff-version: 21.0 -->
# Formatos de Saída, Cenários, Interação, Glossário e Anexos

**Sumário:** §8 Saídas (sumário, relatório, Tabelas 1–9) · §9 Escrita · §10 Cenários A–L, sensibilidade, conclusão, checklist final · §11 Interação · §12 Glossário · Anexos A–D, U, W, X. Histórico de versões: `changelog.md`.

> **Entrega em arquivo:** gere as Tabelas 1–9 em XLSX com `pericia.exportar_xlsx({...}, 'pericia_<caso>.xlsx')` e o
> laudo em DOCX/PDF conforme as skills de documento disponíveis. No chat, apresente o Sumário Executivo; as tabelas
> longas vão no arquivo.

## § 8. FORMATOS DE SAÍDA (TODOS OBRIGATÓRIOS)

### A) SUMÁRIO EXECUTIVO (1–2 páginas)

```text
SUMÁRIO EXECUTIVO — PERÍCIA FINANCEIRA FORENSE
================================================

IDENTIFICAÇÃO
  Devedor: [nome]
  Instituição: [banco]
  Produto(s): [empréstimo pessoal / cartão / cheque especial / consignado / veículo]
  Contrato(s): [nº(s)] | Data(s) de contratação: [DD/MM/AAAA]
  Período analisado: [DD/MM/AAAA] a [DD/MM/AAAA] ([N] meses)
  Nº de transações: [N] | Nº de fases: [F] (tipos: [ORIGEM, NOV, REN...])
  Score de qualidade dos dados: [X]/100 — [classificação]

SALDO DEVEDOR
  Banco informa:     R$ [________]
  Recálculo (base):  R$ [________]
  DIFERENÇA:         R$ [________] ([____]%)

TOTAL PAGO PELO DEVEDOR: R$ [________]
TOTAL DE ENCARGOS COBRADOS: R$ [________]
EXCESSO COBRADO (estimativa): R$ [________] nominal | R$ [________] VP (Selic)

PRINCIPAIS ACHADOS
  1. [HC-XX] [descrição] — R$ [valor] — Severidade [ALTA/MÉDIA] — [data fato gerador]
  2. [HC-XX] [descrição] — R$ [valor] — Severidade [ALTA/MÉDIA] — [data fato gerador]
  3. ...

PRESCRIÇÃO
  Achados dentro do prazo (5 anos): R$ [________] ([___]% do total)
  Achados possivelmente prescritos:  R$ [________] ([___]% do total)

CENÁRIOS
  Cenário mais favorável ao devedor ([X]): saldo R$ [____] (diferença R$ [____] vs. banco)
  Cenário mais desfavorável ([Y]):         saldo R$ [____] (diferença R$ [____] vs. banco)

LIMITAÇÕES
  [listar dados faltantes, premissas adotadas, período não coberto]

PRÓXIMOS PASSOS
  1. [documentos a solicitar]
  2. [validação jurídica recomendada]
  3. [ação sugerida: negociação / revisional / repetição de indébito]
```

### B) RELATÓRIO TÉCNICO DETALHADO

1. Dicionário de colunas e log de limpeza/extração.
2. Mapa de fases com fichas completas.
3. Metodologia matemática.
4. Reconstrução do saldo linha a linha com waterfall.
5. Comparação banco vs. calculado.
6. Análise de encargos: checklist regulatório (45 itens — Etapa 5) + testes §5-T1/T2/T3.
7. Cenários e sensibilidade.
8. Limitações e dados faltantes.
9. Conclusão executiva e recomendações.
10. Anexos (tabelas + logs + registros excluídos).

### C) TABELAS (TODAS DEVEM SER ENTREGUES)

**Tabela 1 — Mapa de Fases:**

| Fase | Tipo_Evento | Data_Início | Data_Fim | Data_Desembolso | Saldo_Ini_Banco | Saldo_Ini_Calc | Gap_Transição | Tipo_Taxa | Tipo_NomEfet | Taxa_Mensal | Spread | Spread_Tipo | CET_Efetivo | Prazo | Parcelas_Pagas | Parcelas_Total | Parcela | Sistema | Carência | Forma_Pgto | Obs |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

**Tabela 2 — Evolução do Saldo (linha a linha):**

| Linha | Data | Data_Fato_Gerador | Fase | Descrição | Tipo | Classificação_Origem | Valor | Juros_Teórico | Encargos | Amort_Principal | Saldo_Calc | Saldo_Banco | Dif | Dif_Pct | Severidade | Flag |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

**Tabela 3 — Discrepâncias (ordenadas por severidade → impacto):**

| # | Data | Data_Fato_Gerador | Linha_ID | Dif(R$) | δ_novo(R$) | Dif(%) | Severidade | Tipo_Divergência | Evidência_Extrato | Hipótese_Causal | Impacto_Acumulado_Dir (= Dif) | Impacto_Acumulado_Abs (Σ abs δ) | Impacto_Atualizado (Σ δ×fator) |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

`δ_novo = Dif_t − Dif_{t−1}` — nunca somar a coluna Dif (é estoque). Ver §6.3 de `regulatorio-formulas.md`.

**Tabela 4 — Impacto Consolidado:**

| Fase | Tipo_Evento | Nº_Achados | Total_Cobrado_a_Maior | Total_Cobrado_a_Menor | Impacto_Direcional | Impacto_Absoluto | Saldo_Final_Calc | Saldo_Final_Banco | Gap_Final | Gap% | Impacto_VP |
|---|---|---|---|---|---|---|---|---|---|---|---|

**Tabela 5 — Comparação de Cenários:**

| Cenário | Sistema | Taxa | Capitalização | Waterfall | Saldo_Final | Dif_vs_Banco | Excesso_Pago_Nominal | Posição_Líquida_VP | Excesso_VP_Selic | Excesso_VP_IPCA | Obs |
|---|---|---|---|---|---|---|---|---|---|---|---|

**Tabela 6 — Checklist Regulatório:**

| # | Verificação | Resultado | Linhas/Datas | Data_Fato_Gerador | Impacto(R$) | Impacto(%) | Referência_Legal | Status |
|---|---|---|---|---|---|---|---|---|

**Tabela 7 — Sensibilidade:**

| Parâmetro | Valor_Testado | Saldo_Final | Gap_vs_Banco | Δ_vs_Cenário_Base | Sinal_Gap_Mudou? | Obs |
|---|---|---|---|---|---|---|

---

**Tabela 8 — Matriz Agentes × Achados:**

Rastreia qual fase/agente produziu cada achado. Torna o laudo auditável quanto à origem
de cada conclusão (NBC TP 01).

| Agente | Etapas | Achados produzidos | HCs atribuídos | Nº de divergências | Status |
|---|---|---|---|---|---|
| SA-1 Ingestão | §0-PRE, 0 | [falhas de extração, lacunas] | — | [n] | [OK/RESSALVA] |
| SA-2 Classificação | 0–2 | [anomalias, fases, triagem §2.4] | — | [n] | [OK/RESSALVA] |
| SA-3 Matemático | 3–4 | [gap de saldo, taxa inferida, amort. negativa] | HC-01, HC-08, HC-13 | [n] | [OK/RESSALVA] |
| SA-4 Regulatório | 5 | [violações do checklist de 45 itens; testes §5-T1/T2/T3] | HC-02..HC-38 | [n] | [OK/RESSALVA] |
| SA-5 Comparador | 6 | [divergências linha a linha] | — | [n] | [OK/RESSALVA] |
| SA-6 Cenários | 7 | [intervalo entre cenários A–L] | — | [n] | [OK/RESSALVA] |
| SA-7 Relatório | 7 | [consolidação, checklist final] | — | [n] | [OK/RESSALVA] |

**Tabela 9 — Temas STJ pendentes e exposição:**

Obrigatória sempre que algum achado dependa de tese não fixada. Explicita ao leitor quanto
do pedido está sujeito a risco de tese. A coluna **Checado em** é obrigatória (§5 Nota 6).

| Tema | Objeto | Situação | Checado em | HC vinculado | Achado no caso | Valor exposto (R$) | Ressalva |
|---|---|---|---|---|---|---|---|
| 1.264 | Dívida prescrita / Limpa Nome | `[TESE_PENDENTE]` (em julgamento) | [data] | HC-36 | [S/N] | [X] | Cálculo autônomo apresentado |
| 1.378 | Taxa média basta para abusividade? | `[TESE_PENDENTE]` | [data] | HC-38 | [S/N] | [X] | Cálculo autônomo apresentado |
| 1.414 | Cartão consignado — decadência, validade, consequências e dano moral (absorveu o REsp do extinto Tema 1.328) | `[TESE_PENDENTE]` (ampliado em 02/10/2026) | [data] | HC-29 | [S/N] | [X] | Suspensão nacional; ajuizamento fixa a data da propositura; risco de decadência (item I) quantificado à parte |
| MP 1.355/2026 | Margem/cartão INSS (norma volátil) | Sem eficácia desde 01/09/2026 — decreto legislativo até 30/10/2026? | [data] | HC-18, HC-29 | [S/N] | [X] | Aplicar a regra da data de cada contratação (janela 04/05–31/08/2026) |

> Não incluir o Tema 1.325 (não trata de RMC) nem o Tema 1.328 (cancelado) — erros das versões ≤ v20.

**Regra de fechamento:** `Σ Valor exposto (Tabela 9)` deve ser reportado **separadamente**
do total pleiteável, para que o leitor distingua o que depende de tese pendente do que não
depende. Nunca somar os dois em um número único sem discriminação.

---

## § 9. PADRÕES DE ESCRITA E TRANSPARÊNCIA

1. Cite SEMPRE a linha/data e texto do histórico que motivou cada classificação.
2. Rotule inferências: `[INFERIDO — método: X, confiança: alta/média/baixa]`.
3. Rotule premissas: `[PREMISSA — descrição]`.
4. Declare convenções no início: base de dias, periodicidade, waterfall, tolerância, regime temporal, tipo de taxa, tipo de spread.
5. Seja técnico, objetivo e auditável. Sem linguagem emocional.
6. Reprodutibilidade: um segundo perito deve chegar aos mesmos números.
7. VP: sempre acompanhe impacto nominal com VP, declarando método.
8. Impacto direcional e absoluto: apresente ambos.
9. Separar `[FATO]`, `[INFERÊNCIA]` e `[PREMISSA]` em TODAS as tabelas e texto.
10. Prescrição: acompanhar data do fato gerador em todos os achados.
11. Consistência de fórmulas com a convenção de dias declarada.
12. Taxas nominais vs. efetivas: declarar explicitamente.
13. Spread multiplicativo vs. aditivo: declarar em cada operação pós-fixada.

---

## § 10. CENÁRIOS DE ANÁLISE E SENSIBILIDADE

### 10.1 Cenários A–L

| Cenário | Sistema | Capitalização | Taxa | Waterfall | Descrição |
|---|---|---|---|---|---|
| A | Price | Composta | Contratada | Contratual | Cenário-base |
| B | SAC | Composta | Contratada | Contratual | Alternativa de sistema |
| C | Price | Composta | Contratada | Legal (Art. 354 CC) | Impacto waterfall |
| D | SAC | Composta | Contratada | Legal (Art. 354 CC) | SAC + waterfall legal |
| E | Price / Gauss | Simples | Contratada (proporcional: 12×i_m) | Legal | Sem anatocismo — juros simples sobre o **capital remanescente**, juros não pagos em conta separada; variante Gauss para parcela fixa |
| F | Price | Composta | Taxa média BACEN (Súmula 530) | Legal | Taxa não comprovável |
| G | Price | Composta | Contratada | Contratual | Sem tarifas/seguros |
| H | (Caso) | Composta | Pós-fixada (CDI/Selic+spread) | Contratual | Com indexador |
| I | Price | Composta | Contratada | Legal | Sem tarifas/seguros + waterfall legal |
| J | Price | Composta | Contratada | Contratual | Mora legal do Art. 406 CC **segmentada por regime** (§4.5 de `regulatorio-formulas.md`): Selic integral sem correção até 29/08/2024; taxa legal (Selic − IPCA-15) + IPCA desde 30/08/2024. Verificar prevalência da Súmula 379/STJ (1% a.m.) quando há pactuação. |
| K | (Caso) | Composta | Contratada | Contratual | **Mínimo existencial / superendividamento** — renda − todas as parcelas (**consignado incluído**, STF ADPFs 1.005/1.006/1.097) ≥ R$ 600 (Dec. 11.567/2023) ou piso provado. Teste §5-T3; HC-21/HC-37. Recalcular o fluxo viável e o excedente cobrado além da capacidade de pagamento. |
| L | (Caso) | Composta | Contratada | Contratual | **Teto de 100% do rotativo** (cartão com origem ≥ 03/01/2024; Lei 14.690/2023; HC-17). Aplicar o teste §5-T1 e recompor o saldo com o excedente decotado. |

**Cenário J — detalhamento (Lei 14.905/2024):**
- Contrato NÃO estipula mora → mora legal do Art. 406 CC, no regime vigente em cada período (segmentar em 30/08/2024).
- Contrato estipula mora ≤ 1% a.m. → usar a taxa contratual.
- Contrato estipula mora > 1% a.m. → limitar a 1% a.m. (Súmula 379/STJ).
- Nunca cumular Selic integral com correção monetária; no regime pós-30/08/2024, a correção (IPCA) é **separada** da taxa legal.
- Calcular pela mora legal e por 1% a.m.; adotar a MENOR neste cenário.

**Cenários K e L — quando executar:** K sempre que houver indício de comprometimento
excessivo de renda (HC-21) ou desconto/parcela que atinja o mínimo existencial (HC-37); L
sempre que houver saldo rotativo de cartão com origem a partir de 03/01/2024. Ambos são
**cenários de decote**: produzem o saldo que restaria com a regra aplicada, e a diferença
para o cenário A é o impacto pleiteável.

**Nota sobre favorabilidade:** com parcelas que cobrem os juros de cada mês, o Cenário E (simples sobre o capital remanescente) dá **o mesmo resultado** que o Cenário A — não há capitalização a expurgar. A diferença surge quando houve juros não pagos incorporados (mora, amortização negativa, rolagem/novação). A variante Gauss sempre reduz a parcela, mas é tese, não cálculo devido. Sempre compute e compare numericamente.

### 10.2 Sensibilidade — 8 parâmetros / 21 cenários

| # | Parâmetro | Variações |
|---|---|---|
| 1 | Taxa de juros mensal | ±0,1%, ±0,5%, ±1,0%, taxa média BACEN (7 variações) |
| 2 | Sistema de amortização | Price, SAC, SAM (3 variações) |
| 3 | Waterfall | Legal vs. Bancário (1 variação) |
| 4 | Convenção de dias | 30/360 vs. actual/365 (1 variação) |
| 5 | Capitalização | Composta vs. Simples (1 variação) |
| 6 | Margem consignável | limite vigente na data da contratação vs. 35% vs. 45% (3 variações) |
| 7 | Teto do rotativo | com teto / sem teto (2 variações — só origem ≥ 03/01/2024) |
| 8 | Mínimo existencial | R$ 600 (Dec. 11.567/2023) vs. piso provado no caso (2 variações) |

Total: 1 (base) + 7 + 3 + 1 + 1 + 1 + 3 + 2 + 2 = **21 cenários**.

Os parâmetros 6–8 só são executados quando o caso os dispara (consignado, cartão rotativo
com origem ≥ 03/01/2024, superendividamento). Quando inaplicáveis, declarar `NÃO APLICÁVEL`
e reportar o total efetivamente executado — nunca omitir silenciosamente.

### 10.3 Conclusão Executiva — 7 Elementos Obrigatórios

1. Saldo recalculado vs. banco → diferença R$ e %.
2. Total pago a maior (ou a menor) → decomposição por tipo HC.
3. Posição líquida em VP (Selic e IPCA).
4. Principais achados (3–8) com severidade e classificação.
5. Prescrição quantificada → dentro do prazo vs. total.
6. Cenário mais favorável e mais desfavorável → intervalo.
7. Limitações e documentos pendentes.

### 10.4 Checklist Final (65 itens)

- ☐ Arquivos catalogados e classificados por tipo (§0-PRE.1)
- ☐ Timeline cronológica construída e gaps detectados (§0-PRE.2)
- ☐ Extração dual executada (parsing + OCR) em cada PDF (§0-PRE.3)
- ☐ Reconciliação A∩B realizada com log de divergências (§0-PRE.3)
- ☐ Consolidação multi-arquivo com deduplicação (§0-PRE.4)
- ☐ Continuidade entre arquivos validada: Saldo_Final_k ≈ Saldo_Inicial_(k+1) (§0-PRE.4)
- ☐ Extração de dados validada — protocolo §0 completo
- ☐ Extração validada (9 testes — §0.2 + §6.3)
- ☐ Dados ordenados, normalizados, log de limpeza gerado
- ☐ Registros excluídos segregados com justificativa
- ☐ Tipos de transação classificados (juros remun. ≠ moratórios)
- ☐ Mora composta decomposta quando possível
- ☐ Estornos vinculados a transações originais
- ☐ Fases mapeadas com fichas completas (novação/reneg/INDET)
- ☐ Gaps de transição detalhados com composição do novo saldo
- ☐ Carência tratada (com verificação de anatocismo — HC-14)
- ☐ Fórmulas declaradas com taxa-base e base de dias explícitas
- ☐ Tipo de taxa identificado: pré vs. pós; nominal vs. efetiva
- ☐ Spread identificado (multiplicativo vs. aditivo)
- ☐ Conversão de taxas correta e declarada
- ☐ Em juros simples, taxa anual PROPORCIONAL (12×i_m)
- ☐ Waterfall declarado (dois cenários se contrato omisso)
- ☐ Amortização negativa detectada (critério N_CONSECUTIVO)
- ☐ Saldo recalculado linha a linha
- ☐ Dif_pct com tratamento de divisão por zero
- ☐ CET efetivo calculado e comparado (XIRR se datas irregulares)
- ☐ Encargos verificados (**45 itens** — checklist Etapa 5, HC-completo verificado)
- ☐ Severidade dual (absoluto E relativo)
- ☐ Impacto: direcional E absoluto, nominal E VP (método declarado)
- ☐ Cenários A–L computados (os aplicáveis; K e L quando disparados)
- ☐ Sensibilidade executada (8 parâmetros, até 21 cenários; inaplicáveis declarados)
- ☐ Mora legal segmentada em 30/08/2024 (Selic integral sem correção ↔ taxa legal + IPCA); Selic integral NUNCA cumulada com correção
- ☐ Limitações declaradas
- ☐ Tabelas 1–9 geradas e consistentes
- ☐ Conclusão executiva com 7 elementos
- ☐ Valor pago a maior com decomposição + VP
- ☐ Data do fato gerador em todos os achados
- ☐ Lista de documentos necessários
- ☐ Liquidação antecipada verificada (se aplicável)
- ☐ Fórmulas consistentes com convenção de dias
- ☐ Cenários compostos (I, J) computados quando aplicáveis
- ☐ Superendividamento (Lei 14.181/2021) avaliado
- ☐ [FATO], [INFERÊNCIA] e [PREMISSA] separados
- ☐ Conformidade NBC TP 01/PP 01 aprovada
- ☐ IOF verificado (HC-16)
- ☐ Módulo por produto aplicado (§2.1)
- ☐ Score de qualidade reportado (§4.8)
- ☐ Se extrato parcial: limitações declaradas (§4.9)
- ☐ Etapa 7 consolidação verificada (unificação de achados e tabelas)
- ☐ Margem consignável verificada pelo limite **vigente na data de cada contratação** (série temporal §2.1)
- ☐ Extrato multiproduto: parser posicional + validação quádrupla V1–V4 (§0-PRE.6)
- ☐ Painel de crédito extraído como série temporal + T8-painel aprovado (§0-PRE.7)
- ☐ Transições de painel investigadas (HC-25/26/27); faturas de cartão solicitadas se a dívida transitou por fatura
- ☐ Taxa inferida com `pericia.taxa_contratual_mensal` (meses-calendário) e CET recalculado com `pericia.cet_regulatorio` (Res. CMN 4.881/2020) — nunca comparados entre si
- ☐ Teste §5-T1 (teto do rotativo) executado ou justificadamente inaplicável
- ☐ Teste §5-T2 (dívida perpétua RMC/RCC) executado ou justificadamente inaplicável
- ☐ Teste §5-T3 (mínimo existencial, consignado incluído) executado ou justificadamente inaplicável
- ☐ Parâmetros com vigência temporal (`MARG_*`, `TETO_ROTATIVO`, `MIN_EXISTENCIAL`, regime do art. 406) aplicados por data de lançamento, não pela data do laudo
- ☐ Achados dependentes de tese pendente marcados `[TESE_PENDENTE]` e calculados de forma autônoma ao desfecho
- ☐ **Revalidação normativa executada** (decreto legislativo da MP 1.355/2026; MP 1.373/2026; Temas 1.264, 1.378, 1.414; mínimo existencial; suspensão TCU do cartão consignado) com data e URL registradas
- ☐ Tabela 8 (Matriz Agentes × Achados) gerada
- ☐ Tabela 9 (Temas STJ pendentes e exposição, com coluna "Checado em") gerada
- ☐ Triagem de produtos especiais (§2.4 de `protocolo-pipeline.md`) executada em todas as fases
- ☐ Integridade da skill confirmada no início (`scripts/verificar_integridade.py` = OK v21.0) ou divergência declarada no laudo
- ☐ Cada número do laudo rastreável à função de `scripts/pericia.py` e aos insumos usados

---

## § 11. MODO DE INTERAÇÃO

### 11.1 Se Faltar Informação — NÃO PARE

Execute com 3 cenários: conservador (pró-banco), central, favorável (pró-devedor).

### 11.2 Documentos a Solicitar

1. Contrato original e todos os aditivos.
2. Termos de renegociação/novação.
3. Demonstrativo de evolução da dívida emitido pelo banco.
4. Memória de cálculo do banco.
5. CET informado em cada fase.
6. Apólice de seguro prestamista.
7. Regulamento de tarifas vigente à época.
8. Comprovantes de pagamento independentes.
9. Declaração da modalidade e base de cálculo.
10. Séries históricas dos indexadores.
11. Termo de quitação/liquidação antecipada.
12. Calendário ANBIMA (se DU/252).
13. Contrato digital: verificar integridade e metadados ICP-Brasil.
14. Faturas de cartão de crédito do período (dívida que transita por parcelamento de fatura é invisível ao extrato da conta).

### 11.3 Quando Faltar Informação Crítica

Execute 3 cenários: conservador (pró-banco), central (melhor estimativa), favorável (pró-devedor). Declare TODAS as premissas adotadas com rótulo [PREMISSA].

### 11.4 Extratos Grandes (> 5.000 linhas)

1. Processe em blocos por fase/período.
2. Priorize períodos com maior variância.
3. Mantenha running totals e checksum entre blocos: `Saldo_Final_Bloco_k == Saldo_Inicial_Bloco_(k+1)`.
4. Forneça código Python como anexo quando possível.

### 11.5 Quando Não For Possível Concluir

Declare explicitamente. NÃO force conclusão — laudo inconcluso > laudo errado.

---

## § 12. GLOSSÁRIO TÉCNICO

| Termo | Definição |
|---|---|
| 30/360 | Convenção: mês=30d, ano=360d. Padrão crédito PF Brasil. |
| Amortização | Parcela que reduz o principal. |
| Amortização Negativa | Pagamento < juros → principal cresce. |
| Anatocismo | Capitalização de juros sobre juros. Permitido pós-2000 se pactuado (Súmula 539). |
| Carência | Período sem amortização (somente juros). |
| CET | Custo Efetivo Total = TIR do fluxo completo pela fórmula da Res. CMN 4.881/2020 (dias/365, base anual). |
| Comissão de Permanência | Encargo na inadimplência, exclui outros (Súmula 472). Inacumulável com correção (Súmula 30). |
| DU/252 | Dias úteis ANBIMA, base 252. Para CDI e renda fixa. |
| Etapa 7 (Consolidação) | Etapa final do pipeline — unificação dos achados, geração de tabelas, cenários e relatório. |
| IOF | Imposto sobre Operações Financeiras (PF). 0,38% adicional + 0,0082%/dia, até 365 dias (2,993%); máximo efetivo 3,373%. |
| Lei 14.601/2023 | Margem consignável INSS 45% (35%+5%+5%). Série: 35% (Lei 13.172/2015) → 40% (Lei 14.431/2022) → 45% INSS. |
| Mínimo existencial | R$ 600,00 (Dec. 11.150/2022 c/ Dec. 11.567/2023), revisável anualmente pelo CMN; consignado incluído no cômputo (STF ADPFs 1.005/1.006/1.097, abr/2026). |
| Taxa Legal | Juros legais do art. 406 CC desde 30/08/2024: Selic − IPCA-15, juros simples, piso zero (Lei 14.905/2024; Res. CMN 5.171/2024). Correção (IPCA) em separado. |
| Juros simples | Juros que não rendem juros: calculados sobre o capital remanescente; juros não pagos ficam à parte. Juros de mora são sempre simples. |
| Novação | Extinção da obrigação anterior + criação de nova (Arts. 360–367 CC). |
| Pós-fixada | Indexador variável + spread fixo. |
| Pré-fixada | Taxa constante durante vigência. |
| Price | Parcela constante, juros decrescentes, amortização crescente. |
| SAC | Amortização fixa, parcela decrescente. |
| SAM | Parcela = média de Price e SAC; o saldo resultante é igual à média dos saldos Price e SAC. |
| Spread | Margem sobre indexador. Multiplicativo (CDI padrão) ou aditivo (SFH padrão). |
| Taxa Nominal | Proporcional: 12% a.a. = 1% a.m. |
| Taxa Efetiva | Equivalente composta: 12% a.a. efetiva ≈ 0,9489% a.m. |
| VP | Valor Presente. |
| Waterfall | Ordem de prioridade na alocação de pagamentos. |
| XIRR | TIR para datas irregulares. |

---

## ANEXO A — CONVERSÃO DE TAXAS

```
Mensal → Anual (composta):  i_a = (1 + i_m)^12 − 1
Anual → Mensal (composta):  i_m = (1 + i_a)^(1/12) − 1
Mensal → Diária (30/360):  i_d = (1 + i_m)^(1/30) − 1
Mensal → Diária (act/365): i_d = (1 + i_m)^(12/365) − 1
Equivalência: (1 + i_m)^(12/365) = [(1 + i_m)^12]^(1/365) = (1 + i_a)^(1/365)
Nominal → Efetiva:         i_ef = (1 + i_nom/k)^k − 1
Verificação Súmula 541:    Se i_a > 12 × i_m → capitalização pactuada
```

## ANEXO B — FÓRMULAS DE PARCELA

```
Price:     PMT = PV × [i(1+i)^n] / [(1+i)^n − 1]
SAC:       Amort_t = PV/n ; PMT_t = Amort_t + S_{t−1} × i
SAM:       PMT_SAM_t = (PMT_Price + PMT_SAC_t)/2
Gauss:     PMT = PV × (1 + i·n) / (n + i·n·(n−1)/2)   [juros simples, parcela fixa — cenário]
Liquidação: Quitação = Σ PMT_k / (1+i)^(m_k)   [VP à taxa pactuada]
Americano: PMT_t = PV × i (t < n)           [somente juros]
           PMT_n = PV × (1 + i)             [principal + juros finais]
           S_t = PV (t < n); S_n = 0
```

## ANEXO C — FONTES DE INDEXADORES

| Indexador | Fonte | Série SGS |
|---|---|---|
| Selic (meta) | BACEN | 432 |
| Selic (diária) | BACEN | 11 |
| CDI | BACEN / B3 | 12 |
| IPCA | IBGE via BACEN | 433 |
| IPCA-15 | IBGE via BACEN | 7478 |
| IGPM | FGV via BACEN | 189 |
| INPC | IBGE via BACEN | 188 |
| TR | BACEN | 226 |
| Taxa legal (art. 406 CC) | BACEN | 29543 |
| Selic acumulada no mês | BACEN | 4390 |
| Taxa média mensal PF por modalidade | BACEN — SGS | 25464 pessoal não consignado · 25470 pessoal total · 25463 cheque especial · 25477 cartão rotativo (ver Anexo B de `regulatorio-formulas.md`) |

## ANEXO D — CHECKLIST RÁPIDO PRÉ-ANÁLISE

1. ☐ Arquivo recebido e legível
2. ☐ Formato identificado (PDF/XLSX/CSV/OFX)
3. ☐ Colunas mapeadas — Dicionário criado se necessário
4. ☐ Contra-verificação aprovada (T1–T6)
5. ☐ Convenção de sinal declarada
6. ☐ Parâmetros centralizados declarados
7. ☐ Produtos segregados (se múltiplos)
8. ☐ Período coberto identificado
9. ☐ Contrato(s) disponível(is)?

## ANEXOS E–T, V, Y, Z — HISTÓRICO

Movidos para `references/changelog.md` (v21.0) — não são necessários durante a perícia.

---

## ANEXO U — REFERÊNCIA DE CONSISTÊNCIA DIMENSIONAL (OPCIONAL)

> **Nota:** Este anexo é uma referência de boas práticas para implementação em código. Não é requisito da perícia forense nem das normas NBC TP 01/PP 01. Seu uso é recomendado em pipelines automatizados de recálculo.

### U.1 Contratos Dimensionais das Fórmulas Principais

| Fórmula | Entradas | Saída | Invariante |
|---|---|---|---|
| `J = S × [(1+i)^(d/base) − 1]` | S[R$], i[%/período], d[dias], base[dias] | J[R$] | Expoente `d/base` deve ser adimensional |
| `PMT = P × [i(1+i)^n]/[(1+i)^n−1]` | P[R$], i[%/mês], n[períodos] | PMT[R$] | `n` é contagem pura (adimensional) |
| `CET via XIRR` | CF[R$], datas[dias] | taxa[%/ano] | Fluxo em R$, retorno em taxa anual |
| `IOF = P × alíq × N` | P[R$], alíq[%/dia], N[dias] | IOF[R$] | `alíq × N` é taxa acumulada (adimensional) |
| `Correção = S × (Índ_t/Índ_{t-1} − 1)` | S[R$], índices[adimensional] | Correção[R$] | Razão de índices é adimensional |

### U.2 Regras de Compatibilidade

- `VALOR ± VALOR → VALOR` (R$ ± R$ = R$)
- `VALOR × TAXA → VALOR` (R$ × % = R$, pois taxa é adimensional)
- `TEMPO ÷ TEMPO → ADIMENSIONAL` (dias ÷ dias = expoente puro)
- Expoentes em `(1+i)^n` exigem `n` adimensional
- **Proibido:** `VALOR + TAXA`, `VALOR ^ n` (n≠1), `TEMPO + VALOR`

### U.3 Verificação Prática em Python

```python
def verificar_expoente_adimensional(numerador_dias, denominador_dias, label=""):
    """Verifica que o expoente é adimensional (mesma unidade no num/denom)."""
    assert denominador_dias > 0, f"Denominador zero em expoente: {label}"
    # Se ambos são contagens de dias, o quociente é adimensional — OK
    return numerador_dias / denominador_dias

def verificar_soma_valores(v1, v2, label=""):
    """Verifica que ambos os operandos são valores monetários antes de somar."""
    # Em implementação tipada: checar que ambos são float/Decimal com tag R$
    assert isinstance(v1, (int, float)) and isinstance(v2, (int, float)), \
        f"Soma de tipos incompatíveis em {label}: {type(v1)}, {type(v2)}"
    return v1 + v2
```

### U.4 Recomendação

Para pipelines automatizados de auditoria, documentar o contrato dimensional de cada função no docstring:
```python
def juros_compostos(saldo_rs, taxa_mensal, dias, base_dias=30):
    """
    Contrato dimensional:
      saldo_rs: VALOR [R$]
      taxa_mensal: TAXA [decimal, ex: 0.02 = 2%/mês]
      dias: TEMPO [dias corridos ou 30/360]
      base_dias: TEMPO [dias, mesma unidade que 'dias']
      retorno: VALOR [R$]
    """
    expoente = dias / base_dias  # TEMPO/TEMPO = ADIMENSIONAL
    return saldo_rs * ((1 + taxa_mensal) ** expoente - 1)
```

## ANEXO W — MATRIZ DE VALIDAÇÃO

Desde a v21.0 a validação é **executável**: `python3 scripts/pericia.py --selftest` (33 testes) e
`python3 scripts/verificar_integridade.py` (coerência entre arquivos). Afirme em laudo apenas o que esses
comandos reportarem na data — nunca a antiga "suíte de 67 testes" da v17, que não existe em código.

| Família | Objeto | Coberto por `--selftest` |
|---|---|---|
| Parsing BR/OCR | `parse_valor_br` (sufixo `-`, `D`, parênteses, O→0) | sim (4) |
| Convenções de dias | 30/360 NASD/ISMA | sim (2) |
| Amortização | Price, SAC, SAM, zeragem de saldo, recálculo linha a linha | sim (5) |
| Taxa e CET | Newton-Raphson em meses-calendário; CET Res. 4.881 × taxa efetiva; CET com custos; XIRR | sim (4) |
| Waterfall / severidade | amortização negativa; severidade dual; dif_pct com zero | sim (3) |
| IOF | prazo único com teto de 365 dias | sim (1) |
| Testes regulatórios | §5-T1 (violação, não retroatividade, conformidade), §5-T2 (quita/perpétua), §5-T3 | sim (6) |
| Margem / cheque especial / Súmula 541 / prescrição | série de margens (janela MP, pós-MP, CLT 40%) | sim (6) |
| Mora legal art. 406 | segmentação em 30/08/2024 | sim (1) |
| Painel / score | taxa via painel; score de qualidade | sim (2) |
| DU/252, pós-fixadas com séries reais | dependem de calendário ANBIMA e séries do SGS | **não** — validar caso a caso |

---

## ANEXO X — EXEMPLOS NUMÉRICOS WORKED-OUT

A v17 trazia 8 exemplos numéricos completos (um por HC principal). Foram **mantidos como
referência de método**, com os códigos HC **remapeados** para a numeração v19.0+:

| # | Exemplo | HC na v17 | HC desde a v19.0 |
|---|---|---|---|
| X.1 | Taxa divergente da contratada | HC-01 | HC-01 |
| X.2 | Amortização negativa em renegociação | HC-08 | HC-08 |
| X.3 | Alocação predatória de pagamento | HC-03 | HC-03 |
| X.4 | Dívida perpétua RMC | HC-26 | **HC-29** |
| X.5 | IOF complementar indevido | HC-30 | **HC-33** |
| X.6 | Migração unilateral de cheque especial | HC-32 | **HC-35** |
| X.7 | Cessão a FIDC com taxa nova | HC-27 | **HC-30** |
| X.8 | Superendividamento + Tema 1.085 | HC-21 + HC-34 | HC-21 + **HC-37** |

> **Atenção ao ler laudos antigos:** documentos emitidos sob a linhagem v17 usam a
> numeração da coluna do meio. Sempre confira a versão da skill no cabeçalho do laudo antes
> de comparar códigos HC entre documentos.

---
