# Template: Checklist Due Diligence Jurídica

**USO**: Para due diligence em M&A, concessão de crédito, contratação de fornecedor crítico ou avaliação de parceiro estratégico. Adaptar escopo ao tipo de operação.

---

## IDENTIFICAÇÃO DA OPERAÇÃO

- **Empresa-alvo / Parte analisada**: _______________
- **Tipo de operação**: _______________
- **Data de início da DD**: _______________
- **Responsável**: _______________
- **Prazo de entrega**: _______________

---

## FRENTE 1: SOCIETÁRIA

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Contrato social / Estatuto consolidado | ☐ | ☐ | | |
| Última alteração arquivada na Junta | ☐ | ☐ | | |
| Quadro de sócios / acionistas atualizado | ☐ | ☐ | | |
| Acordo de sócios / acionistas | ☐ | ☐ | | |
| Atas de eleição de administradores vigentes | ☐ | ☐ | | |
| Procurações outorgadas | ☐ | ☐ | | |
| Livro de registro de sócios | ☐ | ☐ | | |
| Certidão simplificada da Junta Comercial | ☐ | ☐ | | |
| Estrutura societária (organograma) | ☐ | ☐ | | |
| Subsidiárias e coligadas | ☐ | ☐ | | |

---

## FRENTE 2: CONTRATUAL

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Contratos com clientes (top 10) | ☐ | ☐ | | |
| Contratos com fornecedores críticos | ☐ | ☐ | | |
| Contratos de prestação de serviços relevantes | ☐ | ☐ | | |
| Contratos de financiamento / crédito | ☐ | ☐ | | |
| Contratos de locação (imóveis) | ☐ | ☐ | | |
| Contratos de distribuição / representação | ☐ | ☐ | | |
| Contratos de tecnologia / SaaS / licença | ☐ | ☐ | | |
| Joint ventures e parcerias | ☐ | ☐ | | |
| Identificação de change of control clauses | ☐ | ☐ | | |

---

## FRENTE 3: TRABALHISTA

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Relação de empregados (cargo, salário, admissão) | ☐ | ☐ | | |
| Relação de terceirizados | ☐ | ☐ | | |
| Convenções e acordos coletivos vigentes | ☐ | ☐ | | |
| Planos de benefícios (PLR, previdência, saúde) | ☐ | ☐ | | |
| Relação de processos trabalhistas | ☐ | ☐ | | |
| Passivo trabalhista provisionado | ☐ | ☐ | | |
| Política de assédio / canal de denúncias | ☐ | ☐ | | |
| Contratos de diretores estatutários | ☐ | ☐ | | |

---

## FRENTE 4: TRIBUTÁRIA

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| CND Federal (Receita + PGFN) | ☐ | ☐ | | |
| CND Estadual | ☐ | ☐ | | |
| CND Municipal | ☐ | ☐ | | |
| CND FGTS | ☐ | ☐ | | |
| Regime tributário atual (Simples / LP / LR) | ☐ | ☐ | | |
| Contingências fiscais declaradas | ☐ | ☐ | | |
| Parcelamentos em andamento | ☐ | ☐ | | |
| Créditos fiscais (PIS/COFINS, ICMS) | ☐ | ☐ | | |
| ECF / ECD / SPED dos últimos 3 anos | ☐ | ☐ | | |

---

## FRENTE 5: CONTENCIOSA

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Relação de processos cíveis | ☐ | ☐ | | |
| Relação de processos trabalhistas | ☐ | ☐ | | |
| Relação de processos tributários / execuções fiscais | ☐ | ☐ | | |
| Relação de processos regulatórios / administrativos | ☐ | ☐ | | |
| Contingências provisionadas vs. estimativa jurídica | ☐ | ☐ | | |
| Decisões adversas relevantes transitadas em julgado | ☐ | ☐ | | |

---

## FRENTE 6: PROPRIEDADE INTELECTUAL

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Marcas registradas (INPI) | ☐ | ☐ | | |
| Pedidos de marca pendentes | ☐ | ☐ | | |
| Patentes e modelos de utilidade | ☐ | ☐ | | |
| Domínios registrados | ☐ | ☐ | | |
| Software proprietário — titularidade | ☐ | ☐ | | |
| Acordos de cessão de IP com ex-funcionários | ☐ | ☐ | | |
| Licenças de uso (inbound) | ☐ | ☐ | | |
| Licenças outorgadas (outbound) | ☐ | ☐ | | |

---

## FRENTE 7: PROTEÇÃO DE DADOS

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Política de privacidade | ☐ | ☐ | | |
| Inventário de dados pessoais tratados | ☐ | ☐ | | |
| DPAs com operadores | ☐ | ☐ | | |
| Histórico de incidentes de segurança | ☐ | ☐ | | |
| Reclamações de titulares em aberto | ☐ | ☐ | | |
| Relatório de impacto (RIPD), se aplicável | ☐ | ☐ | | |

---

## FRENTE 8: REGULATÓRIA / SETORIAL

| Item | Solicitado | Recebido | Status | Observação |
|---|---|---|---|---|
| Licenças e autorizações regulatórias vigentes | ☐ | ☐ | | |
| Histórico de autuações regulatórias | ☐ | ☐ | | |
| Obrigações regulatórias em curso | ☐ | ☐ | | |
| Pendências perante agência reguladora setorial | ☐ | ☐ | | |

---

## RESUMO DE RED FLAGS

| # | Frente | Achado | Nível | Impacto | Recomendação |
|---|---|---|---|---|---|
| 1 | | | 🔴/🟡/🟢 | | |
| 2 | | | | | |
| 3 | | | | | |

---

## STATUS CONSOLIDADO

- **Documentos solicitados**: ___
- **Documentos recebidos**: ___
- **Documentos pendentes**: ___
- **Red flags críticos**: ___
- **Recomendação para a operação**: [ ] Prosseguir | [ ] Prosseguir com condições | [ ] Suspender | [ ] Não prosseguir
