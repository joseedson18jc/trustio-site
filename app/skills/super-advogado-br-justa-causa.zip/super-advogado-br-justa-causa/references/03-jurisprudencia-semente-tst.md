# Jurisprudência semente do TST

> Base de localização verificada até 31/07/2026. Confirme status, inteiro teor, publicação e eventual superação antes do uso. Notícias não substituem acórdãos.

## Precedentes e enunciados estruturantes

### CLT art. 482 e art. 818

- Texto consolidado oficial define as hipóteses de justa causa e a distribuição geral do ônus.
- Em ação de reversão, a empresa normalmente sustenta fato impeditivo/extintivo e precisa provar a falta. A aplicação deve ser articulada com as alegações concretas e eventual distribuição dinâmica.

### TST. Antigo IRR Tema 196. Processo 0000227-95.2024.5.11.0008

- Tribunal Pleno, julgamento em 10/04/2026.
- Resultado metodológico: matéria desafetada do regime repetitivo, sem tese vinculante abstrata.
- Ponto útil: o TST reconheceu que dispensa sumária pode ser admissível quando a natureza da falta justificar, mas gravidade, confiança e proporcionalidade são avaliações fático-probatórias contextualizadas.
- Fonte oficial: Informativo TST nº 311 e acórdão do processo.

### Súmula 32 do TST. Abandono após benefício previdenciário

- Presunção específica de abandono quando o empregado não retorna nem justifica a ausência após a cessação do benefício, no período descrito pelo enunciado.
- Usar com cuidado em casos de limbo, comunicação defeituosa, contestação da alta ou prova de intenção contrária.

### Súmula 212 do TST. Ônus sobre o término contratual

- Útil quando são negadas prestação de serviços e despedimento, sob o princípio da continuidade.
- Não substitui a análise específica do ônus da falta grave.

### Súmula 379 do TST. Dirigente sindical

- A resolução por falta grave de dirigente sindical depende de inquérito judicial, nos termos do enunciado e regras legais aplicáveis.
- Confirmar a proteção, comunicação da candidatura/eleição e período de estabilidade.

### Súmula 443 do TST. Dispensa discriminatória

- Presunção em hipóteses de doença grave que suscite estigma ou preconceito, com direito à reintegração conforme o caso.
- Em justa causa, testar se a falta foi comprovada ou usada como pretexto discriminatório.

## Casos oficiais úteis por tese

### Imediatidade e apuração

- **“11 dias entre falta e punição não presumem perdão tácito”**, notícia oficial do TST. Ponto: o tempo razoável depende da complexidade e dos atos reais de apuração.
- **“Justa causa é anulada por ter sido aplicada quatro meses depois da falta”**, notícia oficial de 29/05/2025. Ponto: demora sem justificativa suficiente pode caracterizar perdão tácito.

Use os dois lados para evitar regra mecânica.

### Prova robusta e acusação não comprovada

- **Distribuidora indenizará repositor demitido por furto não comprovado**, TST, 09/06/2020. Ponto de pesquisa: acusação grave, insuficiência da prova e possível dano decorrente da imputação.
- **Empregado que acessou computador do diretor consegue reverter justa causa**, notícia oficial. Ponto de pesquisa: ausência de prova robusta para pena máxima.
- **Turma do TST admite multa em caso de falsa justa causa**, notícia oficial de 19/05/2006. Verificar o acórdão e o fundamento processual antes de usar.

### Atestado ou documento médico

- **Assistente demitido por erro de médico no preenchimento de atestado receberá indenização**, TST, 11/05/2016. Ponto: erro do emissor e inexistência de improbidade atribuível ao empregado.
- **Mantida reversão de justa causa de professora que falsificou horário em atestado**, TST, 01/02/2018. Ponto: mesmo havendo alteração, proporcionalidade e circunstâncias concretas podem alterar o resultado. Ler o caso integral.
- **Propagandista com exame falso de Covid não reverte justa causa**, TST, 20/05/2024. Ponto: uso consciente de documento falso pode ser falta grave suficiente.
- **Mantida justa causa após atestado falso e rasurado**, notícia institucional de 05/03/2026 sobre julgamento regional. Usar apenas como pista até obter acórdão oficial.
- **SDI-1 mantém justa causa por atestados médicos falsos**, notícia oficial. Localizar processo e inteiro teor.

A matriz correta é: existência do documento, alteração, autoria, ciência, intenção, vantagem, original, cadeia de custódia, explicação alternativa e gravidade.

### Abandono e benefício

- **Volta ao trabalho um ano após fim de invalidez é considerada abandono**, TST, 23/02/2024. Comparar com a Súmula 32 e com comunicações do caso.
- **Anulada justa causa após alta previdenciária**, TST, 15/01/2021. Ponto: prova do contexto e da intenção é decisiva.

### Dependência e saúde

- **Dependência de álcool afasta justa causa**, TST, 20/05/2011. Pesquisar linha atual sobre alcoolismo como doença e dever de tratamento, sem generalizar para toda conduta sob influência.
- **Justa causa durante auxílio-doença pode ser válida**, SDI-2/TST, notícia de 10/07/2024. Estabilidade ou suspensão contratual não imunizam falta grave comprovada.

## Como usar esta semente

1. Pesquise pelo título no domínio oficial do TST.
2. Extraia número do processo.
3. Abra acórdão e decisão regional quando necessário.
4. Confirme se o TST julgou mérito ou apenas incidência da Súmula 126, transcendência, deserção ou outro óbice.
5. Não atribua ao TST conclusão fática que veio apenas do TRT sem esclarecer isso.
6. Registre precedente contrário e distinções.
