#!/usr/bin/env python3
"""Validador estrutural local do padrão Agent Skills e referências relativas."""
from __future__ import annotations
import argparse, re, sys
from pathlib import Path

NAME_RE = re.compile(r'^[a-z0-9]+(?:-[a-z0-9]+)*$')
LINK_RE = re.compile(r'\[[^\]]+\]\(([^)]+)\)')

def parse_frontmatter(text: str):
    if not text.startswith('---\n'):
        raise ValueError('SKILL.md deve começar com frontmatter YAML')
    end = text.find('\n---\n', 4)
    if end < 0: raise ValueError('Frontmatter sem fechamento')
    raw = text[4:end]
    data = {}
    current = None
    for line in raw.splitlines():
        if not line.strip() or line.lstrip().startswith('#'): continue
        if line.startswith('  ') and current == 'metadata':
            continue
        if ':' in line and not line.startswith(' '):
            k,v = line.split(':',1); data[k.strip()] = v.strip().strip('"\'')
            current = k.strip()
    return data, text[end+5:]

def main() -> int:
    ap = argparse.ArgumentParser(description='Valida estrutura básica de uma Agent Skill.')
    ap.add_argument('skill_dir', nargs='?', default='.')
    args = ap.parse_args()
    root = Path(args.skill_dir).resolve(); skill = root/'SKILL.md'
    errors=[]; warnings=[]
    if not skill.exists(): errors.append('SKILL.md ausente')
    else:
        text=skill.read_text(encoding='utf-8')
        try: meta, body=parse_frontmatter(text)
        except ValueError as exc: errors.append(str(exc)); meta={}; body=''
        name=meta.get('name',''); desc=meta.get('description','')
        if not name: errors.append('name ausente')
        elif not NAME_RE.fullmatch(name): errors.append('name inválido')
        elif root.name != name: errors.append(f'name {name!r} não corresponde à pasta {root.name!r}')
        if not desc: errors.append('description ausente')
        if len(name)>64: errors.append('name excede 64 caracteres')
        if len(desc)>1024: errors.append('description excede 1024 caracteres')
        if len(text.splitlines())>500: warnings.append('SKILL.md excede recomendação de 500 linhas')
        for target in LINK_RE.findall(body):
            if '://' in target or target.startswith('#'): continue
            p=(root/target).resolve()
            if root not in p.parents and p != root: errors.append(f'referência sai da skill: {target}')
            elif not p.exists(): errors.append(f'referência ausente: {target}')
    for p in root.rglob('*'):
        if p.is_file() and p.stat().st_size == 0: warnings.append(f'arquivo vazio: {p.relative_to(root)}')
    result={'ok': not errors, 'errors': errors, 'warnings': warnings}
    import json; print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1

if __name__ == '__main__':
    raise SystemExit(main())
