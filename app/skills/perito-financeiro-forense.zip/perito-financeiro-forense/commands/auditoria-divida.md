---
description: Auditoria forense de dívida bancária PF — recálculo de saldo devedor, detecção de cobranças indevidas e laudo auditável
argument-hint: "<pasta ou arquivos: extratos, contratos, faturas, termos de renegociação>"
---

<!-- pff-version: 21.0 -->
# /auditoria-divida

Executa a perícia completa da skill **perito-financeiro-forense** (v21.0) sobre os arquivos indicados.
Não constitui parecer jurídico — os achados devem ser validados por advogado antes de uso judicial ou extrajudicial.

## Uso

```
/auditoria-divida <arquivos ou pasta>
```

Aceita qualquer quantidade de PDFs (extratos mensais, demonstrativos de evolução, CCB/contratos, aditivos,
termos de renegociação, faturas de cartão, comprovantes), além de CSV/XLSX/OFX como complemento.
Informações opcionais que melhoram a precisão: taxa contratada, sistema de amortização, CET informado, renda
líquida (para margem consignável e mínimo existencial), existência de ações judiciais anteriores.

## O que acontece

1. **Integridade:** `python3 scripts/verificar_integridade.py` — se falhar, o usuário é avisado.
2. **Estágio 0 — Ingestão:** `python3 scripts/extrair_pdfs.py <entrada> -o <saida>` → catálogo, timeline,
   duplicatas, lacunas, texto com OCR de reserva, lançamentos e linhas de tabela pré-parseados, testes V1/V2.
   Entrega: catálogo + lacunas, para o usuário confirmar que o conjunto está completo.
3. **Estágios 1–2 — Inventário e fases:** classificação das linhas, score de qualidade, mapa de fases com
   validação de cada transição e triagem de produtos especiais (§2.4).
4. **Estágio 3 — Análise:** recálculo linha a linha, inferência de taxa/sistema, CET regulatório, checagem
   regulatória completa e testes §5-T1/T2/T3 com `scripts/pericia.py`; comparação banco × recalculado.
5. **Estágio 4 — Entrega:** sumário executivo, relatório técnico, Tabelas 1–9 em XLSX, cenários e
   sensibilidade, lista de documentos a solicitar, após a revalidação datada das normas voláteis.

Todo o detalhamento (contagens, itens, fórmulas, normas) vive no `SKILL.md` e nas references — este comando
não o repete de propósito, para que os arquivos nunca divirjam entre si.
