# Plugin: Crédito Trabalhista na Recuperação Judicial e na Falência

> **Base verificada em 07/10/2026.** Texto da Lei 11.101/2005 conferido no planalto.gov.br (redação compilada com a Lei 14.112/2020; nenhuma alteração posterior nos dispositivos tratados aqui). Itens marcados **C3** não foram confirmados em fonte oficial nesta sessão: descrever o entendimento, **não citar número**. 🔄 = volátil; ⛔ = erro comum.

**Quando carregar**: crédito trabalhista contra empregador em recuperação judicial (RJ) ou falência; habilitação, divergência, impugnação ou retardatária; competência entre a Justiça do Trabalho (JT) e o juízo universal; stay period; classificação, limite de 150 SM, extraconcursalidade; execução contra tomador subsidiário, grupo econômico ou sócios de empregadora insolvente; multas dos arts. 467 e 477 da CLT nesse contexto. Combinar com `plugin-trabalhista.md` (verbas, atualização) e `plugin-contencioso.md` (execução, IDPJ).

---

## 1. Base normativa (Lei 11.101/2005 — "LRF")

### 1.1 Créditos sujeitos e não sujeitos à RJ
- **Art. 49, caput**: sujeitam-se à RJ todos os créditos **existentes na data do pedido**, ainda que não vencidos. **§1º**: o credor conserva seus direitos contra coobrigados, fiadores e obrigados de regresso. **§2º**: valem as condições originais, inclusive encargos, salvo disposição diversa do plano. §§3º e 4º: excluem o proprietário fiduciário, o arrendador mercantil e outros, além do ACC.
- **Critério temporal — STJ, Tema Repetitivo 1.051** (C1): REsp 1.843.332/RS, 1.842.911/RS, 1.843.382/RS, 1.840.812/RS e 1.840.531/RS; 2ª Seção; Rel. Min. Ricardo Villas Bôas Cueva; j. 09/12/2020; DJe 17/12/2020; **transitado** (23/02/2021; 25/05/2021 para o REsp 1.840.812). Tese: *"Para o fim de submissão aos efeitos da recuperação judicial, considera-se que a existência do crédito é determinada pela data em que ocorreu o seu fato gerador."*
- **Aplicação trabalhista**: o fato gerador é a **prestação do serviço ou o evento** (dispensa, acidente), não a sentença nem o trânsito. Serviço prestado antes do pedido gera crédito **concursal** (Classe I), mesmo que a sentença venha depois. Serviço prestado após o pedido gera crédito **extraconcursal**, que fica fora do plano.

### 1.2 Classe I na RJ e na falência
- **RJ — art. 41, I e §1º**: a Classe I reúne créditos derivados da legislação do trabalho e de acidentes de trabalho; o credor **vota pelo total do crédito, independentemente do valor**.
- **Art. 54, caput**: o plano **não pode prever prazo superior a 1 ano** para os créditos trabalhistas e acidentários **vencidos até a data do pedido**.
- **Art. 54, §1º**: no máximo **30 dias** para pagar, **até 5 SM por trabalhador**, os créditos **estritamente salariais** vencidos nos **3 meses anteriores** ao pedido.
- **Art. 54, §2º**: o prazo do caput pode ir a **até 2 anos** se o plano cumprir, **cumulativamente**, três requisitos: (I) garantias julgadas suficientes pelo juiz; (II) aprovação pela Classe I na forma do art. 45, §2º; (III) **garantia da integralidade** do pagamento dos créditos trabalhistas.
- **Falência — art. 83, I**: créditos trabalhistas **limitados a 150 SM por credor** e créditos de acidente de trabalho (**sem limite**). **Art. 83, VI, "c"**: o **excedente** de 150 SM vira **quirografário**.
- **Art. 151**: na falência, os créditos estritamente salariais dos 3 meses anteriores à decretação, até 5 SM por trabalhador, são pagos **assim que houver caixa**. Pelo **art. 84, I-A**, eles são extraconcursais e pagos antes de tudo.
- Constitucionalidade do limite de 150 SM: o STF rejeitou a impugnação em controle concentrado contra a redação original (C3 — confirmar número e data da ADI antes de citar).
- 🔄 **Limite de 150 SM dentro do plano de RJ**: há entendimento admitindo que o plano preveja limite semelhante, tratando o excedente como quirografário (C3 — verificar o estado atual no STJ).

### 1.3 Extraconcursais (art. 84, redação da Lei 14.112/2020)
São pagos antes do art. 83, na seguinte ordem:
- **I-A**: arts. 150 e 151;
- **I-B**: financiamento DIP;
- **I-C**: restituições em dinheiro;
- **I-D**: remuneração do AJ e **créditos trabalhistas e acidentários por serviços prestados após a decretação da falência**;
- **I-E**: obrigações de atos válidos praticados **durante a RJ** (art. 67) ou após a falência;
- depois, os incisos II a V.

Consequência prática: o trabalho prestado **durante a RJ** que não for pago entra no I-E se houver convolação em falência.

### 1.4 Competência
- **Art. 6º, §2º**: o pedido de habilitação, exclusão ou modificação **pode ser feito ao AJ**. Já as **ações trabalhistas**, inclusive as impugnações do art. 8º, tramitam na **JT até a apuração do crédito**, que entra no QGC **pelo valor da sentença**. **§3º**: o juiz trabalhista pode determinar **reserva** do valor estimado.
- **Art. 76**: o juízo da falência é indivisível, **ressalvadas as causas trabalhistas**.
- **Art. 6º, III**: fica **proibida qualquer constrição** sobre bens do devedor por créditos sujeitos ao concurso. Em regra, portanto, a **JT não penhora** por crédito concursal, que é satisfeito pelo plano ou pelo rateio.
- **Crédito extraconcursal — STJ, CC 191.533/MT** (C1): 2ª Seção; Rel. Min. Marco Aurélio Bellizze; j. 18/04/2024; DJe 26/04/2024. Após a Lei 14.112/2020 (art. 6º, §7º-A), o juízo da RJ **só pode suspender constrições sobre bens de capital essenciais, e apenas durante o stay**. Esgotado o stay, a execução do crédito extraconcursal **segue na JT**, que deve observar a menor onerosidade e cooperar com o juízo recuperacional. 🔄 Confirmar se há julgado posterior em sentido diverso.
- **§11 do art. 6º**: nas execuções de ofício da JT (contribuições previdenciárias — art. 114, VIII, da CF) é **vedada a expedição de certidão** para habilitação. O tratamento é o do §7º-B.

### 1.5 Stay period
- **Art. 6º, I a III**: suspende a prescrição e as execuções e proíbe constrições.
- **Art. 6º, §4º**: o stay dura **180 dias** contados do deferimento do processamento, **prorrogável uma única vez por igual período**, em caráter excepcional, desde que o devedor não tenha contribuído para o atraso.
- **Art. 6º, §4º-A**: se o prazo vencer sem deliberação sobre o plano, os credores podem apresentar **plano alternativo** em 30 dias. Sem plano alternativo, a proteção cessa.
- **Art. 6º, §5º**: o §2º (competência da JT para apurar o crédito) aplica-se durante o stay.
- 🔄 Prorrogações além do limite legal ainda aparecem em decisões de origem; a posição atual do STJ sobre a rigidez do prazo após 2020 está em C3.

### 1.6 Verificação de créditos (arts. 7º a 20)
| Ato | Prazo | Base |
|---|---|---|
| Habilitação ou divergência **perante o AJ** | **15 dias** do edital do art. 52, §1º (RJ) ou do art. 99, §1º (falência) | art. 7º, §1º |
| Publicação da relação do AJ | 45 dias após o fim do prazo anterior | art. 7º, §2º |
| **Impugnação judicial** à relação do AJ | **10 dias** da publicação | art. 8º |
| Contestação do impugnado | 5 dias | art. 11 |
| Manifestação do devedor e do Comitê; depois, parecer do AJ | 5 + 5 dias | art. 12 |
| Recurso contra a decisão da impugnação | agravo | art. 17 |
| Objeção ao plano | 30 dias da relação do art. 7º, §2º | art. 55 |

- **Art. 9º**: a habilitação deve trazer nome e endereço, **valor atualizado até a data do pedido de RJ ou da decretação da falência**, origem, classificação e documentos.
- **Retardatária — art. 10**:
  - em regra, o retardatário **perde o voto na AGC**, **exceto o credor trabalhista na RJ** (§1º);
  - na falência, perde os rateios já feitos e paga custas, sem os acessórios do intervalo (§3º), mas pode pedir **reserva** (§4º);
  - se apresentada **antes da homologação do QGC**, é processada como impugnação (§5º); **depois**, só por ação de retificação do QGC no juízo universal pelo rito comum (§6º);
  - gera **reserva** (§8º);
  - a RJ pode ser encerrada sem QGC definitivo, e os incidentes são redistribuídos como ações autônomas (§9º);
  - ⛔ **falência**: prazo **decadencial de 3 anos** da publicação da sentença de quebra para habilitar ou pedir reserva (§10).
- **Art. 19**: ação para excluir ou retificar crédito por falsidade, dolo, fraude ou erro essencial, até o encerramento. Quando o crédito veio da JT, a ação corre **no juízo que o reconheceu** (§1º).
- **Papel do AJ (art. 22, I)**: avisa cada credor da natureza, valor e classificação do crédito; fornece extratos dos livros; elabora a relação do art. 7º, §2º; consolida o QGC.

### 1.7 Atualização
- **Crédito concursal na RJ**: atualizado **até a data do pedido** (art. 9º, II). Os encargos posteriores seguem o **plano** (art. 49, §2º, e art. 59 — novação).
- **Falência**: corre até a decretação. Depois dela, **não são exigíveis juros contra a massa se o ativo não pagar os subordinados** (art. 124), e esses juros ficam no inciso IX do art. 83.
- **Índice até o marco do concurso**: aplicam-se o regime da ADC 58/59 e, a partir de 30/08/2024, a **Lei 14.905/2024** (IPCA + taxa legal = Selic − IPCA, com resultado negativo considerado zero; art. 406, §§1º e 3º, do CC — C1, planalto). Detalhes no §8.6 do `plugin-trabalhista.md` (C2).
- A forma de conciliar a Selic pós-ajuizamento da ADC 58 com o corte do art. 9º, II, está em C3 — verificar a orientação do STJ e do TST.

### 1.8 Cessão do crédito trabalhista
- **Art. 83, §5º (incluído pela Lei 14.112/2020, vigente)**: créditos **cedidos a qualquer título mantêm natureza e classificação**.
- ⛔ A regra antiga, que convertia o crédito trabalhista cedido em quirografário (antigo §4º), foi **revogada**.
- Pontos a verificar no caso: o direito de voto do cessionário na Classe I e a aplicação do limite de 150 SM ao cessionário (C3).

### 1.9 Responsabilidade de terceiros
- **Art. 6º-C**: é vedado atribuir responsabilidade a terceiros pelo **mero inadimplemento** do devedor em RJ ou falido, ressalvadas as garantias reais e fidejussórias e as hipóteses da própria lei. O efeito desse dispositivo sobre a responsabilidade subsidiária trabalhista está em C3.
- **Tomador (Súmula 331, IV e VI, do TST)**: vigente (C2, ver `plugin-trabalhista.md` §3). **TST, IRR Tema 133** (C1): Pleno; Rel. Min. Aloysio Corrêa da Veiga; acórdão de 16/05/2025 (reafirmação de jurisprudência). Tese: *"A constatação do inadimplemento do devedor principal autoriza o redirecionamento da execução para o subsidiário independentemente do exaurimento da execução contra o obrigado principal e seus sócios, salvo na hipótese de indicação de bens do devedor principal que efetiva e comprovadamente bastem para satisfazer integralmente a execução."* Entre os precedentes do acórdão há caso de devedor principal **em RJ**. A RJ do empregador **não impede** a execução contra o subsidiário.
- **STJ, Súmula 581** (C1; DJe 19/09/2016): a RJ do devedor principal não impede o prosseguimento das ações contra coobrigados por garantia cambial, real ou fidejussória. Serve de **reforço por analogia**; não trata do tomador trabalhista.
- **Grupo econômico — STF, Tema 1.232 (RE 1.387.795)** (C1 via ofício oficial do TRT-3; ata publicada em 20/10/2025):
  - (1) a execução **não alcança** empresa que não participou da fase de conhecimento; o autor deve indicar **na inicial** as corresponsáveis, inclusive do grupo econômico, e demonstrar concretamente os requisitos;
  - (2) o redirecionamento é excepcional, só em **sucessão (art. 448-A da CLT)** ou **abuso da personalidade (art. 50 do CC)**, via IDPJ (art. 855-A da CLT; arts. 133 a 137 do CPC);
  - (3) vale também para redirecionamentos anteriores a 2017, ressalvados os casos já transitados, os créditos satisfeitos e as execuções findas ou arquivadas;
  - 🔄 verificar embargos e trânsito.
- **Sócios — TST, IRR Tema 26** (C1): Pleno; Rel. Min. Amaury Rodrigues Pinto Junior; j. 08/05/2026.
  - (1) a JT é competente, **mesmo após a Lei 14.112/2020**, para o IDPJ contra empresa **em RJ**, **salvo ordem expressa do juízo recuperacional** suspendendo atos contra os sócios;
  - (2) a desconsideração exige **abuso (art. 50 do CC)**; mero inadimplemento, insuficiência patrimonial ou frustração da execução **não bastam**;
  - 🔄 trânsito não verificado.
- **Falência**: a desconsideração da falida **só pelo juízo falimentar** (art. 82-A, parágrafo único), observados o art. 50 do CC e os arts. 133 a 137 do CPC.
- **UPI e alienação de ativos**: **não há sucessão trabalhista** do arrematante (art. 60, parágrafo único, e art. 141, II), salvo arrematante ligado ao devedor ou agente de fraude (art. 141, §1º).

### 1.10 Multas dos arts. 467 e 477, §8º, da CLT
- **Súmula 388 do TST** (texto conferido em acórdãos do TST): *a massa falida não se sujeita à penalidade do art. 467 nem à multa do §8º do art. 477 da CLT.*
- **Não se estende à RJ** (C1, jurisprudência reiterada citada em acórdãos do TST): RR-255100-86.2008.5.02.0068 (6ª T., Rel. Min. Kátia Magalhães Arruda, DEJT 11/11/2016); RR-91900-78.2008.5.01.0051 (3ª T., Rel. Min. Mauricio Godinho Delgado, DEJT 08/04/2016). Fundamento: a empresa em RJ mantém a administração dos seus bens, o que não ocorre na falência (art. 103).
- **Falência posterior à rescisão**: as multas são devidas, porque a Súmula 388 só incide quando a quebra antecede o prazo de pagamento (C1 quanto à orientação; conferir a data da rescisão e a da decretação).
- Na falência, as multas devidas entram na **classificação própria**. Saber se a multa do art. 477 é Classe I ou classe VII ("multas contratuais e penas pecuniárias") é discussão C3.

### 1.11 Votação do plano e cram down
- **Art. 45, caput**: todas as classes devem aprovar o plano. **§2º**: na Classe I, decide a **maioria simples dos credores presentes, por cabeça, independentemente do valor**. **§3º**: quem não sofre alteração no valor ou nas condições do crédito **não vota**.
- **Art. 45-A**: a assembleia pode ser substituída por termos de adesão.
- **Cram down — art. 58, §1º**: os requisitos são cumulativos:
  - (I) mais da metade do valor de todos os créditos presentes;
  - (II) aprovação de 3 classes; se só houver 3 classes votantes, de 2; se só houver 2, de 1;
  - (III) na classe que rejeitou, voto favorável de **mais de 1/3** dos credores;
  - **§2º**: sem tratamento diferenciado dentro da classe que rejeitou.
- Rejeitado o plano sem cram down possível → **falência** (art. 58-A).
- Descumprimento do plano durante a supervisão (até 2 anos — art. 61) → convolação em falência (art. 73, IV).

---

## 2. Fluxos práticos

**(1) Reclamação ainda não ajuizada, empresa em RJ**
1. Datar o fato gerador de cada verba (Tema 1.051) e separar o que é **concursal** do que é **extraconcursal**.
2. Ajuizar na **JT** (art. 6º, §2º), incluindo a recuperanda e, desde a inicial, tomadores e empresas do grupo, com os requisitos demonstrados (Tema 1.232).
3. Pedir **reserva** ao juízo trabalhista (art. 6º, §3º) e comunicar a reserva ao juízo da RJ.
4. Pedir as multas dos arts. 467 e 477 (Súmula 388 inaplicável à RJ).
5. Paralelamente, conferir se o crédito consta da lista do devedor (art. 52, §1º, II) e apresentar **divergência ao AJ em 15 dias**.

**(2) Sentença líquida já obtida**
1. Na parte concursal, obter **certidão de crédito** na JT com valor atualizado **até a data do pedido** (art. 9º, II) e discriminação de principal, verbas e natureza.
2. Habilitar perante o AJ, se ainda estiver no prazo do art. 7º, §1º. Fora do prazo e antes do QGC: habilitação retardatária no juízo da RJ (art. 10, §5º), que **não tira o voto do trabalhista**.
3. Na parte extraconcursal, executar **na JT**; durante o stay, a única ressalva são os bens de capital essenciais (CC 191.533).
4. Ao mesmo tempo, redirecionar ao **subsidiário** (IRR 133) e, havendo abuso, instaurar **IDPJ** (IRR 26).

**(3) Crédito não listado ou listado a menor**
1. Antes da relação do AJ: **divergência administrativa** (art. 7º, §1º).
2. Depois da relação: **impugnação** em 10 dias (art. 8º), com cálculo, sentença e certidão. Se a impugnação exigir apuração de mérito trabalhista, ela tramita na JT (art. 6º, §2º).
3. Contra a decisão: **agravo** (art. 17), com pedido de efeito suspensivo para garantir o voto em AGC.
4. Após a homologação do QGC: ação de retificação (art. 10, §6º).

**(4) Falência decretada**
1. Habilitar ou pedir reserva em até **3 anos** da sentença (art. 10, §10). Não esperar o QGC.
2. Separar as parcelas em quatro grupos:
   - salariais dos 3 meses até 5 SM (art. 151 e art. 84, I-A);
   - **Classe I até 150 SM** (art. 83, I);
   - excedente **quirografário** (VI, "c");
   - serviços prestados após a quebra → extraconcursais (art. 84, I-D).
3. Multas 467 e 477: verificar se a rescisão foi anterior à quebra (Súmula 388).
4. A desconsideração da falida só pode ser pedida no **juízo falimentar** (art. 82-A). Contra o tomador, a execução segue na JT.

---

## 3. Checklist documental e de prazos
- [ ] Data do **pedido de RJ** e data do **deferimento do processamento** (que dá início ao stay)
- [ ] **Edital do art. 52, §1º** ou do art. 99, §1º → termo inicial dos **15 dias** (art. 7º, §1º)
- [ ] Edital da relação do AJ (art. 7º, §2º) → **10 dias** para impugnar e **30 dias** para objetar ao plano
- [ ] CTPS, TRCT, contracheques, extrato do FGTS e comunicação de dispensa (datas de fato gerador)
- [ ] Sentença, acórdão, certidão de trânsito e **cálculos homologados**; certidão de crédito com corte na data do pedido ou da quebra
- [ ] Planilha que separa concursal de extraconcursal, salarial dos 3 meses (até 5 SM) e excedente de 150 SM
- [ ] Procuração com poderes para habilitar, votar em AGC e assinar termo de adesão (art. 45-A)
- [ ] Contratos com o tomador e prova de grupo econômico (para a inicial — Tema 1.232)
- [ ] Prazo decadencial de 3 anos na falência (art. 10, §10)
- [ ] Cronograma do plano: **30 dias** (salariais até 5 SM) e **1 ano** (2 anos só com os requisitos do §2º do art. 54)

---

## 4. Pontos de verificação obrigatória (antes de qualquer peça)
1. **Edital do art. 52, §1º**: data, valor e classificação atribuídos ao cliente.
2. **Relação do AJ** (art. 7º, §2º) e eventual **QGC homologado**.
3. **Plano aprovado ou homologado**: prazos e deságio da Classe I e eventual limite em SM, conferidos contra o art. 54. Verificar também cram down, aditivos e o termo de supervisão (art. 61).
4. **Decisão de prorrogação do stay**: verificar se houve prorrogação, se ela é a única e se o devedor concorreu para o atraso (art. 6º, §4º). Verificar ainda se há ordem expressa do juízo da RJ sobre atos contra sócios ou bens essenciais.
5. **Salário mínimo vigente**: em 2026, **R$ 1.621,00** (Decreto 12.797/2025 — C1). Com ele, 150 SM = R$ 243.150,00 e 5 SM = R$ 8.105,00. 🔄 Qual SM serve de base para o limite (data da quebra ou do pagamento) é questão C3; confirmar no QGC e na jurisprudência local.
6. Situação atual do processo: houve **convolação em falência**? A RJ foi **encerrada**?
7. Status dos precedentes: Tema 1.232/STF e IRR 26 e 133/TST (embargos ou trânsito).

---

## 5. Erros comuns
1. ⛔ Usar a **data da sentença** trabalhista para definir se o crédito se sujeita à RJ (o critério é o fato gerador — Tema 1.051).
2. ⛔ Pedir **penhora na JT por crédito concursal** durante a RJ (art. 6º, III).
3. ⛔ Arquivar a execução de crédito **extraconcursal** e mandar o credor habilitar (CC 191.533).
4. ⛔ Aplicar a **Súmula 388** a empresa **em RJ**.
5. ⛔ Aplicar o teto de **150 SM** a crédito de **acidente de trabalho** ou como regra legal da RJ (é regra da falência, art. 83, I).
6. ⛔ Tratar o crédito trabalhista **cedido** como quirografário (art. 83, §5º, vigente).
7. ⛔ Dizer que o retardatário trabalhista **perde o voto na RJ** (art. 10, §1º, o preserva).
8. ⛔ Ignorar o prazo **decadencial de 3 anos** na falência (art. 10, §10).
9. ⛔ Incluir na execução empresa do grupo **que não participou da fase de conhecimento** fora das hipóteses do Tema 1.232.
10. ⛔ Desconsiderar a personalidade da recuperanda por **mero inadimplemento** (IRR 26) ou desconsiderar a **falida** na JT (art. 82-A).
11. ⛔ Atualizar o crédito concursal **além da data do pedido** na habilitação (art. 9º, II).
12. ⛔ Admitir prazo de 2 anos no plano **sem** garantias suficientes, aprovação da Classe I e pagamento integral (art. 54, §2º).
