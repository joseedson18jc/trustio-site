# Plugin: Direito do Trabalho Avançado

> **Base de conhecimento fechada em 03/08/2026; itens marcados "(atualizado 07/10/2026)" foram revistos nessa data — ver `radar-normativo.md`.** Todo item marcado 🔄 é volátil: confirmar em fonte oficial antes de usar em peça, parecer ou cálculo. Todo item marcado ⛔ é erro comum — não repetir.

## Ativar quando
Vínculo empregatício, pejotização, terceirização, rescisão, verbas, jornada, saúde e segurança (NR), assédio, passivo trabalhista, compliance trabalhista, negociação coletiva, teletrabalho, trabalho por plataformas, cálculo de contingência ou execução trabalhista.

---

## 1. Sequência obrigatória de análise

1. **Vínculo**: existe? qual natureza (CLT, autônomo, PJ, intermitente, doméstico, cooperado, plataforma)?
2. **Modalidade contratual e jornada** aplicáveis.
3. **Verbas** devidas por modalidade de extinção + reflexos.
4. **Estabilidades e garantias** de emprego.
5. **Riscos de recaracterização** (pejotização, terceirização ilícita, quarteirização, contratação por parceria).
6. **Exposição regulatória**: fiscalização do trabalho, eSocial/DET, NRs, FGTS Digital, autuação.
7. **Regime de atualização e honorários** aplicável ao período do crédito.
8. **Estado do precedente**: o tema está suspenso, afetado ou pacificado? (ver §8)

---

## 2. Elementos do vínculo — arts. 2º e 3º da CLT

- **Pessoalidade** — prestação *intuitu personae*.
- **Não eventualidade** — habitualidade/permanência.
- **Subordinação** — jurídica; discute-se subordinação estrutural e algorítmica.
- **Onerosidade** — contraprestação.

Os quatro elementos são **cumulativos**; a ausência de qualquer um afasta o vínculo. A **alteridade** (art. 2º — risco da atividade pelo empregador) é elemento de reforço.

⚠️ **Regra de ouro pós-2025**: a análise não pode parar nos quatro elementos. É preciso confrontar o caso com a jurisprudência do STF sobre **licitude das formas alternativas de contratação** (ADPF 324, Tema 725, ADI 5625) e com o estado do **Tema 1389** (§7.2).

---

## 3. Reforma trabalhista (Lei 13.467/2017) — pontos críticos

| Instituto | Base | Nota crítica |
|---|---|---|
| Contrato intermitente | arts. 443, §3º, e 452-A | Convocação com **3 dias corridos** de antecedência; resposta em 1 dia útil. ⛔ Não citar multa de 50% por descumprimento nem período de inatividade remunerado: vinham da **MP 808/2017, que caducou em 23/04/2018**. |
| Teletrabalho | arts. 75-A a 75-F | Redação atual decorre da **Lei 14.442/2022**: teletrabalho por jornada sujeito a controle; por produção/tarefa, fora do Capítulo II do Título II. Prioridade a PcD e a quem tem filho até 4 anos. |
| Autônomo exclusivo | art. 442-B | Contratação regular **não gera vínculo por si só** — mas não blinda contra fraude comprovada. |
| Banco de horas | art. 59, §§5º e 6º | Acordo **individual escrito**: compensação em até **6 meses**. **Coletivo**: até **12 meses**. Compensação no mesmo mês admite acordo individual tácito. |
| Negociado sobre legislado | arts. 611-A e 611-B | O art. 611-B lista os **direitos indisponíveis** (limite). Aplicar sempre com o **Tema 1046/STF**. |
| Ultratividade | art. 614, §3º | Vedada. **Súmula 277 do TST cancelada** (Res. TST 225/2025). |
| Prescrição intercorrente | art. 11-A | Prazo de **2 anos** na execução. **Súmula 114 do TST cancelada**. Efeitos intertemporais **pendentes** (IRR Tema 39). |
| Jornada 12x36 | art. 59-A | **Súmula 444 do TST cancelada**. Feriados em dobro no 12x36 sob o Tema 1046: **pendente** (IRR Tema 152). |
| Horas *in itinere* | art. 58, §2º | Não são mais tempo à disposição. **Súmulas 90, 320, 429 e 449 canceladas**. Confirmado nos IRR **Temas 50** (petroleiros) e **172** (rural). |
| Intervalo intrajornada | art. 71, §4º | Supressão parcial gera pagamento **só do período suprimido**, com 50%, de **natureza indenizatória**. **Súmula 437 cancelada**. |
| Aplicação no tempo | — | **IRR Tema 23 do TST** (j. 25/11/2024): *"A Lei nº 13.467/2017 possui aplicação imediata aos contratos de trabalho em curso, passando a regular os direitos decorrentes de lei cujos fatos geradores tenham se efetivado a partir de sua vigência."* |

### ⚠️ Resolução TST nº 225, de 30/06/2025 — o ato mais impactante do período
O Pleno do TST **cancelou 27 súmulas/itens + 5 OJs da SBDI-1 + a OJ Transitória 36 + a OJ 16 da SDC + a OJ 13 do Pleno/Órgão Especial + o Precedente Normativo 100**, por perda de eficácia.

- Súmulas canceladas (íntegra ou itens): **6** (I, II, VI "b", X), **90**, **114**, **152**, **219**, **228**, **268**, **277**, **294**, **307**, **311**, **320**, **329**, **331 (item I)**, **366**, **372 (I)**, **375**, **377**, **423**, **426**, **429**, **437**, **439**, **444**, **449**, **450**, **452**.
- **Marco da perda de eficácia** (não é a data da resolução): **11/11/2017** para as incompatíveis com a Lei 13.467/2017; **14/06/2022** (ata do Tema 1046) para as Súmulas 375 e 423; **09/12/2021** (ADC 58/ADI 5867) para 307, 311 e 439; **15/08/2022** (ADPF 501) para a 450; **18/04/2018** (Rcl 6266) para a 228.
- ⛔ **A Súmula 331 permanece vigente nos itens II a VI** — só o item I foi cancelado. A responsabilidade **subsidiária** da tomadora (item IV) continua de pé.
- ⛔ **Nenhuma súmula nova foi editada pelo TST entre 2023 e ago/2026.** A de maior número segue sendo a **463**. Nunca citar "Súmula 464" ou superior.

---

## 4. Verbas rescisórias — referência corrigida

| Modalidade | Aviso prévio | Saldo | Férias vencidas +1/3 | Férias prop. +1/3 | 13º prop. | FGTS do período | Multa FGTS | Saque FGTS | Seguro-desemprego |
|---|---|---|---|---|---|---|---|---|---|
| Dispensa sem justa causa | Sim (indenizado ou trabalhado) | Sim | Sim | Sim | Sim | Sim | **40%** | 100% | Sim |
| Pedido de demissão | Devido pelo empregado (descontável) | Sim | Sim | Sim | Sim | Sim | Não | Não | Não |
| Justa causa (art. 482) | Não | Sim | Sim | **Não** | **Não** | Sim | Não | Não | Não |
| Acordo (art. 484-A) | **50%** se indenizado | Sim | Sim | Sim | Sim | Sim | **20%** | **80%** | **Não** |
| Culpa recíproca (art. 484) | **50%** | Sim | Sim | **50%** | **50%** | Sim | **20%** | 100% | Sim |
| Rescisão indireta (art. 483) | Sim | Sim | Sim | Sim | Sim | Sim | 40% | 100% | Sim |
| Término do contrato por prazo determinado | Não (salvo art. 481) | Sim | Sim | Sim | Sim | Sim | Não | 100% | Não |

Notas:
- **Culpa recíproca**: Súmula 14 do TST — 50% do aviso prévio, do 13º e das férias proporcionais. ⛔ Não lançar essas parcelas como integrais.
- **Aviso prévio proporcional**: Lei 12.506/2011 — 30 dias + 3 dias por ano completo, teto de 90 dias; a proporcionalidade beneficia **apenas o empregado**.
- **Prazo de pagamento**: art. 477, §6º — **10 dias corridos** do término do contrato, qualquer que seja a modalidade. Atraso → multa do art. 477, §8º (um salário).
- **Homologação sindical não é mais exigida** (art. 477, §1º revogado).
- **Quitação anual** (art. 507-B) e **PDV com quitação ampla** (art. 477-B) são válidos; o PDV não afasta discussão de vício de consentimento.
- **Multa do art. 477, §8º**: devida também na **rescisão indireta** (IRR Tema 52) e na **reversão judicial da justa causa** (IRR Tema 71).

---

## 5. Jornada, adicionais e ponto

- **Jornada padrão**: 8h/dia e 44h/semana (art. 7º, XIII, da CF). 🔄 A **PEC da escala 6x1** foi aprovada em dois turnos na Câmara em **27/05/2026** e está pendente no Senado — **não é norma vigente**. Se promulgada, prevê transição para 42h e, depois, 40h semanais.
- **Adicional de horas extras**: mínimo 50%. Domingos/feriados não compensados: 100% (Súmula 146 do TST).
- **Adicional noturno**: urbano 20%, hora reduzida de 52min30s (art. 73); rural 25%, sem redução ficta. A prorrogação da jornada noturna mantém o adicional (Súmula 60, II). 🔄 IRR **Tema 92** (limitação por norma coletiva) está com **suspensão nacional**.
- **Intervalo e hora noturna**: IRR **Tema 285** — a redução ficta da hora noturna conta para fixar o intervalo intrajornada.
- **Redução ínfima do intervalo**: até **5 minutos** no total não atrai o art. 71, §4º (IRR Tema 14).
- ⛔ **Cargo de confiança (art. 62, II)**: a gratificação de função deve ser de **no mínimo 40%** do salário do cargo efetivo (art. 62, parágrafo único) — **não 20%** — além de poderes de gestão reais.
- **Trabalho externo (art. 62, I)**: exige incompatibilidade com controle **e** anotação no registro. **O ônus de provar a impossibilidade de controle é do empregador** — IRR **Tema 73** (j. 24/03/2025). 🔄 Há RE admitido em 03/03/2026.
- **Controle de ponto**: Portaria MTP 671/2021 (REP-P, REP-A, REP-C) nos artigos não revogados. **Registro por exceção**: validade sob o Tema 1046 **pendente** no IRR Tema 151.
- **Compensação de jornada — IRR Tema 19** (j. 16/12/2024): descaracterizado o acordo, devido **apenas o adicional** sobre as horas que ultrapassam a jornada normal até 44h semanais, e hora + adicional acima de 44h; **não existe invalidade parcial** do acordo de compensação.
- **Prescrição**: bienal após a extinção e quinquenal retroativa ao ajuizamento (art. 7º, XXIX, da CF; Súmula 308 do TST). A **suspensão da Lei 14.010/2020 (COVID) aplica-se ao processo do trabalho**, bienal e quinquenal — IRR **Tema 46**.
- **Prescrição em acidente/doença ocupacional**: termo inicial na **ciência inequívoca da consolidação da lesão** — IRR Tema 183.

---

## 6. Saúde, segurança e o novo eixo psicossocial

### 6.1 NR-1 e riscos psicossociais — prioridade máxima de compliance
- **Portaria MTE 1.419, de 27/08/2024**: nova redação do **Capítulo 1.5 da NR-1 (GRO)**, incluindo expressamente os **fatores de risco psicossociais** no inventário de riscos do **PGR**, com remissão à NR-17.
- **Portaria MTE 765, de 15/05/2025**: prorrogou a vigência para **26/05/2026**.
- Entre 26/05/2025 e 25/05/2026 a fiscalização foi **orientativa**. **Desde 26/05/2026 a fiscalização é punitiva.**
- **Portaria MTE 104, de 29/01/2026**: revisou o **Anexo II da NR-28** (códigos de infração e gradação de multas), operacionalizando a autuação — inclusive da NR-1.
- Apoio oficial do MTE: *Guia de Fatores de Riscos Psicossociais*, *Manual do GRO/PGR* (mar/2026) e *Perguntas e Respostas sobre a NR-1* (mai/2026).
- **Efeito prático**: PGR sem identificação, avaliação, medidas de controle e plano de ação para fatores psicossociais (sobrecarga, metas, assédio, jornada, autonomia, suporte social) é **autuável** — e vira prova pré-constituída em ações de dano moral e doença ocupacional.

### 6.2 Outras NRs relevantes
- **NR-16, Anexo V** (Portaria MTE 2.021, de 03/12/2025, vigente ≈03/04/2026): periculosidade de **motociclistas** em vias públicas — 30%. Exclusões: deslocamento residência-trabalho, vias internas/privadas, uso ocasional ou de duração extremamente reduzida; exige laudo técnico.
  - **IRR Tema 101 do TST** (j. 18/05/2026): o **art. 193, §4º, da CLT é autoaplicável** — o direito **não dependia** de regulamentação; as exceções da portaria valem a partir da vigência dela e o ônus de provar a exceção é de quem a alega.
- **NR-4** (Portaria MTE 1.341/2024): prorrogada a primeira atualização dos graus de risco por CNAE.
- **NR-10** (Portaria MTE 737, de 29/05/2026): nova redação, com foco em arco elétrico. 🔄 **Vigência apenas a partir de ≈01/06/2027** — não aplicar como direito vigente hoje.
- **NR-5 (CIPA/CIPA+A)**: sem alteração no período; base permanece a Lei 14.457/2022 + Portaria MTP 4.219/2022.

### 6.3 Estabilidades e garantias
- **Gestante**: da confirmação da gravidez até 5 meses após o parto (ADCT, art. 10, II, "b"; Súmula 244 do TST — aplicável inclusive no contrato por prazo determinado).
- **Acidentária**: 12 meses após a cessação do auxílio-doença acidentário (art. 118 da Lei 8.213/91; Súmula 378 do TST — exige afastamento superior a 15 dias ou doença profissional constatada).
- **Cipeiro** (titular e **suplente** — Súmula 339): do registro da candidatura até 1 ano após o mandato.
- **Dirigente sindical**: do registro da candidatura até 1 ano após o mandato (art. 543, §3º; Súmula 369 — limite de 7 dirigentes e 7 suplentes; comunicação em 24h).
- **Reabilitado/PcD**: art. 93, §1º, da Lei 8.213/91 — dispensa condicionada à contratação de substituto em condição semelhante.
- **Pedido de demissão de gestante** exige assistência sindical (art. 500 da CLT) — IRR Tema 55.

---

## 7. Terceirização, pejotização e plataformas

### 7.1 Quadro consolidado
- **Terceirização de qualquer atividade é lícita** — STF, **ADPF 324** e **Tema 725 (RE 958252)**; o Tema 725 **transitou em julgado em 15/10/2024**. Base legal: Lei 6.019/74, com a redação das Leis 13.429/17 e 13.467/17.
- Deveres da contratante: verificar **idoneidade e capacidade econômica** da prestadora e responder **subsidiariamente** (Súmula 331, IV, do TST — vigente).
- **Quarentena**: arts. 5º-C e 5º-D da Lei 6.019/74 (vedação de recontratar ex-empregado como terceirizado por 18 meses).
- **Poder Público — Tema 1118 (RE 1298647, j. 13/02/2025, trânsito 29/04/2025)**: não há responsabilidade subsidiária fundada só em inversão do ônus da prova; exige **prova de conduta negligente**. Há negligência quando a Administração fica inerte após **notificação formal** de descumprimento. Deveres: exigir capital social compatível (art. 4º-B da Lei 6.019/74) e condicionar o pagamento à quitação das obrigações do mês anterior (art. 121, §3º, da Lei 14.133/2021).
- **Transporte de mercadorias** — IRR **Tema 59 do TST**: a contratação tem **natureza comercial**, não se enquadra na Súmula 331, IV, e não gera responsabilidade subsidiária. Vem sendo aplicado a plataformas de entrega (ex.: TST, 5ª T., Ag-REg-0000217-88.2022.5.09.0004, decisão de 13/04/2026 — iFood/empresa parceira).
- **Transportadores autônomos**: ADC 48 e ADI 3961 (16/04/2020) — Lei 11.442/2007 constitucional; preenchidos os requisitos, a relação é **comercial**.
- **Salões de beleza**: ADI 5625 — a parceria da Lei 13.352/2016 é constitucional, **mas nula quando dissimula relação de emprego**. Esse "item 2" é o vetor argumentativo central em qualquer discussão de forma alternativa de contratação.

### 7.2 Pejotização — STF, Tema 1389 (ARE 1532603) 🔄🔴
- ⛔ A classe correta é **ARE 1532603**, não "RE". Relator **Min. Gilmar Mendes**.
- Objeto: **competência** da Justiça do Trabalho, **ônus da prova** da fraude e **licitude** da contratação de PJ/autônomo, à luz da ADPF 324.
- Repercussão geral reconhecida em **12/04/2025**; **suspensão nacional** em 14/04/2025; audiência pública em **06/10/2025** (48 expositores).
- **17–18/06/2026**: o relator **levantou a suspensão em 1º grau e nos TRTs**; **recursos de revista e embargos seguem suspensos no TST** (decisão de 18/06/2026, confirmada em fonte oficial). 🔄 A versão anterior desta base mencionava um "despacho de 22/06/2026" retendo os autos no TRT sem prazo para RR — **esse ato não foi localizado** na revisão de 07/10/2026; não citá-lo sem conferir.
- **Em 07/10/2026 NÃO HÁ TESE FIXADA** e não há data de julgamento do mérito (atualizado). ⛔ Nunca afirmar que o STF "liberou a pejotização" ou "fixou tese".
- O relator esclareceu em **28/08/2025** que o **Tema 1389 não abrange trabalho por aplicativos**.
- **Como aconselhar enquanto pende**: (i) tratar o desenho PJ como risco vivo, não como estrutura segura; (ii) documentar autonomia real (ausência de exclusividade, de controle de jornada e de subordinação hierárquica; estrutura própria; pluralidade de clientes); (iii) mapear exposição por coorte de prestadores; (iv) considerar o custo de retenção processual nos TRTs até a tese; (v) não prometer resultado.

### 7.3 Plataformas digitais — STF, Tema 1291 (RE 1446336) 🔄🔴
- Relator **Min. Edson Fachin**; RG reconhecida em 02/03/2024. Objeto: vínculo entre **motorista de aplicativo** e plataforma. Sem suspensão nacional.
- **02/10/2025**: despacho incluindo expressamente o debate sobre **subordinação algorítmica**.
- **24/06/2026**: retirado de pauta pela Presidência, ante fato superveniente — aprovação, em 12/06/2026, na 114ª CIT, da **Convenção nº 193 da OIT** sobre trabalho em plataformas digitais.
- **02/07/2026**: incluído em calendário, com julgamento designado para 27/08/2026.
- **27/08/2026: NÃO JULGADO** (atualizado 07/10/2026) — retirado da pauta sem nenhum voto e sem nova data; último andamento "Conclusos ao Relator" (21/08/2026). Imprensa (C2) projeta julgamento para depois das eleições ou 2027. **Não há tese, placar nem modulação.**
- 🔴 **Verificar o andamento antes de responder qualquer questão sobre vínculo em plataformas.**
- **Não há lei brasileira regulando trabalho por plataformas** até 07/10/2026 (nenhum avanço desde 03/08). Em tramitação: **PLP 12/2024** (motoristas, Executivo), **PLP 152/2025** (substitutivo ao PL 2.096/2025; votação em Plenário cancelada em abr/2026) e **PL 2.479/2025** (entregadores). ⛔ Não tratar nenhum desses textos como norma vigente.
- **Não há súmula, OJ ou tese repetitiva do TST** sobre subordinação algorítmica.

---

## 8. Precedentes que mudam cálculo, custo e estratégia

### 8.1 Negociado x legislado — Tema 1046 (ARE 1121633)
Tese: *"São constitucionais os acordos e as convenções coletivos que, ao considerarem a adequação setorial negociada, pactuam limitações ou afastamentos de direitos trabalhistas, independentemente da explicitação especificada de vantagens compensatórias, desde que respeitados os direitos absolutamente indisponíveis."* Trânsito em **09/05/2023**; **sem modulação**. Marco prático de perda de eficácia das súmulas incompatíveis: **ata publicada em 14/06/2022**.
🔄 Aplicações pendentes no TST: **Tema 152** (feriados no 12x36), **Tema 151** (ponto por exceção), **Tema 92** (adicional noturno — suspensão nacional), **Tema 43** (enquadramento de grau de insalubridade).

### 8.2 Dano moral — art. 223-G da CLT (ADIs 6050, 6069 e 6082, j. 26/06/2023)
Interpretação conforme: (i) os arts. 223-A e 223-B **não excluem** o dano moral **em ricochete**; (ii) os parâmetros do art. 223-G, *caput* e §1º, são **orientativos**, sendo **constitucional o arbitramento acima dos tetos** conforme razoabilidade, proporcionalidade e igualdade. ⛔ Não tratar o tarifamento como teto vinculante.

### 8.3 Contribuição assistencial — Tema 935 (ARE 1018459) 🔄
Tese vigente: *"É constitucional a instituição, por acordo ou convenção coletivos, de contribuições assistenciais a serem impostas a todos os empregados da categoria, ainda que não sindicalizados, desde que assegurado o direito de oposição."*
Novos ED **acolhidos em 26/11/2025**, com efeitos integrativos: (i) **vedada a cobrança retroativa** relativa ao período em que vigorava o entendimento anterior de inconstitucionalidade; (ii) impossibilidade de interferência de terceiros no direito de oposição; (iii) valor compatível com a capacidade econômica da categoria. Acórdão publicado em 09/12/2025; **não transitado**, com incidentes pendentes.

### 8.4 Terço de férias e contribuição previdenciária — Tema 985 (RE 1072485)
Tese: é **legítima** a incidência da contribuição social sobre o terço constitucional. **Modulação em 12/06/2024**: efeitos **ex nunc** a partir da publicação da ata do julgamento de mérito, ressalvadas as contribuições já pagas e não impugnadas até então, que não serão devolvidas. ED da União rejeitados em 12/08/2025; **trânsito em 24/09/2025**.

### 8.5 Honorários e gratuidade
- **ADI 5766** (j. 20/10/2021): inconstitucionais o **art. 790-B, *caput* e §4º** e o **art. 791-A, §4º**; **constitucional** o art. 844, §2º.
- **Súmulas 219 e 329 do TST canceladas** (Res. 225/2025).
- **IRR Tema 21**: poder-dever de conceder gratuidade a quem percebe até 40% do teto do RGPS, independentemente de pedido; acima disso, basta declaração de hipossuficiência (Lei 7.115/83), salvo impugnação instruída com prova.
- **IRR Tema 242**: há sucumbência recíproca **apenas quando ao menos um pedido é julgado totalmente improcedente** — indevidos honorários do reclamante sobre pedidos parcialmente procedentes.
- **IRR Tema 304**: cabíveis honorários na extinção **sem** resolução do mérito (causalidade).
- **IRR Tema 182**: incabíveis honorários na produção antecipada de provas.
- 🔄 **IRR Tema 35** (pendente): os valores dos pedidos do art. 840, §1º, limitam a condenação ou são estimativos?

### 8.6 Atualização monetária e juros — três regimes sucessivos ⚠️ crítico para cálculo
1. **Até 29/08/2024** — **ADC 58/59 e ADI 5867/6021**: **IPCA-E + juros da Lei 8.177/91 (TRD)** na fase pré-judicial; **Selic** (que engloba correção e juros) a partir do ajuizamento.
2. **A partir de 30/08/2024** — **Lei 14.905/2024**: correção pelo **IPCA** (art. 389, parágrafo único, do CC) e juros pela **"taxa legal" = Selic − IPCA** (art. 406, §1º), com **resultado negativo considerado zero**.
3. **Uniformização no TST**: SBDI-1, **TST-E-ED-RR-713-03.2010.5.04.0029**, j. **17/10/2024**, Rel. Min. Alexandre de Souza Agra Belmonte — taxa legal a partir de 30/08/2024, mantida a estrutura da ADC 58 para o período anterior.
🔄 Conferir a tabela única de atualização vigente no CSJT/TRT antes de fechar cálculo.

### 8.7 Depósito recursal 🔄
- **01/08/2025 a 31/07/2026** (ATO SEGJUD.GP 391/2025): RO **R$ 13.813,83**; RR/Embargos/RO em rescisória **R$ 27.627,66**.
- **A partir de 01/08/2026** (ATO SEGJUD.GP 381/2026): RO **R$ 14.411,57**; RR/Embargos **R$ 28.823,14**.
- Reajuste anual pelo INPC — confirmar o ato vigente na data do recurso.

### 8.8 Outros repetitivos do TST com efeito prático direto
Prova e processo: **Tema 41** (custas/depósito pagos por terceiro aproveitam ao recorrente), **Tema 64** (indeferir adiamento por ausência de rol não é cerceamento), **Tema 72** (ação idêntica não torna testemunha suspeita), **Tema 286** (documento na fase recursal), **Tema 305** (intimação em nome de advogado diverso), **Tema 173** (seguro-garantia sem os 30% → intimação para complementar).
Verbas e dano: **Tema 65** (vedado estorno de comissões por inadimplência/cancelamento), **Tema 57** (comissão sobre o valor total, incluídos juros e encargos), **Tema 58** (revista visual impessoal não gera dano), **Tema 60** (falta de anotação em CTPS não é dano *in re ipsa*), **Tema 61** (transporte de valores por não especializado é dano *in re ipsa*), **Tema 62** (justa causa por improbidade não comprovada é dano *in re ipsa*), **Tema 54** (falta de instalações sanitárias em atividade externa), **Tema 80** (pausa térmica do art. 253 mesmo com EPI), **Tema 76** (concausalidade reduz pensão em até 50%), **Tema 75** (penhora de rendimentos até 50%, preservado 1 salário mínimo), **Tema 66** (motoristas e cobradores na base da cota de aprendizes), **Tema 81** (pluralidade de tomadores não afasta a subsidiária).
Rescisão indireta: **Tema 85** (descumprimento contumaz de horas extras e intervalo), **Tema 70** (irregularidade no FGTS, sem exigência de imediatidade), 🔄 **Tema 44** (conversão de pedido de demissão em rescisão indireta — pendente).
Execução: **Tema 26** (competência da JT para IDPJ contra empresa em recuperação judicial, salvo ordem do juízo recuperacional; a desconsideração exige **abuso** nos termos do art. 50 do CC — inadimplemento, insuficiência patrimonial ou frustração da execução **não bastam**); 🔄 **Tema 42** (teoria maior ou menor — pendente); 🔄 **Temas 39 e 91** (prescrição intercorrente e reconhecimento de ofício — pendentes).

---

## 9. Igualdade salarial, assédio e ambiente

- **Lei 14.611/2023 + Decreto 11.795/2023 + Portaria MTE 3.714/2023**: empresas com **100 ou mais empregados** publicam **semestralmente** o Relatório de Transparência Salarial e de Critérios Remuneratórios. Multa de até **3% da folha, limitada a 100 salários mínimos**, **pela não publicação** (não pela existência de diferença salarial).
- **STF, 14/05/2026**: ADIs **7612** e **7631** improcedentes e **ADC 92** procedente — a lei e sua regulamentação são **constitucionais**, por unanimidade.
- **Equiparação salarial**: art. 461 da CLT — mesma função e estabelecimento; diferença de tempo na função ≤4 anos e de tempo de serviço para o mesmo empregador ≤2 anos; quadro de carreira dispensa homologação.
- **Lei 14.457/2022 (Emprega + Mulher)**, art. 23: empresas com CIPA devem adotar medidas de prevenção e combate ao assédio sexual — inclusive **canal de denúncias**, regras de conduta e treinamentos bienais.
- **Lei 14.831/2024**: certificação voluntária "Empresa Promotora da Saúde Mental" — combinável com a NR-1 como evidência de compliance.
- **Assédio moral**: conduta abusiva e reiterada que degrada o ambiente. **Assédio sexual**: art. 216-A do CP; responsabilidade civil do empregador por ato de preposto (arts. 932, III, e 933 do CC — **objetiva**).
- ⛔ **A Convenção nº 190 da OIT NÃO foi ratificada pelo Brasil** (atualizado 07/10/2026): a Câmara aprovou o **PDL 997/2026** em 01/09/2026 e o enviou ao Senado, onde aguarda tramitação. Ainda faltam aprovação no Senado, ratificação e decreto de promulgação. Não citar como norma interna vigente. (Numeração da mensagem presidencial divergente nas fontes — não citar.)
- **Protocolo de 2014 à Convenção 29 da OIT** (trabalho forçado): Decreto Legislativo 177/2025 e **Decreto 12.857, de 24/02/2026**; **em vigor para o Brasil desde 26/08/2026** (atualizado 07/10/2026).

---

## 10. Obrigações digitais e fiscalização

- **Portaria Consolidada MTE nº 1, de 17/12/2025** (vigente desde **02/01/2026**; republicada em 30/12/2025): consolida CTPS Digital, **registro de empregados exclusivamente pelo eSocial**, CAGED/RAIS via eSocial, **DET** como canal oficial da Inspeção do Trabalho, certidões de cotas de PcD e aprendizes, CBO e QBQ. Revogou **parcialmente** a Portaria MTP 671/2021 (arts. 1º, 2º a 23 e 140 a 184-F).
- **DET**: a falta de leitura das comunicações não afasta a ciência — risco real de perda de prazo em defesa administrativa.
- **eSocial SST**: eventos **S-2210** (CAT), **S-2220** (monitoramento da saúde) e **S-2240** (condições ambientais) ganham peso probatório com a NR-1 revisada.
- **FGTS Digital**: em produção desde **01/03/2024** (Portaria MTE 240/2024); vencimento no dia **20**; IN SIT/MTE 02/2025 disciplina cobrança e fiscalização; há módulo de parcelamento.
- **Trabalho aos feriados no comércio**: **Portaria MTE 1.316, de 21/07/2026**, revogou a Portaria 3.665/2023 e disciplinou a matéria — funcionamento em feriados depende de **autorização em convenção coletiva**, salvo atividades essenciais. 🔄 Tema historicamente instável (sucessivos adiamentos em 2025 e 2026) — conferir vigência.
- **Consignado privado — "Crédito do Trabalhador"**: MP 1.292/2025 convertida na **Lei 15.179/2025** (altera a Lei 10.820/2003); Decreto 12.415/2025; Portarias MTE 434 e 435/2025, 2.254/2025 e 240/2026; **Resolução CGCONSIG/MTE nº 3 e Portaria MTE 1.115, ambas de 25/06/2026** (regime de garantias: até 35% das verbas rescisórias, até 100% da multa do FGTS e até 10% do saldo). Para o empregador: obrigações de consulta e declaração de margem via eSocial, retenção e repasse — com risco de responsabilização por falha operacional.

---

## 11. Passivo e contingência trabalhista

Fórmula base por pedido:
`(verba principal) + (reflexos: DSR, férias+1/3, 13º, FGTS+multa, aviso) + (atualização pelo regime do §8.6) + (honorários e custas)`

- **Provisão sugerida** (ajustar ao caso e à política contábil — CPC 25/IAS 37): **provável 70–100%** do principal atualizado; **possível 30–50%** (em regra, divulgação sem provisão); **remoto**, sem provisão.
- Fatores que **elevam** risco: tema **afetado ou suspenso** (efeito de represamento), prova documental ausente, ponto britânico, PGR sem fatores psicossociais, relatório de transparência salarial não publicado, terceirização sem verificação de idoneidade, base de PJs homogênea e subordinada.
- Fatores que **reduzem**: normas coletivas válidas sob o Tema 1046, quitação anual (art. 507-B), acordo homologado, CCP, PDV com quitação ampla.
- Incluir sempre: honorários periciais (art. 790-B, com a ressalva da ADI 5766), sucumbenciais (art. 791-A e Temas 242/304), custas de 2%, multas dos arts. 467 e 477, §8º, e risco de execução (IDPJ — Tema 26).

**Matriz de passivo**: categoria | contratos expostos | valor unitário estimado | probabilidade | precedente aplicável | **status do precedente** (pacificado/afetado/suspenso) | provisão.

---

## 12. Checklist de compliance trabalhista (atualizado 2026)

- [ ] Registro no eSocial e CTPS Digital conforme a Portaria Consolidada MTE 1/2025
- [ ] **DET monitorado**, com rotina de leitura e responsável designado
- [ ] Controle de ponto conforme a Portaria 671/2021 (parte não revogada); acordo escrito para banco de horas
- [ ] **PGR com fatores de risco psicossociais** documentados, plano de ação e evidências (NR-1; fiscalização punitiva desde 26/05/2026)
- [ ] PCMSO, LTCAT/PPP e eventos S-2210/S-2220/S-2240 atualizados
- [ ] CIPA/CIPA+A constituída e medidas do art. 23 da Lei 14.457/2022 implementadas
- [ ] Política de assédio, canal de denúncia com não retaliação e treinamento bienal registrado
- [ ] **Relatório de Transparência Salarial** publicado no prazo (100+ empregados), com plano de ação quando houver diferença
- [ ] Adicionais corretos (insalubridade, periculosidade — inclusive **motociclistas** —, noturno)
- [ ] Contratos de teletrabalho formalizados, com regime (jornada x produção) e regras de equipamento/reembolso
- [ ] Terceirização: due diligence de idoneidade e capacidade econômica, checagem de capital social (art. 4º-B) e retenção de comprovantes mensais
- [ ] Base de PJs mapeada, com evidência de autonomia (risco Tema 1389)
- [ ] Rotina de consignado CLT (margem, retenção, repasse) sob a Lei 15.179/2025
- [ ] Normas coletivas catalogadas e lidas sob o Tema 1046
- [ ] Cotas de PcD e de aprendizes atendidas e documentadas

---

## 13. Formato de saída preferencial

- **Parecer trabalhista**: vínculo → modalidade → verbas → precedente aplicável **com status** → risco → recomendação.
- **Cálculo de rescisão**: tabela por verba, com base de cálculo explícita e regime de atualização identificado por período.
- **Matriz de passivo**: conforme §11.
- **Política interna**: seções com obrigações, vedações, canais, sanções e evidências de implementação.
- **Nota de risco regulatório**: norma → prazo → exposição → medida → responsável.

---

## 14. Erros que este plugin existe para impedir

1. Citar **Súmulas 90, 114, 219, 277, 437, 444 ou 450 do TST** como vigentes.
2. Dizer que o **STF fixou tese no Tema 1389** ou "autorizou a pejotização".
3. Tratar **PLP 12/2024 ou PLP 152/2025** como lei em vigor.
4. Afirmar que o Brasil **ratificou a Convenção 190 da OIT**.
5. Usar **20%** como piso da gratificação de função do art. 62, II (é 40%).
6. Lançar **férias e 13º proporcionais integrais** na culpa recíproca (são 50%).
7. Aplicar **IPCA-E/TR** a créditos posteriores a 30/08/2024.
8. Tratar o **tarifamento do art. 223-G** como teto vinculante.
9. Ignorar que a **NR-1 psicossocial já é autuável** desde 26/05/2026.
10. Citar súmula do TST **de número superior a 463**.
