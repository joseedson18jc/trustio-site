# Plugin: M&A e Due Diligence

## Ativar quando
Pedido envolver compra e venda de empresa, fusão, cisão, incorporação, due diligence, SPA, MOU, LOI, earn-out, representações e garantias, fechamento de operação ou integração pós-aquisição.

## Raciocínio especializado

### Fases da operação de M&A

```
1. Originação → NDA → Teaser / IM
2. LOI / MOU (não-vinculante) → exclusividade
3. Due diligence (jurídica, financeira, fiscal, trabalhista, ambiental, técnica)
4. Negociação do SPA/definitivos
5. Condições precedentes (CPs)
6. Signing
7. Closing (simultâneo ou diferido)
8. Post-closing: ajustes de preço, escrow, integração
```

### Due diligence jurídica — checklist por frente

#### Societária
- [ ] Contrato social / estatuto consolidado
- [ ] Atas de eleição de administradores vigentes
- [ ] Livros societários (registro de sócios, atas, transferências)
- [ ] Acordos de sócios ou acionistas
- [ ] Certidão de arquivamento na JUCERJA/JUCESP
- [ ] Estrutura de grupo e participações cruzadas
- [ ] Autorização para a operação (quórum assemblear)

#### Contratual
- [ ] Contratos materiais (> threshold definido)
- [ ] Contratos com change of control clause — cláusula de mudança de controle
- [ ] Contratos com clientes chave (top 10–20)
- [ ] Contratos com fornecedores críticos
- [ ] Contratos de distribuição e representação comercial
- [ ] Joint ventures e acordos de parceria
- [ ] Contratos de locação (imóveis operacionais)
- [ ] Contratos de financiamento — covenants e cross-default

#### Trabalhista
- [ ] Quadro de funcionários (headcount, cargo, salário, admissão)
- [ ] Passivo estimado (reclamações trabalhistas)
- [ ] Planos de benefícios (PLR, stock options, previdência privada)
- [ ] Acordos coletivos vigentes
- [ ] Terceirizados — risco de vínculo
- [ ] Diretores estatutários — contratos e pacotes

#### Tributária
- [ ] Certidões negativas federais, estaduais e municipais
- [ ] Contingências fiscais declaradas e não declaradas
- [ ] Parcelamentos em andamento (PERT, outros)
- [ ] Créditos fiscais (PIS/COFINS, ICMS) — realização
- [ ] Obrigações acessórias em dia (SPED, ECF, ECD, e-Social)
- [ ] Planejamentos tributários implementados — risco de requalificação

#### Contenciosa
- [ ] Processos cíveis, trabalhistas, tributários, regulatórios
- [ ] Provisões contábeis vs. passivo jurídico estimado — gap
- [ ] Processos não provisionados (possível) — divulgação em nota
- [ ] Decisões com potencial de precedente negativo

#### Propriedade intelectual
- [ ] Marcas registradas e pedidos pendentes (INPI)
- [ ] Patentes e desenhos industriais
- [ ] Domínios registrados
- [ ] Software proprietário — titularidade, escrow de código
- [ ] Acordos de licença (outbound e inbound)
- [ ] Contratos de cessão de direitos com ex-funcionários/prestadores

#### Regulatória
- [ ] Autorizações, licenças e alvarás vigentes
- [ ] Histórico de sanções regulatórias
- [ ] Setores específicos: BACEN, ANVISA, ANATEL, ANEEL, CADE
- [ ] Necessidade de aprovação regulatória para o fechamento

#### Ambiental
- [ ] Licenças ambientais vigentes
- [ ] Passivos ambientais declarados e contingentes
- [ ] Autuações e TACs
- [ ] Áreas contaminadas ou de risco

#### LGPD / Proteção de dados
- [ ] Inventário de dados pessoais tratados
- [ ] Bases legais documentadas
- [ ] DPAs com operadores
- [ ] Incidentes anteriores
- [ ] Reclamações de titulares em aberto

### Red flags — escalonamento

#### 🔴 Vermelho (deal-breaker ou ajuste de preço obrigatório)
- Passivo oculto material não declarado
- Mudança de controle sem notificação/anuência de contrapartes chave
- Irregularidade societária grave (nulidade de atos)
- Processo criminal contra administradores
- Licença operacional revogada ou não renovável
- Contingência fiscal/trabalhista sem provisão > X% do valor do deal

#### 🟡 Amarelo (representação, garantia e mecanismo de proteção)
- Contratos sem cláusula de change of control
- Passivo trabalhista provável não totalmente provisionado
- Teses tributárias sem precedente consolidado
- Acordos coletivos com cláusulas onerosas
- Propriedade intelectual sem registro formalizado

#### 🟢 Verde (disclosures e monitoramento pós-closing)
- Contratos vencidos tacitamente renovados
- Obrigações acessórias com atrasos menores
- Políticas internas defasadas

### Estrutura do SPA — cláusulas essenciais

```
1. Definições
2. Objeto (ações/quotas, participação)
3. Preço e forma de pagamento
4. Ajuste de preço (mecanismo: locked-box ou completion accounts)
5. Condições precedentes (CPs)
6. Período entre signing e closing (interim covenants)
7. Closing: procedimento e documentos
8. Representações e garantias (R&W) do vendedor
9. R&W do comprador
10. Indenização: procedimento de claim, basket, cap, survival
11. Escrow: valor, prazo, liberação
12. Earn-out (se aplicável): métricas, proteção ao comprador
13. Non-compete / non-solicitation
14. Confidencialidade
15. Rescisão pré-closing (material adverse change)
16. Disposições gerais: lei aplicável, foro/arbitragem, notificações
```

### Ajuste de preço — mecanismos

#### Locked-box
- Preço fixo na data de referência (locked-box date)
- Vendedor não pode extrair valor após essa data (leakage)
- Permitted leakage: definida e taxativa
- Vantagem: simplicidade, certeza de preço

#### Completion accounts
- Preço provisório no closing
- Ajuste após fechamento com base em balanço de fechamento
- Parâmetros: caixa, dívida, capital de giro (target)
- Prazo: 30–90 dias para preparação + 30–60 dias para revisão

### Formato de saída preferencial
- Relatório de DD: sumário executivo → frentes → achados por nível de risco → recomendações
- Red flag report: achado | nível | impacto | recomendação para negociação
- Minuta de LOI/MOU: estrutura não-vinculante com termos principais
- Análise de cláusula SPA: texto atual → problema → risco → redação sugerida
