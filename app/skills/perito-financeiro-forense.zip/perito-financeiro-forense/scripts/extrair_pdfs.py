#!/usr/bin/env python3
# pff-version: 21.0
"""
extrair_pdfs.py — SA-1 (Ingestão): catálogo, timeline, extração com OCR de reserva e
pré-parse de lançamentos, com validação V1/V2. Ponto de partida, não substitui a revisão.

    python3 extrair_pdfs.py <pasta_ou_arquivos...> -o <pasta_saida> [--ocr auto|sempre|nunca]

Saídas em <pasta_saida>:
    catalogo.json / catalogo.md   inventário, tipo, período, nativo×scan, duplicatas, timeline, gaps
    texto/<arquivo>.txt           texto integral por página (rastreabilidade)
    lancamentos/<arquivo>.csv     lançamentos pré-parseados (data, descrição, valor, saldo, página)
    consolidado.csv               todos os lançamentos em ordem cronológica + Arquivo_Origem
    log_extracao.md               por arquivo: ferramenta, linhas, V1 (fechamento), V2 (continuidade)

Princípios (§0-PRE): nada é descartado em silêncio; tudo que não parseou vai para o log;
duplicatas são registradas, não apagadas; o pré-parse genérico é conferido pelos testes V1/V2
e, quando reprova, o perito passa para o parser posicional (§0-PRE.6) ou leitura visual.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import defaultdict
from datetime import date

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from pericia import parse_valor_br  # noqa: E402

__version__ = "21.0"

TIPOS = [  # (tipo, prioridade, padrões) — ordem importa (mais específico primeiro)
    ("termo_renegociacao", 3, r"renegocia|aditamento|aditivo|termo de (acordo|confiss|composi)|novação|parcelamento de d[ée]bito|sob medida"),
    ("contrato", 2, r"c[ée]dula de cr[ée]dito|contrato de (empr[ée]stimo|financiamento|cr[ée]dito)|proposta de ades|condi[cç][õo]es gerais"),
    ("demonstrativo_divida", 1, r"demonstrativo de (evolu|d[ée]bito)|evolu[cç][ãa]o (da|de) d[íi]vida|planilha de (c[áa]lculo|evolu)"),
    ("fatura_cartao", 1, r"fatura|pagamento m[íi]nimo|limite de cr[ée]dito|encargos do rotativo"),
    ("extrato_conta", 1, r"extrato|saldo anterior|lan[cç]amentos|movimenta[cç][ãa]o"),
    ("comprovante", 4, r"comprovante|autentica[cç][ãa]o|pix enviado|ted realizada"),
    ("judicial_ou_correspondencia", 5, r"excelent[íi]ssimo|processo n|notifica[cç][ãa]o|of[íi]cio"),
]
RE_DATA = re.compile(r"\b(\d{2})/(\d{2})/(\d{4})\b")
RE_PERIODO = re.compile(r"per[íi]odo\s*(?:de|:)?\s*(\d{2}/\d{2}/\d{4})\s*(?:a|at[ée]|-)\s*(\d{2}/\d{2}/\d{4})", re.I)
VALOR = r"-?\(?\d{1,3}(?:\.\d{3})*,\d{2}\)?(?:\s?-|\s?[DC])?"
RE_LANC = re.compile(rf"^(?P<data>\d{{2}}/\d{{2}}(?:/\d{{2,4}})?)?\s*(?P<desc>.*?\S)\s+(?P<valor>{VALOR})(?:\s+(?P<saldo>{VALOR}))?\s*$")
RE_VALOR_ALL = re.compile(r"(?<![\d/])-?\d{1,3}(?:\.\d{3})*,\d{2}-?(?![\d%])")
RE_COMPETENCIA = re.compile(r"^(0[1-9]|1[0-2])/(\d{4})\b")
RE_SALDO_ANT = re.compile(rf"saldo\s+anterior.*?(?P<v>{VALOR})\s*$", re.I)
RE_SALDO_FIM = re.compile(rf"saldo\s+(?:final|em\s+\d{{2}}/\d{{2}}(?:/\d{{4}})?|atual|dispon[íi]vel\s+final).*?(?P<v>{VALOR})\s*$", re.I)


def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def _ocr_pagina(pdf: str, pagina: int, lang: str) -> str:
    if not (shutil.which("pdftoppm") and shutil.which("tesseract")):
        return ""
    with tempfile.TemporaryDirectory() as td:
        base = os.path.join(td, "p")
        subprocess.run(["pdftoppm", "-r", "300", "-f", str(pagina), "-l", str(pagina), "-png", pdf, base],
                       check=False, capture_output=True)
        imgs = sorted(f for f in os.listdir(td) if f.endswith(".png"))
        if not imgs:
            return ""
        r = subprocess.run(["tesseract", os.path.join(td, imgs[0]), "-", "-l", lang, "--psm", "6"],
                           check=False, capture_output=True, text=True)
        return r.stdout


def _lang_ocr() -> tuple[str, str | None]:
    try:
        langs = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True).stdout
    except FileNotFoundError:
        return "", "tesseract ausente — PDFs escaneados exigirão leitura visual"
    if "por" in langs.split():
        return "por", None
    return "eng", "tesseract sem 'por' (instale tesseract-ocr-por); OCR em 'eng' — conferir acentos e R$"


def extrair_texto(pdf: str, modo_ocr: str = "auto") -> dict:
    import pdfplumber
    lang, aviso = _lang_ocr()
    paginas, metodo = [], []
    try:
        with pdfplumber.open(pdf) as doc:
            for i, pg in enumerate(doc.pages, 1):
                t = pg.extract_text() or ""
                usa_ocr = modo_ocr == "sempre" or (modo_ocr == "auto" and len(t.strip()) < 40)
                if usa_ocr and lang:
                    o = _ocr_pagina(pdf, i, lang)
                    if len(o.strip()) > len(t.strip()):
                        t = o
                        metodo.append("ocr")
                        paginas.append(t)
                        continue
                metodo.append("nativo")
                paginas.append(t)
    except Exception as e:  # noqa: BLE001 — PDF protegido/corrompido
        return {"erro": f"{e.__class__.__name__}: {e}", "paginas": [], "metodo": []}
    n_ocr = metodo.count("ocr")
    classe = "nativo" if n_ocr == 0 else "escaneado" if n_ocr == len(metodo) else "misto"
    return {"paginas": paginas, "metodo": metodo, "classe": classe, "aviso_ocr": aviso if n_ocr else None}


def classificar(texto: str) -> tuple[str, int]:
    t = texto[:6000].lower()
    for tipo, prio, pad in TIPOS:
        if re.search(pad, t):
            return tipo, prio
    return "outro", 5


def periodo(texto: str) -> tuple[date | None, date | None]:
    m = RE_PERIODO.search(texto)
    if m:
        d1, d2 = (date(int(x[6:]), int(x[3:5]), int(x[:2])) for x in m.groups())
        return d1, d2
    ds = []
    for d, mth, a in RE_DATA.findall(texto[:20000]):
        try:
            dt = date(int(a), int(mth), int(d))
            if 1990 <= dt.year <= 2100:
                ds.append(dt)
        except ValueError:
            pass
    return (min(ds), max(ds)) if ds else (None, None)


def parse_lancamentos(paginas: list[str], ano_ref: int | None, mes_ref: int | None) -> dict:
    """Pré-parse genérico com carry-forward de data e recorte entre 'saldo anterior' e 'saldo final'."""
    linhas, nao_parseadas, tabulares = [], [], []
    cabecalho = ""
    saldo_ant = saldo_fim = None
    data_corrente = None
    dentro = None                 # None = não há marcadores; True/False quando houver
    texto_total = "\n".join(paginas).lower()
    tem_marcadores = "saldo anterior" in texto_total
    if tem_marcadores:
        dentro = False
    for np_, pg in enumerate(paginas, 1):
        for bruta in pg.splitlines():
            l = bruta.strip()
            if not l:
                continue
            m_ant = RE_SALDO_ANT.search(l)
            if m_ant and saldo_ant is None:
                saldo_ant = parse_valor_br(m_ant.group("v"))
                dentro = True
                continue
            m_fim = RE_SALDO_FIM.search(l)
            if m_fim and dentro:
                saldo_fim = parse_valor_br(m_fim.group("v"))
                dentro = False
                continue
            if dentro is False:
                continue
            vals = RE_VALOR_ALL.findall(l)
            datas_l = RE_DATA.findall(l)
            m_comp = RE_COMPETENCIA.match(l)
            if len(vals) >= 3 and not datas_l and m_comp:
                tabulares.append({"pagina": np_, "data": f"{m_comp.group(2)}-{m_comp.group(1)}-01",
                                  "datas": m_comp.group(0), "valores": ";".join(str(parse_valor_br(v)) for v in vals),
                                  "cabecalho": cabecalho, "texto": l})
                continue
            if len(vals) >= 3 and datas_l:
                # linha de tabela (demonstrativo/planilha): guarda todas as colunas para mapeamento
                d, mth, a_ = datas_l[0]
                try:
                    tabulares.append({"pagina": np_, "data": date(int(a_), int(mth), int(d)).isoformat(),
                                      "datas": ";".join("/".join(x) for x in datas_l),
                                      "valores": ";".join(str(parse_valor_br(v)) for v in vals),
                                      "cabecalho": cabecalho, "texto": l})
                    continue
                except ValueError:
                    pass
            if not vals and len(l.split()) >= 3 and not datas_l:
                cabecalho = l
            m = RE_LANC.match(l)
            if not m:
                if re.search(VALOR, l):
                    nao_parseadas.append({"pagina": np_, "linha": l})
                continue
            if m.group("data"):
                dtxt = m.group("data")
                p = dtxt.split("/")
                dia, mes = int(p[0]), int(p[1])
                if len(p) == 3:
                    ano = int(p[2]) + (2000 if len(p[2]) == 2 else 0)
                else:
                    ano = ano_ref or date.today().year
                    if mes_ref and mes > mes_ref:         # virada dez→jan
                        ano -= 1
                try:
                    data_corrente = date(ano, mes, dia)
                except ValueError:
                    nao_parseadas.append({"pagina": np_, "linha": l})
                    continue
            if data_corrente is None:
                nao_parseadas.append({"pagina": np_, "linha": l})
                continue
            try:
                valor = parse_valor_br(m.group("valor"))
                saldo = parse_valor_br(m.group("saldo")) if m.group("saldo") else None
            except ValueError:
                nao_parseadas.append({"pagina": np_, "linha": l})
                continue
            linhas.append({"data": data_corrente.isoformat(), "descricao": m.group("desc").strip(),
                           "valor": valor, "saldo_impresso": saldo, "pagina": np_})
    v1 = None
    if saldo_ant is not None and saldo_fim is not None:
        residuo = saldo_ant + sum(x["valor"] for x in linhas) - saldo_fim
        v1 = {"saldo_anterior": saldo_ant, "saldo_final": saldo_fim, "residuo": round(residuo, 2),
              "aprovado": abs(residuo) <= 1.0}
    return {"lancamentos": linhas, "nao_parseadas": nao_parseadas, "tabulares": tabulares, "v1": v1,
            "saldo_anterior": saldo_ant, "saldo_final": saldo_fim}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("entradas", nargs="+")
    ap.add_argument("-o", "--saida", required=True)
    ap.add_argument("--ocr", choices=["auto", "sempre", "nunca"], default="auto")
    a = ap.parse_args(argv)

    arquivos = []
    for e in a.entradas:
        if os.path.isdir(e):
            for raiz, _, fs in os.walk(e):
                arquivos += [os.path.join(raiz, f) for f in fs if f.lower().endswith(".pdf")]
        elif e.lower().endswith(".pdf"):
            arquivos.append(e)
    arquivos.sort()
    os.makedirs(os.path.join(a.saida, "texto"), exist_ok=True)
    os.makedirs(os.path.join(a.saida, "lancamentos"), exist_ok=True)

    cat, por_hash, por_texto = [], defaultdict(list), defaultdict(list)
    log = [f"# Log de extração (extrair_pdfs.py v{__version__})\n"]
    consolidado = []
    for i, arq in enumerate(arquivos, 1):
        nome = os.path.basename(arq)
        h = sha256(arq)
        ex = extrair_texto(arq, a.ocr)
        reg = {"id": f"{i:03d}", "arquivo": nome, "caminho": arq, "sha256": h,
               "bytes": os.path.getsize(arq), "paginas": len(ex.get("paginas", []))}
        por_hash[h].append(nome)
        if ex.get("erro"):
            reg.update({"tipo": "ERRO", "erro": ex["erro"]})
            log.append(f"## [{reg['id']}] {nome}\n- **ERRO**: {ex['erro']} (protegido/corrompido? Solicitar versão sem senha — não quebrar senha)\n")
            cat.append(reg)
            continue
        texto = "\n".join(ex["paginas"])
        with open(os.path.join(a.saida, "texto", nome + ".txt"), "w", encoding="utf-8") as f:
            for n, p in enumerate(ex["paginas"], 1):
                f.write(f"\n===== página {n} ({ex['metodo'][n-1]}) =====\n{p}\n")
        norm = hashlib.sha256(re.sub(r"\s+", " ", texto.lower()).encode()).hexdigest()
        por_texto[norm].append(nome)
        tipo, prio = classificar(texto)
        d1, d2 = periodo(texto)
        reg.update({"tipo": tipo, "prioridade": prio, "classe_pdf": ex["classe"],
                    "periodo_ini": d1.isoformat() if d1 else None, "periodo_fim": d2.isoformat() if d2 else None,
                    "aviso_ocr": ex.get("aviso_ocr")})
        pl = parse_lancamentos(ex["paginas"], d2.year if d2 else None, d2.month if d2 else None)
        reg.update({"n_lancamentos": len(pl["lancamentos"]), "n_nao_parseadas": len(pl["nao_parseadas"]),
                    "saldo_anterior": pl["saldo_anterior"], "saldo_final": pl["saldo_final"], "v1": pl["v1"]})
        if pl["tabulares"]:
            with open(os.path.join(a.saida, "lancamentos", nome + ".tabela.csv"), "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["pagina", "data", "datas", "valores", "cabecalho", "texto"])
                w.writeheader()
                w.writerows(pl["tabulares"])
        reg["n_linhas_tabulares"] = len(pl["tabulares"])
        if pl["lancamentos"]:
            with open(os.path.join(a.saida, "lancamentos", nome + ".csv"), "w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=["data", "descricao", "valor", "saldo_impresso", "pagina"])
                w.writeheader()
                w.writerows(pl["lancamentos"])
            for x in pl["lancamentos"]:
                consolidado.append({**x, "arquivo_origem": nome, "tipo_doc": tipo})
        v1txt = ("não aplicável (sem 'saldo anterior/final')" if pl["v1"] is None else
                 f"{'APROVADO' if pl['v1']['aprovado'] else 'REPROVADO'} — resíduo R$ {pl['v1']['residuo']:.2f}")
        log.append(f"## [{reg['id']}] {nome}\n- Tipo: {tipo} · PDF {ex['classe']} · {reg['paginas']} pág. · "
                   f"período {reg['periodo_ini']} → {reg['periodo_fim']}\n- Lançamentos pré-parseados: "
                   f"{len(pl['lancamentos'])} · linhas de tabela (≥3 valores): {len(pl['tabulares'])} → lancamentos/{nome}.tabela.csv · linhas com valor não parseadas: {len(pl['nao_parseadas'])}\n"
                   f"- V1 fechamento: {v1txt}\n" + (f"- Aviso OCR: {ex['aviso_ocr']}\n" if ex.get("aviso_ocr") else "")
                   + "".join(f"  - não parseada p.{u['pagina']}: `{u['linha'][:120]}`\n" for u in pl["nao_parseadas"][:15]))
        cat.append(reg)

    # duplicatas
    dups = [v for v in por_hash.values() if len(v) > 1] + [v for v in por_texto.values() if len(v) > 1]
    dups = [list(x) for x in {tuple(sorted(d)) for d in dups}]
    # timeline + continuidade V2 entre extratos
    ordenados = sorted([c for c in cat if c.get("periodo_ini")], key=lambda c: (c["periodo_ini"], c.get("prioridade", 9)))
    v2, gaps = [], []
    extratos = [c for c in ordenados if c["tipo"] in ("extrato_conta", "fatura_cartao", "demonstrativo_divida")
                and c.get("saldo_final") is not None]
    for x, y in zip(extratos, extratos[1:]):
        if y.get("saldo_anterior") is not None:
            v2.append({"de": x["arquivo"], "para": y["arquivo"], "saldo_final": x["saldo_final"],
                       "saldo_anterior_seguinte": y["saldo_anterior"],
                       "aprovado": abs(x["saldo_final"] - y["saldo_anterior"]) <= 1.0})
        d_fim = date.fromisoformat(x["periodo_fim"])
        d_ini = date.fromisoformat(y["periodo_ini"])
        if (d_ini - d_fim).days > 92:
            gaps.append({"apos": x["arquivo"], "antes_de": y["arquivo"], "dias": (d_ini - d_fim).days})

    consolidado.sort(key=lambda r: (r["data"],))
    if consolidado:
        with open(os.path.join(a.saida, "consolidado.csv"), "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(consolidado[0].keys()))
            w.writeheader()
            w.writerows(consolidado)

    res = {"versao": __version__, "total_arquivos": len(arquivos), "catalogo": cat, "duplicatas": dups,
           "continuidade_v2": v2, "gaps_maior_3m": gaps, "n_lancamentos_consolidados": len(consolidado)}
    with open(os.path.join(a.saida, "catalogo.json"), "w", encoding="utf-8") as f:
        json.dump(res, f, ensure_ascii=False, indent=2, default=str)

    md = [f"# Catálogo de arquivos recebidos ({len(arquivos)})\n",
          "| ID | Arquivo | Tipo | PDF | Pág. | Período | Lanç. | Linhas tabela | V1 |", "|---|---|---|---|---|---|---|---|---|"]
    for c in cat:
        v1 = c.get("v1")
        v1s = "—" if not v1 else ("OK" if v1["aprovado"] else f"REPROVADO ({v1['residuo']:+.2f})")
        md.append(f"| {c['id']} | {c['arquivo']} | {c.get('tipo')} | {c.get('classe_pdf', '—')} | {c['paginas']} | "
                  f"{c.get('periodo_ini') or '?'} → {c.get('periodo_fim') or '?'} | {c.get('n_lancamentos', 0)} | {c.get('n_linhas_tabulares', 0)} | {v1s} |")
    md.append("\n## Timeline\n")
    md += [f"- {c['periodo_ini']} → {c['periodo_fim']} · {c['tipo']} · {c['arquivo']}" for c in ordenados]
    md.append("\n## Duplicatas\n" + ("\n".join(f"- {' = '.join(d)}" for d in dups) or "- nenhuma"))
    md.append("\n## Continuidade entre extratos (V2)\n" + ("\n".join(
        f"- {x['de']} → {x['para']}: {x['saldo_final']:.2f} vs {x['saldo_anterior_seguinte']:.2f} "
        f"{'OK' if x['aprovado'] else '**GAP_ENTRE_EXTRATOS (ALTA)**'}" for x in v2) or "- não avaliável"))
    md.append("\n## Lacunas > 3 meses\n" + ("\n".join(f"- após {g['apos']}: {g['dias']} dias" for g in gaps) or "- nenhuma"))
    sem_extrato = not any(c.get("tipo") in ("extrato_conta", "demonstrativo_divida", "fatura_cartao") for c in cat)
    sem_contrato = not any(c.get("tipo") in ("contrato", "termo_renegociacao") for c in cat)
    md.append("\n## Lacunas documentais\n" + "\n".join(filter(None, [
        "- Nenhum extrato/demonstrativo/fatura identificado — base do recálculo ausente" if sem_extrato else "",
        "- Nenhum contrato/termo identificado — taxa/sistema terão de ser inferidos (Etapa 4)" if sem_contrato else "",
    ])) or "- nenhuma crítica")
    with open(os.path.join(a.saida, "catalogo.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(md) + "\n")
    with open(os.path.join(a.saida, "log_extracao.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(log))
    print(f"{len(arquivos)} arquivos · {len(consolidado)} lançamentos · {len(dups)} grupos de duplicatas · "
          f"V2 reprovados: {sum(not x['aprovado'] for x in v2)} · saída: {a.saida}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
