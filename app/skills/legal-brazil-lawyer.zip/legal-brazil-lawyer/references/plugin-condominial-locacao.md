# Plugin: Direito Condominial e Locação Urbana

> **Base verificada em 07/10/2026.** Textos legais conferidos no Planalto (versões compiladas) e precedentes nos portais oficiais do STJ e do STF nesta data. 🔄 = volátil, reconferir antes de usar; ⛔ = erro comum; **(C3 — verificar)** = entendimento descrito sem número porque não foi confirmado em fonte oficial.

## Quando carregar
Carregar quando o pedido envolver condomínio edilício (convenção, assembleia, multas, cotas, síndico, uso de unidades e de áreas comuns, locação de curta temporada) ou locação urbana regida pela Lei 8.245/91 (garantias, despejo, renovatória, revisional, reajuste, benfeitorias, preferência).

---

## 1. Condomínio edilício: base normativa

- **CC, arts. 1.331 a 1.358** (condomínio edilício), **1.358-A** (condomínio de lotes) e **1.358-B a 1.358-U** (multipropriedade). A **Lei 4.591/64** segue aplicável quanto à **incorporação** (Título II). Na parte condominial (arts. 1º a 27), aplica-se só no que não conflitar com o CC.
- Alterações recentes que mudam respostas:
  - **Lei 14.309, de 08/03/2022**: incluiu a **sessão permanente** (art. 1.353, §§1º a 3º) e a **assembleia eletrônica ou híbrida** (art. 1.354-A).
  - **Lei 14.405, de 12/07/2022**: o art. 1.351 passou a exigir **2/3 dos votos** tanto para alterar a convenção quanto para **mudar a destinação** do edifício ou da unidade. ⛔ A antiga exigência de unanimidade para mudar a destinação não existe mais.
  - **Lei 14.905/2024**: deu nova redação ao art. 1.336, §1º. Os juros de mora são os convencionados; na falta deles, a **taxa legal do art. 406** (Selic menos o índice do art. 389, parágrafo único). Correção monetária e **multa moratória de até 2%** foram mantidas.
- **Súmula 260/STJ**: a convenção aprovada é eficaz entre os condôminos ainda que não registrada. O registro (art. 1.333, parágrafo único) serve à **oponibilidade a terceiros** (C1).

### 1.1 Hierarquia e quóruns (CC, conferidos em 07/10/2026)
`Lei > convenção (ato constitutivo) > regimento interno > deliberação de assembleia > ato do síndico`. Uma deliberação de assembleia **não altera a convenção** se não atingir o quórum legal. O regimento interno não pode criar sanção que a convenção ou a lei não autorizem.

| Matéria | Quórum | Base |
|---|---|---|
| Instituir a convenção | 2/3 das frações ideais | art. 1.333 |
| Alterar a convenção; mudar a destinação do edifício ou da unidade | 2/3 dos votos dos condôminos | art. 1.351 (Lei 14.405/2022) |
| Novo pavimento ou novo edifício no solo comum | **Unanimidade** | art. 1.343 |
| Obras voluptuárias / úteis | 2/3 / maioria dos condôminos | art. 1.341, I e II |
| Acréscimos em partes comuns | 2/3 dos votos | art. 1.342 |
| Multa do art. 1.336, §2º, quando a convenção for omissa | 2/3 dos condôminos restantes | art. 1.336, §2º |
| Multa por descumprimento reiterado (até 5x) | 3/4 dos condôminos restantes | art. 1.337, caput |
| Destituir o síndico | maioria absoluta dos membros da assembleia | art. 1.349 |
| Deliberações gerais | 1ª convocação: maioria dos presentes que representem ao menos metade das frações; 2ª convocação: maioria dos presentes | arts. 1.352 e 1.353 |
| Convocar assembleia (omissão do síndico ou AGE) | 1/4 dos condôminos | arts. 1.350, §1º, e 1.355 |
| Regras complementares da assembleia eletrônica (no regimento) | maioria simples dos presentes | art. 1.354-A, §5º |
| Reconstrução ou venda após destruição | metade mais uma das frações | art. 1.357 |

- **Sessão permanente** (art. 1.353, §§1º a 3º): usada quando não se atinge um quórum especial. Exige indicar data e hora da continuação (até **60 dias**), convocar expressamente os ausentes, lavrar ata parcial com os argumentos apresentados e concluir em até **90 dias** contados da abertura. Os votos já dados ficam registrados.
- **Assembleia eletrônica** (art. 1.354-A): cabe se a convenção não a proibir e se forem preservados os direitos de voz, debate e voto. O edital deve informar o meio e as instruções de acesso e votação. A ata só é lavrada depois da apuração. Admite formato híbrido.
- **Sem convocação de todos os condôminos, a assembleia não pode deliberar** (art. 1.354). Isso é causa frequente de nulidade.
- **Votar exige estar quite** (art. 1.335, III).

## 2. Multas condominiais

### 2.1 Espécies (CC)
| Espécie | Hipótese | Teto | Quem decide |
|---|---|---|---|
| Moratória | Atraso no pagamento da cota | **até 2%** do débito, mais correção e juros (art. 1.336, §1º) | Automática |
| Por infração | Descumprir os deveres dos incisos II a IV do art. 1.336 (obras que ponham a segurança em risco, fachada, destinação, sossego, salubridade, segurança, bons costumes) | **até 5x** a contribuição mensal, sem prejuízo de perdas e danos (art. 1.336, §2º) | Prevista no ato constitutivo ou na convenção. Se ela for omissa, a assembleia decide por 2/3 dos condôminos restantes |
| Descumprimento reiterado | Descumprimento reiterado de deveres | **até 5x**, conforme a gravidade e a reiteração (art. 1.337, caput) | Deliberação de **3/4 dos condôminos restantes** |
| Antissocial | Comportamento antissocial reiterado que torne a convivência incompatível | **até 10x**, até nova deliberação da assembleia (art. 1.337, parágrafo único) | Assembleia (C3 — verificar o quórum exigido pela jurisprudência local) |

⛔ A multa de **20%** do art. 12, §3º, da Lei 4.591/64 não se aplica a débitos vencidos na vigência do CC. O teto é de 2% (C3 — verificar o precedente de referência do STJ antes de citá-lo).
⛔ O condomínio **não pode impedir o inadimplente de usar áreas comuns**: as sanções contra a inadimplência são só as pecuniárias da lei. **STJ, 4ª T., REsp 1.699.022/SP**, Rel. Min. Luis Felipe Salomão, j. 28/05/2019, DJe 01/07/2019, unânime (C1, acórdão de turma). No mesmo sentido: **STJ, 3ª T., REsp 1.564.030/MG**, Rel. Min. Marco Aurélio Bellizze, j. 09/08/2016, DJe 19/08/2016 (C1).

### 2.2 Requisitos de validade (checar todos)
1. **Previsão normativa**: a conduta e a sanção devem estar previstas na convenção ou no regimento autorizado pela convenção (art. 1.334, IV; Lei 4.591/64, art. 21). Os deveres do art. 1.336 já são legais, mas o **valor e o procedimento** dependem da convenção.
2. **Tipicidade e descrição do fato**: data, hora, unidade, conduta concreta e dispositivo violado. Notificação genérica ("barulho excessivo") é frágil.
3. **Notificação prévia e defesa**: o STJ entendeu que a multa do art. 1.337, parágrafo único, **não pode ser aplicada sem antes garantir o direito de defesa** ao condômino. A ementa invoca a **eficácia horizontal dos direitos fundamentais** nas relações condominiais. **STJ, 4ª T., REsp 1.365.279/SP**, Rel. Min. Luis Felipe Salomão, j. 25/08/2015, DJe 29/09/2015 (C1, acórdão de turma, persuasivo). 🔄 Estender esse entendimento às multas do art. 1.336, §2º, é **argumento por analogia**, não precedente direto. Conferir a jurisprudência do TJ local.
4. **Prova do fato**, sobretudo em caso de ruído:
   - Livro de ocorrências, relatos de portaria, testemunhas e registros contemporâneos.
   - **Medição técnica** pela **ABNT NBR 10151:2019** (ruído em áreas habitadas) e pela **NBR 10152:2017** (níveis em ambientes internos), ambas com versão corrigida de 2020 (versões confirmadas via CBIC; conferir no catálogo da ABNT).
   - A **lei municipal de ruído e de horário de silêncio** serve como parâmetro de tolerância.
   - Leitura de decibelímetro por aplicativo, sem calibração e sem método, tem baixo valor probatório.
   - Normas de apoio: **CC, art. 1.277** (uso anormal da propriedade; tolerância conforme a zona e os costumes) e **LCP, art. 42** (perturbação do sossego), que reforçam o dever de urbanidade mas não dispensam prova.
5. **Proporcionalidade e gradação**: advertência antes da multa, quando a convenção a prevê; valor compatível com a gravidade. A multa máxima no primeiro episódio é atacável.
6. **Reincidência**: só agrava a multa se houver infração anterior **validamente constituída** (notificada, com prazo de defesa, sem anulação).
7. **Competência e forma**: a multa é imposta pelo órgão previsto na convenção (em regra o síndico, art. 1.348, VII) e a cobrança deve ser feita por escrito e de forma motivada.

### 2.3 Impugnação
- **Recurso administrativo**: ao conselho ou à assembleia, conforme a convenção e o regimento. **Não há rito legal geral**: ler o procedimento interno e seus prazos. Pedir efeito suspensivo e a exibição das provas (livro, medições, imagens). Imagens de câmeras envolvem a LGPD (ver `plugin-compliance-lgpd.md`).
- **Ação anulatória** (ou declaratória de inexigibilidade, com repetição se a multa já foi paga): pode trazer pedido de tutela de urgência para evitar cobrança ou negativação.
- **JEC**: possível para a ação do condômino pessoa física contra o condomínio em causa de até 40 salários mínimos (Lei 9.099/95, art. 3º, I). As causas do art. 275, II, do CPC/73 seguem no JEC por força do CPC, art. 1.063 (redação da Lei 14.976/2024). A alínea "c" desse inciso abrange despesas de condomínio. Se o **condomínio for autor** no JEC: art. 8º, §1º, da Lei 9.099 (C3 — verificar o enunciado do FONAJE e a jurisprudência local).
- **Prazo para anular a deliberação ou a multa**: há divergência entre o prazo decadencial de 2 anos do CC, art. 179 (ato anulável), e a tese de nulidade, que seria imprescritível ou sujeita ao art. 205 (C3 — verificar a posição do STJ e do TJ local). **Agir rápido** é a recomendação segura.
- **Prescrição da cobrança da multa por infração**: a tese do Tema 949 trata da **taxa condominial**. Aplicá-la à multa é **inferência** (C3 — verificar).

## 3. Cobrança de cotas condominiais
- **Título executivo extrajudicial**: CPC, art. 784, X. Abrange contribuições ordinárias ou extraordinárias previstas na convenção ou aprovadas em assembleia, **documentalmente comprovadas** (convenção, ata, planilha e demonstrativo). O inciso VIII cobre os encargos de condomínio cobrados junto com o aluguel.
- **Prescrição**: **5 anos** a partir do dia seguinte ao vencimento de cada parcela. **STJ, 2ª Seção, Tema Repetitivo 949, REsp 1.483.930/DF**, Rel. Min. Luis Felipe Salomão, j. 23/11/2016, DJe 01/02/2017, trânsito em julgado em 28/06/2017 (C1, vinculante pelo art. 927, III, do CPC).
- **Natureza propter rem**: o adquirente responde pelos débitos do alienante, incluindo multas e juros (CC, art. 1.345).
- **Promitente comprador sem registro**: o **Tema 886/STJ** (REsp 1.345.331/RS, j. 08/04/2015, trânsito em julgado em 30/09/2015) diz que o que decide é a imissão na posse somada à ciência inequívoca do condomínio. 🔄 Esse entendimento está **em revisão no Tema 1349/STJ** (2ª Seção, REsp 2.015.740/SP e 2.100.395/SP, Rel. Min. Maria Isabel Gallotti, afetado em 2025, situação "afetado"). Há **suspensão dos REsp e AREsp** sobre a questão. Conferir antes de discutir legitimidade passiva.
- **Bem de família**: é penhorável para cobrar contribuições devidas em função do próprio imóvel (Lei 8.009/90, art. 3º, IV, C1). Entendimento consolidado na *Jurisprudência em Teses* do STJ, ed. 44 (C1 quanto à existência do enunciado).
- **Preferência**: o crédito de cotas condominiais prefere ao crédito hipotecário (**Súmula 478/STJ**, 2ª Seção, DJe 19/06/2012, C1).
- **Teses de defesa**: excesso de execução; cobrança de parcelas prescritas; juros e multa acima do art. 1.336, §1º; ilegitimidade passiva (Temas 886 e 1349); ausência de ata aprovando a cota extra; rateio fora da fração ideal sem previsão na convenção (art. 1.336, I).

## 4. Síndico: atribuições, contas e destituição
- **Mandato** de até 2 anos, renovável; o síndico pode não ser condômino (art. 1.347).
- **Competências** (art. 1.348): convocar assembleias; representar o condomínio; cumprir e fazer cumprir convenção, regimento e deliberações; elaborar orçamento; cobrar contribuições e **impor e cobrar multas**; **prestar contas anualmente e quando exigidas**; contratar o seguro da edificação (art. 1.346).
- **Conselho fiscal** (art. 1.356): facultativo, com 3 membros, que dão parecer sobre as contas.
- **Destituição** (art. 1.349): por irregularidades, falta de prestação de contas ou má administração, com voto da maioria absoluta dos membros da assembleia especialmente convocada.
- **Contas em juízo**: ação de exigir contas (CPC, arts. 550 e seguintes). A legitimidade do condômino isolado, quando a assembleia já aprovou as contas, é controvertida (C3 — verificar).
- **Responsabilidade civil** pessoal do síndico por ato ilícito ou abuso: regra geral (CC, arts. 186 e 927). O síndico profissional também responde contratualmente.

## 5. Uso das unidades e das áreas comuns
### 5.1 Locação de curta temporada por plataformas (Airbnb e similares) 🔄
- **STJ, 4ª T., REsp 1.819.075/RS**, Rel. Min. Luis Felipe Salomão, relator para o acórdão Min. Raul Araújo, j. 20/04/2021, DJe 27/05/2021, por maioria (C1). Se a convenção impõe destinação residencial, é indevido usar a unidade para hospedagem atípica. Os condôminos podem autorizar esse uso por maioria qualificada.
- **STJ, 2ª Seção, REsp 2.121.055/MG**, Rel. Min. Nancy Andrighi, j. 07/05/2026, por maioria, Informativo 889 (C1, **não repetitivo**, mas uniformiza as Turmas de direito privado). Pontos centrais:
  - Os contratos atípicos de curta estadia com **exploração econômica reiterada ou profissionalizada** descaracterizam a destinação residencial.
  - Esses contratos **não são** locação para temporada nem hospedagem.
  - O uso depende de previsão na convenção aprovada por **2/3 dos condôminos** (art. 1.351).
- 🔄 **Tema Repetitivo 1443/STJ** (2ª Seção, Rel. Min. Raul Araújo, REsp 2.272.537/SC e 2.272.536/SP; afetação em sessão encerrada em 26/05/2026; situação "afetado").
  - **Questão**: se a cláusula de destinação residencial basta para impedir locações curtas por plataforma sem proibição expressa.
  - **Há suspensão de todos os processos pendentes**, individuais ou coletivos, sobre a mesma questão.
  - **Efeito prático**: em demanda nova ou em curso, pedir o sobrestamento ou verificar se cabe distinção. Não prometer resultado.
- Leis municipais que regulam a hospedagem por plataforma também devem ser checadas (C3 — verificar no município).

### 5.2 Animais, obras e áreas comuns
- **Animais**: é ilegítima a proibição genérica de criar e guardar animais de qualquer espécie. Restrições ligadas a risco, higiene ou sossego são admitidas. **STJ, 3ª T., REsp 1.783.076/DF**, Rel. Min. Ricardo Villas Bôas Cueva, j. 14/05/2019, DJe 24/05/2019, unânime (C1).
- **Obras na unidade**: não podem comprometer a segurança nem alterar a fachada (art. 1.336, II e III). Obras urgentes e necessárias nas partes comuns podem ser feitas pelo síndico ou por qualquer condômino (art. 1.341, §§1º a 4º). Conferir também a norma técnica de reformas e o regimento.
- **Partes comuns**: o uso deve seguir a destinação, sem excluir os demais (art. 1.335, II). A vaga de garagem não pode ser alugada ou vendida a estranhos sem autorização expressa na convenção (art. 1.331, §1º, Lei 12.607/2012). Na locação de vaga, os condôminos têm preferência (art. 1.338).

---

## 6. Locação urbana (Lei 8.245/91)
Texto conferido em 07/10/2026. As últimas alterações relevantes vieram das Leis 12.112/2009 e 12.744/2012. Não se localizou alteração legislativa posterior que afete os pontos abaixo.

### 6.1 Modalidades
- **Residencial**: com contrato escrito de **30 meses ou mais**, a locação termina no fim do prazo; se prorrogada, a denúncia vazia exige aviso de 30 dias (art. 46). Com prazo **inferior a 30 meses**, a retomada só cabe nas hipóteses do art. 47, entre elas uso próprio, obras e vigência ininterrupta acima de 5 anos.
- **Temporada**: prazo de **até 90 dias** (art. 48). Admite cobrança antecipada (art. 49). Se o locatário ficar mais de 30 dias após o termo sem oposição, a locação se prorroga e só pode ser denunciada após 30 meses ou nas hipóteses do art. 47 (art. 50).
- **Não residencial**: tem direito à renovatória (arts. 51 e seguintes). A locação *built to suit* segue o art. 54-A: prevalece o pactuado, pode haver renúncia à revisional e a multa não pode passar dos aluguéis restantes.

### 6.2 Garantias
- **Modalidades** (art. 37): caução, fiança, seguro-fiança e cessão fiduciária de cotas de fundo. **É vedada, sob pena de nulidade, mais de uma modalidade no mesmo contrato.** A caução em dinheiro é de **até 3 aluguéis** (art. 38, §2º).
- As garantias valem até a devolução do imóvel, mesmo com prorrogação por prazo indeterminado (art. 39). Na prorrogação, o fiador pode se exonerar, mas continua obrigado por **120 dias** após notificar (art. 40, X). O locador pode exigir nova garantia em 30 dias (art. 40, parágrafo único). Sem garantia, o aluguel pode ser cobrado antecipadamente (art. 42).
- O fiador não responde por aditamento a que não anuiu (**Súmula 214/STJ**, 3ª Seção, DJ 02/10/1998, C1).
- **Bem de família do fiador**: a Lei 8.009/90, art. 3º, VII, exclui da impenhorabilidade a dívida de fiança locatícia.
  - **STF, Tema 1127 (RE 1.307.334)**, Rel. Min. Alexandre de Moraes, Plenário Virtual encerrado em 08/03/2022, DJe 01/07/2022, trânsito em julgado em 06/08/2022 (C1, repercussão geral). Tese: é constitucional a penhora do bem de família do fiador de locação **residencial ou comercial**.
  - **STJ, Tema Repetitivo 1091** (REsp 1.822.033/PR e 1.822.040/PR, 2ª Seção, Rel. Min. Luis Felipe Salomão, j. 08/06/2022, trânsito em julgado em 24/08/2022) e **Súmula 549/STJ** (DJe 19/10/2015): no mesmo sentido (C1).

### 6.3 Despejo
- **Hipóteses gerais** (art. 9º): mútuo acordo, infração legal ou contratual, falta de pagamento e reparos urgentes; além das hipóteses dos arts. 46, 47, 50 e 53.
- **Liminar** de desocupação em **15 dias**, sem ouvir o réu, com caução de **3 aluguéis** (art. 59, §1º). Cabe nos incisos I a IX, entre eles:
  - fim da temporada, com ação proposta em até 30 dias;
  - fim do prazo da locação não residencial, com ação em até 30 dias do termo ou da notificação;
  - não apresentação de nova garantia (art. 40, parágrafo único);
  - **falta de pagamento em contrato sem garantia** (inciso IX). Nesse caso, o depósito integral dentro dos 15 dias evita a rescisão (§3º).
- **Purga da mora**: locatário ou fiador podem depositar o débito atualizado em **15 dias** da citação (art. 62, II). Não cabe se o locatário já purgou nos **24 meses** anteriores (art. 62, parágrafo único).
- **Prazos de desocupação**: 30 dias após a procedência, reduzidos a 15 dias nos casos do art. 63, §1º. A execução provisória exige caução de **6 a 12 aluguéis**, salvo nas ações do art. 9º (art. 64).
- **Regras processuais** (art. 58): os recursos contra a sentença têm **efeito só devolutivo**; o valor da causa é de 12 aluguéis; o foro é o do imóvel, salvo eleição.
- O despejo para **uso próprio** também pode correr no JEC (Lei 9.099, art. 3º, III).

### 6.4 Renovatória, revisional, reajuste e outros pontos
- **Renovatória** (art. 51): requisitos cumulativos:
  - contrato escrito com prazo determinado;
  - **5 anos** de contrato (ou soma de contratos ininterruptos);
  - **3 anos** no mesmo ramo.
  A ação deve ser proposta **entre 1 ano e 6 meses antes** do fim do contrato. O prazo é **decadencial** (§5º). A petição inicial segue o art. 71. A contestação fica limitada às matérias do art. 72. As exceções à renovação estão no art. 52, e o §3º prevê indenização ao locatário.
- **Revisional** (art. 19): cabe após **3 anos** de vigência do contrato ou do último acordo, para ajustar o aluguel ao valor de mercado. O aluguel provisório é limitado a 80% do pedido (locador) ou não pode ser inferior a 80% do vigente (locatário) (art. 68, II).
- **Reajuste**:
  - O índice é de livre escolha, vedada a vinculação ao salário mínimo, ao câmbio ou a moeda estrangeira (arts. 17 e 85).
  - A periodicidade mínima é **anual** (Lei 10.192/2001, art. 2º, §1º).
  - 🔄 **IGP-M x IPCA**: não há lei impondo o IPCA. A substituição do índice depende de acordo, de cláusula de substituição ou de revisão judicial por onerosidade excessiva.
  - Projetos de lei que limitam o reajuste ao IPCA (ex.: PL 1.026/2021, na Câmara) **não são lei** (C3 — verificar a tramitação). A jurisprudência sobre troca judicial de índice é casuística (C3 — verificar o TJ local).
- **Multa rescisória** (art. 4º): é **proporcional** ao tempo de contrato já cumprido. O locatário fica dispensado dela se for transferido pelo empregador e avisar com 30 dias. A exceção é o *built to suit* (art. 54-A, §2º).
- **Benfeitorias**: as necessárias e as úteis autorizadas são indenizáveis e dão direito de retenção, salvo cláusula em contrário (art. 35). As voluptuárias não são indenizáveis (art. 36). A renúncia contratual à indenização e à retenção é válida (**Súmula 335/STJ**, 3ª Seção, DJ 07/05/2007, C1).
- **Direito de preferência** (art. 27): na venda, o locador deve comunicar todas as condições do negócio.
  - Sem averbação, o locatário preterido só pode pedir **perdas e danos**.
  - Para **adjudicar o imóvel**, o contrato precisa estar **averbado ao menos 30 dias antes** da alienação, e a ação deve vir em **6 meses** do registro, com depósito do preço (art. 33).
- **Encargos**: as despesas **extraordinárias** de condomínio são do locador (art. 22, X). As ordinárias, do locatário (art. 23).

---

## 7. Checklists de atuação

**A. Recurso contra multa condominial**
- [ ] Obter convenção, regimento, ata de aprovação do regimento, notificação e provas que embasaram a multa
- [ ] Identificar a base da multa (art. 1.336, §2º, ou art. 1.337) e verificar se o valor respeita o teto em contribuições mensais
- [ ] Conferir tipicidade, descrição do fato, competência de quem aplicou e previsão de advertência prévia
- [ ] Verificar se houve oportunidade de defesa **antes** da aplicação (REsp 1.365.279/SP)
- [ ] Em caso de ruído, checar se houve medição pela NBR 10151/10152, o horário frente à lei municipal e a existência de testemunhas independentes
- [ ] Conferir reincidência: as infrações anteriores foram validamente constituídas?
- [ ] Respeitar o prazo do recurso interno, pedir efeito suspensivo e a exibição de provas
- [ ] Definir a via judicial (anulatória no JEC ou na vara cível) e avaliar tutela contra a cobrança

**B. Defesa em cobrança ou execução de cotas**
- [ ] Título (art. 784, X): há convenção, ata e demonstrativo? A cota extra foi aprovada?
- [ ] Prescrição quinquenal parcela a parcela (Tema 949)
- [ ] Legitimidade passiva (Tema 886 e Tema 1349, pendente)
- [ ] Encargos: multa limitada a 2%, juros convencionados ou taxa legal, índice de correção
- [ ] Bem de família: a exceção do art. 3º, IV, da Lei 8.009/90 se aplica → buscar acordo ou parcelamento antes da praça

**C. Despejo e renovatória**
- [ ] Modalidade da locação, prazo, garantia existente (art. 37) e hipótese de retomada
- [ ] Cabimento da liminar (art. 59, §1º), caução de 3 aluguéis e prazo de 30 dias para ajuizar quando exigido
- [ ] Purga da mora: houve purgação nos 24 meses anteriores?
- [ ] Renovatória: requisitos do art. 51, janela de 1 ano a 6 meses (decadência), documentos do art. 71 e idoneidade atual do fiador
- [ ] Revisional: completou 3 anos? Há laudo de mercado?

## 8. Pontos de verificação obrigatória (pesquisar antes de afirmar)
1. **Convenção e regimento do condomínio concreto**: texto vigente, registro, alterações e quórum com que foram aprovadas.
2. **Lei municipal** de ruído e silêncio (limites e horários) e eventual lei municipal sobre hospedagem por plataforma.
3. **Jurisprudência do TJ do estado**: multas, Airbnb (enquanto o Tema 1443 estiver pendente), troca de índice de reajuste, condomínio como autor no JEC.
4. **Status dos Temas 1443 e 1349/STJ**: tese fixada, modulação e fim da suspensão.
5. **Reforma do Código Civil** (PL 4/2025, no Senado) e projetos sobre reajuste de aluguel: verificar se viraram lei (C3).
6. **Taxa legal do art. 406** vigente no período do débito.

## 9. Erros que este plugin existe para impedir
1. Dizer que mudar a destinação exige **unanimidade**: desde a Lei 14.405/2022, bastam 2/3. A unanimidade só vale para novo pavimento ou edifício (art. 1.343).
2. Aplicar a multa moratória de **20%** da Lei 4.591/64 a débitos atuais.
3. Tratar o **REsp 2.121.055/MG** como repetitivo, ou ignorar a **suspensão nacional do Tema 1443**.
4. Afirmar que o fiador de **locação comercial** tem bem de família impenhorável (Tema 1127/STF e Tema 1091/STJ dizem o contrário).
5. Exigir ou aceitar **duas garantias** no mesmo contrato de locação (nulidade, art. 37, parágrafo único).
6. Aplicar multa por infração **sem notificação e sem defesa prévias**, ou sem prova técnica do ruído.
7. Proibir o inadimplente de usar áreas comuns.
8. Cobrar **multa rescisória integral** sem proporcionalidade (art. 4º).
9. Perder a **janela decadencial** da renovatória (art. 51, §5º).
10. Afirmar que existe lei que impõe o **IPCA** ao reajuste de aluguel.
