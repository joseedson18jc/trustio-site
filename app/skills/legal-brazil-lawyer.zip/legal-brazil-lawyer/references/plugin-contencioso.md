# Plugin: Contencioso, Processo Civil e Estratégia Processual

## Ativar quando
Pedido envolver análise de risco processual, estratégia de litígio, elaboração de peças processuais, tutela de urgência, execução, recursos, arbitragem ou avaliação de contingências.

## Raciocínio especializado

### Sequência obrigatória de análise processual
1. Identificar natureza da demanda (conhecimento, execução, cautelar)
2. Verificar competência (absoluta/relativa, material, territorial, funcional)
3. Verificar legitimidade ativa e passiva
4. Verificar prescrição e decadência
5. Analisar requisitos da tutela de urgência (se aplicável)
6. Mapear provas disponíveis e necessárias
7. Identificar precedentes vinculantes aplicáveis
8. Estimar prognóstico e construir estratégia

### Tutela de urgência — CPC arts. 300-310

#### Tutela cautelar
- **Requisitos**: fumus boni iuris + periculum in mora
- **Fungibilidade**: art. 305 parágrafo único — juiz pode conceder cautelar quando pedida antecipada e vice-versa
- **Prazo**: efetivada em 30 dias; não executada, cessa (art. 309 I)

#### Tutela antecipada
- **Requisitos**: probabilidade do direito + perigo de dano ou risco ao resultado útil
- **Tutela de evidência** (art. 311): dispensa periculum — abuso de defesa, prova documental suficiente, tese firmada em repetitivo, dependência de contrato de depósito
- **Estabilização** (art. 304): não impugnada = estabilização; revisão em 2 anos

#### Tutela antecipada antecedente
- Petição simplificada → deferimento → aditamento em 15 dias
- Não cumprida a tutela: multa + medidas indutivas (art. 139 IV CPC)

### Precedentes vinculantes — hierarquia CPC art. 927
1. Decisões STF em controle concentrado
2. Súmulas vinculantes STF
3. Acórdãos STF/STJ em incidente de resolução de demandas repetitivas (IRDR) e recursos repetitivos
4. Enunciados das súmulas do STF e STJ
5. Acórdãos dos tribunais locais em IRDR e assunção de competência

**Distinguishing**: demonstrar que os fatos do caso diferem do precedente
**Overruling**: sinalizar superação do entendimento com fundamentação

### Prescrição — prazos principais

| Pretensão | Prazo | Base |
|---|---|---|
| Geral (CC) | 10 anos | Art. 205 CC |
| Reparação civil | 3 anos | Art. 206 §3º V CC |
| Responsabilidade civil contratual | 3 anos | Art. 206 §3º V CC |
| Trabalhista (durante contrato) | 5 anos | Art. 7º XXIX CF |
| Trabalhista (após extinção) | 2 anos | Art. 7º XXIX CF |
| Tributária (lançamento) | 5 anos | Art. 173 CTN |
| Tributária (execução fiscal) | 5 anos | Art. 174 CTN |
| Consumidor | 5 anos (fato do produto/serviço) | Art. 27 CDC |
| Consumidor | 30 dias / 90 dias (vício) | Art. 26 CDC |

### Recursos — prazo e preparo (CPC 2015)

| Recurso | Prazo | Preparo |
|---|---|---|
| Apelação | 15 dias úteis | Sim |
| Agravo de instrumento | 15 dias úteis | Sim |
| Agravo interno | 15 dias úteis | Não |
| Embargos de declaração | 5 dias úteis | Não |
| Recurso especial / extraordinário | 15 dias úteis | Sim |
| Agravo em REsp/RE | 15 dias úteis | Sim |
| Embargos de divergência | 15 dias úteis | Sim |

⚠️ Prazo em dias **úteis** (art. 219 CPC) — verificar feriados locais

### Execução civil
- **Título executivo judicial**: art. 515 CPC — sentença, decisão, acórdão, homologação, formal de partilha
- **Título executivo extrajudicial**: art. 784 CPC — CDA, escritura, notas promissórias, duplicatas, etc.
- **Penhora**: ordem preferencial art. 835 CPC — dinheiro primeiro
- **Impenhorabilidade**: art. 833 CPC — salário, bem de família (Lei 8.009/90), pequena propriedade rural
- **Desconsideração da personalidade jurídica**: arts. 133-137 CPC — incidente com contraditório

### Arbitragem — pontos críticos (Lei 9.307/96)
- **Cláusula compromissória vazia**: mediação prévia + compromisso arbitral
- **Cláusula cheia**: câmara + regimento + sede definidos — inicia diretamente
- **Kompetenz-Kompetenz**: árbitro decide sobre própria competência
- **Medidas de urgência pré-arbitrais**: juízo estatal (art. 22-A Lei 9.307/96)
- **Sentença arbitral**: equiparada ao título executivo judicial; anulação apenas pelos vícios do art. 32
- **Sigilo**: regra geral na arbitragem comercial — explicitar em cláusula
- **Câmaras relevantes no Brasil**: CAM-CCBC, CAMARB, FGV, ICC Brasil, CIESP/FIESP

### Análise de contingência — metodologia
```
Valor da contingência = Valor discutido × Probabilidade de perda

Probabilidade sugerida:
- Risco remoto (< 25%): não provisionar, divulgar em nota
- Risco possível (25–75%): divulgar em nota; avaliar provisão por política
- Risco provável (> 75%): provisionar integralmente

Valor a provisionar = principal + juros Selic + multa moratória + honorários estimados
```

### Estrutura de peça processual — padrão

#### Petição inicial
1. Endereçamento e qualificação das partes
2. Dos fatos (cronológico, objetivo, sem adjetivos desnecessários)
3. Do direito (norma → jurisprudência → aplicação ao caso)
4. Da tutela de urgência (se cabível) — requisitos explicitados
5. Dos pedidos (principal + subsidiários + honorários + custas)
6. Do valor da causa
7. Das provas que pretende produzir
8. Requerimentos finais

#### Contestação
1. Preliminares (prescrição, ilegitimidade, incompetência, inépcia)
2. No mérito (impugnar fato a fato; não negar fato verdadeiro — art. 341 CPC)
3. Matérias de defesa (exceções, compensação, reconvenção se cabível)
4. Contrariedade à tutela de urgência (se deferida)
5. Pedido de improcedência total ou parcial

### Formato de saída preferencial
- Parecer de risco processual: questão → análise → probabilidade → impacto → provisão sugerida
- Estratégia de litígio: linha de defesa principal + linhas subsidiárias + provas necessárias + precedentes favoráveis/desfavoráveis
- Minuta de petição: estrutura completa com campos variáveis marcados em [COLCHETES]
- Cronograma processual: marco | prazo | responsável | risco
