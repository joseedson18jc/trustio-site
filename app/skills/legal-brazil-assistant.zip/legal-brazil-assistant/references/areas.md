# Referência: Áreas Jurídicas Cobertas

Este arquivo contém o detalhamento completo dos tópicos por área. Consultar quando a análise exigir aprofundamento em subtópicos específicos de uma área.

> Mapa de escopo, não de vigência. Para norma, data, valor ou precedente recente, consultar `radar-normativo.md` e, quando disponível, verificar em fonte oficial.
> Aprofundamento nas áreas 12, 14 e 16: `plugin-trabalhista.md` e `plugin-consumidor-bancario.md`.

---

## 1. Direito constitucional
- controle de constitucionalidade
- direitos e garantias fundamentais
- organização do estado
- repartição de competências
- federalismo
- administração pública sob perspectiva constitucional
- devido processo legal
- contraditório e ampla defesa
- remédios constitucionais
- ações constitucionais
- princípios constitucionais aplicáveis a casos concretos
- colisão de direitos fundamentais
- interpretação conforme
- modulação de efeitos
- repercussão geral
- controle difuso e concentrado

## 2. Direito administrativo
- atos administrativos
- poderes da administração
- discricionariedade e vinculação
- processo administrativo
- responsabilidade civil do estado
- improbidade administrativa
- agentes públicos
- bens públicos
- intervenção do estado
- delegações de serviço público
- concessão, permissão e autorização
- parcerias com a administração pública
- poder de polícia
- sanções administrativas
- controle interno e externo
- regime jurídico-administrativo
- nulidades administrativas

## 3. Licitações, contratos administrativos e compras públicas
- nova lei de licitações
- contratação direta
- dispensa e inexigibilidade
- fase preparatória
- habilitação
- julgamento
- recursos administrativos
- gestão e fiscalização contratual
- equilíbrio econômico-financeiro
- reequilíbrio e reajuste
- penalidades contratuais
- matriz de riscos
- contratos de obras e serviços
- contratos continuados
- aditivos
- governança em compras públicas
- compliance em contratação pública

## 4. Direito civil
- personalidade e capacidade
- direitos da personalidade
- bens
- fatos, atos e negócios jurídicos
- nulidade e anulabilidade
- prescrição e decadência
- obrigações
- inadimplemento
- responsabilidade civil
- perdas e danos
- dano moral
- dano material
- dano estético
- enriquecimento sem causa
- posse
- propriedade
- direitos reais
- usucapião
- condomínio
- direitos de vizinhança

## 5. Direito contratual
- formação do contrato
- interpretação contratual
- cláusulas gerais
- boa-fé objetiva
- função social do contrato
- revisão contratual
- resolução e resilição
- cláusula penal
- arras
- garantias
- compra e venda
- prestação de serviços
- distribuição
- representação comercial
- comissão
- agência
- locação
- empreitada
- parceria comercial
- contratos atípicos
- contratos empresariais complexos
- contratos de tecnologia
- contratos de fornecimento
- contratos de longo prazo

## 6. Direito empresarial
- empresa e empresário
- estabelecimento empresarial
- nome empresarial
- títulos de crédito
- governança corporativa
- responsabilidade empresarial
- contratos mercantis
- operações estruturadas
- reorganização societária
- grupos econômicos
- conflitos entre sócios
- deveres fiduciários
- operações societárias
- joint ventures
- compliance corporativo
- contencioso empresarial

## 7. Direito societário
- sociedades simples e empresárias
- limitada
- sociedade anônima
- acordo de sócios e acionistas
- assembleias e reuniões
- quóruns
- administração
- deveres de administradores
- conflito de interesses
- abuso de poder de controle
- dissolução parcial
- retirada e exclusão de sócio
- aumento e redução de capital
- reorganizações societárias
- fusão, cisão e incorporação
- due diligence societária
- governança e documentação societária

## 8. Fusões e aquisições (M&A)
- estruturação da operação
- due diligence
- carta de intenções
- memorando de entendimentos
- conditions precedent
- representations and warranties
- indenizações
- escrow
- earn-out
- non-compete
- non-solicitation
- alocação de riscos
- closing e post-closing
- integração pós-aquisição
- red flags de passivo oculto
- impactos regulatórios e concorrenciais

## 9. Recuperação judicial, extrajudicial, insolvência e falência
- crise econômico-financeira
- crédito sujeito e extraconcursal
- stay period
- plano de recuperação
- assembleia de credores
- classificação de créditos
- impugnação de crédito
- falência
- arrecadação de bens
- revocatória
- responsabilidade de administradores
- efeitos da insolvência em contratos
- sucessão e passivos
- reestruturação de dívida
- negociação com credores

## 10. Direito tributário
- tributos diretos e indiretos
- obrigação tributária
- fato gerador
- base de cálculo
- imunidade
- isenção
- benefício fiscal
- lançamento
- crédito tributário
- suspensão, extinção e exclusão do crédito
- obrigações acessórias
- contencioso administrativo
- execução fiscal
- planejamento tributário
- tributos sobre consumo
- tributos sobre renda e patrimônio
- contribuições
- compensação
- restituição
- teses tributárias
- impacto tributário em contratos e operações societárias

## 11. Direito aduaneiro e comércio exterior
- importação e exportação
- classificação fiscal
- valoração aduaneira
- drawback
- regimes especiais
- despacho aduaneiro
- infrações aduaneiras
- barreiras regulatórias
- sanções comerciais
- defesa comercial
- compliance aduaneiro
- contratos internacionais
- documentação de comércio exterior
- risco regulatório transfronteiriço

## 12. Direito financeiro, bancário e mercado de capitais
- operações e contratos bancários
- crédito, garantias financeiras, cédulas e títulos
- juros, capitalização, tarifas e custo efetivo total
- revisional bancária e execução de dívida
- alienação fiduciária e busca e apreensão (inclusive extrajudicial — Lei 14.711/2023)
- consignado público, privado (Lei 15.179/2025) e RMC
- regulação bancária e conduta com clientes (Res. CMN 4.949/2021)
- meios de pagamento, arranjos e instituições de pagamento
- Pix, MED e prevenção a fraudes (Res. BCB 1/2020 e alterações)
- fintechs, SCD e SEP (Res. CMN 5.050/2022)
- Banking as a Service (Res. Conjunta 16/2025)
- autorização e capital de instituições (Res. BCB 80 e 81/2021; Res. Conjunta 14/2025)
- criptoativos e prestadoras de serviços de ativos virtuais (Lei 14.478/2022; Res. BCB 519, 520 e 521/2025)
- open finance e portabilidade de crédito (Res. Conjunta 1/2020 e 15/2025)
- PLD/FT, KYC e compartilhamento de dados de fraude
- mercado de capitais, ofertas públicas e deveres informacionais
- governança de companhias abertas, insider trading e abuso de mercado
- fundos de investimento e securitização
- responsabilidade civil por falha de segurança e vazamento de dados

## 13. Direito securitário
- contrato de seguro
- cobertura e exclusões
- aviso de sinistro
- agravamento de risco
- sub-rogação
- negativa de cobertura
- resseguro
- seguros empresariais
- responsabilidade civil segurada
- seguro garantia
- interpretação de apólices
- regulação setorial
- litígios securitários

## 14. Direito do trabalho
- vínculo empregatício e elementos dos arts. 2º e 3º da CLT
- pejotização e contratação de autônomo (STF, Tema 1389)
- terceirização, quarteirização e responsabilidade subsidiária
- trabalho por plataformas digitais e subordinação algorítmica (STF, Tema 1291)
- modalidades contratuais: prazo determinado, intermitente, temporário, doméstico
- teletrabalho e trabalho híbrido (Lei 14.442/2022)
- jornada, horas extras, banco de horas, 12x36 e controle de ponto
- cargos de confiança e trabalho externo
- adicionais: insalubridade, periculosidade (inclusive motociclistas), noturno
- rescisão, verbas rescisórias, justa causa e rescisão indireta
- estabilidades e garantias de emprego
- equiparação salarial e igualdade salarial (Lei 14.611/2023)
- assédio moral e sexual; canal de denúncia (Lei 14.457/2022)
- saúde e segurança, NRs e riscos psicossociais no PGR (NR-1)
- acidente do trabalho, doença ocupacional e nexo
- eSocial, DET, CTPS Digital e FGTS Digital
- negociação coletiva, sindicatos e contribuição assistencial
- negociado sobre legislado (STF, Tema 1046)
- prescrição, prescrição intercorrente e execução trabalhista
- honorários, gratuidade de justiça e custas
- atualização monetária e juros do crédito trabalhista
- passivo trabalhista, provisão e contingência
- compliance trabalhista e políticas internas
- proteção de dados nas relações de trabalho

## 15. Direito previdenciário
- regime geral e regimes próprios
- benefícios previdenciários
- aposentadorias
- auxílio-doença e incapacidade
- pensão por morte
- revisão de benefícios
- tempo de contribuição
- qualidade de segurado
- carência
- contribuições previdenciárias
- contencioso previdenciário
- impactos previdenciários em relações de trabalho

## 16. Direito do consumidor
- responsabilidade por vício e por defeito (arts. 12 a 20 do CDC)
- aplicação do CDC a bancos, fintechs e instituições de pagamento
- teoria finalista mitigada e prova de vulnerabilidade
- dever de informação e custo efetivo total
- publicidade enganosa e abusiva
- práticas e cláusulas abusivas
- assédio de crédito e crédito responsável
- superendividamento, mínimo existencial e repactuação (arts. 54-A a 54-G e 104-A a 104-C)
- fraudes e golpes bancários; responsabilidade por fortuito interno (Súmula 479 do STJ)
- negativação, cadastros restritivos e comunicação prévia
- dano moral, dano moral coletivo e desvio produtivo
- comércio eletrônico, plataformas e marketplaces
- atendimento ao consumidor, SAC e cancelamento
- recall e segurança de produtos
- contratos de adesão e interpretação mais favorável
- seguros e seguro prestamista (Lei 15.040/2024)
- proteção de dados do consumidor
- contencioso de massa, litigância predatória e ações coletivas
- Procons, Senacon e consumidor.gov.br

## 17. Direito digital e tecnologia
- contratos de tecnologia
- software
- SaaS
- licenciamento
- cloud
- dados e governança informacional
- plataformas digitais
- marketplaces
- responsabilidade de intermediários
- moderação de conteúdo
- provas digitais
- logs e rastreabilidade
- crimes digitais em interface com outras áreas
- incidentes cibernéticos
- termos de uso
- políticas de plataforma
- inteligência artificial
- governança algorítmica
- risco regulatório em tecnologia

## 18. Privacidade e proteção de dados
- LGPD
- bases legais
- consentimento
- legítimo interesse
- direitos dos titulares
- controlador e operador
- compartilhamento de dados
- transferência internacional
- retenção e descarte
- resposta a incidentes
- segurança da informação
- anonimização e pseudonimização
- relatórios de impacto
- contratos de tratamento de dados
- políticas de privacidade
- governança de privacidade
- atuação perante ANPD

## 19. Propriedade intelectual
- direito autoral
- software
- marcas
- patentes
- desenhos industriais
- nomes de domínio
- trade dress
- segredos de negócio
- licenciamento
- cessão
- franquia sob aspecto de ip
- infração e contrafação
- concorrência desleal
- proteção contratual de ativos intangíveis
- exploração econômica de propriedade intelectual

## 20. Direito concorrencial e antitruste
- abuso de posição dominante
- cartel
- gun jumping
- atos de concentração
- análise concorrencial de contratos
- exclusividade
- discriminação anticoncorrencial
- concorrência desleal
- mercado relevante
- barreiras à entrada
- investigação concorrencial
- remédios concorrenciais
- impactos concorrenciais de operações societárias

## 21. Direito regulatório
- regulação setorial
- agências reguladoras
- autorizações, licenças e concessões
- conformidade regulatória
- sanções regulatórias
- deveres informacionais
- monitoramento normativo
- interação com órgãos reguladores
- riscos de setor regulado
- interpretação de atos infralegais
- contencioso administrativo regulatório

## 22. Compliance, ética corporativa e investigações internas
- programa de integridade
- anticorrupção
- conflito de interesses
- due diligence de terceiros
- canais de denúncia
- investigações internas
- relatórios investigativos
- políticas internas
- controles internos
- sanções disciplinares
- treinamento e governança
- prevenção à fraude
- avaliação de risco de compliance
- interação com auditoria
- responsabilização corporativa

## 23. Lavagem de dinheiro, sanções e integridade financeira
- prevenção à lavagem de dinheiro
- know your customer
- know your supplier
- monitoramento de operações
- comunicações obrigatórias
- pessoas politicamente expostas
- sanções nacionais e internacionais
- screening
- bloqueios e restrições
- risco reputacional e financeiro
- governança de prevenção a ilícitos financeiros

## 24. Direito penal e processo penal
- teoria do crime
- tipicidade, ilicitude e culpabilidade
- crimes patrimoniais
- crimes contra a administração
- crimes econômicos
- crimes tributários
- crimes ambientais
- crimes digitais
- responsabilidade penal da pessoa física
- persecução penal
- inquérito
- medidas cautelares
- ação penal
- provas penais
- nulidades
- recursos
- execução penal
- garantias processuais penais

## 25. Direito penal econômico e empresarial
- lavagem de dinheiro
- crimes societários
- crimes financeiros
- crimes falimentares
- crimes contra a ordem tributária
- crimes contra a ordem econômica
- responsabilidade de administradores
- interface entre investigação interna e persecução penal
- cooperação com autoridades
- gestão de crise jurídica empresarial

## 26. Direito processual civil
- competência
- legitimidade
- interesse de agir
- tutela provisória
- ônus da prova
- produção de prova
- negócios processuais
- saneamento
- sentença
- coisa julgada
- cumprimento de sentença
- execução
- impugnações
- recursos
- precedentes no cpc
- nulidades
- preclusão
- estratégias processuais

## 27. Arbitragem, mediação e métodos adequados de resolução de disputas
- cláusula compromissória
- compromisso arbitral
- competência do tribunal arbitral
- arbitrabilidade
- medidas de urgência
- confidencialidade
- produção de prova em arbitragem
- sentença arbitral
- anulação de sentença arbitral
- mediação
- negociação assistida
- dispute boards
- estratégia de resolução consensual

## 28. Direito imobiliário
- compra e venda de imóveis
- promessa de compra e venda
- incorporação imobiliária
- loteamento
- locação residencial e comercial
- built to suit
- sale and leaseback
- garantias imobiliárias
- matrícula e registro
- due diligence imobiliária
- vícios construtivos
- posse e propriedade
- regularização documental
- contratos imobiliários empresariais

## 29. Direito urbanístico
- uso e ocupação do solo
- plano diretor
- zoneamento
- licenciamento urbanístico
- regularização fundiária
- parcelamento do solo
- restrições urbanísticas
- instrumentos urbanísticos
- desapropriação
- interface com direito ambiental e imobiliário

## 30. Direito ambiental
- licenciamento ambiental
- responsabilidade ambiental
- dano ambiental
- obrigação propter rem
- áreas protegidas
- resíduos
- recursos hídricos
- poluição
- compensações ambientais
- termos de ajustamento
- infrações e sanções ambientais
- due diligence ambiental
- contencioso ambiental
- ESG em interface jurídica

## 31. Direito agrário e agronegócio
- propriedade e posse rural
- arrendamento rural
- parceria rural
- crédito rural
- garantias do agronegócio
- regularidade fundiária
- contratos do agro
- armazenagem e logística
- títulos do agronegócio
- questões ambientais rurais
- conflitos fundiários
- cadeias produtivas e distribuição

## 32. Direito minerário e recursos naturais
- títulos minerários
- pesquisa e lavra
- licenciamento
- servidões
- regulação setorial
- royalties e participações
- responsabilidade socioambiental
- conflitos com superficiários
- contencioso regulatório e contratual

## 33. Direito de energia
- geração, transmissão e distribuição
- comercialização de energia
- contratos de energia
- autoprodução
- geração distribuída
- regulação setorial
- autorizações e concessões
- encargos e tarifas
- riscos regulatórios e contratuais
- infraestrutura energética

## 34. Direito de telecomunicações e mídia
- serviços de telecom
- outorgas
- espectro
- obrigações regulatórias
- contratos de infraestrutura
- responsabilidade de provedores
- conteúdo e mídia
- publicidade regulada
- plataformas de comunicação
- sanções regulatórias
- interface com consumidor e proteção de dados

## 35. Direito da saúde e saúde suplementar
- contratos de plano de saúde
- cobertura assistencial
- reajustes
- rol regulatório
- negativa de cobertura
- judicialização da saúde
- responsabilidade médica e hospitalar
- compliance em saúde
- proteção de dados sensíveis
- regulação sanitária
- produtos sujeitos à vigilância sanitária

## 36. Direito farmacêutico e life sciences
- regulação sanitária
- registro e autorização
- ensaios clínicos
- publicidade de produtos regulados
- distribuição e comercialização
- responsabilidade por produto
- compliance setorial
- propriedade intelectual em saúde
- interação com autoridades sanitárias

## 37. Direito educacional
- regulação de instituições de ensino
- contratos educacionais
- responsabilidade civil em ambiente escolar
- proteção de dados de alunos
- conflitos de consumo em educação
- compliance institucional
- contencioso educacional

## 38. Direito de família
- casamento e união estável
- pacto antenupcial
- regime de bens
- alimentos
- guarda
- convivência
- filiação
- parentalidade
- investigação e reconhecimento
- dissolução conjugal
- partilha
- planejamento patrimonial familiar
- medidas protetivas em interface com outras áreas

## 39. Direito das sucessões
- sucessão legítima e testamentária
- inventário
- arrolamento
- partilha
- herdeiros necessários
- testamentos
- planejamento sucessório
- doações
- colação
- holding familiar sob ótica sucessória
- conflitos hereditários

## 40. Direito internacional privado e contratos internacionais
- lei aplicável
- foro competente
- arbitragem internacional
- execução de sentença estrangeira
- homologação
- contratos internacionais
- distribuição internacional de riscos
- cláusulas de hardship e force majeure
- compliance transnacional
- conflitos de leis

## 41. Direitos humanos
- tratados internacionais de direitos humanos
- controle de convencionalidade
- proteção de grupos vulneráveis
- liberdade de expressão
- igualdade e não discriminação
- garantias processuais
- interface com constitucional, penal, administrativo e internacional

## 42. Direito eleitoral e partidário
- elegibilidade e inelegibilidade
- propaganda eleitoral
- prestação de contas
- condutas vedadas
- abuso de poder
- financiamento de campanha
- partidos políticos
- contencioso eleitoral
- sanções eleitorais

## 43. Direito marítimo, portuário e logística
- transporte marítimo
- fretamento
- responsabilidade do transportador
- avarias
- operações portuárias
- contratos logísticos
- seguros de transporte
- regulação portuária
- comércio internacional em interface logística

## 44. Direito aeronáutico
- transporte aéreo
- responsabilidade do transportador
- regulação setorial
- contratos aeronáuticos
- seguros aeronáuticos
- operações e infraestrutura
- litígios em aviação civil

## 45. Direito desportivo
- contratos esportivos
- direitos de imagem
- transferências
- formação de atletas
- responsabilidade disciplinar
- entidades esportivas
- patrocínio
- propriedade intelectual no esporte
- litígios esportivos

## 46. Direito do terceiro setor e organizações sem fins lucrativos
- associações
- fundações
- governança
- qualificação e certificações
- parcerias com o poder público
- prestação de contas
- compliance
- responsabilidade de dirigentes
- captação de recursos
- imunidades e benefícios fiscais

## 47. Direito cooperativo
- sociedades cooperativas
- governança cooperativa
- assembleias
- responsabilidade de cooperados e administradores
- regimes regulatórios específicos
- relações contratuais e institucionais

## 48. Direito notarial e registral
- registros públicos
- atos notariais
- autenticação e fé pública
- registro civil
- registro imobiliário
- títulos e documentos
- regularização documental
- interface com imobiliário, família, sucessões e empresarial

## 49. Direito da moda, entretenimento e economia criativa
- contratos artísticos
- licenciamento
- imagem e voz
- publicidade
- direitos autorais
- marcas
- patrocínio
- cessão de direitos
- exploração comercial de ativos criativos
- litígios de reputação e uso indevido

## 50. ESG e sustentabilidade sob perspectiva jurídica
- governança
- responsabilidade socioambiental
- disclosures
- due diligence ESG
- greenwashing
- deveres de transparência
- cadeia de fornecedores
- riscos reputacionais e regulatórios
- interfaces com ambiental, societário, consumidor, trabalhista e mercado de capitais
