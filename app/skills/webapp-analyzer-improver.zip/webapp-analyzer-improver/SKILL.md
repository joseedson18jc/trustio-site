---
name: webapp-analyzer-improver
description: "Full-stack webapp/webpage analyzer, auditor and improver. Audits HTML, React, Vue or any web code across 8 dimensions (UI/UX, accessibility, performance, design, data viz, responsiveness, modernity, content) then IMPLEMENTS real fixes — modernizes the interface, adds charts, illustrations, animations and rich graphics. Trigger when user uploads HTML/JSX/web code and wants it analyzed, reviewed, audited, improved, modernized, redesigned, fixed or enhanced. Also trigger on: review my app, fix my UI, improve this page, modernize this design, make it professional, add charts/graphs, audit webapp, UX review, redesign, refactor frontend, beautify, make interactive, make dynamic, improve accessibility, fix responsiveness, or any variation of analyze and improve my web project. Produces improved output files, not just advice."
---

# Webapp Analyzer & Improver v2

Audits web applications across 8 dimensions, then **implements real improvements** — producing modernized, professional, interactive output with rich visual content. This is not an advisory skill — it writes and delivers production code.

## Core Principle

Operate as a **senior frontend architect + UX designer + performance engineer**. Every analysis MUST produce working improved code, not just a report. The goal: transform any webapp from its current state into a modern, polished, production-grade interface that looks like a funded startup shipped it.

## Design Creativity Mandate

**NEVER produce generic "AI slop" output.** Before implementing any improvements:

1. **Read the source deeply** — understand its purpose, audience, and domain
2. **Choose a bold aesthetic direction** — not "clean and modern" (too vague), but something specific: "editorial fintech with serif authority", "neon dashboard with cyberpunk data viz", "warm wellness with organic curves", "brutalist SaaS with bold type"
3. **Commit to a signature element** — one thing that makes the result unforgettable: an animated hero gradient mesh, a dramatic card hover effect, a distinctive navigation pattern, an unexpected color accent
4. **Vary every output** — never reuse the same palette, font pairing, or layout between projects. Rotate between light/dark themes, serif/sans, geometric/organic, maximalist/minimal

Avoid these clichés: Inter/Roboto everywhere, purple gradients on white, predictable card grids, cookie-cutter layouts, emoji as icons, generic hero sections.

Read `references/color-palettes.md` and `references/typography-pairings.md` to select distinctive combinations per project context.

## When to Apply

### Must Use
- User uploads HTML, JSX, TSX, Vue, Svelte, or any web page code
- User asks to "review", "audit", "improve", "fix", "modernize", "redesign", or "enhance" any web interface
- User wants charts, graphs, illustrations, animations, or rich visual content added
- User says something looks "ugly", "outdated", "boring", "basic", or "unprofessional"
- User wants responsive/mobile improvements or accessibility fixes
- User asks to "make it interactive", "make it dynamic", or "make it look like a real product"

### Skip
- Pure backend/API work with no frontend component
- Database-only or DevOps tasks
- User explicitly says they only want advice, no code changes

## File Handling (Cowork Environment)

### Reading Input
1. Check `/mnt/user-data/uploads/` for uploaded files
2. For HTML/JSX/TSX files: read with `view` tool or `cat` via bash
3. For large files (>500 lines): read in sections, build mental model before auditing
4. If file content is already in conversation context (text/image), use it directly — don't re-read

### Writing Output
1. Work in `/home/claude/` as scratch space
2. Copy final improved files to `/mnt/user-data/outputs/`
3. Use `present_files` to deliver — this is critical, the user cannot see files otherwise
4. For single-file apps: deliver one improved file
5. For multi-file apps: deliver a zip or each file separately

### File Type Strategy
| Input Type | Output Type | Notes |
|-----------|------------|-------|
| `.html` (single file) | `.html` (single file) | Inline CSS/JS, self-contained |
| `.jsx` / `.tsx` (React) | `.jsx` (single file artifact) | Tailwind + inline styles, no separate CSS |
| `.vue` | `.vue` or `.html` | SFC with scoped styles |
| Multiple files | Each file separately | Maintain original structure |
| Screenshot only | `.html` (recreation) | Recreate from visual, improve in process |

## Audit Framework: 8 Dimensions

Run ALL 8 audits on every analysis. Score each 0–100.

### Audit Report Format

Present the audit as a structured scorecard BEFORE implementing. Use this exact format:

```
╔══════════════════════════════════════════════════════╗
║           WEBAPP AUDIT REPORT — [App Name]          ║
╠══════════════════════════════════════════════════════╣
║                                                      ║
║  OVERALL SCORE: [XX]/100  [Letter Grade]            ║
║  ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━                  ║
║                                                      ║
║  1. Visual Design & Aesthetics   [XX]/100  [Grade]  ║
║  2. UI/UX Patterns               [XX]/100  [Grade]  ║
║  3. Data Viz & Graphics          [XX]/100  [Grade]  ║
║  4. Accessibility (CRITICAL)     [XX]/100  [Grade]  ║
║  5. Performance & Code Quality   [XX]/100  [Grade]  ║
║  6. Responsiveness               [XX]/100  [Grade]  ║
║  7. Modernity & Tech Stack       [XX]/100  [Grade]  ║
║  8. Content & Information Arch.  [XX]/100  [Grade]  ║
║                                                      ║
║  TOP CRITICAL ISSUES:                                ║
║  🔴 1. [Issue]                                       ║
║  🔴 2. [Issue]                                       ║
║  🔴 3. [Issue]                                       ║
║                                                      ║
║  QUICK WINS:                                         ║
║  🟢 1. [Win]                                         ║
║  🟢 2. [Win]                                         ║
║  🟢 3. [Win]                                         ║
╚══════════════════════════════════════════════════════╝
```

### Scoring Weights (for overall score)
| Dimension | Weight | Rationale |
|-----------|--------|-----------|
| Accessibility | 20% | Non-negotiable — legal and ethical baseline |
| Visual Design | 15% | First impression, professional credibility |
| UI/UX Patterns | 15% | User satisfaction and task completion |
| Performance | 15% | Core Web Vitals, user retention |
| Responsiveness | 10% | Multi-device reach |
| Data Viz & Graphics | 10% | Information clarity and engagement |
| Modernity | 10% | Maintainability, developer experience |
| Content/IA | 5% | Scannability and comprehension |

### Letter Grades
- **A** (90-100): Exceptional — production-ready, impressive
- **B** (80-89): Good — solid, minor polish needed
- **C** (70-79): Acceptable — functional but clearly improvable
- **D** (60-69): Below average — significant issues
- **F** (0-59): Critical — major rework needed

---

### Dimension 1: Visual Design & Aesthetics (15%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Typography system | Consistent scale, max 2 families, distinctive choice | Replace with Google Font pairing from `references/typography-pairings.md` |
| Color system | Semantic tokens, 4.5:1 contrast, cohesive palette | Implement full palette from `references/color-palettes.md` |
| Spacing rhythm | 4px/8px grid, consistent padding/margins | Apply design token spacing scale |
| Visual hierarchy | Clear flow, size/weight/color differentiation | Restructure with heading scale + accent colors |
| Imagery & icons | SVG icon system, purposeful illustrations | Add Lucide/Heroicons via CDN, create SVG decorations |
| White space | Breathing room, appropriate density | Increase section padding, card margins |
| Backgrounds & depth | Gradients, textures, shadows, visual layers | Add gradient meshes, noise textures, card elevation |
| Dark mode readiness | CSS custom properties allow theme switching | Implement `prefers-color-scheme` media query |

### Dimension 2: UI/UX Patterns & Interactions (15%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Navigation | Predictable, ≤7 items, current state shown | Rebuild nav with active states, mobile hamburger |
| Call-to-action | One primary CTA per view, visually dominant | Resize/recolor primary CTA, demote secondary actions |
| Feedback loops | Loading, success, error, progress states | Add skeleton loaders, toasts, spinners |
| Form UX | Labels, inline validation, helper text, proper types | Refactor forms with visible labels, validation |
| Empty states | Helpful message + illustration + action | Create SVG empty state with guidance text |
| Micro-interactions | Hover, focus, active, transition on everything interactive | Add CSS transitions per `references/animation-library.md` |
| Mobile UX | ≥44px targets, no hover-only, bottom nav option | Increase tap targets, add touch-friendly patterns |
| Onboarding | First-use guidance for complex interfaces | Add tooltip hints, welcome state |

### Dimension 3: Data Visualization & Graphics (10%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Chart presence | Data visualized, not just raw tables/numbers | Add charts using patterns from `references/chart-patterns.md` |
| Chart quality | Legends, tooltips, responsive, accessible colors | Fix chart config with proper labels and color scale |
| KPI cards | Key metrics in visual stat cards with trends | Create stat card components with sparklines |
| Progress indicators | Ring gauges, progress bars for completion data | Add SVG progress rings |
| Icons throughout | Lucide/Heroicons for all actions and categories | Replace text-only labels with icon+text |
| Animated data | Counter animations, chart entrance effects | Add IntersectionObserver-triggered animations |
| Visual dividers | Section separators, decorative SVG elements | Create wave/angle SVG dividers between sections |

### Dimension 4: Accessibility — CRITICAL (20%)

This dimension is non-negotiable. Every output must pass WCAG 2.1 AA minimum.

| Check | Standard | Fix When Failing |
|-------|----------|-----------------|
| Color contrast | 4.5:1 normal, 3:1 large text | Recalculate and fix all foreground/background pairs |
| Keyboard navigation | Complete tab order, visible focus rings (2px+) | Add `outline` styles, fix `tabindex`, add skip-link |
| Screen readers | Semantic HTML, ARIA labels, heading hierarchy h1→h6 | Replace div soup with semantic elements, add ARIA |
| Alt text | Descriptive alt on meaningful images, `alt=""` on decorative | Audit all `<img>` tags, add/fix alt text |
| Form labels | `<label for="">`, aria-describedby for errors | Wire all labels to inputs |
| Motion sensitivity | `prefers-reduced-motion` media query | Add reduced-motion override that disables all animations |
| Touch targets | ≥44×44px, ≥8px spacing between targets | Increase padding on interactive elements |
| Language | `lang` attribute on `<html>` | Add `lang="en"` or appropriate language code |
| Focus management | Focus moves logically after interactions, no traps | Test and fix tab flow through modals and dynamic content |

### Dimension 5: Performance & Code Quality (15%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Semantic HTML | `<nav>`, `<main>`, `<section>`, `<article>`, `<aside>`, `<footer>` | Replace div soup with semantic elements |
| CSS architecture | Custom properties, no `!important`, scoped styles | Refactor to design tokens + clean selectors |
| JavaScript quality | ES6+, no inline handlers, no `var`, no `console.log` | Modernize JS, add event delegation |
| Image optimization | `loading="lazy"`, explicit width/height, responsive | Add lazy loading, dimensions, srcset |
| Font loading | `font-display: swap`, preload critical fonts | Fix `@font-face` or Google Fonts link |
| Layout stability | No CLS, reserved space for async content | Add explicit dimensions, skeleton placeholders |
| Meta tags | Viewport, title, description, charset | Add missing `<meta>` tags |
| Security basics | No inline scripts where avoidable, CSP-ready, no mixed content | Clean up inline JS, use external scripts |

### Dimension 6: Responsiveness (10%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Mobile (375px) | Fully functional, readable, no horizontal scroll | Fix with mobile-first media queries |
| Tablet (768px) | Proper column adaptation | Add intermediate breakpoint |
| Desktop (1024-1440px) | Optimal layout, max-width container | Add `max-width` container, proper grid |
| Typography scaling | `clamp()` for fluid type | Replace fixed `font-size` with `clamp()` |
| Navigation adaptation | Hamburger/bottom bar on mobile | Implement responsive nav component |
| Touch vs pointer | No hover-dependent features on touch | Add `@media (hover: hover)` guards |
| Images | Responsive, no overflow | Add `max-width: 100%`, `srcset` |

### Dimension 7: Modernity & Tech Stack (10%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| CSS | Grid, Flexbox, custom properties, `clamp()` | Refactor layouts from float/table to Grid/Flex |
| HTML | HTML5 semantic elements, modern attributes | Remove deprecated elements, add modern attrs |
| JavaScript | ES6+, async/await, modern APIs (IntersectionObserver, Fetch) | Modernize syntax, replace jQuery where possible |
| Component pattern | Modular, reusable, clear separation of concerns | Restructure into logical components |
| No deprecated APIs | No `document.write`, `<font>`, `<center>`, etc. | Remove all deprecated elements and APIs |

### Dimension 8: Content & Information Architecture (5%)

| Check | Target | Fix When Failing |
|-------|--------|-----------------|
| Content hierarchy | Clear sections, logical flow, progressive disclosure | Restructure into scannable blocks with headers |
| Scannability | Short paragraphs, visual breaks, bold key terms | Add section dividers, highlight key info |
| Error states | Specific messages with recovery actions | Create error UI components |
| Empty states | Illustration + message + CTA | Design empty state components |
| Search/filter | Present when >10 items in any list | Add filter bar or search input |

---

## Implementation Workflow

### Step 1: Read & Understand (DO NOT SKIP)
1. Read the ENTIRE source file — every line
2. Identify the app type (dashboard, landing page, SaaS, e-commerce, etc.)
3. Note the tech stack (vanilla HTML, React, Vue, etc.)
4. Identify the domain/industry for palette and font selection

### Step 2: Full Audit
1. Score all 8 dimensions (0-100)
2. Present the scorecard in the format above
3. List top 3 critical issues and top 3 quick wins
4. Briefly explain the improvement plan before starting implementation

### Step 3: Implement Improvements
Apply in this exact order (dependencies flow downward):

1. **Semantic structure** — Replace div soup, fix heading hierarchy, add landmark elements
2. **Design token system** — Inject CSS custom properties for all colors, typography, spacing, shadows, radii, transitions
3. **Typography upgrade** — Add Google Font link, apply type scale, fix line-heights
4. **Color palette** — Apply cohesive palette from `references/color-palettes.md`, ensure contrast
5. **Layout modernization** — CSS Grid/Flexbox, responsive breakpoints, fluid sizing
6. **Visual enrichment** — Backgrounds, gradients, card depth, SVG decorations, illustrations
7. **Data visualization** — Charts, KPI cards, sparklines, progress indicators per `references/chart-patterns.md`
8. **Interactivity** — Hover effects, transitions, animations per `references/animation-library.md`
9. **Accessibility pass** — ARIA, focus styles, skip links, reduced-motion, contrast check
10. **Final polish** — Loading states, empty states, error states, edge cases

### Step 4: Self-Review Checklist
Before delivering, verify:
- [ ] All 8 dimensions score ≥ 75 (≥ 85 for accessibility)
- [ ] File is self-contained and renders correctly standalone
- [ ] No broken links, missing images, or console errors
- [ ] Responsive at 375px, 768px, 1024px, 1440px
- [ ] At least 5 items from the Graphic Enhancement Checklist (below)
- [ ] `prefers-reduced-motion` media query present
- [ ] All interactive elements have hover + focus states
- [ ] No "AI slop" (generic Inter font, purple gradient cliché, cookie-cutter layout)

### Step 5: Deliver
1. Save to `/mnt/user-data/outputs/[filename]`
2. Call `present_files` to make file downloadable
3. Present a brief BEFORE → AFTER score comparison
4. List the 5 most impactful changes made
5. Offer to iterate further on specific areas

---

## Graphic Content Enhancement Checklist

Every improved webapp MUST include at least 5 of these 15 items:

1. Hero section with gradient, mesh, or illustration
2. KPI/stat cards with icons and trend indicators (↑/↓)
3. At least one data visualization (chart, graph, or gauge)
4. Animated counters or progress indicators
5. SVG decorative elements (wave dividers, dot patterns, background shapes)
6. Consistent icon system (Lucide/Heroicons via CDN)
7. Skeleton loading states for async content
8. Empty state illustrations with guidance
9. Hover animations on all interactive elements
10. Scroll-triggered fade-in/slide-in animations
11. Gradient accents (buttons, headers, cards, borders)
12. Card-based layout with layered shadow depth
13. Status badges/pills with semantic colors
14. Toast notification component
15. Responsive data tables with sort/filter indicators

---

## Anti-Patterns to Auto-Fix

When found, ALWAYS replace — no exceptions:

| Anti-Pattern | Replacement |
|-------------|-------------|
| `<div>` everywhere | Semantic HTML5 elements |
| Inline `style=""` attributes | CSS custom properties + classes |
| `!important` scattered | Proper specificity with cascade layers |
| `onclick="..."` inline handlers | `addEventListener` / React `onClick` |
| `<table>` for layout | CSS Grid / Flexbox |
| `<br><br>` for spacing | `margin` / `padding` / `gap` |
| `<b>` / `<i>` | `<strong>` / `<em>` |
| `alert()` / `confirm()` | Modal or toast component |
| Fixed `px` for everything | `rem` + `clamp()` for fluid |
| `float` layout | Grid / Flexbox |
| Missing `alt` on `<img>` | Descriptive alt text |
| `<font>` / `<center>` / deprecated | Modern CSS equivalents |
| `px` media queries | `em`-based breakpoints |
| `var` keyword | `const` / `let` |
| `document.write()` | DOM methods |
| jQuery for simple DOM ops | Vanilla JS or framework equivalent |

---

## Design Token System

Inject this baseline and customize per project. Read `references/color-palettes.md` for domain-specific palette selection.

```css
:root {
  /* --- TYPOGRAPHY --- */
  --font-display: 'Plus Jakarta Sans', system-ui, sans-serif;
  --font-body: 'Inter', system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', 'Fira Code', monospace;

  /* --- TYPE SCALE (fluid) --- */
  --text-xs: clamp(0.7rem, 0.65rem + 0.25vw, 0.75rem);
  --text-sm: clamp(0.8rem, 0.75rem + 0.25vw, 0.875rem);
  --text-base: clamp(0.9rem, 0.85rem + 0.25vw, 1rem);
  --text-lg: clamp(1rem, 0.9rem + 0.5vw, 1.125rem);
  --text-xl: clamp(1.15rem, 1rem + 0.75vw, 1.25rem);
  --text-2xl: clamp(1.4rem, 1.1rem + 1.5vw, 1.5rem);
  --text-3xl: clamp(1.7rem, 1.2rem + 2.5vw, 1.875rem);
  --text-4xl: clamp(2rem, 1.3rem + 3.5vw, 2.25rem);
  --text-5xl: clamp(2.5rem, 1.5rem + 5vw, 3rem);

  /* --- SPACING (4px grid) --- */
  --space-1: 0.25rem; --space-2: 0.5rem; --space-3: 0.75rem;
  --space-4: 1rem; --space-6: 1.5rem; --space-8: 2rem;
  --space-10: 2.5rem; --space-12: 3rem; --space-16: 4rem;
  --space-20: 5rem; --space-24: 6rem;

  /* --- ELEVATION --- */
  --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
  --shadow-md: 0 4px 6px -1px rgba(0,0,0,0.1), 0 2px 4px -2px rgba(0,0,0,0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0,0,0,0.1), 0 4px 6px -4px rgba(0,0,0,0.1);
  --shadow-xl: 0 20px 25px -5px rgba(0,0,0,0.1), 0 8px 10px -6px rgba(0,0,0,0.1);
  --shadow-glow: 0 0 20px rgba(99, 102, 241, 0.15);

  /* --- RADII --- */
  --radius-sm: 0.375rem; --radius-md: 0.5rem;
  --radius-lg: 0.75rem; --radius-xl: 1rem;
  --radius-2xl: 1.5rem; --radius-full: 9999px;

  /* --- TRANSITIONS --- */
  --ease-out: cubic-bezier(0.16, 1, 0.3, 1);
  --ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
  --duration-fast: 150ms;
  --duration-base: 250ms;
  --duration-slow: 350ms;
}

/* --- REDUCED MOTION (always include) --- */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```

---

## Iterative Improvement Protocol

If the user says "improve it more", "make it better", "keep going", or similar:

1. Re-audit the already-improved version
2. Focus on the 2-3 lowest-scoring dimensions
3. Raise the bar: target ≥ 90 on all dimensions
4. Add more graphic content from the Enhancement Checklist
5. Experiment with bolder design choices
6. Deliver the updated file and show score progression

---

## References

Read these reference files for deeper guidance. Load only when the specific topic is needed.

| Reference | When to Read | Content |
|-----------|-------------|---------|
| `references/color-palettes.md` | Selecting colors for a specific domain | 20 curated palettes by product type, dark mode rules |
| `references/typography-pairings.md` | Choosing fonts | 18 Google Font pairings with CDN links, fluid scale system |
| `references/chart-patterns.md` | Adding data visualization | Recharts, Chart.js, inline SVG snippets for charts and KPIs |
| `references/animation-library.md` | Adding motion and interactivity | CSS keyframes, micro-interactions, scroll reveals, loaders |
| `references/audit-checklist.md` | Doing a thorough audit | 200-point checklist with pass/fail criteria per dimension |
| `references/component-patterns.md` | Building reusable UI components | Ready-to-paste nav, modal, toast, card, table, form patterns |
