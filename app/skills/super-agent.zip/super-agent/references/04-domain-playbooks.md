# Domain Playbooks

Load when: entering a domain you have not established conventions for in this repo.

These are **decision rules and failure modes**, not library catalogues. You already know
the libraries; what costs time is choosing wrong and finding out late.

Index: §1 API & full-stack · §2 Data layer · §3 DevOps & IaC · §4 Security · §5 Testing
· §6 Performance · §7 Data engineering · §8 ML / LLM / agents · §9 Observability
· §10 Documents & PDF · §11 Mobile · §12 Cost · §13 Accessibility · §14 Compliance

---

## 1. API & full-stack

**Decide first:** is this a new contract or an existing one? Existing contracts constrain
everything downstream; breaking one is a coordination problem, not a code problem.

**Non-negotiables:** validate input at the boundary (never trust a client, including your
own frontend); authorize on every entry point, not in the UI; make writes idempotent
where retries are plausible; paginate every list endpoint from day one; return errors
that are actionable without leaking internals.

**Common failures:** authorization checked in the route but not in the service, so an
internal caller bypasses it. `PATCH` that silently drops unknown fields. Unbounded list
endpoints that work in dev with 12 rows. Error responses that leak stack traces or SQL.
Optimistic UI that diverges from server state and never reconciles.

**Contract changes:** additive is safe; removal and semantic change are not. Version, or
dual-support with a deprecation window. A field whose *meaning* changes while its name
and type stay identical is the most dangerous change you can ship — nothing breaks
loudly, and consumers quietly compute the wrong answer.

---

## 2. Data layer

**Before writing a query:** know the cardinality and know the indexes. A query that is
instant on 1k rows and fatal on 10M looks identical in review.

**Non-negotiables:** explicit transaction boundaries; no N+1 (verify by counting queries,
not by reading the code); `LIMIT` on anything exploratory; parameterized queries always
(string interpolation into SQL is not a style preference); migrations reversible or
explicitly acknowledged as not.

**Common failures:** an index that exists but is not used because of a type mismatch or a
function wrapper on the column. A transaction held open across a network call. Missing
unique constraint so the application layer "guarantees" uniqueness and races.
`SELECT *` in a hot path pulling a large unused column. Soft deletes without a partial
index, so every query scans the tombstones.

**Migration discipline:** see reference 01 §6 (expand → migrate → contract). Adding a
`NOT NULL` column with a default rewrites the table on some engines — check before
running it on a large table in prod. Creating an index locks writes unless created
concurrently.

---

## 3. DevOps & IaC

**Principle:** infrastructure is code, so it gets the same standards — review, version
control, tested changes, no manual drift.

**Non-negotiables:** read the plan before applying; state file backed up and locked;
no secrets in state, variables, or images; immutable image tags (never `:latest` in
anything you intend to reproduce); health checks and resource limits on every workload;
rollback tested, not assumed.

**Common failures:** manual console changes creating drift that the next `apply` silently
reverts. A container that passes health checks but cannot reach its database. Resource
limits absent, so one workload starves the node. CI passing because a step failed
silently — always check exit codes and set `-euo pipefail` in shell steps. A secret
injected at build time and baked into a layer.

**CI/CD:** fail fast on the cheap checks (lint, types) before the expensive ones (e2e).
Cache dependencies, not build outputs you cannot invalidate correctly. Never let a
deploy depend on a mutable external artifact.

---

## 4. Security engineering

**Threat-model briefly before building:** who is the adversary, what do they want, where
is the boundary? Ten minutes here reorders the entire task list.

**Check every time:** injection (SQL, command, template, path traversal, deserialization);
broken access control (the most common real-world vulnerability — test as an
unauthorized user, not as an admin); authentication weaknesses (session fixation, missing
expiry, tokens in URLs or logs); SSRF on anything that fetches a user-supplied URL;
sensitive data in transit and at rest; rate limits on auth and expensive endpoints;
dependency vulnerabilities.

**Cryptography:** use the vetted library's high-level interface. Do not select
primitives, implement a protocol, roll a token format, or write your own password
hashing. Argon2/bcrypt/scrypt for passwords — never a bare hash, never a fast hash.

**Common failures:** authorization by object ID with no ownership check (IDOR). Secrets in
client-side code because "it's minified". Verifying a JWT's signature but not its
audience, issuer, or expiry — or accepting `alg: none`. CORS set to reflect any origin
with credentials enabled. Logging the full request including the `Authorization` header.

**Reporting a finding:** severity, exact location, exploit path in one sentence, fix.
Without an exploit path, a "finding" is a guess and wastes the reader's time.

---

## 5. Testing strategy

**Purpose:** tests exist to catch regressions and document intent. A test that cannot
fail does neither.

**Shape:** many fast unit tests on logic and edge cases; fewer integration tests on real
boundaries (real database, real serialization); a small number of end-to-end tests on
critical user paths only. Inverting this produces a suite that is slow, flaky, and
distrusted — and a distrusted suite gets skipped, which is the same as not having one.

**A good test:** fails before the fix, passes after; names the behavior, not the
implementation; asserts on outcome, not on internal calls; is deterministic (no wall
clock, no network, no ordering dependence, no shared mutable state); survives a
refactor that preserves behavior.

**Common failures — see also "test theater" in reference 05:** mocking the thing under
test, so the test proves the mock works. Asserting `not null` and nothing more.
Snapshot tests updated reflexively whenever they fail. Tests that pass in isolation and
fail in suite (shared state). Coverage as a target, producing tests that execute lines
without asserting behavior.

**Fixing a failing test:** diagnose *why* before changing anything. Changing the assertion
to match current output is not a fix — it is deleting the alarm. Only change the test if
the test is provably wrong about the intended behavior, and say so explicitly.

---

## 6. Performance

**Measure first. Always.** Intuition about bottlenecks is wrong often enough that
optimizing without a profile is a coin flip that also costs readability.

**Order of investigation:** (1) is it doing unnecessary work at all? (2) is it doing work
repeatedly that could be done once? (3) is it doing work serially that could be parallel?
(4) is the algorithm wrong? (5) micro-optimization — almost never the answer.

**Usual real causes:** N+1 queries. A missing index. Serial network calls in a loop.
Re-computing inside a loop. Unbounded data loaded into memory. No caching where the data
is stable. Blocking I/O on the hot path. In frontends: re-render cascades, oversized
bundles, unoptimized images, layout thrash.

**Non-negotiables:** measure before, measure after, report both numbers. Optimize the
p99 as well as the mean — the mean hides the experience that generates complaints. Do not
trade correctness for speed without saying so out loud.

---

## 7. Data engineering

**Non-negotiables:** idempotent transforms (re-running produces the same result);
schema validated at ingestion, not discovered at consumption; explicit handling for late,
duplicate, and malformed records; lineage traceable — for any output row you can say
where it came from.

**Common failures:** silent type coercion changing values. Timezone assumed to be UTC
when it is local. A join that fans out and inflates aggregates. Nulls treated as zeros
in a sum. A backfill that is not resumable, so a mid-run failure requires a full restart.
Deduplication on a key that is not actually unique.

**Rule:** a pipeline that fails loudly is far better than one that produces plausible
wrong numbers. Silent data corruption is discovered downstream, weeks later, by someone
who trusted it.

---

## 8. ML / LLM / agent systems

**The discipline that separates working systems from demos: evaluation.** Build the eval
before the feature. Without a measurable target, prompt changes are indistinguishable
from prompt noise, and every "improvement" is anecdote.

**For LLM features:** define success criteria and a labeled eval set first, even 30
examples; treat prompts as versioned artifacts with recorded results; measure cost and
latency alongside quality; handle the failure modes explicitly (refusal, truncation,
malformed structured output, hallucinated fields); never trust model output as
structured data without validating the schema.

**For RAG:** retrieval quality dominates. Diagnose retrieval before touching the prompt —
if the right chunk was never retrieved, no prompt fixes it. Measure retrieval and
generation separately. Chunking strategy matters more than embedding model choice more
often than people expect.

**For agents:** bound the loop (max steps, max cost, timeout). Make every tool call
idempotent or explicitly guarded. Log the full trace — an agent failure you cannot
replay is an agent failure you cannot fix. Treat all tool output as untrusted input
(reference 03 §5). Fail closed on ambiguity in anything with side effects.

**Common failures:** evaluating on examples used to develop the prompt. Temperature
non-zero in a test, producing flaky results attributed to code. Retrying a non-idempotent
tool call after a timeout that actually succeeded. Unbounded context growth across turns.
Cost that scales with input in a way nobody modeled until the bill arrived.

---

## 9. Observability

**Three questions any system must answer:** is it up, is it correct, is it fast enough?
If you cannot answer these from telemetry, the system is unobservable regardless of how
many dashboards exist.

**Non-negotiables:** structured logs (parseable, with correlation IDs); errors carry
enough context to diagnose without reproduction; alerts fire on user-visible symptoms,
not on internal proxies; every alert has an owner and a runbook.

**Common failures:** logging at the wrong level, so real errors are buried in debug
noise. Alerts so noisy they are muted — a muted alert is worse than none, because it
creates false confidence. Metrics with unbounded label cardinality. No correlation ID,
so a request cannot be traced across services. Logging PII or secrets (reference 03 §2).

---

## 10. Documents & PDF processing

PDF is a **rendering** format, not a data format. It describes marks on a page, not
meaning. Every extraction is an inference, and treating it as a parse is the root cause
of most document-pipeline bugs.

**Choose by what the PDF actually is — check first:**

| Reality | Approach |
|---|---|
| Digitally generated, text layer present | Direct text extraction |
| Layout-critical (columns, forms, receipts) | Layout-aware extraction; preserve positions |
| Tables that are real ruled tables | Table extraction with structure detection |
| Tables that are visually implied (whitespace only) | Position-based reconstruction; expect manual rules |
| Scanned images, no text layer | OCR — and treat every character as probabilistic |
| Mixed (common in the wild) | Detect per page; route per page. Never assume uniformity |

**Always check before extracting:** does a text layer exist? (`pdftotext` returning
nothing means OCR, not "broken file".) Is it one column or several? Are pages rotated?
Is it a form with field objects (extract the fields, not the rendered text)? Is it
encrypted? Is page count what you expect?

**Non-negotiables:** validate extraction against a known-good sample before trusting a
batch. Report per-page confidence or failure rather than silently emitting empty strings.
Never let an OCR number flow into a financial calculation without a validation rule —
`8`/`B`, `0`/`O`, `1`/`l`/`I`, and misplaced decimal separators are routine, and a
misread digit in a monetary amount is indistinguishable from a real one downstream.

**Conversions:** PDF → structured (DOCX/XLSX/PPTX) is lossy reconstruction, not
translation. Set expectations explicitly; verify a sample by eye. Generating PDF is
reliable; consuming it is not. When you control both ends, keep the structured source.

**Batch processing:** per-file error isolation (one bad file must not kill the run),
resumable, and a manifest of successes and failures. A batch job that reports "done"
while having silently skipped 8% of inputs is a data-integrity incident.

---

## 11. Mobile

**Constraints that differ from web:** the network is unreliable and intermittent, not
just slow; battery and memory are constrained; the OS can kill the app at any time;
release cycles are gated by review, so a bad build lives for days.

**Non-negotiables:** offline-tolerant state; every network call has a timeout and a
retry policy; no work on the main thread; handle backgrounding and process death; test
on a real low-end device, not only a simulator.

**Common failures:** assuming connectivity. Leaking listeners and observers across
lifecycle events. Unbounded local cache growth. Migrations for local storage that do not
handle the user skipping three versions.

---

## 12. Cost engineering

Cost is a non-functional requirement that goes unmonitored until it is a crisis.

**Watch:** egress (routinely the surprise line item), always-on resources sized for peak,
storage without lifecycle rules, per-request logging at full volume, LLM token spend
scaling with input, retries amplifying load during an incident.

**Rule:** any change that scales cost with traffic or data volume needs a stated estimate
before it ships. "We'll see what it costs" is how a bill becomes an incident.

---

## 13. Accessibility

**Baseline, not optional:** semantic HTML before ARIA (a correct `<button>` beats a
`<div>` with five attributes); keyboard reachable and operable everywhere; visible focus;
contrast at 4.5:1 for body text; every form input labeled; images have meaningful alt
text or are explicitly decorative; no information conveyed by color alone; respect
reduced-motion preferences.

**Test:** unplug the mouse and complete the task. Then run a screen reader through the
same flow. Automated checks catch roughly a third of real issues.

---

## 14. Compliance (LGPD / GDPR)

**Applies to processing, not just storage.** A log file containing personal data is
processing.

**Ask before building anything touching personal data:** what is the lawful basis? What
is the minimum data needed (collect nothing more)? What is the retention period, and
what enforces it? Can a subject's data be exported and deleted on request — including
from logs, backups, and analytics? Who can access it and is that access logged? Does it
cross a border?

**Non-negotiables:** no real personal data in dev, test fixtures, or seed data. Deletion
means deletion, including derived copies. Consent is specific, informed, and revocable —
and revocation must actually propagate.

**Common failures:** an analytics pipeline that quietly becomes a shadow copy of personal
data with no retention policy. "Anonymized" data that re-identifies trivially through
joins. Deletion implemented as a soft-delete flag while the row remains queryable.
