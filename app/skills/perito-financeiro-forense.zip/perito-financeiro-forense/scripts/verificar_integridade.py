#!/usr/bin/env python3
# pff-version: 21.0
"""
verificar_integridade.py — detecta pacote incompleto ou "quimera" (arquivos de versões diferentes).

    python3 scripts/verificar_integridade.py            # a partir da pasta da skill ou de qualquer lugar

Por que existe: duas vezes (v19 e v20) a skill instalada ficou com o SKILL.md novo e as references antigas —
o modelo então citava seções, HCs e testes que não existiam nos arquivos. Este script roda em < 1 s e diz,
antes da perícia, se o que está instalado é coerente. Saída 0 = íntegra; 1 = problemas listados.
"""
from __future__ import annotations

import os
import re
import subprocess
import sys

VERSAO = "21.0"
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ARQUIVOS = ["SKILL.md", "references/regulatorio-formulas.md", "references/protocolo-pipeline.md",
            "references/outputs-cenarios-anexos.md", "references/changelog.md", "commands/auditoria-divida.md",
            "scripts/pericia.py", "scripts/extrair_pdfs.py", "scripts/bcb_sgs.py", "scripts/verificar_integridade.py"]
ESPERADO = {"etapa5": 45, "checklist_final": 65, "cenarios": 12}
OBSOLETOS = {  # padrão -> motivo (procurado fora do changelog)
    r"Tema 1\.325[^\n]{0,60}(RMC|consignado|invalida)": "Tema 1.325 não trata de RMC",
    r"Tema 1\.328(/STJ)?\s*`\[TESE_PENDENTE|^\|\s*(Tema )?1\.328\s*\|[^\n]*TESE_PENDENTE": "Tema 1.328 foi cancelado em 02/10/2026",
    r"\b2778[89]\b|\b2543[35]\b": "código SGS de taxa média errado",
    r"MIN_EXISTENCIAL`?\s*\|\s*sal[áa]rio": "mínimo existencial não é o salário mínimo",
    r"Res\. BCB 200/2022": "CET é regido pela Res. CMN 4.881/2020",
    r"CLT 35%\)|MARG_CONSIGN_CLT`\s*\|\s*35": "margem CLT é 40% (35+5)",
    r"provavelmente caducada|provável caducidade": "MP 1.355 já confirmada sem eficácia",
}


def ler(rel):
    with open(os.path.join(RAIZ, rel), encoding="utf-8") as f:
        return f.read()


def main() -> int:
    prob, avisos = [], []
    txt = {}
    for rel in ARQUIVOS:
        if not os.path.exists(os.path.join(RAIZ, rel)):
            prob.append(f"arquivo ausente: {rel}")
            continue
        t = ler(rel)
        txt[rel] = t
        m = re.search(r"pff-version:\s*([\d.]+)", t)
        if not m:
            prob.append(f"{rel}: sem marcador de versão (provavelmente ≤ v20 — QUIMERA)")
        elif m.group(1) != VERSAO:
            prob.append(f"{rel}: versão {m.group(1)} ≠ {VERSAO} (QUIMERA)")

    reg = txt.get("references/regulatorio-formulas.md", "")
    out = txt.get("references/outputs-cenarios-anexos.md", "")
    if reg:
        hcs = set(re.findall(r"^\| `(HC-\d\d)` \|", reg, re.M))
        esperado = {f"HC-{i:02d}" for i in range(1, 39)} | {"HC-99"}
        if hcs != esperado:
            prob.append(f"tabela HC divergente: faltam {sorted(esperado - hcs)} sobram {sorted(hcs - esperado)}")
        citados = set()
        for rel, t in txt.items():
            if not rel.endswith("changelog.md"):
                citados |= set(re.findall(r"HC-\d\d", t))
        if citados - esperado:
            prob.append(f"HC citados sem definição: {sorted(citados - esperado)}")
        if "## ETAPA 5 — CHECAGEM" in reg and "## ETAPA 6" in reg:
            et5 = reg[reg.index("## ETAPA 5 — CHECAGEM"):reg.index("## ETAPA 6")]
            n5 = len(re.findall(r"^\| \d+ \| ", et5, re.M))
            if n5 != ESPERADO["etapa5"]:
                prob.append(f"Etapa 5 com {n5} itens (esperado {ESPERADO['etapa5']})")
            sem = sorted(h for h in esperado - {"HC-99"} if h not in et5)
            if sem:
                prob.append(f"Etapa 5 não é HC-completa: {sem}")
        for sec in ("§5-T1", "§5-T2", "§5-T3", "### 5.6", "Res. CMN 4.881/2020"):
            if sec not in reg:
                prob.append(f"regulatorio-formulas.md sem '{sec}'")
    if out:
        nf = len(re.findall(r"^- ☐", out, re.M))
        nc = len(re.findall(r"^\| [A-L] \| ", out, re.M))
        if nf != ESPERADO["checklist_final"]:
            prob.append(f"checklist final com {nf} itens (esperado {ESPERADO['checklist_final']})")
        if nc != ESPERADO["cenarios"]:
            prob.append(f"cenários: {nc} (esperado {ESPERADO['cenarios']})")
    for rel, t in txt.items():
        if rel.endswith("changelog.md") or rel.endswith("verificar_integridade.py") or rel.endswith("bcb_sgs.py"):
            continue
        for pat, motivo in OBSOLETOS.items():
            for m in re.finditer(pat, t, re.M):
                linha = t[:m.start()].count("\n") + 1
                ctx = t[max(0, m.start() - 80):m.end()]
                if re.search(r"n[ãa]o\s+(trata|é|incluir|citar)|errad|≤ v20|Não confundir|obsolet|antes", ctx, re.I):
                    continue
                prob.append(f"{rel}:{linha}: marcador obsoleto — {motivo}")
    # auto-teste dos cálculos
    pf = os.path.join(RAIZ, "scripts", "pericia.py")
    if os.path.exists(pf):
        r = subprocess.run([sys.executable, pf, "--selftest"], capture_output=True, text=True)
        if r.returncode != 0:
            prob.append("pericia.py --selftest falhou: " + (r.stdout + r.stderr).strip()[:300])
        else:
            avisos.append(r.stdout.strip())

    if prob:
        print(f"INTEGRIDADE: FALHOU ({len(prob)} problema(s)) — skill perito-financeiro-forense")
        for p in prob:
            print("  -", p)
        print("Ação: avisar o usuário de que a instalação está inconsistente e reinstalar o pacote completo v"
              f"{VERSAO}. Até lá, não citar seções/HCs/testes ausentes e declarar a limitação no laudo.")
        return 1
    print(f"INTEGRIDADE: OK — perito-financeiro-forense v{VERSAO} completa e coerente "
          f"(HC-01–38+99; Etapa 5 = {ESPERADO['etapa5']}; checklist final = {ESPERADO['checklist_final']}; "
          f"cenários A–L). " + " ".join(avisos))
    return 0


if __name__ == "__main__":
    sys.exit(main())
