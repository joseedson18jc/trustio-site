---
name: crawl4ai
description: |
  Turn any web page or whole site into clean, LLM-ready Markdown using Crawl4AI. Handles JS-heavy pages via a headless browser, deep crawling, and LLM-based extraction. Use for reading a page, scraping a site into Markdown, RAG ingestion, or agent web browsing.
  TRIGGERS: crawl4ai, crwl, scrape page to markdown, crawl a website, read this url, deep crawl, headless browser scrape, page to markdown, LLM-ready web content, extract from webpage
---

# Crawl4AI — web pages to LLM-ready Markdown

Crawl4AI is a headless-browser crawler that renders JS and returns clean Markdown, links, media, and (optionally) structured JSON. Use it whenever an agent needs the *actual rendered content* of a page rather than raw HTML.

## When to use this vs. alternatives
- **Use crawl4ai** for JS-heavy pages, deep/multi-page crawls, or when you want Markdown + extracted structure from a live browser render.
- Use `firecrawl` when you want a hosted API (no local browser) or built-in web search.
- Use `markitdown` when you already have a *file* (PDF/DOCX/PPTX) rather than a URL.
- Use `scrapy` for large, structured, rule-based crawls of thousands of pages.

## Setup (once)
```bash
pip install -U crawl4ai
crawl4ai-setup            # installs & configures Playwright browsers
# If Playwright errors: python -m playwright install --with-deps chromium
```

## Fast path — CLI (`crwl`)
```bash
crwl https://example.com/article -o markdown          # single page -> Markdown
crwl https://docs.example.com --deep-crawl bfs --max-pages 10   # crawl a section
crwl https://shop.example.com/p -q "Extract all product names and prices"  # LLM extract
```

## Runnable helper (recommended)
`scripts/crawl.py` wraps the async API with sane defaults (cache bypass, Markdown out, optional deep crawl and CSS/screenshot).
```bash
python scripts/crawl.py https://example.com                 # print Markdown
python scripts/crawl.py https://example.com -o out.md        # save Markdown
python scripts/crawl.py https://docs.example.com --deep 15   # BFS up to 15 pages -> out dir
```

## Python API (when you need control)
```python
import asyncio
from crawl4ai import AsyncWebCrawler, CrawlerRunConfig, CacheMode

async def main():
    cfg = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)
    async with AsyncWebCrawler() as crawler:
        result = await crawler.arun("https://example.com", config=cfg)
        print(result.markdown)          # clean Markdown
        # result.links, result.media, result.cleaned_html also available

asyncio.run(main())
```

## Good practices
- Respect `robots.txt`, rate-limit, and identify your crawler; don't scrape private/personal data.
- Prefer `CacheMode.BYPASS` for fresh data, default cache for repeated runs.
- Cap `--max-pages` on deep crawls; start small and widen.
- For structured output, pass a natural-language query (`-q`) or an extraction schema rather than post-parsing Markdown by hand.
