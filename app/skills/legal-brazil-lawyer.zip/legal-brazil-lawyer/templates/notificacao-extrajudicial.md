# Template: Notificação Extrajudicial

**INSTRUÇÕES DE USO**: Substituir todos os campos em [COLCHETES]. Adaptar fundamento jurídico ao caso. Revisar antes de enviar.

---

[CIDADE], [DATA COMPLETA].

**NOTIFICAÇÃO EXTRAJUDICIAL**

**NOTIFICANTE**: [NOME COMPLETO / RAZÃO SOCIAL], [nacionalidade], [estado civil], [profissão], portador(a) do [CPF/CNPJ] nº [NÚMERO], residente e domiciliado(a) / com sede em [ENDEREÇO COMPLETO], neste ato [representado(a) por / por seu advogado] [NOME DO ADVOGADO], inscrito(a) na OAB/[ESTADO] sob o nº [NÚMERO].

**NOTIFICADO(A)**: [NOME COMPLETO / RAZÃO SOCIAL], [CPF/CNPJ] nº [NÚMERO], [residente e domiciliado(a) / com sede] em [ENDEREÇO COMPLETO].

---

Vem, o(a) NOTIFICANTE, por meio desta, e com fundamento nos artigos [ARTIGOS APLICÁVEIS] [do Código Civil / do Código de Defesa do Consumidor / da CLT / outro], NOTIFICAR Vossa Senhoria sobre os fatos e fundamentos a seguir expostos:

**I — DOS FATOS**

[Narrar os fatos de forma objetiva e cronológica. Incluir datas, valores, documentos relevantes, descumprimento identificado.]

**II — DO DIREITO**

[Indicar fundamento legal: artigos do CC, CDC, CLT, legislação específica. Indicar cláusula contratual violada, se houver.]

**III — DA EXIGÊNCIA**

Em razão do exposto, NOTIFICA-SE Vossa Senhoria a, no prazo de **[PRAZO] dias corridos / úteis** contados do recebimento desta, [EXIGÊNCIA ESPECÍFICA: pagar / devolver / cessar conduta / cumprir obrigação / apresentar documentos].

**IV — DA ADVERTÊNCIA**

O não atendimento desta notificação no prazo indicado implicará [adoção de medidas judiciais cabíveis / cobrança de multa contratual de R$ [VALOR] / registro em órgãos de proteção ao crédito / rescisão contratual], sem prejuízo de perdas e danos, correção monetária e honorários advocatícios.

Sem mais,

[LOCAL], [DATA].

___________________________________
[NOME DO NOTIFICANTE / ADVOGADO]
[CPF / OAB]
[CONTATO]

---

**Meio de envio recomendado**: Correios (AR) ou cartório de títulos e documentos (fé pública).
