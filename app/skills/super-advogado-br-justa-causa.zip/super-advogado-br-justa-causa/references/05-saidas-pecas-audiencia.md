# Saídas, peças e audiência

## Parecer executivo

Comece pela resposta decisória, não por histórico doutrinário. Use:

- conclusão provisória;
- três fundamentos mais fortes;
- três riscos mais sérios;
- prova que falta;
- ação imediata.

Depois desenvolva cronologia, direito, prova e cenários.

## Notificação extrajudicial

Deve:

- identificar fatos e documentos de forma precisa;
- evitar acusação criminal conclusiva;
- formular pedidos objetivos, possíveis e com finalidade legítima;
- fixar prazo razoável e juridicamente justificável;
- preservar direitos sem ameaçar exposição ou sanção como instrumento de coação;
- pedir preservação e exibição de prova com categorias específicas;
- registrar canal de resposta.

## Reclamação trabalhista

Estrutura sugerida:

1. competência e partes;
2. contrato e estrutura real da prestação;
3. cronologia;
4. comunicação da justa causa e alínea invocada;
5. impugnação por gate, conectada às provas;
6. distribuição do ônus e exibição;
7. reversão e verbas consequentes;
8. estabilidade/reintegração, se aplicável;
9. dano extrapatrimonial somente com fundamento autônomo;
10. obrigações de fazer e tutela, se cabível;
11. pedidos individualizados e valores estimados conforme regra vigente;
12. provas.

Não narrar como fato o que é mera suspeita. Use “há indício”, “não foi apresentado” e “requer-se comprovação” quando adequado.

## Réplica

Monte tabela:

`alegação da defesa | documento citado | falha de autenticidade/contexto | contradição | regra de ônus | prova requerida | resposta`

Impugne documento especificamente. Não use impugnação genérica para tudo.

## Audiência

### Mapa de depoimento pessoal

Perguntas devem buscar fato simples e admissão útil:

- quem recebeu a denúncia/documento?
- quando teve ciência?
- quem tinha poder de decidir?
- quais diligências foram feitas, por quem e em que datas?
- o empregado foi ouvido?
- qual original foi examinado?
- quem concluiu pela falsidade e com que qualificação?
- havia regulamento ou matriz disciplinar?
- houve recomendação ou ordem da tomadora?
- o empregador formal produziu análise própria?
- quando a decisão foi registrada em sistema?

Evite perguntas que permitam discurso longo sem objetivo.

### Testemunhas

Associe cada testemunha a no máximo três fatos essenciais. Verifique conhecimento direto, vínculo, interesse, acesso ao sistema e contemporaneidade.

### Confronto documental

Prepare documento, página, trecho, data, autoria e contradição. Não descubra a inconsistência pela primeira vez na audiência.

## Recurso

Distinguir:

- erro de direito;
- erro de valoração dentro dos limites recursais;
- necessidade de revolvimento fático e possível incidência da Súmula 126/TST;
- prequestionamento;
- divergência específica e fonte oficial;
- transcendência no recurso de revista.

Não usar precedente com fatos diferentes como divergência específica sem cotejo analítico.
