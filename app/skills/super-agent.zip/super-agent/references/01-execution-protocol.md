# Execution Protocol

Load when: task spans more than two files, more than three steps, or is irreversible.

Contents: §1 Orient · §2 Plan · §3 Execute · §4 Diagnostic loop · §5 Refactor protocol
· §6 Migration protocol · §7 Review protocol · §8 Incident protocol · §9 Handoff

---

## 1. Orient

Cheap reconnaissance before expensive commitment. Time-box it — orientation that
becomes archaeology is its own failure mode.

**Establish, in this order:**

1. **Does the target exist?** Confirm paths before planning around them.
2. **How does this repo already solve this?** Find the nearest existing analogue and
   follow it. An inconsistent-but-idiomatic solution beats a superior alien one.
3. **What runs the checks?** Locate test command, lint command, type check, build.
   If you cannot find how to verify, that is the first problem to solve — not
   something to skip.
4. **What is the blast radius?** Who calls this? What depends on its current
   behavior? Is it public API, internal, or dead code?
5. **What is the current state?** Uncommitted changes, current branch, failing tests
   that were already failing. Establish the baseline before you can attribute breakage.

**Baseline rule:** run the test suite *before* changing anything on any Complex or
Hazardous task. Without a baseline you cannot distinguish "I broke it" from "it was
already broken" — and you will spend an hour proving the wrong one.

**Orientation output** (internal, or stated briefly if the user needs it):
target files, governing convention, verification command, blast radius, baseline status.

---

## 2. Plan

A plan is a sequence of independently verifiable steps. If a step has no check, it is
not a step — it is a hope.

**Structure:**

```
Goal: <one line, the observable end state>
Assumptions: <each load-bearing assumption, and what would falsify it>
Constraints: <what you must not break>

1. <action> → verify: <command or observation>
2. <action> → verify: <command or observation>
...
Rollback: <exact revert path>
```

**Ordering rules — these decide plan quality:**

- **Dependency first.** Nothing before its prerequisite.
- **Reversible before irreversible.** Do all the undoable work first; put the
  one-way door as late as possible.
- **Verification before dependence.** If step 4 depends on step 2 being right, verify
  step 2 before step 3.
- **Do not let an early step block a later required one.** The user's stated order is
  a wish list, not an execution order. Reorder freely — and say that you did, and why.
- **Isolate the risky step.** The step most likely to fail should be attempted early
  and alone, while the context is clean and rollback is trivial. Discovering the hard
  problem last is how a two-hour task becomes a two-day one.

**Gate for Hazardous class:** present the plan and stop. Do not mutate anything until
the user confirms. Include in the gate: what becomes irreversible, at which step, and
what you need from them (credentials, approval, a decision).

---

## 3. Execute

One step. Verify. Next step.

**Per step:**

1. State which step you are on (only if the plan is long enough to lose track).
2. Make the change — smallest correct version.
3. Run the verification for that step.
4. Read the actual output. Not the exit code alone: the output.
5. Failed → do not advance. Fix, or reassess the plan.

**Batching is forbidden** on Complex and Hazardous work. Five edits then one test run
gives you a failure you cannot attribute, and attribution is the entire value of
incremental execution.

**Deviation rule:** if execution reveals the plan is wrong, stop executing and say so.
Do not improvise a new plan silently mid-flight — the user's mental model of what you
are doing is a resource worth preserving.

**Checkpointing:** on long tasks, write progress to a scratch file
(`.claude/scratch/<task>.md`) after each meaningful step: what is done, what is
verified, what is next, what you learned. This survives compaction. Without it, a
context reset mid-task means re-deriving everything — and re-deriving usually means
re-deciding differently.

---

## 4. Diagnostic loop

For "it's broken", "why does this happen", flaky behavior, and any bug.

**Do not edit code before you can explain the failure.** A fix applied to a
misunderstood cause either fails, or works by accident and hides the real defect.

```
1. REPRODUCE   — get a deterministic failing case. If you cannot reproduce, that
                 is the whole task until solved.
2. OBSERVE     — read the actual error, the whole stack trace, the real logs.
                 Not what you expect them to say.
3. LOCALIZE    — bisect. Narrow to the smallest region that still exhibits it.
                 git bisect for regressions; binary search on input; disable half.
4. HYPOTHESIZE — enumerate causes. Rank by probability × cheapness-to-test.
                 Include at least one non-obvious candidate.
5. TEST ONE    — design a check that *distinguishes* hypotheses. A check that
                 passes under every hypothesis teaches nothing.
6. FIX CAUSE   — treat the mechanism, not the symptom.
7. PROVE       — a test that fails before the fix and passes after. This is the
                 only proof that you fixed *this* bug.
8. SWEEP       — does the same defect class exist elsewhere in the codebase?
```

**Abductive discipline.** The most likely cause is not always the simplest one.
Consider, before settling: environment/version drift, config not what you think it is,
caching or stale build artifacts, ordering and concurrency, an upstream change,
data-shape assumptions violated, silent truncation or coercion, timezone and encoding,
a fix that was never actually deployed. Low-probability causes are still causes — do
not eliminate one because it is inconvenient. Eliminate it because a check ruled it out.

**When hypotheses are exhausted:** widen the frame. Question what you accepted as
given — including the reported symptom itself. "It's slow" sometimes means "a
different thing is slow." Verify the premise.

**Never** conclude "cannot reproduce, probably fixed." State exactly what you tried,
under what conditions, and what would be needed to reproduce.

---

## 5. Refactor protocol

Refactoring means behavior-preserving structural change. If behavior changes, it is
not a refactor — it is a rewrite, and it needs its own plan and its own tests.

1. **Tests first.** No adequate test coverage on the target → write characterization
   tests capturing *current* behavior, bugs included. Without them you cannot prove
   preservation, and "it looks equivalent" is not proof.
2. **Green baseline.** Confirm tests pass before touching structure.
3. **One transformation at a time**, tests green between each. Extract, then rename,
   then move — never simultaneously.
4. **No behavior changes smuggled in.** Spotted a bug mid-refactor? Note it, finish
   the refactor, fix the bug in a separate change with its own test.
5. **Stop at the requested boundary.** The adjacent module is also ugly. It is not
   in scope.

---

## 6. Migration protocol

Schema changes, API version changes, data backfills, dependency major bumps.

**Expand → migrate → contract.** Never mutate in place when live consumers exist.

1. **Expand** — add the new structure alongside the old. Nothing breaks; nothing
   depends on the new thing yet. Deployable and reversible on its own.
2. **Dual-write / dual-read** — write both, read old, verify new matches. This is
   where you catch the wrong assumption, while both paths still exist.
3. **Backfill** — batched, idempotent, resumable, rate-limited. A backfill that
   cannot be safely re-run will need to be re-run.
4. **Cut over** — read from new. Keep the old path available behind a flag.
5. **Contract** — remove the old path only after the new one has been verified in
   the real environment for a real interval.

**Non-negotiables:** every migration has a tested down path or an explicit
"irreversible, here is why" acknowledgment. Backfills report progress and can be
interrupted without corruption. Backups verified *before*, not assumed.

---

## 7. Review protocol

Reviewing code — yours or someone else's. Order matters: cheap high-severity checks first.

1. **Correctness** — does it do what it claims? Off-by-one, null/undefined paths,
   error branches, boundary values, the empty case, the concurrent case.
2. **Security** — injection (SQL, command, template, path), authz check on every
   entry point (not just the UI), secrets, unsafe deserialization, SSRF, missing
   rate limits on expensive or auth-adjacent endpoints.
3. **Data integrity** — transaction boundaries, partial-failure states, idempotency
   of retried operations, unbounded queries.
4. **Contract** — breaking change to a consumer? Versioned? Documented?
5. **Failure behavior** — what happens when the dependency is down, slow, or lying?
   Timeouts set? Retries bounded? Does it fail loudly or silently?
6. **Tests** — do they assert meaningful behavior, or merely execute the code?
   Would they catch the bug this change fixes? (See "test theater", ref 05.)
7. **Maintainability** — will the next reader understand it? Names accurate?
8. **Style** — last, and only where it deviates from repo convention.

Report findings as **Blocking / Should fix / Consider**. Attach severity to every
finding — an unranked list of twenty nits buries the one SQL injection.

---

## 8. Incident protocol

Something is broken in production, now.

**Order: stabilize → diagnose → fix → prevent.** Restoring service is not the same
as understanding the failure, and confusing the two extends outages.

1. **Assess** — what is the user-visible impact, and what is the blast radius?
2. **Stabilize** — fastest safe path to service restored: roll back, flag off,
   scale out, fail over. A rollback now beats a correct fix in an hour.
3. **Preserve evidence** — capture logs, metrics, and state *before* they rotate or
   are overwritten by the recovery. Post-hoc diagnosis needs artifacts.
4. **Diagnose** — §4 loop, once the bleeding has stopped.
5. **Fix forward** — with a test that reproduces the failure.
6. **Prevent** — what monitoring would have caught this earlier? What hook, test, or
   guardrail makes this class of failure impossible rather than unlikely?

During an incident: state facts and timestamps, mark inference as inference, and do
not speculate about cause in a channel people will treat as authoritative.

---

## 9. Handoff

End every non-trivial task so that a different agent — or you after a context reset —
can pick it up cold.

State: what is done and verified (with the commands), what is done but unverified,
what is left with the next concrete action, decisions taken and why (so they are not
silently reversed), known landmines, and the exact revert path.

The test: could someone with zero conversation history continue from your report
without re-deriving your reasoning? If not, the handoff is incomplete.
