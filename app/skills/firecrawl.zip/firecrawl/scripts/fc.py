#!/usr/bin/env python3
"""fc.py — thin wrapper around the Firecrawl SDK for agents.

Examples:
    export FIRECRAWL_API_KEY=fc-...
    python fc.py search "firecrawl alternatives" --limit 5
    python fc.py scrape https://example.com -o page.md
    python fc.py crawl  https://docs.example.com --limit 30 --out-dir crawl_out
    python fc.py map    https://example.com

Requires: pip install firecrawl-py
"""
import argparse
import json
import os
import re
import sys


def _client():
    try:
        from firecrawl import Firecrawl
    except ImportError:
        sys.exit("Install the SDK first: pip install firecrawl-py")
    key = os.environ.get("FIRECRAWL_API_KEY")
    if not key:
        sys.exit("Set FIRECRAWL_API_KEY in your environment.")
    return Firecrawl(api_key=key)


def _slug(url: str) -> str:
    return re.sub(r"[^a-zA-Z0-9]+", "_", url).strip("_")[:80] or "page"


def _md(doc) -> str:
    for attr in ("markdown", "content", "html"):
        v = getattr(doc, attr, None) or (doc.get(attr) if isinstance(doc, dict) else None)
        if v:
            return v
    return json.dumps(doc, default=str, indent=2)


def main() -> None:
    ap = argparse.ArgumentParser(description="Firecrawl CLI wrapper")
    sub = ap.add_subparsers(dest="cmd", required=True)

    s = sub.add_parser("search"); s.add_argument("query"); s.add_argument("--limit", type=int, default=5)
    sc = sub.add_parser("scrape"); sc.add_argument("url"); sc.add_argument("-o", "--out")
    cr = sub.add_parser("crawl"); cr.add_argument("url"); cr.add_argument("--limit", type=int, default=30)
    cr.add_argument("--out-dir", default="crawl_out")
    mp = sub.add_parser("map"); mp.add_argument("url")

    args = ap.parse_args()
    app = _client()

    if args.cmd == "search":
        res = app.search(args.query, limit=args.limit)
        print(json.dumps(res, default=str, indent=2))
    elif args.cmd == "scrape":
        doc = app.scrape(args.url)
        md = _md(doc)
        if args.out:
            open(args.out, "w", encoding="utf-8").write(md)
            print(f"Wrote {len(md)} chars -> {args.out}")
        else:
            print(md)
    elif args.cmd == "crawl":
        res = app.crawl(args.url, limit=args.limit)
        docs = getattr(res, "data", None) or (res.get("data") if isinstance(res, dict) else res) or []
        os.makedirs(args.out_dir, exist_ok=True)
        n = 0
        for d in docs:
            url = getattr(d, "url", None) or (d.get("url") if isinstance(d, dict) else f"doc{n}")
            open(os.path.join(args.out_dir, f"{_slug(url)}.md"), "w", encoding="utf-8").write(_md(d))
            n += 1
        print(f"Saved {n} page(s) -> {args.out_dir}/")
    elif args.cmd == "map":
        print(json.dumps(app.map(args.url), default=str, indent=2))


if __name__ == "__main__":
    main()
