#!/usr/bin/env bash
# install.sh — install the super-agent skill for Claude Code.
# Idempotent: safe to re-run. Backs up anything it would overwrite.
#
#   bash install.sh                 # project scope: ./.claude/
#   bash install.sh --user          # user scope:    ~/.claude/
#   bash install.sh --skill-only    # skill, no hooks, no agents
#   bash install.sh --dry-run       # show what would happen, change nothing
#   bash install.sh --uninstall     # remove what this script installed

set -euo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NAME="super-agent"
SCOPE="project"
SKILL_ONLY=0
DRY=0
UNINSTALL=0

for arg in "$@"; do
  case "$arg" in
    --user)       SCOPE="user" ;;
    --project)    SCOPE="project" ;;
    --skill-only) SKILL_ONLY=1 ;;
    --dry-run)    DRY=1 ;;
    --uninstall)  UNINSTALL=1 ;;
    -h|--help)    sed -n '2,12p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'; exit 0 ;;
    *)            echo "Unknown option: $arg (try --help)" >&2; exit 1 ;;
  esac
done

if [ "$SCOPE" = "user" ]; then ROOT="$HOME/.claude"; else ROOT="$PWD/.claude"; fi
SKILL_DIR="$ROOT/skills/$NAME"
STAMP="$(date +%Y%m%d-%H%M%S)"

say()  { printf '  %s\n' "$*"; }
step() { printf '\n%s\n' "$*"; }
run()  { if [ "$DRY" = 1 ]; then say "[dry-run] $*"; else eval "$@"; fi; }

# ---------------------------------------------------------------- uninstall
if [ "$UNINSTALL" = 1 ]; then
  step "Uninstalling from $ROOT"
  run "rm -rf '$SKILL_DIR'";                       say "removed skills/$NAME"
  for a in verifier explorer security-reviewer; do
    [ -f "$ROOT/agents/$a.md" ] && { run "rm -f '$ROOT/agents/$a.md'"; say "removed agents/$a.md"; }
  done
  for h in block-secrets block-dangerous guard-uncommitted lint-changed; do
    [ -f "$ROOT/hooks/$h.sh" ] && { run "rm -f '$ROOT/hooks/$h.sh'"; say "removed hooks/$h.sh"; }
  done
  step "Done. NOTE: hook entries in settings.json were NOT removed — edit it by hand."
  exit 0
fi

# ---------------------------------------------------------------- preflight
step "Preflight"
[ -f "$SRC/SKILL.md" ] || { echo "ERROR: SKILL.md not found in $SRC" >&2; exit 1; }
say "source: $SRC"
say "target: $ROOT  ($SCOPE scope)"
[ "$DRY" = 1 ] && say "MODE: dry-run — nothing will be written"
command -v python3 >/dev/null 2>&1 && HAVE_PY=1 || HAVE_PY=0
[ "$HAVE_PY" = 0 ] && say "WARN: python3 not found — settings.json merge will be skipped"

# ---------------------------------------------------------------- 1. skill
step "1/4  Skill"
if [ -d "$SKILL_DIR" ]; then
  run "mv '$SKILL_DIR' '${SKILL_DIR}.bak-$STAMP'"
  say "existing install backed up → ${NAME}.bak-$STAMP"
fi
run "mkdir -p '$SKILL_DIR'"
run "cp '$SRC/SKILL.md' '$SKILL_DIR/'"
run "cp -r '$SRC/references' '$SKILL_DIR/'"
run "cp -r '$SRC/assets' '$SKILL_DIR/'"
[ -f "$SRC/README.md" ] && run "cp '$SRC/README.md' '$SKILL_DIR/'"
say "installed → $SKILL_DIR"
say "invoke with: /$NAME"

if [ "$SKILL_ONLY" = 1 ]; then
  step "Done (--skill-only). Hooks and agents skipped."
  say "Safety invariants are prompt-level requests only. Re-run without --skill-only for enforcement."
  exit 0
fi

# ---------------------------------------------------------------- 2. agents
step "2/4  Subagents"
run "mkdir -p '$ROOT/agents'"
for a in "$SRC/assets/agents/"*.md; do
  base="$(basename "$a")"
  if [ -f "$ROOT/agents/$base" ] && ! cmp -s "$a" "$ROOT/agents/$base"; then
    run "cp '$ROOT/agents/$base' '$ROOT/agents/$base.bak-$STAMP'"
    say "backed up existing $base"
  fi
  run "cp '$a' '$ROOT/agents/'"
  say "installed agents/$base"
done

# ---------------------------------------------------------------- 3. hooks
step "3/4  Hook scripts"
run "mkdir -p '$ROOT/hooks'"
for h in "$SRC/hooks/"*.sh; do
  base="$(basename "$h")"
  run "cp '$h' '$ROOT/hooks/'"
  run "chmod +x '$ROOT/hooks/$base'"
  say "installed hooks/$base"
done

# ------------------------------------------------------- 4. settings merge
step "4/4  settings.json"
SETTINGS="$ROOT/settings.json"
TEMPLATE="$SRC/assets/settings.json.template"

if [ "$HAVE_PY" = 0 ]; then
  say "SKIPPED — python3 unavailable. Merge the 'hooks' key from:"
  say "  $TEMPLATE"
elif [ "$DRY" = 1 ]; then
  say "[dry-run] would merge hooks into $SETTINGS"
else
  [ -f "$SETTINGS" ] && { cp "$SETTINGS" "$SETTINGS.bak-$STAMP"; say "backed up settings.json"; }
  python3 - "$SETTINGS" "$TEMPLATE" << 'PY'
import json, sys, os
settings_path, template_path = sys.argv[1], sys.argv[2]

with open(template_path) as f:
    new_hooks = json.load(f).get("hooks", {})

existing = {}
if os.path.exists(settings_path):
    try:
        with open(settings_path) as f:
            existing = json.load(f)
    except json.JSONDecodeError:
        print("  ERROR: existing settings.json is not valid JSON — not touching it.")
        print("  Merge the 'hooks' key manually from the template.")
        sys.exit(0)

hooks = existing.setdefault("hooks", {})
added = kept = 0

def cmd_of(entry):
    return tuple(sorted(h.get("command", "") for h in entry.get("hooks", [])))

for event, entries in new_hooks.items():
    bucket = hooks.setdefault(event, [])
    have = {(e.get("matcher", ""), cmd_of(e)) for e in bucket}
    for entry in entries:
        key = (entry.get("matcher", ""), cmd_of(entry))
        if key in have:
            kept += 1
        else:
            bucket.append(entry)
            added += 1

with open(settings_path, "w") as f:
    json.dump(existing, f, indent=2)
    f.write("\n")

print(f"  merged: {added} hook entr{'y' if added==1 else 'ies'} added, {kept} already present")
PY
fi

# ---------------------------------------------------------------- summary
step "Installed."
cat << EOF

  Skill      $SKILL_DIR
  Agents     $ROOT/agents/{verifier,explorer,security-reviewer}.md
  Hooks      $ROOT/hooks/*.sh  (4 guards)
  Settings   $ROOT/settings.json

  Next:
    1. bash doctor.sh $([ "$SCOPE" = user ] && echo --user)   # verify the install
    2. cp assets/CLAUDE.md.template ./CLAUDE.md  &&  fill in the placeholders
    3. Start Claude Code, run /context to confirm the skill is discovered
    4. Try /$NAME

  Rollback:  bash install.sh --uninstall $([ "$SCOPE" = user ] && echo --user)
             Backups from this run carry the suffix .bak-$STAMP

EOF
