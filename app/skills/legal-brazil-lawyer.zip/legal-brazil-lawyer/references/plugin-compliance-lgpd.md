# Plugin: Compliance, LGPD e Proteção de Dados

## Ativar quando
Pedido envolver LGPD, tratamento de dados pessoais, programa de integridade, anticorrupção, investigação interna, due diligence de terceiros, políticas internas, canais de denúncia, ou avaliação de risco regulatório.

## LGPD — Raciocínio especializado

### Sequência obrigatória de análise de dados
1. Identificar natureza dos dados (pessoais comuns, sensíveis, de crianças)
2. Identificar papel da organização (controlador, operador, controlador conjunto)
3. Verificar base legal aplicável (art. 7º ou art. 11 LGPD)
4. Mapear finalidade, necessidade e proporcionalidade
5. Verificar direitos dos titulares e como serão atendidos
6. Analisar compartilhamento e transferência internacional
7. Verificar medidas de segurança e resposta a incidentes

### Bases legais — art. 7º LGPD (dados comuns)
| Base | Requisito | Uso típico |
|---|---|---|
| Consentimento | Livre, informado, inequívoco, específico | Marketing opt-in, cookies não essenciais |
| Contrato | Necessário para execução | Cadastro de cliente, entrega de serviço |
| Obrigação legal | Norma que exige o tratamento | Nota fiscal, e-Social, SPED |
| Interesse legítimo | Legítimo + necessário + não prejudica titular | Analytics, prevenção a fraude, segurança |
| Proteção ao crédito | Dados financeiros para análise de crédito | Score, negativação, Open Finance |
| Execução de políticas públicas | Órgãos públicos | Governo, saúde pública |

### Dados sensíveis — art. 11 LGPD (bases mais restritas)
- Origem racial/étnica, convicção religiosa, opinião política, saúde, vida sexual, dado genético/biométrico, filiação sindical
- Bases permitidas: consentimento específico, obrigação legal, políticas públicas, estudos (anonimizado), proteção da vida, tutela da saúde, prevenção à fraude (biometria)
- ⚠️ Consentimento para dados sensíveis deve ser destacado e específico

### Direitos dos titulares — art. 18 LGPD
- Confirmação de tratamento
- Acesso aos dados
- Correção
- Anonimização, bloqueio ou eliminação (dados desnecessários ou tratados sem base legal)
- Portabilidade
- Eliminação após revogação do consentimento
- Informação sobre compartilhamento
- Não fornecimento de consentimento e consequências
- Revisão de decisão automatizada

**Prazo de resposta**: ANPD recomenda 15 dias (sem prazo legal fixo ainda)

### Incidente de segurança — procedimento
1. Detectar e conter o incidente
2. Avaliar gravidade e risco para titulares
3. Comunicar à ANPD em até **72 horas** (recomendação ANPD; prazo formal em resolução)
4. Comunicar titulares afetados se risco ou dano relevante
5. Documentar: o quê, quando, quem afetado, medidas tomadas
6. Relatório pós-incidente e revisão de controles

### DPA — cláusulas obrigatórias (controlador-operador)
- [ ] Finalidade e escopo do tratamento
- [ ] Categorias de dados e titulares
- [ ] Obrigações de segurança do operador
- [ ] Suboperadores: autorização, responsabilidade, lista
- [ ] Instrução documental do controlador
- [ ] Cooperação em direitos dos titulares
- [ ] Cooperação em incidentes
- [ ] Eliminação ou devolução dos dados ao término
- [ ] Auditoria e evidências de conformidade

### Transferência internacional
- Países com nível adequado: decisão ANPD (ainda não publicada lista definitiva)
- Mecanismos alternativos: cláusulas contratuais padrão (aprovadas ANPD), normas corporativas globais (BCR), consentimento específico, contratos internacionais necessários

---

## Compliance Anticorrupção

### Marco legal
- **Lei 12.846/13** (Lei Anticorrupção): responsabilidade objetiva da PJ
- **Decreto 11.129/22**: programa de integridade como atenuante
- **Lei 8.429/92** (Improbidade): agentes públicos
- **FCPA** (EUA) e **UK Bribery Act**: risco para empresas com operações internacionais
- **OCDE**: Convenção sobre suborno de funcionários públicos estrangeiros

### Elementos do programa de integridade — Decreto 11.129/22
1. Comprometimento da alta direção
2. Instância de integridade (CCO, comitê)
3. Análise de risco periódica
4. Código de conduta e políticas
5. Treinamento
6. Canal de denúncias confidencial e com proteção ao denunciante
7. Due diligence de terceiros
8. Controles internos contábeis e financeiros
9. Monitoramento contínuo
10. Medidas de resposta e remediação

### Due diligence de terceiros — níveis de profundidade
| Risco | Perfil | Diligência |
|---|---|---|
| Baixo | Fornecedor padrão, sem acesso a dados, sem contato público | Checklist básico: sanções, PEP, negativação |
| Médio | Representante comercial, consultor, parceiro com acesso a clientes | + background check, referências, justificativa contratual |
| Alto | Intermediário com contato com poder público, mercados sensíveis, offshore | + due diligence aprofundada, relatório investigativo, aprovação C-level |

### Sinais de alerta (red flags anticorrupção)
- Solicitação de pagamento em espécie ou conta no exterior
- Comissão desproporcional ao serviço prestado
- Resistência a due diligence ou auditoria
- Empresa recém-constituída sem histórico
- Terceiro indicado por funcionário público
- Fatura sem detalhamento de serviços
- Pagamentos fracionados abaixo de limites de aprovação

### Investigação interna — procedimento
1. Triagem da denúncia/suspeita
2. Decisão de investigar (threshold)
3. Composição da equipe (independência, confidencialidade)
4. Coleta de evidências (documentos, e-mails, entrevistas)
5. Entrevistas: direito ao contraditório — atenção ao momento de ouvir investigado
6. Relatório investigativo: fatos, achados, conclusões, recomendações
7. Medidas disciplinares e remediação
8. Decisão sobre autodeclaração a autoridades
9. Monitoramento pós-investigação

### Formato de saída preferencial
- Programa de integridade: estrutura em 10 pilares com gaps e prioridades
- Relatório de due diligence de terceiro: sumário executivo + detalhamento por frente
- Política anticorrupção: objeto, abrangência, definições, vedações, canal, sanções
- Matriz de risco de compliance: processo | risco | controle existente | gap | ação
