# Plugin: EOR (Employer of Record) e Contratação para Tomador Estrangeiro

> **Base verificada em 07/10/2026.** Dispositivos e precedentes **sem marcação** foram conferidos nesta data em fonte oficial (planalto.gov.br, stf.jus.br, stj.jus.br, tst.jus.br, gov.br/anpd, in.gov.br) — grau **C1**. **(C2)** = vem do `plugin-trabalhista.md` (corte 03/08/2026), sem reverificação. **(C3 — verificar)** = entendimento descrito sem número, não confirmado. 🔄 volátil · ⛔ erro comum.

**Quando carregar**: trabalhador registrado no Brasil por uma empresa brasileira (EOR, "PEO", "global employment", "payroll partner") que presta serviço a cliente estrangeiro que dirige o trabalho; teletrabalho do Brasil para empresa sem estabelecimento aqui; salário em moeda estrangeira, comissões ou equity concedidos pelo grupo estrangeiro; rescisão decidida pelo cliente; citação/execução de tomador no exterior; LGPD na transferência de dados de empregados.

**Não repetir aqui** (carregar o `plugin-trabalhista.md`): elementos do vínculo (§2), tabela de verbas (§4), estabilidades (§6.3), quadro geral de terceirização e Súmula 331 (§7.1), pejotização/Tema 1389 (§7.2), IRR sobre comissões (§8.8), atualização monetária (§8.6).

---

## 1. Enquadramento jurídico do EOR

O EOR não tem tipo legal próprio no Brasil. A estrutura cabe em uma de três molduras:

| Moldura | Base | Quando se sustenta | Ponto fraco no EOR |
|---|---|---|---|
| **Prestação de serviços a terceiros** | Lei 6.019/74, arts. 4º-A a 5º-D (redação das Leis 13.429/2017 e 13.467/2017) | Prestadora com capacidade econômica que **contrata, remunera e dirige** o trabalho (art. 4º-A, §1º); serviços determinados no contrato (art. 5º-A, §1º) | No EOR típico quem **dirige** é o cliente — o elemento do §1º fica formalmente com a EOR e materialmente com o tomador |
| **Trabalho temporário** | Lei 6.019/74, arts. 2º, 4º, 9º e 10 | Empresa registrada no MTE, motivo justificador (substituição transitória ou demanda complementar), até **180 dias + 90** (art. 10, §§1º e 2º) | Raramente atende o EOR permanente; recontratação antes de 90 dias do término **gera vínculo com a tomadora** (art. 10, §§5º e 6º) |
| **Intermediação ilícita / fraude** | CLT, art. 9º (nulidade de atos para desvirtuar ou fraudar a CLT) | — | Pessoalidade + subordinação direta ao tomador + EOR reduzida a folha de pagamento |

**Licitude da terceirização (STF)**:
- **ADPF 324** (Rel. Min. Roberto Barroso; mérito em **30/08/2018**; trânsito em **28/09/2021**): é lícita a terceirização de qualquer atividade, meio ou fim, sem relação de emprego entre contratante e empregado da contratada; cabe à contratante verificar idoneidade e capacidade econômica da terceirizada e responder **subsidiariamente** (trabalhista e previdenciário, art. 31 da Lei 8.212/91).
- **Tema 725 (RE 958252)** (Rel. Min. Luiz Fux): tese — é lícita a terceirização ou qualquer outra forma de divisão do trabalho entre pessoas jurídicas distintas, independentemente do objeto social, **mantida a responsabilidade subsidiária** da contratante. Trânsito em 15/10/2024 (C2).
- ⚠️ **Limite que decide o caso EOR**: o STF validou a **divisão do trabalho entre empresas**, não a **interposição de mão de obra com subordinação direta** ao tomador. Fraude comprovada continua atraindo o art. 9º da CLT. A discussão sobre até onde vai a blindagem da ADPF 324 está viva no **Tema 1389** 🔄 (ver trabalhista §7.2) — conferir status antes de concluir.
- Requisitos formais que a EOR precisa cumprir: CNPJ, registro na Junta e **capital social escalonado** pelo número de empregados (art. 4º-B); vedação de usar o trabalhador fora do objeto contratado (art. 5º-A, §1º); quarentenas de 18 meses (arts. 5º-C e 5º-D).

## 2. Responsabilidade do tomador

- **Subsidiária (regra)**: art. 5º-A, §5º, da Lei 6.019/74 (período da prestação); no temporário, art. 10, §7º. **Súmula 331 do TST, item IV** (vigente; o item I foi cancelado pela Res. TST 225/2025 — página oficial do TST): exige que o tomador **tenha participado da relação processual e conste do título executivo**; item VI: abrange todas as verbas da condenação referentes ao período.
- **Solidária**: (i) fraude/intermediação ilícita — nulidade (CLT, art. 9º) e reparação solidária por coautoria (CC, art. 942) → normalmente com **reconhecimento de vínculo direto** com o tomador; (ii) temporário, na falência da empresa de trabalho temporário (Lei 6.019/74, art. 16).
- **Grupo econômico** (CLT, art. 2º, §§2º e 3º, red. Lei 13.467/2017): solidariedade entre empresas sob direção/controle comum ou em grupo; **mera identidade de sócios não basta** — exige interesse integrado, comunhão de interesses e atuação conjunta. Útil quando o tomador estrangeiro tem **subsidiária brasileira**.
- **STF, Tema 1232 (RE 1387795)** — mérito em **13/10/2025** (Plenário Virtual 03 a 10/10/2025; ata publicada em 20/10/2025); tese: a execução **não pode ser promovida contra empresa que não participou da fase de conhecimento**; o reclamante deve indicar **na petição inicial** os corresponsáveis solidários, inclusive do grupo econômico, demonstrando concretamente os requisitos; redirecionamento posterior só em sucessão (CLT, art. 448-A) ou abuso da personalidade (CC, art. 50), via IDPJ. 🔄 Trânsito e eventuais embargos: verificar.
- ⛔ Consequência prática: **tomador e empresa brasileira do grupo entram no polo passivo desde a inicial**, ou ficam fora da execução.

## 3. Tomador estrangeiro sem presença no Brasil

**Jurisdição e competência**
- CPC, art. 21: jurisdição brasileira quando o réu é domiciliado aqui, a obrigação deve ser cumprida aqui ou o fato ocorreu aqui (incisos I a III). **Parágrafo único**: pessoa jurídica estrangeira com **agência, filial ou sucursal** no Brasil considera-se domiciliada no país. Art. 22, III: submissão expressa ou tácita. Aplicação subsidiária ao processo do trabalho: CLT, art. 769; CPC, art. 15.
- CLT, art. 651: competência pelo **local da prestação de serviços**, ainda que contratado no estrangeiro; §3º: se o empregador realiza atividades fora do lugar do contrato, opção entre foro da celebração e da prestação. Em teletrabalho, o local da prestação tende a coincidir com o domicílio do empregado (C3 — verificar a jurisprudência do TRT).
- CPC, art. 25 (afasta a jurisdição brasileira se houver **foro exclusivo estrangeiro em contrato internacional**, arguido em contestação): a aplicação a contrato de trabalho executado no Brasil é **altamente contestável** diante do art. 651 da CLT, norma especial (C3 — verificar).

**Citação**
- Com filial/agência no Brasil: o gerente **presume-se autorizado a receber citação** (CPC, art. 75, X e §3º).
- Sem presença: cooperação jurídica internacional (CPC, arts. 26 e 27, I) — carta rogatória ou tratado.
- **Convenção da Haia de 1965 sobre citação**: promulgada pelo **Decreto 9.734, de 20/03/2019**; adesão depositada em 29/11/2018; **em vigor para o Brasil desde 01/06/2019**; **reservas aos arts. 8º e 10** (o Brasil se opõe a esses meios de transmissão — p. ex., via postal — **para documentos destinados ao Brasil**); Autoridade Central: **Ministério da Justiça e Segurança Pública**; documentos recebidos exigem tradução para o português. Para citação **no exterior**, valem as reservas e exigências do **Estado de destino**. A Convenção cobre "matéria civil e comercial" — se o Estado requerido aceita demanda trabalhista nesse conceito depende dele (C3 — verificar caso a caso).
- Prazo realista: meses (C3). Planejar a prescrição bienal (CF, art. 7º, XXIX) sem depender da citação no exterior.

**Execução**
- Sentença brasileira contra réu sem bens no Brasil precisa ser reconhecida **no país do réu**, pela lei de lá. Sentença estrangeira para valer no Brasil: homologação no STJ (CF, art. 105, I, "i"; CPC, arts. 960 a 963).
- Pontos de contato que viabilizam execução no Brasil: subsidiária ou filial brasileira (grupo econômico, Tema 1232), créditos que clientes brasileiros devem ao tomador (penhora de créditos — C3), bens e contas locais. Sem nada disso, a **EOR é o patrimônio executável real**.

## 4. Lei aplicável e cláusulas de lei/foro estrangeiros

- **Súmula 207 do TST (lex loci executionis) — CANCELADA** pela **Res. TST 181, de 16/04/2012** (DEJT 19, 20 e 23/04/2012). ⛔ Não citar como vigente.
- **Lei 7.064/82**: desde a Lei 11.962/2009, regula trabalhadores **contratados no Brasil ou transferidos** para prestar serviço no exterior (art. 1º); garante a lei brasileira de proteção ao trabalho **quando mais favorável que a territorial, no conjunto de normas e por matéria** (art. 3º, II); salário-base em **moeda nacional**, admitido pagamento parcial no exterior em moeda estrangeira (art. 5º). Parágrafo único do art. 1º (red. Lei 14.978/2024): exclui o designado para serviço transitório de até 90 dias e tripulantes de cruzeiros.
- **Empregado no Brasil para tomador estrangeiro** (caso EOR típico): a execução é no Brasil → aplica-se a lei brasileira (CLT, art. 651 e princípio territorial — C3 quanto à fundamentação jurisprudencial atual). A Lei 7.064/82 não é a base desse caso (ela trata de **saída** para o exterior).
- **Teletrabalho fora do país** por empregado admitido no Brasil: aplica-se a legislação brasileira, excetuada a Lei 7.064/82, salvo disposição em contrário (CLT, art. 75-B, §8º, Lei 14.442/2022). Teletrabalhador segue as normas coletivas da base do **estabelecimento de lotação** (art. 75-B, §7º) — na EOR, a lotação é na EOR.
- **Cláusula de lei estrangeira**: LINDB, art. 9º (obrigações regem-se pela lei do lugar em que se constituem) não prevalece sobre normas de proteção — CLT, arts. 9º e 444 (livre estipulação só no que não contravenha a proteção). Exceção relevante: **hipersuficiente** (diploma superior + salário ≥ 2× o teto do RGPS) pode negociar as matérias do art. 611-A (art. 444, parágrafo único) e pactuar **arbitragem** por iniciativa ou concordância expressa (art. 507-A). Validade de arbitragem **com sede no exterior** para empregado no Brasil: C3 — verificar.

## 5. Remuneração

- **Moeda**: salário pago em **moeda corrente do país**; pagamento em desacordo **considera-se não feito** (CLT, art. 463 e parágrafo único). A **Lei 14.286/2021** revogou o **DL 857/69** (art. 28, XIV) e admite estipulação em moeda estrangeira só nas hipóteses do art. 13 (p. ex., inciso II: credor ou devedor **não residente**); fora delas, nulidade de pleno direito (art. 13, parágrafo único). Vigência: um ano após a publicação (DOU 30/12/2021). Na EOR, empregador e empregado são residentes → salário **fixado em reais**; referência cambial só como critério de reajuste, com risco de redução nominal vedada (CF, art. 7º, VI) se o câmbio cair (C3 — verificar jurisprudência).
- **Comissões e metas definidas pelo tomador**: comissões pagas pelo empregador **integram o salário** (CLT, art. 457, §1º); são exigíveis após ultimada a transação e a cessação do contrato não prejudica sua percepção (art. 466 e §2º). Metas, territórios e aprovação de deals pelo tomador são **prova de subordinação a ele**. Estornos e base de cálculo: IRR Temas 65 e 57 (C2).
- **Bônus**: prêmio = liberalidade por desempenho **superior ao ordinariamente esperado**, sem natureza salarial mesmo habitual (art. 457, §§2º e 4º). Bônus garantido, ligado a metas ordinárias ou pago com habitualidade tende à natureza salarial (C3). Bônus pago **diretamente pelo grupo estrangeiro** a empregado da EOR: risco de integração como salário pago por terceiro e de prova de vínculo direto (C3 — verificar).
- **PLR**: não substitui remuneração, não é base de encargos e afasta a habitualidade (Lei 10.101/2000, art. 3º); vedados pagamentos em mais de 2 vezes no ano civil ou em periodicidade inferior a um trimestre (art. 3º, §2º). "Bonus plan" global rotulado de PLR sem os requisitos procedimentais da Lei 10.101 → risco de reclassificação (C3).

## 6. Stock options e RSUs do grupo estrangeiro

- **STJ, Tema 1226** (1ª Seção; REsp 2069644/SP e REsp 2074564/SP; Rel. Min. Sérgio Kukina; julgado em **11/09/2024**, acórdão publicado em 18/09/2024; ED em 25/11/2024; **trânsito em julgado em 31/03/2026 e 19/06/2026**, respectivamente): no *stock option plan* (Lei 6.404/76, art. 168, §3º), de **natureza mercantil**, não incide IRPF na aquisição das ações; incide sobre o **ganho de capital** na revenda. 🔄 Há processo STF vinculado (ARE 1577528) — verificar.
- ⚠️ O Tema 1226 é **tributário** e trata de plano de companhia (opção onerosa). Para **RSU gratuita**, sem preço de exercício e sem risco do beneficiário, o argumento mercantil é mais fraco (C3).
- **TST**: há acórdão de Turma qualificando stock options como vantagem **mercantil**, sem natureza salarial, por haver onerosidade e risco de mercado — 5ª Turma, **RR-201000-02.2008.5.15.0140** (notícia oficial do TST de 23/03/2015; precedente persuasivo, não vinculante). Não localizei tese vinculante do TST sobre o tema (C3). Planos com desconto relevante, sem risco ou usados como substituto de salário podem ser tratados como salário (C3).
- Perda de *unvested* na saída: cláusulas de *vesting* e *forfeiture* têm sido validadas em casos concretos (C3 — verificar). Competência (JT x Justiça Comum) para litígio sobre plano do grupo: C3.

## 7. Rescisão

- **Quem decide e quem paga**: juridicamente, a **EOR** dispensa e paga — verbas da modalidade (trabalhista §4), entrega de documentos e pagamento em **10 dias** do término (CLT, art. 477, §6º), sob multa de um salário (art. 477, §8º). O tomador responde subsidiariamente pelo inadimplemento.
- **Encerramento do contrato EOR–cliente** não é justa causa nem força maior: é **dispensa sem justa causa** pela EOR, salvo realocação aceita.
- **Justa causa por fato ocorrido no tomador**: a EOR precisa de apuração própria, prova documental, imediatidade e tipicidade (art. 482); "o cliente pediu" não é prova. Justa causa revertida atrai multa do §8º (IRR Tema 71 — C2).
- **Contestação da rescisão**: discute-se (i) verbas e multas; (ii) reversão de justa causa; (iii) estabilidades (trabalhista §6.3) — a garantia **também** vincula a EOR quando o cliente encerra; (iv) vínculo direto com o tomador, quando a dispensa foi decidida, comunicada e executada por ele (forte indício de subordinação direta).

## 8. Não concorrência, confidencialidade e PI

- **Não concorrência pós-contratual**: sem regra legal específica na CLT. Validade usualmente condicionada a limite de tempo, território e atividade **e a compensação financeira** durante a restrição (C3 — verificar). Cláusula imposta pelo **cliente estrangeiro** a quem não é seu empregado formal: eficácia duvidosa e reforça prova de vínculo direto (C3).
- **Confidencialidade**: violação de segredo da empresa é justa causa (CLT, art. 482, "g") — mas o segredo é do **cliente**; a EOR precisa de cláusula contratual estendendo a obrigação.
- **PI — atenção à cadeia de titularidade**: invenção e modelo de utilidade pertencem ao **empregador** quando o contrato executado no Brasil tem por objeto pesquisa/atividade inventiva (Lei 9.279/96, art. 88); programa de computador pertence ao empregador ou contratante de serviços, salvo estipulação em contrário (Lei 9.609/98, art. 4º). Empregador = **EOR**, não o cliente → exigir **cessão EOR → cliente** no contrato de serviços e, quando aplicável, termo do empregado.

## 9. Prova de subordinação ao tomador

Ônus do reclamante quanto ao fato constitutivo (CLT, art. 818, I). Meios: todos os legais e moralmente legítimos (CPC, art. 369); **ata notarial** de conteúdo digital (CPC, art. 384); **exibição de documento** em poder da parte, com presunção de veracidade se injustificadamente negada (CPC, arts. 396 e 400).

Mapa de evidências (quem fez o quê):
- **Ordens e rotina**: e-mails, Slack/Teams, convites de reunião, quem atribuía tarefas e cobrava prazos.
- **Hierarquia**: organograma do tomador com o trabalhador; título/e-mail corporativo do cliente; assinatura com a marca do cliente.
- **Metas e desempenho**: quotas, planos de comissão, avaliações, PIPs emitidos pelo tomador.
- **Gestão de pessoal**: quem aprovava férias, viagens, despesas, contratação de pares, promoção e **dispensa**.
- **Ferramentas e integração**: acessos (SSO, CRM, HRIS do cliente), onboarding do cliente, participação em all-hands.
- **Papel real da EOR**: contatos limitados a folha e benefícios = indício forte de mera interposição.
- ⛔ Preservar prova sem exfiltrar dados sigilosos do cliente além do necessário — risco de justa causa (art. 482, "g") e de ilícito de dados (C3 sobre limites jurisprudenciais).

## 10. Riscos para o tomador estrangeiro

- **Vínculo direto** (art. 9º CLT) com todas as verbas, e/ou **responsabilidade subsidiária** pelo período (art. 5º-A, §5º).
- **Estabelecimento permanente** tributário pela atuação de empregado com poderes de negociação/fechamento no Brasil — **apenas sinalizar**; carregar `plugin-tributario.md`.
- **LGPD**: o envio de dados do empregado da EOR ao cliente no exterior é **transferência internacional** (LGPD, art. 33). **Resolução CD/ANPD nº 19, de 23/08/2024** (Regulamento de Transferência Internacional + cláusulas-padrão no Anexo II): cláusulas-padrão adotadas **integralmente e sem alteração**; prazo de **12 meses da publicação** para incorporá-las aos contratos (vencido); titular pode demandar exportador ou importador **no Brasil**, inclusive no foro de sua residência; dados sensíveis (saúde, biometria, filiação sindical) exigem salvaguardas adicionais.

---

## 11. Fluxos

**Fluxo 1 — Avaliar a estrutura antes de contratar (consultivo)**
1. Há entidade do grupo no Brasil? Se sim, contratar por ela tende a ser mais seguro que EOR.
2. A função exige gestão diária pelo cliente? Quanto maior a subordinação direta, maior o risco de vínculo (§1).
3. Due diligence da EOR: capital social (art. 4º-B), certidões, histórico de reclamações, capacidade econômica (ADPF 324).
4. Contrato EOR–cliente: objeto determinado (art. 5º-A, §1º), cessão de PI (§8), cláusulas-padrão ANPD (§10), indenização regressiva, regras de rescisão e de investigação disciplinar.
5. Remuneração em reais; bônus/comissões **pela EOR**; equity documentado como plano mercantil (§§5–6).
6. Desenho de governança: canal formal da EOR para disciplina, férias e dispensa; evitar e-mail/título do cliente quando possível.
7. Sinalizar PE tributário e Tema 1389 🔄 como riscos vivos.

**Fluxo 2 — Empregado questionando a rescisão: contra quem e em que ordem**
1. **Prazos primeiro**: prescrição bienal da extinção; não esperar citação no exterior para ajuizar.
2. **Polo passivo único, desde a inicial** (Súmula 331, IV; Tema 1232): (a) **EOR** — empregadora; (b) **tomador estrangeiro** — pedido principal de vínculo direto/solidariedade (art. 9º CLT; CC, art. 942) e **sucessivo** de responsabilidade subsidiária; (c) **entidade brasileira do grupo**, se houver — grupo econômico (art. 2º, §§2º e 3º), com demonstração concreta.
3. Citação: entidade/filial no Brasil → via local (CPC, arts. 21, parágrafo único, e 75, §3º); sem presença → Haia/rogatória (§3), em paralelo ao andamento contra a EOR.
4. Pedidos: verbas e multas (arts. 467 e 477, §8º), reversão de justa causa, estabilidade, comissões/bônus/equity, dano moral se houver.
5. Prova: requerer exibição de documentos (CPC, arts. 396 e 400) dirigida à EOR **e** ao tomador.
6. Avaliar executabilidade: se a EOR é solvente, a subsidiária pode bastar; o vínculo direto só agrega se houver diferença de direitos ou patrimônio do tomador alcançável.

**Fluxo 3 — Defesa da EOR**
1. Demonstrar que a EOR **contrata, remunera e dirige** (art. 4º-A, §1º): políticas próprias, gestor de RH, decisões disciplinares documentadas.
2. Regularidade formal: art. 4º-B, contrato com objeto determinado, recolhimentos e quitação tempestiva.
3. Rescisão: provar pagamento no prazo; se justa causa, apuração própria e imediatidade.
4. ⚠️ **Conflito de defesas** com o tomador: a EOR sustenta a licitude (dirige o trabalho); o tomador tende a negar qualquer gestão. Avaliar representação separada e alinhamento prévio.
5. Regresso contra o cliente pela via contratual (cláusula de indenização), em regra fora do processo trabalhista (C3 — verificar cabimento de intervenção de terceiros na JT).

## 12. Checklist documental

- [ ] Contrato de trabalho com a EOR (função, lotação, teletrabalho — art. 75-C, remuneração em reais)
- [ ] Contrato EOR–cliente (objeto, SLA, rescisão, indenização, cessão de PI, cláusulas-padrão ANPD)
- [ ] Atos constitutivos e capital social da EOR (art. 4º-B); certidões
- [ ] Plano de comissões, metas e bônus — **quem emitiu**
- [ ] Documentos de equity (plano, *grant*, *vesting*, *forfeiture*, lei e foro)
- [ ] Organograma, e-mails, Slack/Teams, avaliações, aprovações de férias e despesas
- [ ] Comunicação de dispensa (quem decidiu, quem comunicou), TRCT, comprovantes de pagamento e datas
- [ ] Atestados e comunicações que indiquem estabilidade
- [ ] Prova de presença do grupo no Brasil (CNPJ de subsidiária/filial, contratos com clientes locais)
- [ ] Termos de NDA, não concorrência, PI e política de dados (aviso de transferência internacional)

## 13. Pontos de verificação obrigatória

- 🔄 **Tema 1389 (STF)**: status e eventual tese antes de concluir sobre licitude da estrutura.
- 🔄 **Tema 1232 (STF)**: trânsito e embargos; jurisprudência de aplicação a tomadores estrangeiros.
- 🔄 **Tema 1226 (STJ)** e ARE 1577528 no STF; tratamento de RSUs.
- Reservas e declarações do **Estado de destino** na Convenção da Haia antes de pedir citação.
- Norma coletiva da base da **EOR** (lotação) e enquadramento sindical.
- Regulamentação da ANPD posterior à Res. 19/2024 (decisões de adequação, cláusulas equivalentes).
- Jurisprudência atual do TRT competente sobre EOR, cláusula de foro estrangeiro e não concorrência (tudo marcado C3 acima).

## 14. Erros que este plugin existe para impedir

1. Citar a **Súmula 207 do TST** como vigente (cancelada em 2012).
2. Citar o **DL 857/69** como vigente (revogado pela Lei 14.286/2021).
3. Pagar ou fixar salário de empregado da EOR **em dólar** como obrigação em moeda estrangeira (CLT, art. 463; Lei 14.286/2021, art. 13).
4. Incluir o tomador ou o grupo **só na execução** (Súmula 331, IV; Tema 1232).
5. Tratar a ADPF 324/Tema 725 como salvo-conduto para **subordinação direta** ao tomador.
6. Invocar a **Lei 7.064/82** para quem trabalha **no Brasil** para empresa estrangeira.
7. Usar o **Tema 1226 do STJ** como se fosse tese trabalhista vinculante ou estendê-lo automaticamente a RSUs.
8. Esquecer a **cessão de PI** EOR → cliente (o titular legal é o empregador).
9. Ignorar as **cláusulas-padrão da ANPD** na transferência de dados do empregado ao cliente.
10. Esperar a citação no exterior para ajuizar, deixando correr a **prescrição bienal**.
