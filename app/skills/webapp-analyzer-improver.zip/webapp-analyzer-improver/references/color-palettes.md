# Color Palettes Reference

30 curated color palettes organized by product type. Each includes semantic roles, dark mode variants, and accessibility-verified contrast ratios.

## Table of Contents
1. [Fintech & Banking](#fintech--banking)
2. [Healthcare & Wellness](#healthcare--wellness)
3. [SaaS & Dashboards](#saas--dashboards)
4. [E-commerce](#e-commerce)
5. [Education](#education)
6. [Creative & Portfolio](#creative--portfolio)
7. [Universal Neutrals](#universal-neutrals)

---

## Fintech & Banking

### 1. Trust Navy
```css
--color-primary: #1a365d;      /* Deep navy - trust, authority */
--color-primary-light: #2b6cb0;
--color-secondary: #d69e2e;    /* Gold - premium, value */
--color-accent: #38a169;       /* Green - growth, positive */
--color-danger: #e53e3e;       /* Red - alerts, losses */
--color-surface: #f7fafc;
--color-surface-dark: #0f1729;
--color-text: #1a202c;
--color-text-muted: #718096;
```

### 2. Modern Fintech
```css
--color-primary: #6366f1;      /* Indigo - modern, innovative */
--color-primary-light: #818cf8;
--color-secondary: #06b6d4;    /* Cyan - clarity, transparency */
--color-accent: #10b981;       /* Emerald - success, growth */
--color-danger: #ef4444;
--color-surface: #fafafa;
--color-surface-dark: #111827;
--color-text: #111827;
--color-text-muted: #6b7280;
```

### 3. Premium Banking
```css
--color-primary: #1e293b;      /* Slate - sophistication */
--color-primary-light: #334155;
--color-secondary: #c9a96e;    /* Champagne gold */
--color-accent: #0ea5e9;       /* Sky - clarity */
--color-danger: #dc2626;
--color-surface: #f8fafc;
--color-surface-dark: #0c0f1a;
--color-text: #0f172a;
--color-text-muted: #64748b;
```

### 4. Crypto / DeFi
```css
--color-primary: #7c3aed;      /* Violet - innovation */
--color-primary-light: #a78bfa;
--color-secondary: #14b8a6;    /* Teal - tech-forward */
--color-accent: #f59e0b;       /* Amber - value, alerts */
--color-danger: #f43f5e;
--color-surface: #faf5ff;
--color-surface-dark: #0f0a1e;
--color-text: #1e1b4b;
--color-text-muted: #6366f1;
```

---

## Healthcare & Wellness

### 5. Clinical Calm
```css
--color-primary: #0d9488;      /* Teal - healing, trust */
--color-primary-light: #2dd4bf;
--color-secondary: #3b82f6;    /* Blue - reliability */
--color-accent: #22c55e;       /* Green - health */
--color-danger: #ef4444;
--color-warning: #f59e0b;
--color-surface: #f0fdfa;
--color-surface-dark: #0a1f1c;
--color-text: #134e4a;
--color-text-muted: #5eead4;
```

### 6. Wellness Warm
```css
--color-primary: #059669;      /* Emerald - vitality */
--color-primary-light: #34d399;
--color-secondary: #f97316;    /* Orange - energy */
--color-accent: #8b5cf6;       /* Violet - mindfulness */
--color-danger: #dc2626;
--color-surface: #ecfdf5;
--color-surface-dark: #0a1e16;
--color-text: #064e3b;
--color-text-muted: #6ee7b7;
```

### 7. Mental Health
```css
--color-primary: #7c3aed;      /* Purple - calm, introspection */
--color-primary-light: #a78bfa;
--color-secondary: #ec4899;    /* Pink - warmth, compassion */
--color-accent: #06b6d4;       /* Cyan - clarity */
--color-danger: #ef4444;
--color-surface: #faf5ff;
--color-surface-dark: #1a0a2e;
--color-text: #3b0764;
--color-text-muted: #c084fc;
```

---

## SaaS & Dashboards

### 8. Dashboard Pro
```css
--color-primary: #3b82f6;      /* Blue - action, reliability */
--color-primary-light: #60a5fa;
--color-secondary: #8b5cf6;    /* Purple - premium features */
--color-accent: #10b981;       /* Green - success, metrics up */
--color-danger: #ef4444;       /* Red - errors, metrics down */
--color-warning: #f59e0b;      /* Amber - caution */
--color-surface: #f8fafc;
--color-surface-dark: #0f172a;
--color-text: #1e293b;
--color-text-muted: #94a3b8;
```

### 9. Minimal SaaS
```css
--color-primary: #18181b;      /* Near-black - bold, clean */
--color-primary-light: #3f3f46;
--color-secondary: #6366f1;    /* Indigo - accent */
--color-accent: #22c55e;
--color-danger: #ef4444;
--color-surface: #ffffff;
--color-surface-dark: #09090b;
--color-text: #18181b;
--color-text-muted: #a1a1aa;
```

### 10. Neon Dashboard (Dark-first)
```css
--color-primary: #06b6d4;      /* Cyan - tech, data */
--color-primary-light: #22d3ee;
--color-secondary: #a855f7;    /* Purple - segments */
--color-accent: #10b981;       /* Green - positive */
--color-danger: #f43f5e;       /* Rose - alerts */
--color-warning: #eab308;
--color-surface: #0f172a;      /* Dark surface */
--color-surface-light: #1e293b;
--color-text: #f1f5f9;
--color-text-muted: #64748b;
```

### 11. Analytics Blue
```css
--color-primary: #2563eb;
--color-primary-light: #3b82f6;
--color-secondary: #7c3aed;
--color-accent: #059669;
--color-danger: #dc2626;
--color-surface: #eff6ff;
--color-surface-dark: #0c1524;
--color-text: #1e3a5f;
--color-text-muted: #93c5fd;
```

---

## E-commerce

### 12. Conversion Red
```css
--color-primary: #dc2626;      /* Red - urgency, action */
--color-primary-light: #f87171;
--color-secondary: #1e293b;    /* Dark - grounding */
--color-accent: #f59e0b;       /* Gold - deals, savings */
--color-success: #16a34a;
--color-surface: #fff7ed;
--color-surface-dark: #1c1917;
--color-text: #1c1917;
--color-text-muted: #78716c;
```

### 13. Luxury E-commerce
```css
--color-primary: #1a1a2e;      /* Deep navy-black */
--color-primary-light: #16213e;
--color-secondary: #c9a96e;    /* Gold */
--color-accent: #e2e8f0;       /* Silver */
--color-surface: #fafaf9;
--color-surface-dark: #0a0a14;
--color-text: #0a0a14;
--color-text-muted: #a8a29e;
```

### 14. Fresh Marketplace
```css
--color-primary: #059669;      /* Green - fresh, organic */
--color-primary-light: #34d399;
--color-secondary: #ea580c;    /* Orange - warmth */
--color-accent: #0284c7;       /* Blue - trust */
--color-surface: #f0fdf4;
--color-surface-dark: #0a1e16;
--color-text: #14532d;
--color-text-muted: #86efac;
```

---

## Education

### 15. Academic Indigo
```css
--color-primary: #4f46e5;      /* Indigo - wisdom */
--color-primary-light: #6366f1;
--color-secondary: #0891b2;    /* Cyan - exploration */
--color-accent: #f59e0b;       /* Amber - achievement */
--color-success: #16a34a;
--color-surface: #eef2ff;
--color-surface-dark: #0f0e24;
--color-text: #1e1b4b;
--color-text-muted: #a5b4fc;
```

### 16. Playful Learning
```css
--color-primary: #8b5cf6;      /* Purple - creative */
--color-primary-light: #a78bfa;
--color-secondary: #f43f5e;    /* Rose - fun */
--color-accent: #06b6d4;       /* Cyan - discovery */
--color-success: #22c55e;
--color-surface: #faf5ff;
--color-surface-dark: #1a0a2e;
--color-text: #3b0764;
--color-text-muted: #c4b5fd;
```

---

## Creative & Portfolio

### 17. Brutalist Mono
```css
--color-primary: #000000;
--color-primary-light: #262626;
--color-secondary: #fbbf24;    /* Yellow accent */
--color-accent: #ef4444;       /* Red accent */
--color-surface: #fafaf9;
--color-surface-dark: #000000;
--color-text: #000000;
--color-text-muted: #737373;
```

### 18. Gradient Dream
```css
--color-primary: #7c3aed;
--color-primary-end: #ec4899;  /* Use as gradient endpoint */
--color-secondary: #06b6d4;
--color-accent: #fbbf24;
--color-surface: #faf5ff;
--color-surface-dark: #0f0720;
--color-text: #1e1b4b;
--color-text-muted: #a78bfa;
/* Hero gradient: linear-gradient(135deg, #7c3aed, #ec4899, #f97316) */
```

### 19. Editorial
```css
--color-primary: #1a1a1a;
--color-primary-light: #404040;
--color-secondary: #b91c1c;    /* Editorial red */
--color-accent: #1d4ed8;       /* Link blue */
--color-surface: #f5f5f4;
--color-surface-dark: #0a0a0a;
--color-text: #171717;
--color-text-muted: #737373;
```

### 20. Retro Futurism
```css
--color-primary: #f97316;      /* Orange - retro */
--color-primary-light: #fb923c;
--color-secondary: #06b6d4;    /* Cyan - futuristic */
--color-accent: #facc15;       /* Yellow - energy */
--color-surface: #1e1b4b;      /* Deep indigo surface */
--color-surface-light: #312e81;
--color-text: #f5f5f4;
--color-text-muted: #c7d2fe;
```

---

## Universal Neutrals

### 21-25: Neutral Scales (use with any accent)

**Slate** (cool): `#f8fafc #f1f5f9 #e2e8f0 #cbd5e1 #94a3b8 #64748b #475569 #334155 #1e293b #0f172a`

**Gray** (neutral): `#fafafa #f5f5f5 #e5e5e5 #d4d4d4 #a3a3a3 #737373 #525252 #404040 #262626 #171717`

**Zinc** (modern): `#fafafa #f4f4f5 #e4e4e7 #d4d4d8 #a1a1aa #71717a #52525b #3f3f46 #27272a #18181b`

**Stone** (warm): `#fafaf9 #f5f5f4 #e7e5e4 #d6d3d1 #a8a29e #78716c #57534e #44403c #292524 #1c1917`

**Sand** (earthy): `#fefdfb #faf8f5 #f0ece4 #ddd6ca #b8a992 #8e7f6d #6b5e4f #4a4038 #2e2822 #1a1611`

---

## Dark Mode Conversion Rules

When converting a light palette to dark mode:

1. **Surface**: Invert — light backgrounds become dark (use 900-950 values)
2. **Text**: Invert — dark text becomes light (use 50-100 values)
3. **Primary**: Keep hue, increase lightness by 10-15% for visibility
4. **Accent**: Keep hue, increase lightness slightly
5. **Borders**: Use rgba(255,255,255,0.1) instead of gray values
6. **Shadows**: Use larger blur + lower opacity, or glow effects instead
7. **Contrast**: Re-verify all text meets 4.5:1 against dark surfaces

```css
@media (prefers-color-scheme: dark) {
  :root {
    --color-surface: var(--color-surface-dark);
    --color-text: #f1f5f9;
    --color-text-muted: #94a3b8;
    --color-border: rgba(255, 255, 255, 0.1);
  }
}
```
