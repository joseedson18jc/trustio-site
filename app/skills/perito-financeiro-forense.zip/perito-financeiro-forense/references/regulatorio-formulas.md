<!-- pff-version: 21.0 -->
# Contexto, Marco Regulatório, Fórmulas e Etapas 3–7

> **Código:** todas as funções citadas aqui estão em `scripts/pericia.py` (fonte única, auto-testada com
> `python3 scripts/pericia.py --selftest`). Cite no laudo o nome da função e os insumos — é o que torna o
> número reproduzível. Não reescreva as fórmulas em código novo durante a perícia.

**Sumário:** §2 Contexto · §2.1 Módulos por produto · §4.3.1 HC-01–38 · §4.5 Regime temporal e art. 406 · §5 Marco regulatório (5.1–5.6) · Etapa 3 Modelo · Etapa 4 Inferência e CET · Etapa 5-T Testes · Etapa 5 Checagem (45 itens) · Etapa 6 Comparação · Etapa 7 Consolidação · Anexos A–B

## § 2. CONTEXTO DO CASO

O arquivo anexado contém histórico financeiro completo (transações) de uma conta/dívida de pessoa física. Podem existir múltiplas fases: dívida original, negociações, renegociações, novações, consolidações e refinanciamentos sucessivos.

**Suspeitas recorrentes a investigar:**

1. Pagamentos alocados integralmente em juros/encargos sem amortizar o principal.
2. Taxa efetiva aplicada divergente da taxa contratada (alteração unilateral — vedada por boa-fé contratual, Art. 422 CC). Se taxa não comprovável: Súmula 530/STJ → taxa média BACEN.
3. Capitalização composta de juros (anatocismo) sem previsão contratual ou legal (Súmulas 539 e 541/STJ).
4. Renegociações que "reabrem" saldos ignorando amortizações já realizadas.
5. Cobrança cumulativa de comissão de permanência + multa + juros moratórios (vedada — Súmula 472/STJ; v. também Súmula 30/STJ para correção monetária).
6. IOF recalculado ou embutido sem discriminação em renegociações.
7. Tarifas/seguros não contratados incorporados ao saldo (venda casada — Art. 39, I, CDC).
8. Amortização negativa não declarada (pagamento < juros → principal cresce).
9. Carência não respeitada (cobrança de amortização durante período de graça).
10. Correção monetária aplicada sobre base incorreta ou com indexador divergente do contratado.
11. Liquidação antecipada sem desconto proporcional de juros futuros (Art. 52, §2º, CDC).
12. Novação que incorpora encargos indevidos ao novo principal (juros sobre juros na transição).
13. Alteração retroativa de taxas sem aditivo contratual.
14. Pagamento parcial alocado de forma prejudicial ao devedor (violação do art. 354 CC).
15. Descumprimento das regras de prevenção ao superendividamento (Lei 14.181/2021).

> **IMPORTANTE — Produtos múltiplos:** Se o extrato contiver movimentações de mais de um produto, segregue os produtos ANTES de iniciar a análise.

> **IMPORTANTE — Novação vs. Renegociação:** Novação (Arts. 360–367, CC) extingue a obrigação anterior. Renegociação altera condições da mesma obrigação. IOF: novação = fato gerador autônomo (integral); renegociação = complementar.

> **IMPORTANTE — Data de contrato vs. Data de desembolso:** A contagem de juros parte da data de desembolso, não da assinatura.

### 2.1 Módulos por Produto — Regras Específicas

**CARTÃO DE CRÉDITO (rotativo + parcelamento de fatura):**
- Rotativo incide sobre saldo NÃO PAGO. Desde 2017 (Res. CMN 4.549), limitado a 30 dias — banco DEVE oferecer parcelamento.
- **Teto de 100%** (Lei 14.690/2023 art. 28; Res. CMN 5.112/2023, que *alterou* a 4.549): para operações iniciadas a partir de 03/01/2024, juros + encargos financeiros (art. 2º-A, III da Res. CMN 4.549/2017, incl. pela Res. 5.112/2023: "encargos financeiros" = multa e juros de mora) não podem exceder o valor original da dívida — **IOF e tarifas ficam fora** da definição; em migração rotativo → parcelamento, o valor original é apurado desde o início do rotativo (art. 2º-A). Renegociação assegurada a qualquer momento (art. 2º-C). Teste §5-T1.
- Na migração rotativo → parcelamento: verificar anatocismo na transição (`HC-07`, `HC-17`).
- IOF do cartão: 0,38% flat + 0,0082%/dia. Verificar duplicação ao migrar.
- Pagamento mínimo: verificar se juros incidem sobre valor total da fatura (vedado após REsp 1.333.481/SP).

**CHEQUE ESPECIAL:**
- Juros diários sobre saldo utilizado. Desde jan/2020 (Res. CMN 4.765/2019): teto 8% a.m.
- IOF: 0,38% flat + 0,0082%/dia sobre saldo utilizado, cobrado mensalmente.
- Tarifa sobre o limite: só admitida sobre a parcela do limite que exceder R$ 500, no máximo 0,25% a.m. (Res. CMN 4.765/2019). Limite ≤ R$ 500: sem tarifa.
- Saldo negativo > 30 dias: banco deve comunicar e oferecer alternativas.

**CRÉDITO CONSIGNADO (série temporal da margem — aplicar a vigente na data de cada contratação; `pericia.margem_vigente`):**
- Lei 13.172/2015: 30% empréstimo + 5% cartão = **35%**.
- Lei 14.431/2022: 35% empréstimo + 5% cartão = **40%** — é também a base do **CLT** (Lei 10.820/2003, art. 1º §1º).
- Lei 14.601/2023: INSS 35% + 5% (cartão consignado — RMC) + 5% (cartão benefício — RCC) = **45%** `[conferir a data de vigência exata no inteiro teor]`.
- **MP 1.355/2026** (eficácia de 04/05/2026 a 31/08/2026): teto global de 40% para INSS/servidores (distribuição 30% + 5% + 5% segundo fonte secundária) e cronograma de extinção do RMC/RCC. **Perdeu a eficácia em 31/08/2026 sem conversão em lei** (Congresso: "sem eficácia / tramitação encerrada"; atos publicados no DOU de 08/09/2026). Contratos firmados **na janela** seguem regidos por ela enquanto não editado decreto legislativo (CF art. 62 §11 — prazo até 30/10/2026; revalidar). Fora da janela: 45% INSS (Lei 14.601/2023). **O cronograma 2027–2029 não existe juridicamente.**
- **Crédito do Trabalhador (Lei 15.179/2025, conversão da MP 1.292/2025):** operacionaliza o consignado CLT via plataformas digitais; a margem é **40% (35% empréstimo + 5% cartão)** — os 35% são o sublimite de empréstimo, não o total.
- **TCU — Acórdão 1.094/2026-Plenário (29/04/2026):** suspensão cautelar de **novas averbações de cartão consignado (RMC/RCC)** no INSS até a implantação de controles no eConsignado (o empréstimo consignado foi liberado em ~08/05/2026; os cartões seguiam bloqueados em out/2026). Averbação de RMC/RCC **posterior a 29/04/2026** é anomalia a investigar (Etapa 5, item 45).
- Parâmetros: `MARG_CONSIGN` (40%), `MARG_CONSIGN_INSS` (45%), `MARG_RMC_INSS` (5% + 5% RCC). Declarar a base e a data-base usadas.
- Verificar teto INSS (se aplicável). Em demissão: verificar renegociação (Lei 10.820/2003).

**FINANCIAMENTO DE VEÍCULO (alienação fiduciária):**
- Sistema comum: Price ou SAC, pré-fixado. CET inclui juros + IOF + tarifas + seguro + registro.
- Busca e apreensão: verificar notificação prévia e purgação da mora (DL 911/1969).

---

## § 4.3.1 Classificação de Hipóteses Causais (HC-01 a HC-38)

> **Estabilidade de códigos (desde v19.0):** HC-01 a HC-27 mantêm o significado publicado na
> v18.0 — não renumerar, sob pena de invalidar laudos já entregues. As hipóteses trazidas
> da v17 (não publicada) foram reassentadas em **HC-28 a HC-38** para eliminar a colisão
> de códigos entre as duas linhagens (a v17 usava HC-25/26/27 com outro significado).
> Ao ler laudos anteriores a jul/2026, confira a versão da skill no cabeçalho.

| Código | Hipótese | Exemplo | Referência normativa |
|---|---|---|---|
| `HC-01` | Taxa efetiva divergente da contratada | Contrato: 2,5% a.m.; aplicado: 3,1% a.m. | Art. 422 CC; Súmula 530/STJ |
| `HC-02` | Anatocismo irregular | Juros compostos sem previsão contratual (pré-2000) | Súmulas 539 e 541/STJ |
| `HC-03` | Alocação predatória de pagamento | 100% em juros, 0% em amortização por N_CONSECUTIVO+ períodos | Arts. 352–354 CC |
| `HC-04` | Encargos moratórios cumulativos | Comissão permanência + multa + juros mora | Súmula 472/STJ |
| `HC-05` | IOF irregular em transição | IOF integral em renegociação (deveria ser complementar) | Decreto 6.306/2007 |
| `HC-06` | Tarifa/seguro não contratado | Seguro prestamista sem opt-in documentado | Art. 39, I, CDC |
| `HC-07` | Saldo de transição inflado | Novação incorpora encargos indevidos ao novo principal | Arts. 360–367 CC |
| `HC-08` | Amortização negativa oculta | Parcela < juros sem aviso; principal crescente | Art. 6º, III, CDC |
| `HC-09` | Liquidação sem desconto | Art. 52 §2º CDC não aplicado | Art. 52 §2º CDC |
| `HC-10` | Correção monetária irregular | Indexador divergente ou base incorreta; pós-30/08/2024, índice legal supletivo = IPCA | Contrato; Art. 389, §ú, CC |
| `HC-11` | Carência violada | Amortização cobrada durante período de graça | Contrato |
| `HC-12` | Spread aplicado incorretamente | Multiplicativo vs. aditivo divergente do contrato | Contrato |
| `HC-13` | Arredondamento sistemático desfavorável | Arredondamento consistente contra o devedor (> TOL_SALDO acumulado) | NBC TP 01 |
| `HC-14` | Capitalização na carência sem previsão | Juros capitalizados durante carência sem cláusula expressa | Súmula 539/STJ |
| `HC-15` | Multa/cláusula penal excessiva | Multa > 2% ou desproporcional | Art. 52 §1º CDC; Art. 413 CC |
| `HC-16` | IOF calculado incorretamente | Alíquota, base ou período divergentes | Decreto 6.306/2007 |
| `HC-17` | Rotativo → parcelamento irregular / teto de 100% | Migração após 30 dias não oferecida, saldo inflado, ou juros+encargos > principal (origem ≥ 03/01/2024) | Res. CMN 4.549/2017; Lei 14.690/2023; Res. CMN 5.112/2023 |
| `HC-18` | Margem consignável excedida | Soma das parcelas > limite vigente na data da contratação (35% → 40% → 45% INSS → 40% na janela da MP 1.355/2026; CLT 40% = 35+5) — `pericia.verificar_margem` | Leis 10.820/2003, 13.172/2015, 14.431/2022, 14.601/2023, 15.179/2025; MP 1.355/2026 (só a janela 04/05–31/08/2026) |
| `HC-19` | Cheque especial acima do teto | Taxa efetiva > 8% a.m. | Res. CMN 4.765/2019 |
| `HC-20` | Portabilidade com spread abusivo | Spread superior ao contratado, ou recusa injustificada | Res. CMN 5.057/2022 |
| `HC-21` | Superendividamento — renda mínima comprometida | Comprometimento excessivo sem oferta de renegociação global | Lei 14.181/2021; Art. 104-A CDC; Lei 15.252/2025 |
| `HC-22` | Tarifa de avaliação duplicada | Cobrada novamente em refinanciamento do mesmo bem | Res. CMN 4.949/2021 |
| `HC-23` | Venda casada de título de capitalização | Capitalização vinculada ao crédito sem opt-out claro | Art. 39, I, CDC; Circ. SUSEP 620/2020 |
| `HC-24` | Amortização extraordinária sem desconto proporcional | Amortização parcial sem redução de juros futuros | Art. 52 §2º CDC (interpretação extensiva) |
| `HC-25` | Extinção de contrato sem lastro documentado | Contrato some do painel de crédito sem liquidação/novação demonstrada; saldo sucessor não auditável | Arts. 360–367 CC; NBC TP 01 |
| `HC-26` | Rolagem em cadeia de renegociações | Nova renegociação < 90 dias após a anterior, recorrente, com saldo crescente | Lei 14.181/2021; Art. 104-A CDC |
| `HC-27` | Mora acruada sem decomposição | Saldo cresce em atraso sem discriminar juros/multa/mora | Art. 52 §1º CDC; Súmula 379/STJ |
| `HC-28` | Consulta/inscrição indevida SCR/Serasa | Inclusão sem dívida comprovada ou sem notificação prévia | LGPD; Art. 43 CDC; Súmula 550/STJ; Tema 710/STJ; REsp 1.378.380 |
| `HC-29` | Cartão consignado (RMC/RCC) — dívida perpétua / contratação viciada | Desconto mínimo insuficiente para amortizar; saldo não decresce; averbação após a suspensão do TCU | Tema 1.414/STJ `[TESE_PENDENTE]` (absorveu o REsp 2.145.244/SC do Tema 1.328, cancelado em 02/10/2026); Arts. 6º III, 39 e 51 CDC; Acórdão TCU 1.094/2026-Plenário |
| `HC-30` | Cessão a FIDC com taxa nova / sem notificação | Cessionário aplica taxa diferente da contratada com o cedente | Arts. 286–298 CC; EAREsp 1.125.139/PR |
| `HC-31` | Pix parcelado com CET opaco | CET não informado ou lançamento sem discriminação em fatura | Arts. 6º, III e 52 CDC |
| `HC-32` | Antecipação FGTS saque-aniversário sem adesão | Banco não comprova adesão pelo app FGTS | Súmula 479/STJ; Res. CCFGTS 1.130/2025 |
| `HC-33` | IOF complementar indevido em renegociação | IOF reincide em mera prorrogação sem nova operação/liberação | Decreto 6.306/2007 art. 7º §1º; TNU Tema 352 |
| `HC-34` | Capitalização de tarifas | Tarifa incorporada ao principal e gerando juros | Súmula 539/STJ; Art. 51, IV, CDC; Res. CMN 4.949/2021 |
| `HC-35` | Migração unilateral cheque especial → empréstimo | Saldo migrado sem manifestação inequívoca do consumidor | Res. CMN 4.765/2019; Arts. 6º, III e 51, X, CDC |
| `HC-36` | Dívida prescrita em cobrança / Serasa Limpa Nome | Manutenção em plataforma ou cobrança extrajudicial de dívida prescrita | Tema 1.264/STJ `[TESE_PENDENTE]`; Arts. 189 e 882 CC |
| `HC-37` | Mínimo existencial violado (Tema 1.085 mitigado) | Renda − todas as parcelas (**inclusive consignado**) < R$ 600 (Dec. 11.567/2023) ou < mínimo provado no caso | Art. 54-A §1º CDC; Decreto 11.150/2022 c/ Dec. 11.567/2023; STF ADPFs 1.005/1.006/1.097 (2026) |
| `HC-38` | Abusividade de juros — análise além da taxa média | Comparação isolada com a taxa média BACEN pode não bastar; documentar fatores do caso (risco, prazo, garantias, perfil) | Tema 1.378/STJ `[TESE_PENDENTE]` (sem tese fixada); REsp 2.152.686/RS `[não reconferido]` |
| `HC-99` | Outra / Não determinada | Descrever | — |

**Uso obrigatório:** todo achado registrado sob §4.3 item 6 (hipótese causal) e item 10
(referência normativa) deve citar o código HC e a referência desta tabela. Achados marcados
`[TESE_PENDENTE]` exigem a ressalva de §5 (Nota 5) no relatório.

---

## § 4.5 Regime Temporal: Competência vs. Caixa

Quando a data de vencimento difere da data de pagamento:

1. Calcule juros remuneratórios pela competência (até a data de vencimento).
2. Calcule mora a partir do dia seguinte ao vencimento até a data do pagamento efetivo (Art. 394 CC — *dies a quo non computatur, dies ad quem computatur*).
3. `dias_mora = data_pagamento − data_vencimento`. Para 30/360: `pericia.dias_30_360` (360×Δano + 30×Δmês + Δdia, com ajuste de dia 31). Para actual/365: dias corridos do calendário. Usar mesma convenção dos juros remuneratórios.
4. Multa moratória: evento único de `MULTA_PCT`% (default 2%, Art. 52 §1º CDC) sobre a prestação vencida. Se excessiva: Art. 413 CC.
5. Juros moratórios: **simples**, pro rata, sobre a **prestação vencida** (não sobre o saldo total). Limite: `JMORA_MAX`% a.m. (Súmula 379/STJ). Implementação: `pericia.juros_mora_contratual`.

```
30/360:      J_mora = Prestação_Vencida × (JMORA_MAX/100) × (dias_mora / 30)
actual/365:  J_mora = Prestação_Vencida × (JMORA_MAX/100) × 12 × (dias_mora / 365)
```

**Por que simples:** juros de mora remuneram o atraso e não se capitalizam — capitalizá-los é anatocismo
(HC-02/HC-27). A forma exponencial `[(1 + i)^(meses) − 1]` só entra como **cenário de sensibilidade** se o
contrato previr expressamente a capitalização da mora, e nesse caso a própria cláusula é um achado. Diferença
exponencial × simples a 1% a.m.: 30 dias −0,0001 p.p.; 90 dias +0,03 p.p. (+1,0%); 180 dias +0,15 p.p. (+2,5%);
365 dias +0,68 p.p. (+5,7%) — material em atrasos longos.

> **Correção v21:** até a v20 a skill chamava a fórmula exponencial de "exata", a linear de "aproximação" e mandava
> usar a exponencial acima de 90 dias. Era o inverso: o padrão jurídico é o simples.

**REGIME TEMPORAL DOS JUROS LEGAIS (quando o contrato NÃO estipula mora):**

| Período de mora | Juros moratórios legais | Correção monetária | Fonte |
|---|---|---|---|
| até 29/08/2024 | Selic **integral** (art. 406 CC, redação original) — já embute correção; **não cumular** | nenhuma separada (*bis in idem*) | Tema 1.368/STJ (out/2025); REsp 1.081.149/RS |
| a partir de 30/08/2024 | **Taxa legal = Selic − IPCA-15**, juros simples, piso zero (art. 406 §§1º–3º CC) | **IPCA**, em separado (art. 389, §ú, CC) | Lei 14.905/2024; Res. CMN 5.171/2024 |

Mora que atravessa 30/08/2024: **segmentar** o cálculo nos dois regimes. Em contratos de
consumo, a Súmula 379/STJ (1% a.m.) continua como teto quando há pactuação; a taxa legal
aplica-se apenas na ausência de estipulação. A tabela mensal da Taxa Legal é divulgada pelo
BCB (SGS **29543**, conferido em 10/10/2026; Calculadora do Cidadão) — registrar a fonte e a data de consulta no laudo.
Cálculo segmentado: `pericia.mora_legal_art406(valor, d_ini, d_fim, selic, taxa_legal, ipca)` com séries de
`scripts/bcb_sgs.py` (4390 Selic mensal, 29543 Taxa Legal, 433 IPCA). Sem as séries, não estimar: pedir ou declarar `[PREMISSA]`.


### 4.6 Pagamento Parcial (devedor não inadimplente)

1. Aplique o waterfall sobre o valor pago.
2. Registre saldo remanescente como "parcela parcialmente liquidada".
3. Juros do próximo período incidem sobre o saldo devedor efetivo.
4. Se pagamento parcial < juros do período: registre como amortização negativa (flag `AMORT_NEG`).

### 4.9 Tratamento de Extrato Parcial

1. Identifique o gap: data do contrato vs. primeira linha do extrato.
2. Use o primeiro saldo do extrato como S₀. NÃO reconstrua período anterior.
3. Declare que irregularidades anteriores NÃO podem ser detectadas.
4. Infira taxa usando APENAS dados do período coberto.
5. Impacto total reportado é SUBESTIMADO.
6. Solicite demonstrativo completo ao banco.

---

## § 5. MARCO REGULATÓRIO DE REFERÊNCIA (BRASIL)

**Última revalidação desta tabela: 10/10/2026** (v21.0, fontes oficiais STJ/Planalto/Congresso/BCB/STF/TCU — ver §5.6; anteriores: 06–08/09/2026, 26/07/2026). Ver Nota 6.

### 5.1 Súmulas

| Referência | Descrição / Aplicação |
|---|---|
| Súmula 30/STJ | Comissão de permanência e correção monetária são inacumuláveis. |
| Súmula 297/STJ | CDC é aplicável às instituições financeiras. |
| Súmula 379/STJ | Juros moratórios até 1% a.m. em contratos sem legislação específica. |
| Súmula 472/STJ | Comissão de permanência exclui juros remun., moratórios e multa. |
| Súmula 479/STJ | IFs respondem objetivamente por fraudes de terceiros. |
| Súmula 530/STJ | Taxa não comprovável → taxa média BACEN da mesma espécie. |
| Súmula 539/STJ | Capitalização < anual permitida em contratos pós-31/03/2000 se pactuada. |
| Súmula 541/STJ | Taxa anual > 12× mensal = capitalização implicitamente pactuada. |
| Súmula 550/STJ | Score de crédito é lícito se observadas as condições legais (cf. LC 166/2019). |
| Súmula 566/STJ | Tarifa de cadastro lícita no início do relacionamento (pós-30/04/2008). |
| Súmula 596/STF | Lei de Usura NÃO se aplica a juros remuneratórios de IFs. |

### 5.2 CDC e Código Civil

| Referência | Descrição / Aplicação |
|---|---|
| Art. 6º, III, CDC | Direito à informação adequada e clara. |
| Art. 6º, VIII, CDC | Inversão do ônus da prova a favor do consumidor. |
| Art. 39, I, CDC | Vedação de venda casada. |
| Art. 43, CDC | Cadastros de consumidores — acesso, correção e notificação prévia. |
| Art. 51, IV, CDC | Cláusulas que colocam o consumidor em desvantagem exagerada são abusivas. |
| Art. 51, X, CDC | Vedação de variação unilateral de preço/condições pelo fornecedor. |
| Art. 52, §1º, CDC | Multa moratória ≤ 2% sobre a prestação vencida. |
| Art. 52, §2º, CDC | Liquidação antecipada: redução proporcional de juros. |
| Arts. 54-A a 54-G, CDC | Superendividamento (incluídos pela Lei 14.181/2021). |
| Art. 104-A, CDC | Direito à renegociação global (Lei 14.181/2021). |
| Arts. 189 e 882, CC | Prescrição — pretensão e pagamento de dívida prescrita. |
| Art. 206, §5º, I, CC | Prescrição: 5 anos para dívidas líquidas. **NOTA:** para encargos sucessivos (tarifas, juros mensais, lançamentos de favor), cada lançamento indevido é fato gerador autônomo, iniciando nova contagem de 5 anos. |
| Arts. 286–298, CC | Cessão de crédito (incl. notificação do devedor). |
| Arts. 352–354, CC | Imputação do pagamento (juros vencidos antes do capital). |
| Arts. 360–367, CC | Novação. |
| Art. 389, §ú, CC | Correção monetária supletiva = IPCA (redação da Lei 14.905/2024, vigência 30/08/2024). |
| Art. 394, CC | Mora do devedor. |
| Art. 406, CC | Juros legais: até 29/08/2024 = Selic integral (Tema 1.368/STJ); desde 30/08/2024 = **taxa legal = Selic − IPCA-15**, juros simples, piso zero (Lei 14.905/2024; Res. CMN 5.171/2024). Ver §4.5. |
| Art. 413, CC | Redução judicial de cláusula penal excessiva. |
| Art. 422, CC | Boa-fé objetiva. |

### 5.3 Legislação, decretos e regulamentação

| Referência | Descrição / Aplicação |
|---|---|
| DL 911/1969 | Alienação fiduciária — busca e apreensão. |
| Lei 10.820/2003 | Consignação em folha. |
| Lei 13.172/2015 | Margem consignável 35% (30% empréstimo + 5% cartão). |
| Lei 13.709/2018 (LGPD) | Proteção de dados pessoais — tratamento em cadastros e SCR. |
| Lei 14.181/2021 | Superendividamento. |
| Lei 14.431/2022 | Margem consignável 40% (35% + 5%) — inclusive CLT (Lei 10.820 art. 1º §1º). |
| Lei 14.601/2023 | INSS: 45% (35% + 5% cartão consignado + 5% cartão benefício). |
| Lei 14.690/2023 | Programa Desenrola + teto de 100% do principal no rotativo. |
| Lei 14.905/2024 | IPCA como correção supletiva (art. 389) e taxa legal Selic − IPCA (art. 406); vigência 30/08/2024. |
| Lei 15.179/2025 (24/07/2025) | Crédito do Trabalhador — conversão da MP 1.292/2025; consignado CLT por plataformas digitais. Margem CLT = 40% (35% empréstimo + 5% cartão), redação da Lei 14.431/2022. |
| Lei 15.252/2025 (04/11/2025) | Direitos da pessoa natural usuária de serviços financeiros (portabilidade de salário, crédito com taxa reduzida, débito direto, informação). Regulamentada pela Res. CMN 5.299/2026 e Res. BCB 564/2026 — **vigência 01/07/2027**. |
| MP 1.355/2026 | Novo Desenrola + extinção gradual do RMC/RCC + teto global 40% (INSS/servidores). **Sem eficácia desde 01/09/2026** (perdeu a eficácia em 31/08/2026, sem PLV nem lei de conversão — Congresso Nacional, consulta 10/10/2026). Janela de eficácia 04/05–31/08/2026: relações nela constituídas seguem regidas pela MP salvo decreto legislativo (CF art. 62 §11; prazo até 30/10/2026). Fora da janela: Lei 14.601/2023 (INSS 45%). PL 3.256/2026 sobre cartão consignado tramita na Câmara `[fonte secundária]`. |
| MP 1.373/2026 (29/06/2026) | Desenrola Adimplentes (informais; dívidas até R$ 15 mil; garantia FGO) + Res. CMN 5.326/2026 e 5.333/2026. **MP pendente** (prorrogada) — revalidar antes de citar `[fonte secundária]`. |
| Decreto 6.306/2007 | IOF sobre crédito PF: 0,0082% a.d. (teto 365 dias = 2,993%) + adicional 0,38%. Novação: integral. Renegociação sem nova liberação: complementar (art. 7º §1º). Os aumentos de 2025 (Decretos 12.466 e 12.499/2025) atingiram PJ `[conferir se o caso envolver PJ]`. |
| Decreto 11.150/2022 c/ Decreto 11.567/2023 | Mínimo existencial no superendividamento = **R$ 600,00** (valor nominal; revisão anual pelo CMN determinada pelo STF). **Exclusão do consignado do cômputo declarada inconstitucional** (STF ADPFs 1.005/1.006/1.097, abr/2026). |
| Decreto 12.564/2025 (24/07/2025) | Regulamenta o art. 2º-I da Lei 10.820: identificação biométrica com prova de vida, consentimento LGPD e assinatura eletrônica qualificada/avançada no consignado contratado em meio digital. Ausência → indício de contratação não reconhecida. |
| Res. CMN 4.881/2020 | CET — cálculo (art. 4º: dias/365, base anual) e informação prévia; revogou Res. CMN 3.517/2007, 3.909/2010 e 4.197/2013 (vigência 01/02/2021). |
| Res. CMN 4.549/2017 | Rotativo de cartão limitado a 30 dias. |
| Res. CMN 4.765/2019 | Teto cheque especial PF: 8% a.m.; tarifa sobre limite só acima de R$ 500. |
| Res. CMN 4.949/2021 | Tarifas bancárias PF — serviços essenciais e limites (revogou a Res. CMN 3.919/2010). |
| Res. CMN 5.004/2022 (24/03/2022; vigência 02/05/2022) | Contratação de crédito: instrumento com taxas, tributos, tarifas, CET e encargos de atraso (art. 3º); liquidação antecipada pelo VP à **taxa pactuada** (art. 7º); vedada cobrança/averbação sem instrumento formal (art. 8º); despesas financiadas à mesma taxa do principal (art. 9º). Revogou o art. 2º da Res. 3.516/2007. Conferido no BCB em 10/10/2026. |
| Res. CMN 5.057/2022 | Portabilidade de crédito PF (revogou Res. CMN 4.292/2013). |
| Res. CMN 5.112/2023 (21/12/2023) | Regulamenta o teto de 100% do rotativo e do parcelamento de fatura (Lei 14.690/2023 art. 28) **alterando** a Res. CMN 4.549/2017: arts. 2º-A (conceitos; valor original desde o início do rotativo migrado), 2º-B (detalhamento em fatura), 2º-C (renegociação assegurada). Art. 2º-A, III define **encargos financeiros = multa e juros de mora** (definição fechada: IOF e tarifas não entram no teto); art. 2º-D: aplica-se às operações realizadas após 90 dias da publicação da Lei 14.690 (03/10/2023) — marco usual 03/01/2024; arts. 2º-A a 2º-D vigentes desde 01/07/2024 (art. 5º, II). Texto conferido no BCB em 10/10/2026. |
| Res. CMN 5.171/2024 (29/08/2024) | Metodologia da taxa legal do art. 406 CC: fator Selic do mês anterior ÷ fator IPCA-15, juros simples, piso zero; divulgada pelo BCB (SGS 29543). |
| Res. CMN 5.299/2026 e Res. BCB 564/2026 (04/05/2026) | Regulamentam a Lei 15.252/2025; crédito com taxa reduzida com parcela ≤ 35% da renda bruta (consignado incluído), checagem de mínimo existencial e SCR. **Vigência 01/07/2027** — não aplicar a fatos anteriores `[fonte secundária]`. |
| Res. BCB 468/2025 (30/04/2025; vigência 01/07/2025) | Cálculo mensal e envio ao BCB dos juros e encargos acumulados no **rotativo e no parcelamento de fatura** — monitoramento do teto de 100%. Útil para requisitar ao banco o acumulado por dívida `[fonte secundária]`. |
| Res. BCB 516/2025 (29/10/2025) | SCR: implantação escalonada do envio **diário** (Res. BCB 413/2024): dados gerais desde 01/11/2025; rotativo, cessões, aquisições, assunção e portabilidade desde 01/05/2026. |
| Res. CCFGTS 1.130/2025 (07/10/2025) | Antecipação do saque-aniversário: carência de 90 dias após a adesão; até 3 saques anuais (5 transitoriamente até 31/10/2026); R$ 100 a R$ 500 por saque; 1 contrato por ciclo `[fonte secundária]`. |
| Circ. SUSEP 620/2020 | Títulos de capitalização — vedação de vinculação a crédito sem opt-out. |

### 5.4 Temas repetitivos STJ (situação em 10/10/2026 — página oficial de precedentes do STJ)

| Tema | Objeto | Situação | HC vinculado |
|---|---|---|---|
| Tema 27 | Comissão de permanência | Tese fixada | HC-04 |
| Tema 246 | Capitalização em contratos bancários | Tese fixada | HC-02, HC-14 |
| Tema 710 | Score de crédito | Tese fixada | HC-28 |
| Tema 1.085 | Desconto em conta corrente | Tese fixada — relativizada pelo mínimo existencial (STF ADPFs 1.005/1.006/1.097) | HC-37 |
| Tema 1.264 | Dívida prescrita / plataformas de renegociação | `[TESE_PENDENTE]` — "em julgamento" (rel. Min. João Otávio de Noronha; sustentações em 10/06/2026, julgamento suspenso); suspensão nacional ampla (1º e 2º graus) | HC-36 |
| Tema 1.268 | Coisa julgada × juros sobre tarifa já declarada ilegal | **Tese fixada (10/09/2025; trânsito 20/10/2025) — DESFAVORÁVEL ao consumidor:** a coisa julgada **impede** nova ação para reaver juros remuneratórios incidentes sobre tarifas declaradas ilegais em ação anterior | HC-34 (limitador) |
| Tema 1.328 | Dano moral *in re ipsa* em RMC | **CANCELADO (02/10/2026).** O REsp 2.145.244/SC foi incluído no Tema 1.414. Não citar como pendente | HC-29 |
| Tema 1.368 | Juros legais do art. 406 CC **antes** da Lei 14.905/2024 | **Tese fixada (Corte Especial, 15/10/2025; trânsito 12/11/2025): Selic** | mora pré-30/08/2024 (§4.5) |
| Tema 1.378 | Taxa média do BCB basta para aferir abusividade? | `[TESE_PENDENTE]` — afetado (sessão 27/08–02/09/2025; rel. Min. Antonio Carlos Ferreira); instrução concentrada no REsp 2.227.280/PR; **sem tese**. A expressão "critério multifatorial" é caracterização doutrinária, não texto do tema | HC-38 |
| Tema 1.414 | Cartão consignado (RMC/RCC) — decadência, validade/abusividade e consequências | `[TESE_PENDENTE]` — afetado (sessão 18–24/02/2026; rel. Min. Raul Araújo); suspensão nacional referendada em 08/04/2026; **questão ampliada em 02/10/2026**: (I) decadência de 4 anos do art. 178 CC × inexistência de prazo por nulidade (art. 169); (II) parâmetros objetivos de validade/abusividade (dever de informar; dívida que não amortiza sob juros rotativos); (III) consequências (retorno ao estado anterior, conversão em empréstimo consignado ou revisão) e dano moral *in re ipsa* | HC-29 |

> **Não confundir:** o **Tema 1.325/STJ não trata de RMC** — versa sobre a reiteração automática de bloqueios via Sisbajud
> ("teimosinha") em execução fiscal (julgado em 07/05/2026; trânsito em 02/07/2026). Versões ≤ v20 da skill o citavam
> por engano em HC-29; algumas fontes secundárias repetem o erro.

**Tema 1.414 — nota operacional:** a controvérsia abrange expressamente o prolongamento indeterminado
da dívida quando os descontos mensais não a amortizam frente aos juros rotativos. O teste de dívida perpétua
(§5-T2) é, portanto, prova direta sobre o ponto afetado. Desde 02/10/2026 o tema também discute a
**decadência** (art. 178 CC, 4 anos): para cada RMC/RCC, registre a data da contratação e marque
`[RISCO DE DECADÊNCIA — Tema 1.414, item I]` quando houver mais de 4 anos até o ajuizamento. A suspensão
atinge o processamento de mérito e recursos, **mas não impede o ajuizamento de novas ações** (útil para
fixar a data da propositura) nem tutelas de urgência quando há risco à subsistência.

### 5.5 REsps, STF e demais precedentes

| Referência | Aplicação |
|---|---|
| STF ADPFs 1.005/1.006/1.097 (julg. 22–23/04/2026, rel. Min. André Mendonça) | **Unânime:** R$ 600 mantido; decretos válidos; CMN deve reavaliar o valor **anualmente**, com estudos técnicos e decisão pública. **Por 6×4:** inconstitucional excluir parcelas e limites de **consignado** do cômputo do mínimo existencial. Nenhum novo valor fixado até 10/10/2026. Base para HC-37 e Cenário K. |
| REsp 1.061.530/RS | Temas 25–28: capitalização, comissão de permanência, tarifas. |
| REsp 1.081.149/RS | Selic como mora NÃO se cumula com correção monetária (*bis in idem*) — regime até 29/08/2024. |
| REsp 2.194.074/SC (4ª T., 24/03/2025) | Confirma taxa legal = Selic deduzido o IPCA para mora pós-Lei 14.905/2024. |
| REsp 1.333.481/SP | Mínimo do cartão: juros incidentes sobre saldo não pago. |
| REsp 1.378.380 | Inscrição indevida em cadastro restritivo — dano moral. |
| REsp 2.086.650/MG | SFI ≠ SFN: capitalização sub-anual vedada no SFI. |
| REsp 2.152.686/RS | Abusividade de juros exige análise multifatorial. |
| EAREsp 1.125.139/PR | Cessão de crédito — citação válida como notificação. |
| TNU Tema 352 | IOF em prorrogação sem nova operação. |
| Acórdão TCU 1.094/2026-Plenário (29/04/2026; TC 003.276/2026-0) | Cautelar: suspensão de novas averbações de **cartão consignado** no INSS até controles no eConsignado. Relatório: 36% de não reconhecimento em amostra da CGU (911 beneficiários, 1.476 contratos). **Atenção:** os R$ 6,5 bi referem-se a descontos indevidos da "Operação Sem Desconto" (2019–2024), **não** a perdas com RMC — não atribuir ao cartão consignado. Contexto probatório para HC-29. |

### 5.6 Rastreabilidade da verificação (v21.0 — consulta em 10/10/2026)

| Grau | Referências | Como foram verificadas |
|---|---|---|
| **Fonte oficial consultada em 10/10/2026** | MP 1.355/2026 (Congresso: sem eficácia); Temas 1.264, 1.268, 1.325, 1.328, 1.368, 1.378, 1.414 (página de precedentes do STJ); STF ADPFs 1.005/1.006/1.097 (notícia oficial STF); Leis 15.179/2025 e 15.252/2025, Decreto 12.564/2025, Lei 10.820/2003 compilada (Planalto); Res. CMN 4.881/2020, 5.112/2023 (incl. art. 2º-A, III e 2º-D), 5.171/2024 (BCB); Acórdão TCU 1.094/2026 (íntegra); SGS 29543, 25463, 25464, 25470, 25477 (BCB) | Página oficial lida na data; status transcrito |
| **Fonte secundária (10/10/2026)** | Res. BCB 468/2025; Res. BCB 516/2025; Res. CCFGTS 1.130/2025; Res. CMN 5.299/2026; Res. BCB 564/2026; MP 1.373/2026; distribuição 30+5+5 na MP 1.355; PL 3.256/2026 | Portais jurídicos/normativos; conferir o DOU antes de citar em laudo |
| **Conhecimento estável (sem reconferência)** | Súmulas STJ/STF listadas; CDC e CC (exceto arts. 389/406); Leis 13.172/2015, 14.181/2021, 14.431/2022, 14.601/2023, 14.690/2023, 14.905/2024; Decreto 6.306/2007; Res. CMN 4.549/2017, 4.765/2019, 4.949/2021, 5.057/2022; Temas 27, 246, 710, 1.085 | Baixa volatilidade |
| **Herdadas, NÃO reconferidas** | REsp 1.333.481/SP, 2.086.650/MG, 2.152.686/RS, 2.194.074/SC; EAREsp 1.125.139/PR; TNU Tema 352; REsp 1.378.380 | Localizar o inteiro teor antes de citar |

**NOTAS IMPORTANTES:**
1. Juros moratórios limitados a 1% a.m. (Súmula 379/STJ), pro rata, quando pactuados.
2. **Juros legais são regime-dependentes** (§4.5): Selic integral sem correção até 29/08/2024; Selic − IPCA-15 **mais** IPCA em separado desde 30/08/2024. Nunca cumular Selic integral com IPCA em nenhum dos regimes.
3. Anatocismo irregular ≠ juros compostos. A questão é se juros vencidos não pagos são incorporados ao saldo sem previsão contratual.
4. Margens consignáveis são **série temporal** (§2.1; `pericia.margem_vigente`): 35% (2015) → 40% (2022; também CLT) → 45% INSS (2023) → 40% na janela da MP 1.355/2026 (04/05–31/08/2026) → 45% INSS desde 01/09/2026. Declarar a base e a data usadas.
5. **`[TESE_PENDENTE]`** = tema afetado com suspensão nacional vigente. Em todo achado que dependa de tese pendente, o laudo deve: (a) apresentar o cálculo de forma autônoma, que não dependa do desfecho; (b) registrar a ressalva expressa de que a tese não está fixada; (c) indicar o cenário alternativo caso a tese seja desfavorável.
6. **Protocolo de revalidação (obrigatório).** Normas de 2025–2026 e temas afetados mudam em semanas (entre 08/09 e 10/10/2026 o Tema 1.328 foi cancelado e o 1.414 ampliado). Antes de emitir laudo, reconferir na fonte oficial: (i) decreto legislativo sobre a MP 1.355/2026 (prazo até 30/10/2026) e a situação da MP 1.373/2026; (ii) Temas 1.264, 1.378 e 1.414 (e se surgiu tema novo sobre RMC/RCC); (iii) valor do mínimo existencial (revisão anual do CMN); (iv) suspensão do TCU sobre cartão consignado; (v) qualquer citação marcada `[fonte secundária]` que entre no laudo. Registrar **data da consulta e URL**. Se o site do STJ bloquear a leitura automática, use outra ferramenta de
   raspagem ou fontes institucionais (NUGEP/NUGE dos tribunais, decisões publicadas) e diga qual foi usada. Sem acesso à web, declarar `[STATUS NÃO REVALIDADO EM <data> — última verificação da skill: 10/10/2026]` — nunca afirmar vigência por inércia.

---

## ETAPA 3 — MODELO MATEMÁTICO (SALDO RECALCULADO)

### 3.1 Convenção Temporal

| Convenção | Base | Fórmula de dias | Uso |
|---|---|---|---|
| 30/360 (NASD/ISMA) | Meses=30d, ano=360 | `d = 360×(a₂−a₁) + 30×(m₂−m₁) + (d₂−d₁)` com ajuste de fim de mês (ver abaixo) | Padrão crédito PF Brasil |
| actual/365 | Dias reais, ano=365 | `d = (data₂ − data₁).days` | Alternativa; contratos imobiliários |
| DU/252 | Dias úteis ANBIMA, ano=252 | `d = Σ dias úteis entre t₁ e t₂` | CDI, renda fixa, operações pós-fixadas |

**Regra de ajuste 30/360 (NASD/ISMA) para fim de mês:** dia 31 inicial → 30; dia 31 final → 30 se o inicial ≥ 30.
Implementação: `pericia.dias_30_360(d1, d2)`.

Se contrato não especificar: execute cenários com 30/360 (default) e actual/365, reportar divergência se > `TOL_SALDO`.

### 3.2 Fórmulas-Base — Juros Compostos Pro-Rata

**Quando i_m é a taxa MENSAL (pré-fixada):**

Convenção 30/360:
```
J_t = S_{t−1} × [(1 + i_m)^(d/30) − 1]
```

Convenção actual/365 (via conversão anual):
```
i_a = (1 + i_m)^12 − 1
J_t = S_{t−1} × [(1 + i_a)^(d/365) − 1]
```

**Quando i_a é a taxa ANUAL (pré-fixada):**
```
J_t = S_{t−1} × [(1 + i_a)^(d/360) − 1]   [30/360]
J_t = S_{t−1} × [(1 + i_a)^(d/365) − 1]   [actual/365]
J_t = S_{t−1} × [(1 + i_a)^(du/252) − 1]  [DU/252]
```

**Conversão de taxas:**
```
i_m = (1 + i_a)^(1/12) − 1     [mensal ← anual]
i_a = (1 + i_m)^12 − 1         [anual ← mensal]
i_d360 = (1 + i_a)^(1/360) − 1
i_d365 = (1 + i_a)^(1/365) − 1
i_du = (1 + i_a)^(1/252) − 1
```

**TAXAS NOMINAIS vs. EFETIVAS:**
- Nominal proporcional: `i_m = X / 1200`. Efetiva anual: `(1 + X/1200)^12 − 1 > X/100`.
- Efetiva equivalente: `i_m = (1 + X/100)^(1/12) − 1`.

### 3.2.1 Juros Simples (cenário sem anatocismo — Cenário E)

```
J_t = Capital_{t−1} × i_m × (d/30)                    [30/360]
J_t = Capital_{t−1} × (12 × i_m) × (d/365)            [actual/365 — taxa PROPORCIONAL, não equivalente]
Juros vencidos e não pagos → conta separada, sem render juros; pagamento quita juros pendentes e depois capital (art. 354 CC)
```

`Capital` = principal remanescente **sem** juros incorporados (`pericia.recalcular_saldo(..., capitalizacao="simples")`).

**Atenção — fatos matemáticos que mudam a conclusão:**
1. Se cada parcela cobre os juros do período, **não há capitalização**: juros simples sobre o capital
   remanescente reproduzem exatamente o Price (auto-teste da biblioteca). "Price = anatocismo" não se sustenta
   matematicamente nesse caso; o anatocismo aparece quando juros **não pagos** passam a render juros
   (amortização negativa, mora, rolagem, novação que incorpora juros).
2. Para parcela fixa sem qualquer capitalização implícita, o cenário usado em revisionais é o **método de Gauss**:
   `PMT = P × (1 + i·n) / (n + i·n·(n−1)/2)` (`pericia.pmt_gauss`). Ex.: R$ 12.000, 2,49% a.m., 24× → Gauss
   R$ 620,98 × Price R$ 670,21. Apresente Gauss como **cenário** (tese), nunca como cálculo devido, salvo
   decisão judicial nesse sentido.
3. Juros simples sobre o **principal original** P₀ em todos os períodos (versões ≤ v20) estava errado: cobra juros
   sobre capital já amortizado e pode dar **mais** juros que o Price.

### 3.2.2 Taxas Pós-Fixadas

**CDI + Spread:**
```
Fator_CDI(t1,t2) = ∏_{k=t1+1}^{t2} (1 + CDI_k)
```

Spread MULTIPLICATIVO:
```
Fator_Total = Fator_CDI(t1,t2) × (1 + spread_a)^(du/252)
i_efetiva = Fator_Total − 1
J_t = S_{t−1} × i_efetiva
```
onde `spread_a` é a taxa anual de spread.

Spread ADITIVO: `i_efetiva = (Fator_CDI − 1) + ((1+spread_a)^(du/252) − 1)`

**CLARIFICAÇÃO:** Na forma multiplicativa, `spread_a` refere-se à taxa anual de spread. O termo `(1 + spread_a)^(du/252)` converte essa taxa anual para o período de `du` dias úteis.

**Selic + Spread:**
```
Fator_Selic(t1,t2) = ∏_{k=t1+1}^{t2} (1 + Selic_k)
```

**IMPORTANTE — "X% da Selic":** Quando o contrato refere "X% da Selic", a fórmula CORRETA é:
```
Fator = ∏_{k=t1+1}^{t2} (1 + (X/100) × Selic_k)
```

**NÃO usar** `Fator_Selic^(X/100)`.

Nota: `Selic_k` refere-se à taxa Selic DIÁRIA (série SGS 11 do Banco Central). Se você tem a taxa Selic anualizada, converta: `Selic_k_diária = (1 + Selic_k_anual)^(1/252) − 1`.

Exemplo passo-a-passo:
1. Obtenha a série SGS 11 (Selic diária) do Banco Central para cada dia do período.
2. Se contrato diz "75% da Selic", aplique: `Fator = ∏ (1 + 0,75 × Selic_k_diária)`
3. Juros efetivos: `J = Saldo × (Fator − 1)`

**IPCA + Spread:**
```
Fator_IPCA(t1,t2) = ∏_{meses} (1 + IPCA_mês/100)
```
Pro rata geométrico para mês incompleto. IPCA-15 como proxy intra-mês `[PREMISSA]`.

**TR + Spread:**
```
Fator_TR(t1,t2) = ∏_{meses} (1 + TR_mês/100)
```
Mês incompleto: TR aplica-se na data de aniversário do contrato; se houver pro rata, declarar a convenção (linear ou exponencial) como `[PREMISSA]` — a diferença é desprezível para TR baixa, mas deve ser registrada.

### 3.3 Atualização do Saldo

**Passo 1 — Incidência de encargos:**
```
S'_t = S_{t−1} + J_remun_t + J_mora_t + Multa_t + IOF_t + Tarifa_t + Correção_t
```
(J_mora_t e Multa_t = 0 se pontual; IOF_t, Tarifa_t, Correção_t = 0 se sem lançamento)

**Passo 2 — Alocação do pagamento via waterfall.**

**Saldo final:** `S_t = S'_t − Pgto_t`

**Amortização efetiva:** `Amort_t = Pgto_t − Σ(Alocações_em_encargos)`. Se ≤ 0 → amortização negativa.

### 3.4 Sistemas de Amortização

**Tabela Price (parcela fixa):**
```
A = P × [i × (1+i)^n] / [(1+i)^n − 1]
J_t = S_{t−1} × i
Amort_t = A − J_t
S_t = S_{t−1} − Amort_t
```

**SAC (amortização constante):**
```
Am = P / n
J_t = S_{t−1} × i
Parcela_t = Am + J_t
S_t = S_{t−1} − Am
```

**SAM (misto):**
```
Parcela_SAM_t = (Parcela_Price_t + Parcela_SAC_t) / 2
```

**IMPORTANTE — SAM clarificação:** As parcelas Price e SAC são calculadas sobre o PRINCIPAL ORIGINAL P:
- `Parcela_Price_t = A (constante, calculada uma única vez)` — juros sobre saldo Price (evolui)
- `Parcela_SAC_t = Am + (P − Am × (t−1)) × i` — juros sobre saldo SAC (evolui), onde `S_SAC_{t−1} = P − Am × (t−1)`
- SAM combina as DUAS **parcelas** (não os saldos).

```
J_SAM_t = S_SAM_{t−1} × i
Amort_SAM_t = Parcela_SAM_t − J_SAM_t
S_SAM_t = S_SAM_{t−1} − Amort_SAM_t
```

**Identidade (corrige a v20):** o saldo SAM obtido pela recorrência acima é **igual** à média dos saldos Price e SAC em todo t. Prova por indução: se S_SAM_{t−1} = (S^P_{t−1} + S^S_{t−1})/2, então J_SAM = (J^P + J^S)/2 e Amort_SAM = (Amort^P + Am)/2, logo S_SAM_t = (S^P_t + S^S_t)/2. Use a média como verificação cruzada (conferido no `--selftest`).

**Sistema Americano:**
```
J_t = S_{t−1} × i ; S_t = S_{t−1} (para t < n)
Parcela_n = S_{n−1} + J_n ; S_n = 0
```

### 3.5 Amortização Negativa

Quando `Pgto_t < J_t`: principal CRESCE. Sinalizar como ALTA SEVERIDADE se por `N_CONSECUTIVO`+ períodos consecutivos.

### 3.6 Waterfall — Ordem de Alocação de Pagamentos

**WATERFALL LEGAL (CC arts. 352–354):**
1. Juros vencidos (moratórios + remuneratórios vencidos)
2. Principal

**Waterfall bancário típico:**
1. IOF e tributos
2. Multa moratória
3. Juros moratórios
4. Juros remuneratórios vencidos
5. Juros remuneratórios correntes
6. Amortização do principal
7. Encargos futuros

**OBRIGATÓRIO quando contrato omisso:** Execute AMBAS as ordens — `pericia.aplicar_waterfall(pgto, componentes, ordem)` com
`pericia.ORDEM_WATERFALL_LEGAL` e `pericia.ORDEM_WATERFALL_BANCARIO`. A função marca `amort_negativa` quando o pagamento
não cobre os juros devidos e devolve `juros_nao_cobertos`. Recálculo linha a linha: `pericia.recalcular_saldo(...)`.

### 3.7 Liquidação Antecipada (total ou parcial)

O valor de quitação é o **valor presente das parcelas a vencer, descontadas à taxa de juros pactuada** (Res. CMN
5.004/2022, art. 7º — PF, operações prefixadas; art. 52 §2º CDC):
```
Saldo_quitação = Σ_{k a vencer} PMT_k / (1 + i_contrato)^(meses entre a liquidação e o vencimento k)
```
Para Price em dia, isso coincide com o saldo devedor da tabela (mais juros pro rata desde o último vencimento) —
`pericia.liquidacao_antecipada` (conferido no `--selftest`). Na amortização parcial, o pagamento abate o VP das
parcelas e o banco deve recalcular parcelas ou prazo.

`HC-09` quando o banco cobra acima desse VP — p.ex. a soma nominal das parcelas, ou desconto a uma taxa maior que
a pactuada (o que reduz o desconto). Histórico normativo: Res. CMN 3.516/2007 (taxa pactuada até 12 meses e
Selic + spread acima disso, na redação original) → Res. CMN 4.320/2014 (taxa pactuada) → Res. CMN 5.004/2022, art.
7º (taxa pactuada, cláusula específica). Para fatos anteriores a 05/05/2014 com prazo a decorrer > 12 meses, aplique
a regra da época.

> **Correção v21:** a fórmula anterior (`S_t + J_pro_rata − VP dos juros futuros`) descontava duas vezes — o saldo
> S_t já exclui os juros futuros — e produzia quitação **abaixo** do saldo devedor.

### 3.8 IOF (Decreto 6.306/2007) — PF
```
IOF_adicional = Principal × 0,38%
IOF_diário    = Σ_j Amortização_j × 0,0082% × min(dias_j, 365)     [operação parcelada: por parcela]
              = Principal × 0,0082% × min(N_dias, 365)            [operação de prazo único]
Teto do diário: 365 dias = 2,993%  →  alíquota efetiva máxima 3,373% (não 3,38%)
```
Implementação: `pericia.iof_operacao` e `pericia.iof_parcelado`. Novação: IOF integral. Renegociação sem nova
liberação: complementar. Verificação: `|IOF_cobrado − IOF_esperado| > TOL_SALDO → HC-16`. Se o IOF foi
**financiado**, ele integra o principal sobre o qual correm juros — declarar; se o banco aplicou *gross-up* (IOF calculado sobre o próprio IOF financiado), registrar como `[FATO]` e quantificar a diferença. Despesas financiadas (IOF, tarifas, seguro) devem correr à **mesma taxa** do principal (Res. CMN 5.004/2022, art. 9º).

### 3.9 Correção Monetária
```
Correção_t = S_{t−1} × (Índice_t / Índice_{t−1} − 1)
```

REGRA: Se juros moratórios = Selic → NÃO aplicar correção monetária separada (*bis in idem*).

---

## ETAPA 4 — INFERÊNCIA

### 4.1 Sistema de Amortização
```
EQM_X = (1/N) × Σ (Saldo_Banco_t − Saldo_X_t)²
REQM_X = √EQM_X
```
Se REQM_min / REQM_2º < 0,5 → forte evidência para o sistema com menor REQM. Se ≥ 0,9 → sistemas indistinguíveis — executar ambos como cenários.

### 4.2 Taxa de Juros

**Método 1 — Via parcela e prazo:** Resolver numericamente.
**Método 2 — Via regressão/otimização:** Minimizar Σ(Saldo_Calc − Saldo_Banco)².
**Método 3 — Via encargos explícitos:** `i_efetiva_t = J_t / S_{t−1}`.
**Método 4 — Via TIR/XIRR (Newton-Raphson):**

> **CORREÇÃO (desde v19.0) — viés numérico na inferência de taxa.** A formulação anterior media o
> prazo em **dias corridos** (`(d_t − d_0)/365` na v18; `/30` em variantes monolíticas). Em
> fluxos **mensais regulares** — o caso dominante em crédito PF — nenhuma das duas fecha nas
> datas de vencimento, porque meses-calendário têm 28–31 dias. O expoente deve contar
> **meses-calendário** quando o evento cai no mesmo dia do mês, com fallback para 30,4375
> dias (= 365,25/12).
>
> **Viés medido** (Price R$ 1.000 @ 1,0000% a.m. × 12, vencimentos dia 15):
>
> | Formulação | Taxa inferida | Erro na taxa | Taxa efetiva a.a. | Erro na taxa anual |
> |---|---|---|---|---|
> | Meses-calendário (v19+) | 1,000000% a.m. | 0,000% | 12,6825% | — |
> | Dias/365 (v18) | 0,999419% a.m. eq. | −0,058% | 12,6747% | −0,008 p.p. |
> | Dias/30 | 0,985661% a.m. | **−1,434%** | 12,4907% | −0,192 p.p. |
>
> **Impacto forense:** a taxa inferida alimenta HC-01 (taxa divergente) e o CET. A variante
> `/30` desloca a taxa em 1,4% — o bastante para fabricar ou mascarar um achado contra
> `TOL_TAXA` = 0,05 p.p. Use a implementação abaixo em **todas** as inferências da taxa contratual.
> Para o **CET regulatório**, mantenha a convenção dias/365 da Res. CMN 4.881/2020 (§4.3) e reconcilie.

Implementação: `pericia.taxa_contratual_mensal(fluxos, datas)` (alias legado `newton_raphson_taxa`) — Newton-Raphson com
prazo em meses-calendário (`_meses_entre`: exato quando o dia do mês coincide; senão dias/30,4375) e bisseção de reserva
quando o Newton não converge.

**Conversão para taxa anual equivalente:** `(1 + r_mensal)**12 − 1` — isto é a **taxa efetiva anual**, não o CET regulatório (§4.3).
Se o fluxo tiver datas irregulares (não mensais), `_meses_entre` degrada para a fração
`dias/30,4375` — declarar `[PREMISSA]` no laudo quando isso ocorrer em > 20% dos eventos.

**Auto-verificação:** incluída em `python3 scripts/pericia.py --selftest` (Price 12 × 1% deve devolver 1,000000% a.m.).

### 4.3 CET (Res. CMN 4.881/2020, art. 4º)

Fórmula **regulatória** — é com ela que o CET informado pelo banco foi calculado, e é com ela
que o CET recalculado deve ser comparado:
```
0 = −FC_0 + Σ_{j=1..n} [FC_j / (1 + CET)^((d_j − d_0)/365)]
```
`FC_0` = valor líquido liberado (principal − IOF − tarifas iniciais − seguro financiados);
`FC_j` = pagamentos; `d_j − d_0` em **dias corridos**; `CET` em base **anual** (o normativo
admite arredondar para base mensal na divulgação). Divergência > `CET_ALERTA` → sinalizar.

**Reconciliação com a inferência de taxa (Método 4):** o Newton-Raphson em meses-calendário
infere a **taxa contratual mensal** (HC-01) e reproduz exatamente fluxos mensais; o CET
regulatório usa dias/365 e por isso difere ligeiramente de `(1 + r_mensal)^12 − 1` (viés de
−0,008 p.p. no exemplo do Método 4). Reportar os dois números com o método de cada um; nunca
comparar o CET informado com uma taxa obtida por convenção diferente da Res. 4.881.

Implementação: `pericia.cet_regulatorio(fc0, pagamentos, datas_pagamento, data_liberacao)` e
`pericia.comparar_cet(cet_informado, cet_recalculado)` (classifica contra `CET_ALERTA`/`CET_ALTA`).

### 4.4 Inferência via Painel de Crédito (sem contrato e sem demonstrativo) — `pericia.inferir_taxa_painel`

Quando não há contrato nem demonstrativo dedicado, o painel de crédito mensal (§0-PRE.7 de `protocolo-pipeline.md`) fornece fluxo auditável por contrato: `S_t` (saldo pendente), `PMT` (parcela), `Δpagas` (parcelas pagas no período).

```
Período com exatamente 1 parcela paga:
  i_t = (S_t + PMT − S_{t−1}) / S_{t−1}

Período sem pagamento (Δpagas = 0):
  i_acru_t = (S_t − S_{t−1}) / S_{t−1}      [taxa de acruamento: juros + mora]
```

- **Taxa da fase:** mediana dos `i_t` com `Δpagas = 1` → `[INFERIDO — método painel, confiança média]`.
- **TIR da fase:** XIRR do fluxo `{−S_0; +PMT nas datas de débito observadas; +S_n como valor terminal}`.
- **Validação cruzada:** recomputar `S_t` com a taxa inferida (sistema Price) e comparar com o painel via REQM (Etapa 4.1).
- **Limitações (declarar):** o painel é snapshot na data de corte do extrato, não na data de vencimento — declarar `[PREMISSA]` sobre a data de incidência; usar ≥ 3 observações; `i_acru_t` mistura juros remuneratórios e mora (decompor apenas com documentos — senão `HC-27`).

---

## ETAPA 5-T — TESTES REGULATÓRIOS PARAMETRIZADOS

Três testes computacionais alimentam diretamente itens do checklist da Etapa 5 (45 itens).
Todos devem ter **entrada, saída e parâmetros registrados no laudo** (rastreabilidade §4.1).

### §5-T1 — Teto de 100% do rotativo (Lei 14.690/2023 + Res. CMN 5.112/2023)

Aplica-se a saldo de cartão de crédito **originado a partir de 03/01/2024**: o total de
juros remuneratórios + encargos financeiros (= multa e juros de mora, art. 2º-A, III da Res. 4.549
red. Res. 5.112 — **IOF e tarifas não entram**) não pode exceder o valor original
da dívida. Em migração rotativo → parcelamento de fatura, o valor original é apurado desde o
início do rotativo (Res. CMN 4.549/2017, art. 2º-A, incl. pela Res. 5.112/2023). Passar
o total **já líquido de IOF e tarifas** e registrar a data de origem como `[FATO]`. Se a operação começou
entre 01 e 02/01/2024, declare `[PREMISSA]` sobre o marco do art. 2º-D.

Implementação: `pericia.verificar_teto_rotativo(valor_original, juros_encargos_sem_iof, data_origem)` — devolve
`aplicavel=False` para origem anterior a 03/01/2024 (o teto não retroage) e o excesso em R$ quando violado.

- Violação → `HC-17` e item 31 do checklist da Etapa 5.
- Dívida originada **antes** de 03/01/2024: o teto não se aplica. Declarar a data de origem
  como `[FATO]` e **não** aplicar o teste retroativamente.

### §5-T2 — Dívida perpétua em RMC/RCC (HC-29)

Testa se o pagamento mínimo descontado em folha amortiza o saldo em horizonte finito.

Implementação: `pericia.verificar_divida_perpetua_rmc(saldo, desconto_mensal, taxa_mensal, n_meses=60)`; prazo
analítico com pagamento fixo: `pericia.meses_para_quitar(saldo, pgto, taxa)` (None = nunca quita).

- `perpetua = True` → `HC-29` + item 24 do checklist, com a ressalva `[TESE_PENDENTE]` do
  Tema 1.414 (§5, Nota 5).
- Reportar sempre os três insumos (saldo, mínimo, taxa) e a origem de cada um. Quando a taxa
  não constar do contrato, rodar o teste em cenários (contratada, média BACEN, inferida).
- **Estoque vivo:** contratos de RMC/RCC firmados antes de qualquer restrição continuam em
  execução — o teste permanece aplicável a eles (a MP 1.355/2026 perdeu a eficácia e o cronograma de extinção
  nunca produziu efeitos para o estoque).

### §5-T3 — Mínimo existencial (HC-37; Cenário K)

Aplica a moldura fixada pelo STF (ADPFs 1.005/1.006/1.097): piso de R$ 600 do Decreto
11.567/2023, **consignado incluído** no cômputo, com possibilidade de piso maior provado no caso.

Implementação: `pericia.verificar_minimo_existencial(renda_liquida, parcelas: dict, piso=600, despesas_essenciais_provadas=None)`.
Inclua **todas** as parcelas — consignado, cartão (inclusive o desconto de RMC/RCC), cheque especial, empréstimos em conta.

- `violacao = True` → `HC-37` (+ `HC-21` se houver recusa de renegociação global) e item 33
  do checklist; disparar o Cenário K.
- O piso de R$ 600 é **revisável anualmente pelo CMN** por determinação do STF: registrar no
  laudo o valor vigente na data de cada lançamento e a fonte (§5 Nota 6, item iii).

---

## ETAPA 5 — CHECAGEM DE ENCARGOS (45 ITENS)

**Cobertura:** a lista é **HC-completa e verificada por script** (`scripts/verificar_integridade.py`) — toda
hipótese HC-01 a HC-38 de §4.3.1 é citada em ao menos um item. Itens 44–45 (v21) cobrem a decadência e a
suspensão do TCU no cartão consignado.

| # | Verificação | Critério | Referência / HC |
|---|---|---|---|
| 1 | Capitalização composta | Previsão contratual? Pós-31/03/2000? | HC-02, HC-14; Súmula 539/STJ |
| 2 | Comissão de permanência cumulada | Com multa, mora ou correção? | HC-04; Súmula 472/STJ |
| 3 | Comissão de permanência teto | Excede soma dos encargos previstos? | HC-04; Súmula 472/STJ |
| 4 | Multa moratória | > 2% sobre prestação vencida? | HC-15; Art. 52 §1º CDC |
| 5 | Juros moratórios | > 1% a.m. sobre prestação vencida? | HC-04, HC-27; Súmula 379/STJ |
| 6 | IOF | Reincide em renegociação? Alíquota/base corretas? | HC-05, HC-16; Decreto 6.306/2007 |
| 7 | Tarifas | Sem discriminação ou previsão? | HC-06; Res. CMN 4.949/2021 |
| 8 | Seguro prestamista | Venda casada? | HC-06; Art. 39 I CDC |
| 9 | Tarifa de cadastro | Em renegociação (não início)? | HC-06; Súmula 566/STJ |
| 10 | Alteração de taxa | Sem aditivo? | HC-01; Art. 422 CC; Súmula 530/STJ |
| 11 | Selic + correção | Bis in idem (mora até 29/08/2024)? Regime pós-30/08/2024 aplicado corretamente (taxa legal + IPCA)? | HC-04, HC-10; REsp 1.081.149/RS; Tema 1.368/STJ; Lei 14.905/2024 |
| 12 | Liquidação antecipada | Valor cobrado > VP das parcelas a vencer à taxa pactuada? `pericia.liquidacao_antecipada` | HC-09; Art. 52 §2º CDC; Res. CMN 5.004/2022 art. 7º |
| 13 | Alteração retroativa | Taxa recalculada retroativamente? | HC-01; Art. 422 CC |
| 14 | Teste do duodécuplo | Taxa anual > 12× mensal? | HC-02; Súmula 541/STJ |
| 15 | Portabilidade — spread abusivo | Spread na portabilidade superior ao contratado? Recusa injustificada? | HC-20; Res. CMN 5.057/2022 |
| 16 | Superendividamento | Comprometimento total de renda excessivo sem oferta de renegociação global? | HC-21; Lei 14.181/2021; Art. 104-A CDC |
| 17 | Tarifa de avaliação duplicada | Tarifa de avaliação de bem cobrada novamente em refinanciamento do mesmo bem? | HC-22; Res. CMN 4.949/2021 |
| 18 | Título de capitalização vinculado | Capitalização vinculada à concessão sem opt-out documentado? | HC-23; Art. 39 I CDC; Circ. SUSEP 620/2020 |
| 19 | Extinção de contrato sem lastro | Contrato some do painel sem liquidação/novação documentada? | HC-25; Arts. 360–367 CC |
| 20 | Rolagem em cadeia | Renegociações sucessivas em < 90 dias com saldo crescente? | HC-26; Lei 14.181/2021; Art. 104-A CDC |
| 21 | Margem consignável excedida | Parcelas consignadas > limite **vigente na data da contratação** (35%/40%/45% INSS/40% janela MP 1.355; CLT 40% = 35+5)? `pericia.verificar_margem` | HC-18; Leis 10.820/2003, 13.172/2015, 14.431/2022, 14.601/2023 |
| 22 | Cheque especial acima do teto | Taxa efetiva > 8% a.m.? Tarifa cobrada em limite ≤ R$ 500? | HC-19; Res. CMN 4.765/2019 |
| 23 | Consulta/inscrição indevida SCR/Serasa | Inclusão sem dívida comprovada ou sem notificação prévia? | HC-28; Art. 43 CDC; Súmula 550/STJ |
| 24 | Cartão consignado RMC/RCC — dívida perpétua | Mínimo insuficiente para amortizar? **Rodar teste §5-T2.** | HC-29; Tema 1.414/STJ `[TESE_PENDENTE]` |
| 25 | Cessão a FIDC — taxa nova sem notificação | Cessionário aplicou taxa diferente? Devedor foi notificado? | HC-30; Arts. 286–298 CC |
| 26 | Pix parcelado — CET opaco | CET informado? Lançamento discriminado em fatura? | HC-31; Arts. 6º III e 52 CDC |
| 27 | FGTS saque-aniversário — adesão | Banco comprova adesão pelo app FGTS? | HC-32; Súmula 479/STJ |
| 28 | IOF complementar indevido em renegociação | IOF reincidiu em prorrogação sem nova liberação? | HC-33; Decreto 6.306/2007 art. 7º §1º |
| 29 | Capitalização de tarifas | Tarifa incorporada ao principal e gerando juros? Despesas financiadas a taxa diferente da do principal (Res. CMN 5.004/2022 art. 9º)? | HC-34; Súmula 539/STJ; Art. 51 IV CDC |
| 30 | Migração unilateral cheque especial → empréstimo | Saldo migrado sem manifestação inequívoca? | HC-35; Arts. 6º III e 51 X CDC |
| 31 | Teto de 100% do rotativo (origem ≥ 03/01/2024) | Juros + multa + juros de mora (**sem IOF e sem tarifas** — art. 2º-A, III) > valor original? Origem anterior → NÃO APLICÁVEL. **Rodar teste §5-T1.** | HC-17; Lei 14.690/2023; Res. CMN 5.112/2023 |
| 32 | Dívida prescrita em cobrança / plataforma | Cobrança ou manutenção de dívida já prescrita? | HC-36; Tema 1.264/STJ `[TESE_PENDENTE]` |
| 33 | Mínimo existencial | Renda − parcelas (**inclusive consignado**) < R$ 600 ou < piso provado? **Rodar teste §5-T3.** | HC-37; Dec. 11.567/2023; STF ADPFs 1.005/1.006/1.097 |
| 34 | Abusividade de juros — além da taxa média | Comparação com a média BACEN da modalidade (SGS) **e** fatores do caso documentados? | HC-38; Tema 1.378/STJ `[TESE_PENDENTE]` |
| 35 | Coisa julgada em ação anterior | Já houve ação sobre as mesmas tarifas? Se sim, juros sobre essas tarifas **não** podem ser pleiteados em nova ação (Tema 1.268 — tese desfavorável) | HC-34; Tema 1.268/STJ |
| 36 | Alocação predatória de pagamento | Pagamentos 100% em encargos por ≥ N_CONSECUTIVO períodos? Waterfall diverge do art. 354 CC? | HC-03; Arts. 352–354 CC |
| 37 | Saldo de transição inflado | Gap F(n−1)→F(n) injustificado? Encargos indevidos incorporados ao novo principal? | HC-07; Arts. 360–367 CC |
| 38 | Amortização negativa oculta | Parcela < juros sem aviso, principal crescente (flag `AMORT_NEG`)? | HC-08; Art. 6º III CDC |
| 39 | Carência violada | Amortização cobrada durante o período de graça? | HC-11; contrato |
| 40 | Spread aplicado incorretamente | Multiplicativo × aditivo divergente do contrato (pós-fixadas)? | HC-12; contrato |
| 41 | Arredondamento sistemático desfavorável | Viés acumulado contra o devedor > TOL_SALDO? | HC-13; NBC TP 01 |
| 42 | Amortização extraordinária sem desconto | Amortização parcial sem abatimento pelo VP à taxa pactuada (parcelas ou prazo não recalculados)? | HC-24; Art. 52 §2º CDC; Res. CMN 5.004/2022 art. 7º |
| 43 | Mora acruada sem decomposição | Saldo cresce em atraso sem discriminar juros/multa/mora? | HC-27; Art. 52 §1º CDC; Súmula 379/STJ |
| 44 | Decadência no cartão consignado | Contratação de RMC/RCC há mais de 4 anos do ajuizamento? Marcar `[RISCO DE DECADÊNCIA — Tema 1.414, item I]` e recomendar ajuizamento sem esperar o julgamento | HC-29; Art. 178 × 169 CC; Tema 1.414/STJ `[TESE_PENDENTE]` |
| 45 | Averbação de cartão consignado após a suspensão do TCU | Nova averbação de RMC/RCC no INSS posterior a 29/04/2026? Requisitar o histórico do eConsignado / Meu INSS | HC-29; Acórdão TCU 1.094/2026-Plenário |

**Saída obrigatória da Etapa 5 (45 itens):** para cada item, registrar `CONFORME` / `NÃO CONFORME` /
`NÃO APLICÁVEL` / `SEM DADOS`. Itens `SEM DADOS` entram na lista de documentos a solicitar
(§11.2) e penalizam o score de qualidade (§4.8).

---

## ETAPA 6 — COMPARAÇÃO LINHA A LINHA

### 6.1 Cálculo da Diferença
```
Dif_t = Saldo_Banco_t − Saldo_Calc_t
```

**Diferença percentual com tratamento robusto de zero:** denominador |saldo_calc| → fallback |saldo_banco| → 0 quando
ambos ≈ 0 — `pericia.calcular_dif_pct`. Linha completa (dif, %, severidade dual): `pericia.comparar_linha(banco, calc)`.

### 6.2 Severidade — DUPLO CRITÉRIO (aplicar o MAIOR) — `pericia.severidade`

**Absoluto:**
- < TOL_SALDO: ARREDONDAMENTO
- ≥ TOL_SALDO e < R$ 100: BAIXA
- ≥ R$ 100 e < R$ 1.000: MÉDIA
- ≥ R$ 1.000: ALTA

**Relativo:**
- < TOL_PCT (0,1%): ARREDONDAMENTO
- ≥ 0,1% e < 1%: BAIXA
- ≥ 1% e < 5%: MÉDIA
- ≥ 5%: ALTA

### 6.3 Acumulação de Impacto

`Dif_t` é um **estoque**: já acumula tudo o que divergiu até t. Por isso **não se soma `Dif_t` ao longo das
linhas** — isso conta a mesma divergência repetidas vezes. Some as divergências **novas** de cada período:
```
δ_t = Dif_t − Dif_{t−1}            (Dif_0 = 0)
Impacto direcional até t   = Σ_{s≤t} δ_s = Dif_t
Impacto absoluto           = Σ_t |δ_t|
Impacto atualizado (Selic) = Σ_t δ_t × Fator_Selic(data_t → data_ref)
```
Implementação: `pericia.impacto_divergencias(difs, datas, fator_ate_ref)`. Para pagamentos a maior (fluxos), o
mesmo vale com `δ_t = pago_t − devido_t`. "VP" no laudo = valor **atualizado** até a data-base (o fator leva
o valor para frente); declare a série e o período.

> **Correção v21:** a v20 definia `Impacto_VP = Σ_t Dif_t × Fator(...)`, que superestima o impacto em ordem de
> grandeza (N linhas × mesma divergência).

---

## ETAPA 7 — CONSOLIDAÇÃO

Após completar as Etapas 3–6 (modelo recalculado, inferência, checagem de encargos e comparação linha a linha), proceda à consolidação dos achados:

1. **Síntese de achados:** Resume as hipóteses causais (HC-XX) identificadas e sua severidade.
2. **Geração de tabelas obrigatórias:** Produz as 9 tabelas de saída padrão (formato definitivo em `outputs-cenarios-anexos.md` §8.C):
   - Tabela 1: Mapa de Fases (fichas completas de cada fase F0, F1...)
   - Tabela 2: Evolução do Saldo — linha a linha (banco vs. recalculado)
   - Tabela 3: Discrepâncias (ordenadas por severidade → impacto, com HC-XX)
   - Tabela 4: Impacto Consolidado (por fase, direcional + absoluto + VP)
   - Tabela 5: Comparação de Cenários (A–L, saldo final + excesso + VP)
   - Tabela 6: Checklist Regulatório (45 itens, com resultado e referência legal)
   - Tabela 7: Sensibilidade (21 cenários, Δ vs. base)
   - Tabela 8: Matriz Agentes × Achados; Tabela 9: Temas STJ pendentes e exposição (formato em `outputs-cenarios-anexos.md` §8.C)

3. **Cenários A–L:** Executa variações parametrizadas do modelo (definição canônica em `outputs-cenarios-anexos.md` §10.1; K = mínimo existencial/superendividamento, L = teto do rotativo):
   - **Cenário A (Base):** Price + composta + taxa contratada + waterfall contratual.
   - **Cenário B:** SAC + composta + taxa contratada + waterfall contratual.
   - **Cenário C:** Price + composta + taxa contratada + waterfall legal (Art. 354 CC).
   - **Cenário D:** SAC + composta + taxa contratada + waterfall legal.
   - **Cenário E:** juros simples sobre o capital remanescente (§3.2.1) + waterfall legal — sem anatocismo; variante Gauss (`pmt_gauss`) quando a tese for parcela fixa sem capitalização.
   - **Cenário F:** Price + composta + taxa média BACEN (Súmula 530) + waterfall legal.
   - **Cenário G:** Price + composta + contratada + contratual — sem tarifas/seguros.
   - **Cenário H:** Sistema do caso + composta + pós-fixada (CDI/Selic+spread) + contratual.
   - **Cenário I:** Price + composta + contratada + waterfall legal — sem tarifas/seguros + legal.
   - **Cenário J:** Price + composta + contratada + contratual — mora legal do Art. 406 CC no regime vigente em cada período (§4.5).
   - **Cenário K:** decote pelo mínimo existencial (R$ 600, consignado incluído — STF ADPFs 1.005/1.006/1.097; teste §5-T3).
   - **Cenário L:** decote pelo teto de 100% do rotativo (origem ≥ 03/01/2024; teste §5-T1).

4. **Cenário J — Detalhamento:**
   ```
   Mora legal (Art. 406 CC) — SEGMENTAR por regime (§4.5):
   - Período até 29/08/2024: Selic integral, SEM correção separada (bis in idem — REsp 1.081.149/RS; Tema 1.368/STJ)
   - Período desde 30/08/2024: taxa legal = Selic − IPCA-15 (juros simples, piso zero) + IPCA em separado (Lei 14.905/2024; Res. CMN 5.171/2024)
   - Para contratos PF/CDC: verificar se Súmula 379/STJ (1% a.m.) prevalece
   - Regra de aplicação:
     Se contrato NÃO estipula mora → mora legal do art. 406 CC no regime de cada período (Selic até 29/08/2024; taxa legal + IPCA depois)
     Se contrato estipula mora ≤ 1% a.m. → usar taxa contratual
     Se contrato estipula mora > 1% a.m. → limitar a 1% a.m. (Súmula 379/STJ)
   - Em TODOS os casos: nunca cumular Selic INTEGRAL com correção monetária (nos dois regimes)
   - Comparação: calcular mora tanto por Selic quanto por 1% a.m., reportar ambas,
     adotar a MENOR como cenário mais favorável ao devedor neste cenário J
   ```

5. **Sensibilidade:** 8 parâmetros / até 21 cenários (§10.2 de `outputs-cenarios-anexos.md`); reporta mudança de HC ou impacto > 5%.

6. **Relatório final:** Consolida achados em padrão forense (executivo, recomendações, ressalvas) conforme § 8.

---

## ANEXO A — Conversão de Taxas (Mensal ↔ Diária, actual/365)

Quando o contrato expressa taxa mensal i_m e é necessário calcular em regime diário (actual/365):

**Passo 1 — Obter taxa anual equivalente:**
```
i_a = (1 + i_m)^12 − 1
```

**Passo 2 — Converter para diária (actual/365):**
```
i_d = (1 + i_a)^(1/365) − 1
```

**Fórmula combinada (equivalente matematicamente):**
```
i_d = (1 + i_m)^(12/365) − 1
```

**Demonstração da equivalência:**
```
(1 + i_m)^(12/365) = ((1 + i_m)^12)^(1/365) = (1 + i_a)^(1/365)
```

Logo, `(1 + i_m)^(12/365) − 1` é equivalente a `(1 + i_a)^(1/365) − 1` onde `i_a = (1 + i_m)^12 − 1`.

A fórmula `(1 + i_m)^(12/365)` é correta por aplicação das propriedades de expoentes: o expoente fracionário 12/365 converte a taxa mensal composta para sua equivalente diária em regime exponencial.

**Uso em juros simples (cenário sem anatocismo):**
```
J_t = Capital_{t−1} × i_a_prop × (d/365)
onde i_a_prop = 12 × i_m (PROPORCIONAL, não equivalente)
```

Isto é diferente de juros compostos; observe que i_a_prop é meramente proporcional (12×), não a verdadeira taxa anual composta.

---

## ANEXO B — Consulta a Taxas e Índices via BACEN SGS

Para automação do recálculo, as seguintes séries do Sistema Gerenciador de Séries Temporais (SGS) do Banco Central são essenciais:

| Série SGS | Descrição | Uso na Perícia |
|---|---|---|
| **11** | Selic diária (% a.d.) | Fator acumulado para VP; pós-fixadas Selic |
| **4390** | Selic acumulada no mês (% a.m.) | Mora legal pré-30/08/2024 (art. 406, Tema 1.368) |
| **29543** | Taxa Legal — art. 406 CC (% a.m.) | Mora legal desde 30/08/2024 (conferido 10/10/2026) |
| **12** | CDI diário (% a.d.) | Pós-fixadas CDI+spread |
| **433** / **7478** | IPCA / IPCA-15 mensal (%) | Correção (art. 389 §ú) / proxy intra-mês |
| **189** / **188** / **226** | IGP-M / INPC / TR mensal (%) | Correção conforme contrato |
| **25464** | Taxa média mensal PF — crédito pessoal não consignado | Súmula 530/STJ; HC-38 (conferido 10/10/2026) |
| **25470** | Taxa média mensal PF — crédito pessoal total | Referência (conferido 10/10/2026) |
| **25463** | Taxa média mensal PF — cheque especial | Referência + teto 8% (conferido 10/10/2026) |
| **25477** | Taxa média mensal PF — cartão rotativo | Referência cartão (conferido 10/10/2026) |
| **25478** | Taxa média mensal PF — cartão parcelado (provável) | Conferir título com `bcb_sgs.py titulo 25478` |
| **25468** | Taxa média mensal PF — consignado INSS (provável) | Conferir título com `bcb_sgs.py titulo 25468` antes de usar |

> **Códigos errados em versões ≤ v20:** 25433, 25435, 27788 e 27789 **não** correspondem às modalidades que a skill
> lhes atribuía. `scripts/bcb_sgs.py` emite aviso se forem usados.

### API de Consulta

```
GET https://api.bcb.gov.br/dados/serie/bcdata.sgs.{SERIE}/dados?formato=json&dataInicial={DD/MM/AAAA}&dataFinal={DD/MM/AAAA}
```

**Exemplo — Selic diária:**
```
https://api.bcb.gov.br/dados/serie/bcdata.sgs.11/dados?formato=json&dataInicial=01/01/2023&dataFinal=31/12/2023
```

Retorna JSON: `[{"data":"02/01/2023","valor":"0.050481"}, ...]`

**Fator acumulado e séries:** `scripts/bcb_sgs.py` (`serie`, `serie_mensal`, `fator_acumulado`, `titulo`, `proveniencia`) —
com cache local e frase de proveniência pronta para o laudo. Sem rede, o script falha de forma explícita (não estima).

**NOTA:** A API do BACEN é pública e não requer autenticação. Rate limit: ~5 req/s. Para períodos longos, faça uma única consulta por série e armazene localmente.

**Taxa Legal (art. 406 CC, pós-30/08/2024):** SGS 29543 (Res. CMN 5.171/2024). Registrar código e data de consulta como `[FATO]`.

**Fallback se API indisponível:** Usar taxa Selic meta diária (série 432) como proxy, declarando `[PREMISSA — dados via série alternativa SGS 432]`. Ou solicitar ao usuário planilha de fatores acumulados do BACEN.

**Quando usar:** Sempre que o recálculo envolver taxa Selic, CDI, IPCA, IGP-M ou taxa média de mercado (Súmula 530/STJ), prefira dados reais da API ao invés de aproximações. Declare no relatório: `[FATO — dados obtidos via API BACEN SGS série {N}, consultada em {data}]`.

