# Radar Normativo — controle de vigência e de incerteza

**Data de corte desta base: 07/10/2026** (corte anterior: 03/08/2026).
Este arquivo existe para impedir dois erros opostos: (a) tratar como vigente o que ainda não vigora; (b) tratar como atual o que já foi superado.

Legenda: **C1** = verificado em fonte oficial na atualização de 07/10/2026 · **C2** = notícia confiável sem confirmação oficial · **C3** = indício fraco, não citar.

---

## 1. Regra de uso obrigatória

Antes de afirmar qualquer coisa sobre norma ou precedente, responder internamente:

1. **Qual a data de hoje?** Se for posterior ao corte (07/10/2026), toda informação deste conjunto de arquivos é **presumidamente desatualizada** em temas voláteis.
2. **O item está na tabela §2 (datas futuras)?** Se sim e a data já passou, **verificar antes de responder**.
3. **O item está na lista §4 (não confirmados)?** Se sim, **não afirmar** — dizer que precisa de verificação.
4. **O tema está suspenso ou afetado (§3)?** Isso muda a orientação processual independentemente do mérito.
5. Havendo ferramenta de busca disponível, **pesquisar em fonte oficial** (§5) antes de responder. Não havendo, declarar a limitação de forma explícita.

---

## 2-A. Eventos já ocorridos entre 03/08/2026 e 07/10/2026

| Data | Evento | Situação | Conf. |
|---|---|---|---|
| 01/08/2026 | Depósito recursal (Ato 381/SEGJUD.GP, de 16/07/2026): RO **R$ 14.411,57**; RR, embargos e recurso em AR **R$ 28.823,14** | Em vigor | C1 (ato) / C2 (valores) |
| ~03/09/2026 | **Lei 15.484, de 04/08/2026** — regulamenta a relevância da questão federal no REsp e altera o art. 988 do CPC; vigência 30 dias após a publicação | Em vigor. Efeito sobre a reclamação contra turma recursal (Res. STJ 3/2016) ainda sem jurisprudência | C2 — conferir texto no Planalto |
| 26/08/2026 | Protocolo de 2014 à **Convenção 29 da OIT** (Decreto 12.857/2026) | **Em vigor para o Brasil** | C1 |
| 27/08/2026 | **STF, Tema 1291** — julgamento designado | **Não ocorreu**: retirado da pauta, sem votos e sem nova data | C1/C2 |
| 02/09/2026 | PEC 6x1 aprovada na CCJ do Senado; discussão em Plenário iniciada em 06/10 | Pendente (ver §2) | C1 |
| 01–02/09/2026 | **Convenção 190 da OIT**: PDL 997/2026 aprovado na Câmara e enviado ao Senado | Pendente no Senado | C1 |
| 25/09/2026 | **MP 1.394/2026** proíbe apostas de quota fixa (bets); **Res. BCB 590, 595, 596 e 597/2026** vedam processar pagamentos a apostas | Em vigor (MP — acompanhar conversão) | C1 |
| 01/10/2026 | **IN BCB 746/2026**: fim do teto próprio de R$ 500 do Pix por aproximação; novas regras de limite do Pix Automático | **Em vigor, sem adiamento** | C1 |
| 01/10/2026 | **Res. BCB 589/2026** altera o art. 91 da Res. BCB 520/2025: vedação de operar com PSAV adiada para **06/11/2026**, com texto mais restritivo | Em vigor a alteração | C1 |
| 02/10/2026 | **STJ cancela o Tema 1.328** (dano moral na RMC) e incorpora o caso ao **Tema 1.414** | Feito | C1 |

---

## 2. Datas futuras e itens sem data

| Data | Evento | Efeito se já ocorreu |
|---|---|---|
| **30/10/2026** | **Res. BCB 520/2025, art. 88, I** — fim do prazo de 270 dias para PSAV já em operação pedir autorização | PSAV sem pedido deve encerrar atividades |
| **06/11/2026** | **Res. BCB 520/2025, art. 91** (redação da Res. BCB 589/2026) — IFs e IPs proibidas de operar com contraparte PSAV **não autorizada** | Contraparte cripto sem autorização vira risco regulatório imediato. A ressalva para PSAV "em processo de autorização" saiu do caput: **ler o texto integral antes de afirmar** que o pedido protocolado basta |
| **01/01/2027** | **Res. BCB 584/2026** (prevenção a fraude estendida às PSAVs) e Res. BCB 589/2026 (arts. 88, III, 90-A e 90-B: custódia, prova de reservas, staking) | Exigíveis |
| **01/01/2027** | Novo salário mínimo — PLOA 2027 propõe R$ 1.741 (C2); depende de decreto | Conferir o decreto. Afeta teto do JEC (40/20 SM), limite de 150 SM na falência, alçadas e RPV |
| **~12/01/2027** | **NR-24** — Portaria MTE 1.590/2026 (120 dias após 14/09/2026; data calculada, conferir) | Novas regras de instalações sanitárias móveis, água potável, trabalho externo |
| **01/06/2027** | **Nova NR-10** (Portaria MTE 737/2026) | Exigível (instalações existentes têm +1 ano para o item 10.6.4, "e") |
| **01/07/2027** | **Res. BCB 564 a 567/2026** — regulamentação da Lei 15.252/2025 | Portabilidade salarial automática, débito automático entre instituições, assessoramento e crédito com juros reduzidos exigíveis |
| **02/02/2028** | **Res. BCB 520/2025, art. 44** | Regras específicas exigíveis de todas as PSAVs autorizadas |
| **sem data** | **STF, Tema 1291 (RE 1.446.336)** — vínculo de motoristas de aplicativo. Retirado da pauta de 27/08/2026, sem votos; imprensa projeta para depois das eleições ou 2027 (C2) | **Verificar sempre** antes de responder sobre plataformas |
| **sem data** | **STF, Tema 1389 (ARE 1.532.603)** — pejotização. Mérito não julgado | Verificar sempre. Ver §3 sobre a suspensão |
| **prev. 14–15/10/2026** | **PEC 6x1 (PEC 221/2019 no Senado)** — 1º turno no Plenário; exige 49 votos em dois turnos; emendas rejeitadas na CCJ para não voltar à Câmara | Se promulgada: 40h semanais e dois dias de repouso. **Regra de transição não reconfirmada** — conferir texto aprovado |
| **sem data** | **Convenção 190 da OIT** (PDL 997/2026 no Senado) · **Convenção 193** (nenhuma mensagem ou PDL localizado) | Só valem internamente após decreto legislativo, ratificação e decreto de promulgação |
| **sem data** | **Regulação do trabalho por plataformas** — PLP 12/2024 e PLP 152/2025 prontos para pauta; PL 2.479/2025 aguardando parecer na CTRAB | Nenhum é lei |
| **sem data** | **PL 2.616/2025** (CadÚnico Telefônico, telemarketing e cobrança) — aprovado **terminativamente na CTFC** do Senado em 08/07/2026; na Câmara desde 10/08/2026, aguardando despacho | Não é lei |
| **sem data** | **MP 1.394/2026** (apostas) — prazo de conversão em curso | Se caducar ou for rejeitada, rever as Res. BCB 590 e 595–597 |
| **anual** | Depósito recursal (próximo reajuste: ago/2027) e revisão dos parâmetros do **mínimo existencial** pelo CMN (determinada pelo STF em 23/04/2026; **nenhum ato localizado até 07/10/2026**) | Conferir valores vigentes |

---

## 3. Temas com suspensão ou afetação ativa em 07/10/2026

**Trabalhista (TST)** — 🔴 suspensão nacional: Temas **92** (adicional noturno em jornada prorrogada) e **93** (provisoriedade da transferência); sobrestamento de RR e embargos no Tema **34** (controle de uso do banheiro). Afetados com sobrestamento nos TRTs ou no TST: **35, 39, 42, 43, 44, 91, 94, 95, 151, 152, 32** (não reconferidos nesta atualização).
- Notícias (C3, só Instagram) indicam julgamento do Tema **215** (19/08/2026) e tese no Tema **27** (legitimidade sindical, 28/09/2026). **Não citar sem conferir** no NUGEP/TST.

**Trabalhista (STF)** — Tema **1389**: pela decisão de **18/06/2026**, os processos tramitam na 1ª instância e nos TRTs; **RR e embargos seguem suspensos no TST**. (O radar anterior falava em "despacho de 22/06/2026"; esse ato não foi localizado — usar a decisão de 18/06.)

**Consumidor/bancário (STJ)** — afetados, sem julgamento:
- **1.378** (juros abusivos e taxa média) — suspensão de REsp/AREsp. Há blogs afirmando tese fixada: **falso** segundo a página oficial.
- **1.414** (cartão consignado/RMC) — **suspensão nacional** de todos os processos, exceto cumprimento de sentença (referendada em 08/04/2026). **Absorveu o Tema 1.328** em 02/10/2026.
- **1.396** (exigência de tentativa extrajudicial prévia para interesse de agir em ação de consumo) — suspensão de REsp/AREsp. Afeta diretamente petições no JEC.

**Condominial (STJ)** — **1.443** (locação de curta temporada por plataforma em condomínio residencial), afetado em maio/2026 com **suspensão nacional**. Detalhes na skill legal-brazil-lawyer (`plugin-condominial-locacao.md`).

**Saíram desta seção (julgados e transitados — já citáveis como precedente, conferindo a tese):** STJ **1.286** (consignado de militares, julgado em 12/03/2025) e **1.387** (prescrição PASEP, saque integral como termo inicial, julgado em 10/12/2025). Ambos estavam indevidamente listados como suspensos no radar anterior.

Consequência: em qualquer recomendação processual nesses temas, informar o **efeito de represamento** e ajustar expectativa de prazo.

---

## 4. Itens NÃO CONFIRMADOS — não afirmar sem verificar

1. Resolução do **CSJT** que adapte a tabela única de atualização à Lei 14.905/2024. Só se localizou a Res. CSJT 380/2024, **anterior** à lei.
2. **"Pix parcelado"**: o BCB anunciou (dez/2025, C2) que **não editará norma específica**. Não citar resolução sobre o tema.
3. **Resolução CMN 4.970** — não localizada. Não citar.
4. Números de normas do BCB sobre **ouvidoria, tarifas e CET** — não verificados nesta base.
5. Teor **literal** do acórdão do STF nas ADPFs 1.005/1.006/1.097 (mínimo existencial).
6. Teor **literal consolidado** das teses dos Temas 987/533 do STF após os ED de junho/2026.
7. Números de processo de reclamações constitucionais individuais citadas em notícias do STF.
8. Conteúdo do **Anexo VI da NR-16** (Portaria MTE 1.411/2025).
9. Números e datas das **Notas Técnicas do eSocial S-1.3**.
10. Relator e data exata de julgamento dos Temas **1.279** e **1.288** do STJ.
11. Existência de leis ordinárias de 2025–2026 alterando a CLT além da **Lei 15.377/2026** (art. 169-A e art. 473, §3º).
12. **Teto do RGPS para 2027** — nenhuma projeção oficial localizada.
13. Ação do STF que manteve a competência do INSS/CNPS para fixar teto de juros do consignado (notícias de set/2026): **número, relator e placar não confirmados**.
14. **Súmula vinculante** posterior à SV 63 — conferir a lista oficial antes de citar.
15. Numeração da mensagem presidencial da **Convenção 190** (Senado indica MSG 86/2026; radar anterior dizia MSC 86/2023).
16. **Despacho Decisório CD/ANPD 122/2026** (prazo do art. 31 do ECA Digital) — teor não verificado em fonte oficial.

---

## 5. Fontes oficiais para verificação

| Matéria | Fonte |
|---|---|
| Leis, decretos, textos compilados | planalto.gov.br/ccivil_03 · lexml.gov.br |
| Publicação oficial | in.gov.br (DOU) |
| STF — temas, teses, andamentos | portal.stf.jus.br · noticias.stf.jus.br |
| STJ — repetitivos, súmulas, informativos | processo.stj.jus.br/repetitivos · scon.stj.jus.br |
| TST — súmulas, OJs, repetitivos | juslaboris.tst.jus.br · tst.jus.br/nugep-sp |
| NRs, portarias, eSocial, FGTS Digital | gov.br/trabalho-e-emprego · gov.br/esocial |
| Normas do BCB e CMN | bcb.gov.br/estabilidadefinanceira/buscanormas |
| Tramitação legislativa | camara.leg.br (API de dados abertos) · senado.leg.br · congressonacional.leg.br |
| Enunciados FONAJE | cnj.jus.br |
| Seguros | gov.br/susep |
| Proteção de dados | gov.br/anpd |
| Defesa do consumidor | gov.br/mj (Senacon) · consumidor.gov.br |

**Acesso prático**: os portais do STF e do STJ costumam bloquear o fetch simples (403). Se isso acontecer, tentar outra ferramenta de extração disponível na sessão (scraper/crawler) ou a versão em PDF do acórdão antes de rebaixar a citação para C2/C3. Nunca preencher o dado faltante de memória.

**Regra de citação**: só citar precedente com **tribunal, órgão, classe e número corretos, relator, data e tese**. Classe errada (ex.: "RE" no lugar de "ARE") já compromete a credibilidade da peça.
