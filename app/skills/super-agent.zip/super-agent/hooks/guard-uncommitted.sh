#!/usr/bin/env bash
# PreToolUse guard: refuse discard operations while uncommitted work exists.
# Matcher: Bash
# Uncommitted work may be the only copy of an hour of thinking.
set -uo pipefail

payload="$(cat)"

DISCARD_RE='git[[:space:]]+(checkout[[:space:]]+\.|restore[[:space:]]+\.|reset[[:space:]]+--hard|stash[[:space:]]+(drop|clear)|clean[[:space:]]+-[a-zA-Z]*f)'

if printf '%s' "$payload" | grep -qiE "$DISCARD_RE"; then
  if ! git rev-parse --git-dir > /dev/null 2>&1; then exit 0; fi
  dirty="$(git status --porcelain 2>/dev/null)"
  if [ -n "$dirty" ]; then
    echo "BLOCKED: uncommitted changes present — this operation would destroy them." >&2
    echo "" >&2
    echo "$dirty" >&2
    echo "" >&2
    echo "Run 'git stash' first (costs one second), or get explicit user confirmation." >&2
    exit 2
  fi
fi
exit 0
