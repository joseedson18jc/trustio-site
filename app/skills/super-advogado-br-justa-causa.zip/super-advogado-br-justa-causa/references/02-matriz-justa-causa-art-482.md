# Matriz da justa causa e art. 482 da CLT

## Base legal mínima

A pesquisa deve começar no texto consolidado da CLT, especialmente arts. 477, 482, 493, 494, 818 e, conforme o caso, arts. 543 e 853 a 855. A justa causa é penalidade máxima. Sua validade depende do enquadramento legal e do conjunto concreto de fatos e provas.

## Requisitos transversais

Avalie sempre:

- materialidade e autoria;
- dolo ou culpa compatível com o tipo;
- gravidade concreta e quebra de fidúcia;
- nexo com o contrato;
- atualidade/imediatidade após apuração razoável;
- ausência de perdão e de dupla punição;
- proporcionalidade, histórico e gradação quando cabível;
- isonomia e ausência de discriminação;
- procedimento legal, contratual ou coletivo aplicável;
- prova íntegra e suficiente.

O Pleno do TST, no antigo Tema 196, desafetou em 10/04/2026 a tentativa de formular tese abstrata sobre gradação. Registrou que a possibilidade de dispensa sumária é admitida quando a natureza da falta justificar, mas gravidade, quebra de fidúcia e proporcionalidade dependem das circunstâncias concretas. Verifique o acórdão oficial antes de citar.

## Alíneas do art. 482

### a. Ato de improbidade

Perguntas:

- Qual vantagem indevida ou desonestidade concreta é atribuída?
- Há prova do ato e da consciência do empregado?
- O documento ou dado era falso, ou apenas divergente/irregular?
- Quem tinha acesso, capacidade e oportunidade de alterar?
- A empresa preservou o original e permitiu esclarecimento?

Riscos de enquadramento excessivo: chamar erro, divergência administrativa, falha de sistema ou culpa leve de fraude.

### b. Incontinência de conduta ou mau procedimento

Distinguir comportamento sexual inadequado de conduta social grave incompatível com o contrato. Evitar cláusula genérica para fatos que se ajustam melhor a outra alínea.

### c. Negociação habitual/concorrência ou prejuízo ao serviço

Testar habitualidade, ausência de permissão, concorrência efetiva ou prejuízo. Atividade paralela não é automaticamente concorrência.

### d. Condenação criminal transitada em julgado

Confirmar trânsito, ausência de suspensão da execução e impacto na prestação. Investigação, denúncia ou condenação sem trânsito não bastam para esta alínea.

### e. Desídia

Normalmente exige comportamento reiterado e histórico disciplinar. Um ato isolado pode ser grave, mas talvez pertença a outro enquadramento. Testar metas, treinamento, recursos, doença, sobrecarga e critérios comparativos.

### f. Embriaguez habitual ou em serviço

Separar episódio, dependência e doença. Pesquisar jurisprudência atual sobre alcoolismo e deveres de saúde/encaminhamento. Não tratar diagnóstico como culpa moral.

### g. Violação de segredo da empresa

Identificar informação protegida, dever de sigilo, acesso, divulgação, destinatário, dano/risco e intenção. Diferenciar denúncia legítima, exercício de defesa e comunicação a autoridade.

### h. Indisciplina ou insubordinação

Indisciplina: descumprimento de regra geral. Insubordinação: ordem pessoal e legítima. Testar clareza, ciência, legalidade, segurança, possibilidade de cumprimento e recusa efetiva.

### i. Abandono de emprego

Exige elemento objetivo e intenção de abandonar. A Súmula 32 do TST trata de presunção após cessação de benefício previdenciário em contexto específico. Não transforme 30 dias em regra absoluta para todo abandono. Examine comunicações, justificativas, alta, limbo previdenciário e animus abandonandi.

### j e k. Honra, boa fama e ofensas físicas

Preserve contexto, autoria e integralidade da fala. Teste legítima defesa, provocação, ambiente privado, alcance, função e políticas. Crítica não equivale automaticamente a ofensa grave.

### l. Prática constante de jogos de azar

Exige constância e relevância contratual. Verifique atualização jurisprudencial e distinção entre prática privada e impacto no trabalho.

### m. Perda de habilitação/requisito legal por conduta dolosa

Confirmar requisito indispensável, perda efetiva, nexo causal e dolo. Suspensão temporária, erro administrativo ou perda sem dolo exigem análise distinta.

## Outras hipóteses legais

Consulte regras especiais, como recusa injustificada a medidas de segurança, ferroviários, bancários e empregados com estabilidade. Nunca amplie analogicamente uma hipótese punitiva sem base.

## Imediatidade

Não existe prazo fixo universal. Conte:

- data do fato;
- data da ciência por autoridade competente;
- atos de apuração e intervalos sem diligência;
- complexidade, número de envolvidos e acesso à prova;
- manutenção normal do vínculo após ciência;
- data da decisão e comunicação.

A investigação real pode justificar intervalo. Inércia, reconstrução posterior ou demora desproporcional pode sustentar perdão tácito.

## Gradação e proporcionalidade

Não use fórmula automática. Avalie:

- gravidade intrínseca;
- dano ou risco;
- posição de confiança;
- dolo, preparação e ocultação;
- reiteração;
- histórico funcional;
- tratamento de casos semelhantes;
- medidas anteriores e sua relação com a falta;
- viabilidade de continuidade.

## Resultado da auditoria

Classifique cada gate:

- `ATENDIDO`
- `PARCIAL`
- `NÃO ATENDIDO`
- `INDETERMINADO`
- `NÃO APLICÁVEL`

Não dê nota única sem explicar quais falhas são potencialmente decisivas.
