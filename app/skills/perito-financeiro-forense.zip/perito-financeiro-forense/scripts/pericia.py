#!/usr/bin/env python3
# pff-version: 21.0
"""
pericia.py — biblioteca de cálculo da skill perito-financeiro-forense (v21.0).

Fonte ÚNICA de verdade para os cálculos citados nas references. O laudo deve
citar a função usada (ex.: `pericia.cet_regulatorio`) e os insumos — isso é o
que torna o número reproduzível por um segundo perito (NBC TP 01).

Uso típico (dentro de um script de análise):

    import sys; sys.path.insert(0, "<SKILL_DIR>/scripts")
    import pericia as pf
    pf.pmt_price(10000, 0.0213, 48)

Auto-teste:  python3 pericia.py --selftest

Convenções:
- Taxas em DECIMAL (0.0213 = 2,13% a.m.). Valores em float; arredondar só na
  apresentação (DEC_INTER = 8 casas nos intermediários).
- Datas: datetime.date.
- Nada aqui acessa a rede. Séries do BCB vêm de `bcb_sgs.py` ou do usuário.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, timedelta
from typing import Iterable, Sequence

__version__ = "21.0"

# ---------------------------------------------------------------------------
# Parâmetros centralizados (espelham §3 do SKILL.md)
# ---------------------------------------------------------------------------
PARAMS = {
    "TOL_SALDO": 1.00,          # R$
    "TOL_PCT": 0.1,             # %
    "TOL_TAXA": 0.05,           # p.p. a.m.
    "TOL_PARCELA": 0.50,        # R$
    "GAP_MAX": 60,              # dias
    "FATOR_ABSURDO": 10,
    "N_CONSECUTIVO": 3,
    "MULTA_PCT": 2.00,          # % (art. 52 §1º CDC)
    "JMORA_MAX": 1.00,          # % a.m. (Súmula 379/STJ)
    "PRESC_ANOS": 5,            # art. 206 §5º I CC
    "MIN_EXISTENCIAL": 600.00,  # R$ (Dec. 11.150/2022 c/ 11.567/2023; STF ADPFs 1.005/1.006/1.097)
    "TETO_CHEQUE_ESPECIAL": 0.08,  # 8% a.m. (Res. CMN 4.765/2019)
    "CET_ALERTA": 0.5,          # p.p. a.a.
    "CET_ALTA": 2.0,            # p.p. a.a.
    "DEC_INTER": 8,
}

DATA_TETO_ROTATIVO = date(2024, 1, 3)    # Lei 14.690/2023 art. 28; Res. CMN 5.112/2023
DATA_LEI_14905 = date(2024, 8, 30)       # novo art. 406 CC (taxa legal)


# ---------------------------------------------------------------------------
# Utilidades de parsing BR
# ---------------------------------------------------------------------------
def parse_valor_br(txt: str) -> float:
    """'1.234,56-' -> -1234.56 ; '(1.234,56)' -> -1234.56 ; '1.234,56 D' -> -1234.56.

    Corrige confusões comuns de OCR (O->0, l/I->1, R5/RS->R$).
    """
    s = str(txt).strip()
    if not s:
        raise ValueError("valor vazio")
    s = (s.replace("R$", "").replace("RS", "").replace("R5", "").replace("R§", "")
           .replace("–", "-").replace("−", "-").strip())
    neg = False
    if s.endswith("-") or s.startswith("-"):
        neg = True
        s = s.strip("-").strip()
    if s.startswith("(") and s.endswith(")"):
        neg = True
        s = s[1:-1]
    if s.upper().endswith(" D") or s.upper().endswith("D"):
        if s[:-1].strip().replace(".", "").replace(",", "").isdigit():
            neg = True
            s = s[:-1].strip()
    if s.upper().endswith(" C") or (s.upper().endswith("C") and s[:-1].strip().replace(".", "").replace(",", "").isdigit()):
        s = s[:-1].strip()
    s = s.replace("O", "0").replace("o", "0").replace("l", "1").replace("I", "1").replace(" ", "")
    if "," in s:
        s = s.replace(".", "").replace(",", ".")
    v = float(s)
    return -v if neg else v


def fmt_brl(v: float) -> str:
    """1234.5 -> 'R$ 1.234,50'"""
    sinal = "-" if v < 0 else ""
    inteiro, dec = f"{abs(v):,.2f}".split(".")
    return f"{sinal}R$ {inteiro.replace(',', '.')},{dec}"


def fmt_pct(v: float, casas: int = 4) -> str:
    """0.0213 -> '2,1300%'"""
    return f"{v*100:.{casas}f}%".replace(".", ",")


# ---------------------------------------------------------------------------
# Convenções de dias e conversão de taxas (Etapa 3.1–3.2)
# ---------------------------------------------------------------------------
def dias_30_360(d1: date, d2: date) -> int:
    """30/360 com ajuste de fim de mês (NASD/ISMA)."""
    dd1, dd2 = d1.day, d2.day
    if dd1 == 31:
        dd1 = 30
    if dd2 == 31 and dd1 >= 30:
        dd2 = 30
    return 360 * (d2.year - d1.year) + 30 * (d2.month - d1.month) + (dd2 - dd1)


def dias_corridos(d1: date, d2: date) -> int:
    return (d2 - d1).days


def mensal_para_anual(i_m: float) -> float:
    return (1 + i_m) ** 12 - 1


def anual_para_mensal(i_a: float) -> float:
    return (1 + i_a) ** (1 / 12) - 1


def nominal_para_efetiva(i_nom_anual: float, k: int = 12) -> float:
    return (1 + i_nom_anual / k) ** k - 1


def teste_duodecuplo(taxa_mensal: float, taxa_anual: float) -> dict:
    """Súmula 541/STJ: taxa anual > 12 × mensal => capitalização implicitamente pactuada."""
    return {
        "capitalizacao_pactuada": taxa_anual > 12 * taxa_mensal + 1e-12,
        "doze_vezes_mensal": 12 * taxa_mensal,
        "anual_informada": taxa_anual,
    }


def fator_juros(i_m: float, d1: date, d2: date, convencao: str = "30/360") -> float:
    """Fator de juros compostos pro rata entre d1 e d2 para taxa MENSAL i_m."""
    if convencao == "30/360":
        return (1 + i_m) ** (dias_30_360(d1, d2) / 30)
    if convencao in ("actual/365", "act/365"):
        return (1 + mensal_para_anual(i_m)) ** (dias_corridos(d1, d2) / 365)
    raise ValueError("convencao deve ser '30/360' ou 'actual/365' (DU/252 exige calendário ANBIMA)")


def _add_meses(d: date, n: int) -> date:
    y, m = divmod(d.month - 1 + n, 12)
    y += d.year
    m += 1
    ult = [31, 29 if (y % 4 == 0 and (y % 100 != 0 or y % 400 == 0)) else 28,
           31, 30, 31, 30, 31, 31, 30, 31, 30, 31][m - 1]
    return date(y, m, min(d.day, ult))


# ---------------------------------------------------------------------------
# Sistemas de amortização (Etapa 3.4)
# ---------------------------------------------------------------------------
def pmt_price(P: float, i: float, n: int) -> float:
    if i == 0:
        return P / n
    return P * i * (1 + i) ** n / ((1 + i) ** n - 1)


def tabela_amortizacao(P: float, i: float, n: int, sistema: str = "price",
                       data_liberacao: date | None = None, carencia: int = 0) -> list[dict]:
    """Tabela Price | SAC | SAM | americano. Carência = meses só de juros (pagos).

    SAM: parcela = média das parcelas Price e SAC calculadas sobre P; o saldo SAM, calculado
    pela própria recorrência (J = S·i; Amort = Parcela − J), é IDÊNTICO à média dos saldos Price
    e SAC (prova por indução; conferido no --selftest) — útil como verificação cruzada.
    """
    sistema = sistema.lower()
    linhas, s = [], P
    A = pmt_price(P, i, n)
    am_sac = P / n
    for k in range(1, carencia + 1):
        linhas.append({"n": -carencia + k - 1, "data": _add_meses(data_liberacao, k) if data_liberacao else None,
                       "parcela": s * i, "juros": s * i, "amortizacao": 0.0, "saldo": s, "carencia": True})
    for t in range(1, n + 1):
        j = s * i
        if sistema == "price":
            parc = A
        elif sistema == "sac":
            parc = am_sac + j
        elif sistema == "sam":
            s_sac_ant = P - am_sac * (t - 1)
            parc = (A + am_sac + s_sac_ant * i) / 2
        elif sistema == "americano":
            parc = j + (s if t == n else 0.0)
        else:
            raise ValueError("sistema: price|sac|sam|americano")
        amort = parc - j
        s = s - amort
        if t == n:
            s = 0.0 if abs(s) < 1e-6 else s
        linhas.append({"n": t,
                       "data": _add_meses(data_liberacao, carencia + t) if data_liberacao else None,
                       "parcela": parc, "juros": j, "amortizacao": amort, "saldo": s, "carencia": False})
    return linhas


def inferir_sistema(saldos_banco: Sequence[float], P: float, i: float, n: int) -> dict:
    """Etapa 4.1 — REQM de cada sistema contra os saldos do banco (t = 1..len)."""
    res = {}
    for sist in ("price", "sac", "sam"):
        tab = tabela_amortizacao(P, i, n, sist)
        m = min(len(saldos_banco), n)
        eqm = sum((saldos_banco[t] - tab[t]["saldo"]) ** 2 for t in range(m)) / m
        res[sist] = math.sqrt(eqm)
    ordem = sorted(res, key=res.get)
    r = res[ordem[0]] / res[ordem[1]] if res[ordem[1]] > 0 else 0.0
    veredito = ("forte evidência" if r < 0.5 else "indistinguíveis — rodar ambos como cenários" if r >= 0.9
                else "evidência moderada")
    return {"reqm": res, "melhor": ordem[0], "razao_1o_2o": r, "veredito": veredito}


# ---------------------------------------------------------------------------
# Inferência de taxa contratual e CET (Etapa 4.2–4.3)
# ---------------------------------------------------------------------------
def _meses_entre(d0: date, d: date) -> float:
    """Prazo em meses. Exato quando o dia do mês coincide; senão, dias/30,4375."""
    if d.day == d0.day:
        return (d.year - d0.year) * 12 + (d.month - d0.month)
    return (d - d0).days / 30.4375


def _resolver(f, lo: float, hi: float, tol: float = 1e-13, max_iter: int = 500) -> float | None:
    """Bisseção robusta (fallback do Newton-Raphson)."""
    flo, fhi = f(lo), f(hi)
    if flo * fhi > 0:
        return None
    for _ in range(max_iter):
        mid = (lo + hi) / 2
        fm = f(mid)
        if abs(fm) < 1e-12 or (hi - lo) / 2 < tol:
            return mid
        if flo * fm < 0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return (lo + hi) / 2


def taxa_contratual_mensal(fluxos: Sequence[float], datas: Sequence[date],
                           x0: float = 0.01, tol: float = 1e-12) -> float | None:
    """TIR MENSAL com prazo em meses-calendário (Newton-Raphson + bisseção de reserva).

    Use para inferir a TAXA CONTRATUAL (HC-01). Não use para comparar com o CET
    informado pelo banco — para isso, `cet_regulatorio` (Res. CMN 4.881/2020).
    fluxos: sinais opostos (ex.: -liberado em t0, +parcelas).
    """
    if len(fluxos) != len(datas) or len(fluxos) < 2:
        raise ValueError("fluxos e datas devem ter o mesmo tamanho (>= 2)")
    d0 = datas[0]
    meses = [_meses_entre(d0, d) for d in datas]

    def f(x):
        return sum(cf / (1 + x) ** m for cf, m in zip(fluxos, meses))

    x = x0
    for _ in range(200):
        fx = f(x)
        dfx = sum(-cf * m / (1 + x) ** (m + 1) for cf, m in zip(fluxos, meses))
        if abs(dfx) < 1e-15:
            break
        x1 = x - fx / dfx
        if x1 <= -0.99:
            break
        if abs(x1 - x) < tol:
            return x1
        x = x1
    return _resolver(f, -0.99, 10.0)


# Alias de compatibilidade com v19/v20 (references antigas citam este nome)
newton_raphson_taxa = taxa_contratual_mensal


def cet_regulatorio(fc0: float, pagamentos: Sequence[float], datas_pagamento: Sequence[date],
                    data_liberacao: date) -> dict:
    """CET pela fórmula da Res. CMN 4.881/2020 (art. 4º): dias corridos/365, base ANUAL.

    0 = -FC0 + Σ FC_j / (1+CET)^((d_j - d_0)/365)
    fc0 = valor LÍQUIDO liberado ao cliente (principal − IOF − tarifas − seguro financiados).
    Retorna CET anual e o equivalente mensal ((1+CET)^(1/12) − 1).
    """
    def f(c):
        return -fc0 + sum(p / (1 + c) ** ((d - data_liberacao).days / 365)
                          for p, d in zip(pagamentos, datas_pagamento))
    c = _resolver(f, -0.99, 1000.0)
    if c is None:
        return {"cet_anual": None, "cet_mensal_equiv": None, "metodo": "Res. CMN 4.881/2020 — sem raiz"}
    return {"cet_anual": c, "cet_mensal_equiv": (1 + c) ** (1 / 12) - 1,
            "metodo": "Res. CMN 4.881/2020, art. 4º (dias corridos/365, base anual)"}


def comparar_cet(cet_informado_aa: float, cet_recalculado_aa: float) -> dict:
    """Divergência em p.p. a.a. contra CET_ALERTA / CET_ALTA. Ambos DEVEM vir da Res. 4.881."""
    dpp = (cet_recalculado_aa - cet_informado_aa) * 100
    sev = ("ALTA" if abs(dpp) >= PARAMS["CET_ALTA"] else
           "ALERTA" if abs(dpp) >= PARAMS["CET_ALERTA"] else "DENTRO DA TOLERÂNCIA")
    return {"diferenca_pp_aa": dpp, "classificacao": sev}


def xirr(fluxos: Sequence[float], datas: Sequence[date]) -> float | None:
    """TIR anual para datas irregulares (actual/365)."""
    d0 = datas[0]

    def f(r):
        return sum(cf / (1 + r) ** ((d - d0).days / 365) for cf, d in zip(fluxos, datas))
    return _resolver(f, -0.99, 1000.0)


def inferir_taxa_painel(saldos: Sequence[float], pmt: float, delta_pagas: Sequence[int]) -> dict:
    """Etapa 4.4 — taxa via painel de crédito mensal (sem contrato/demonstrativo).

    saldos: S_0..S_n (snapshot do painel); delta_pagas[t]: parcelas pagas entre t-1 e t (len n).
    """
    taxas, acru = [], []
    for t in range(1, len(saldos)):
        s_ant, s = saldos[t - 1], saldos[t]
        if s_ant <= 0:
            continue
        if delta_pagas[t - 1] == 1:
            taxas.append((s + pmt - s_ant) / s_ant)
        elif delta_pagas[t - 1] == 0:
            acru.append((s - s_ant) / s_ant)
    mediana = None
    if taxas:
        ts = sorted(taxas)
        k = len(ts)
        mediana = ts[k // 2] if k % 2 else (ts[k // 2 - 1] + ts[k // 2]) / 2
    return {"taxa_mediana": mediana, "n_obs": len(taxas), "taxas": taxas, "acruamento": acru,
            "confianca": "média" if len(taxas) >= 3 else "baixa (< 3 observações)",
            "rotulo": "[INFERIDO — método painel]"}


# ---------------------------------------------------------------------------
# Recálculo linha a linha (SA-3) e waterfall (Etapa 3.3–3.6)
# ---------------------------------------------------------------------------
ORDEM_WATERFALL_LEGAL = ["juros_moratorios", "juros_remun_vencidos", "juros_remun_correntes", "principal"]
ORDEM_WATERFALL_BANCARIO = ["iof", "multa", "juros_moratorios", "juros_remun_vencidos",
                            "juros_remun_correntes", "principal", "encargos_futuros"]
_JUROS_KEYS = {"juros_moratorios", "juros_remun_vencidos", "juros_remun_correntes"}


def aplicar_waterfall(pgto: float, componentes: dict, ordem: Sequence[str], tol: float = 1e-9) -> dict:
    """Aloca pagamento por prioridade. Marca amortização negativa quando pgto < juros devidos."""
    rem = pgto
    aloc = {k: 0.0 for k in componentes}
    for c in ordem:
        if c not in componentes:
            continue
        a = min(rem, componentes[c])
        aloc[c] = a
        rem -= a
        if rem <= tol:
            break
    juros = sum(v for k, v in componentes.items() if k in _JUROS_KEYS)
    aloc["remanescente"] = max(0.0, rem)
    aloc["amort_efetiva"] = aloc.get("principal", 0.0)
    aloc["amort_negativa"] = pgto < juros - tol
    aloc["juros_nao_cobertos"] = max(0.0, juros - pgto)
    return aloc


def recalcular_saldo(saldo_inicial: float, data_inicial: date, eventos: Iterable[dict],
                     taxa_mensal: float, convencao: str = "30/360",
                     capitalizacao: str = "composta") -> list[dict]:
    """Recalcula o saldo devedor evento a evento.

    eventos: dicts com 'data' (date), 'valor' (float, POSITIVO = pagamento/crédito que
    reduz o saldo; NEGATIVO = encargo legítimo/desembolso que aumenta) e opcionalmente
    'descricao', 'saldo_banco'.

    capitalizacao='composta' (padrão): juros acruam sobre o saldo total entre eventos.
    capitalizacao='simples' (cenário E, "sem anatocismo"): juros simples sobre o CAPITAL
    remanescente; juros vencidos e não pagos ficam numa conta separada e NUNCA rendem juros;
    pagamento quita primeiro os juros pendentes e depois o capital (art. 354 CC).
    (Juros simples sobre o principal ORIGINAL — versões ≤ v20 — superestima os juros depois
    das primeiras amortizações; não use.)
    """
    s, d_ant, out = saldo_inicial, data_inicial, []
    capital, juros_pend = saldo_inicial, 0.0
    for k, ev in enumerate(sorted(eventos, key=lambda e: e["data"])):
        d = ev["data"]
        v = ev["valor"]
        if capitalizacao == "composta":
            j = s * (fator_juros(taxa_mensal, d_ant, d, convencao) - 1)
            s = s + j - v
        else:
            meses = dias_30_360(d_ant, d) / 30 if convencao == "30/360" else dias_corridos(d_ant, d) * 12 / 365
            j = capital * taxa_mensal * meses
            juros_pend += j
            if v >= 0:
                pago_juros = min(v, juros_pend)
                juros_pend -= pago_juros
                capital -= v - pago_juros
            else:
                capital += -v           # novo desembolso/encargo legítimo entra no capital
            s = capital + juros_pend
        linha = {"linha": k + 1, "data": d, "descricao": ev.get("descricao", ""),
                 "juros_periodo": j, "movimento": v, "saldo_calc": s,
                 "amort_negativa": 0 < v < j}
        if capitalizacao != "composta":
            linha.update({"capital": capital, "juros_pendentes": juros_pend})
        if "saldo_banco" in ev and ev["saldo_banco"] is not None:
            linha.update(comparar_linha(ev["saldo_banco"], s))
            linha["saldo_banco"] = ev["saldo_banco"]
        out.append(linha)
        d_ant = d
    return out


# ---------------------------------------------------------------------------
# Comparação e severidade (Etapa 6)
# ---------------------------------------------------------------------------
def calcular_dif_pct(dif: float, saldo_calc: float, saldo_banco: float, tol: float = 1.0) -> float:
    if abs(saldo_calc) > tol:
        return dif / abs(saldo_calc) * 100
    if abs(saldo_banco) > tol:
        return dif / abs(saldo_banco) * 100
    return 0.0


_ORD_SEV = {"ARREDONDAMENTO": 0, "BAIXA": 1, "MÉDIA": 2, "ALTA": 3}


def severidade(dif: float, dif_pct: float) -> str:
    """Duplo critério (absoluto E relativo) — prevalece o MAIOR."""
    a = abs(dif)
    sa = ("ARREDONDAMENTO" if a < PARAMS["TOL_SALDO"] else "BAIXA" if a < 100 else
          "MÉDIA" if a < 1000 else "ALTA")
    p = abs(dif_pct)
    sr = ("ARREDONDAMENTO" if p < PARAMS["TOL_PCT"] else "BAIXA" if p < 1 else
          "MÉDIA" if p < 5 else "ALTA")
    return sa if _ORD_SEV[sa] >= _ORD_SEV[sr] else sr


def comparar_linha(saldo_banco: float, saldo_calc: float) -> dict:
    dif = saldo_banco - saldo_calc
    pct = calcular_dif_pct(dif, saldo_calc, saldo_banco, PARAMS["TOL_SALDO"])
    return {"dif": dif, "dif_pct": pct, "severidade": severidade(dif, pct)}


# ---------------------------------------------------------------------------
# IOF PF (Decreto 6.306/2007) — §3.8
# ---------------------------------------------------------------------------
IOF_ADICIONAL = 0.0038
IOF_DIARIO_PF = 0.000082


def iof_operacao(principal: float, dias: int, diaria: float = IOF_DIARIO_PF,
                 adicional: float = IOF_ADICIONAL, teto_dias: int = 365) -> dict:
    """IOF de operação com prazo único: adicional 0,38% + 0,0082%/dia (teto 365 dias = 2,993%;
    máximo efetivo 3,373% — não 3,38%)."""
    d = min(dias, teto_dias)
    return {"iof_adicional": principal * adicional, "iof_diario": principal * diaria * d,
            "iof_total": principal * (adicional + diaria * d), "dias_considerados": d}


def iof_parcelado(amortizacoes: Sequence[float], datas_venc: Sequence[date], data_liberacao: date,
                  principal: float, diaria: float = IOF_DIARIO_PF, adicional: float = IOF_ADICIONAL) -> dict:
    """IOF de operação parcelada: alíquota diária sobre CADA amortização × dias até o
    vencimento (teto 365), + adicional sobre o principal. Base = principal (não parcela)."""
    diario = sum(a * diaria * min((d - data_liberacao).days, 365)
                 for a, d in zip(amortizacoes, datas_venc))
    return {"iof_adicional": principal * adicional, "iof_diario": diario,
            "iof_total": principal * adicional + diario}


# ---------------------------------------------------------------------------
# Mora (§4.5) e juros legais do art. 406 CC
# ---------------------------------------------------------------------------
def multa_moratoria(prestacao_vencida: float, pct: float | None = None) -> float:
    return prestacao_vencida * (PARAMS["MULTA_PCT"] if pct is None else pct) / 100


def juros_mora_contratual(prestacao_vencida: float, dias_mora: int, taxa_mensal: float = 0.01,
                          convencao: str = "30/360", composta: bool = False) -> float:
    """Juros moratórios pactuados, limitados a 1% a.m. (Súmula 379/STJ), sobre a PRESTAÇÃO vencida.

    Regra: juros de mora SIMPLES, pro rata (30/360: dias/30; actual/365: 12·dias/365).
    composta=True só como cenário de sensibilidade quando o contrato prever capitalização da
    mora expressamente — e isso deve ser apontado (capitalizar mora = anatocismo, HC-02/HC-27).
    """
    i = min(taxa_mensal, PARAMS["JMORA_MAX"] / 100)
    meses = dias_mora / 30 if convencao == "30/360" else dias_mora * 12 / 365
    if not composta:
        return prestacao_vencida * i * meses
    return prestacao_vencida * ((1 + i) ** meses - 1)


def pmt_gauss(P: float, i: float, n: int) -> float:
    """Parcela fixa a juros SIMPLES (método de Gauss), usada em revisionais como alternativa
    sem capitalização ao Price: PMT = P·(1 + i·n) / (n + i·n·(n−1)/2).
    Identidade: Σ_k PMT·(1 + i·(n−k)) = P·(1 + i·n)."""
    return P * (1 + i * n) / (n + i * n * (n - 1) / 2)


def liquidacao_antecipada(parcelas_restantes: Sequence[float], datas_venc: Sequence[date],
                          data_liquidacao: date, taxa_mensal: float) -> dict:
    """Valor de quitação = VALOR PRESENTE das parcelas a vencer descontadas à TAXA PACTUADA
    (Res. CMN 5.004/2022, art. 7º — PF, operações prefixadas; art. 52 §2º CDC).
    Prazo em meses-calendário a partir da data da liquidação. Para Price em dia, coincide com o
    saldo devedor da tabela (+ juros pro rata desde o último vencimento).
    HC-09 quando o banco cobra acima deste valor (ex.: soma nominal das parcelas)."""
    vp = sum(p / (1 + taxa_mensal) ** _meses_entre(data_liquidacao, d)
             for p, d in zip(parcelas_restantes, datas_venc))
    return {"valor_quitacao": vp, "soma_nominal": sum(parcelas_restantes),
            "desconto_obrigatorio": sum(parcelas_restantes) - vp,
            "metodo": "VP à taxa pactuada (Res. CMN 5.004/2022, art. 7º)"}


def impacto_divergencias(difs: Sequence[float], datas: Sequence[date] | None = None,
                         fator_ate_ref=None) -> dict:
    """Impacto correto a partir da série de diferenças de SALDO (Dif_t = banco − calculado).

    Dif_t é um ESTOQUE: já acumula tudo o que divergiu até t. Somar Dif_t ao longo das linhas
    conta a mesma divergência várias vezes. O que se soma são as divergências NOVAS de cada
    período, δ_t = Dif_t − Dif_{t−1} (Dif_0 = 0):
      impacto direcional acumulado até t = Σ δ = Dif_t
      impacto absoluto                    = Σ |δ_t|
      impacto atualizado (VP/Selic)       = Σ δ_t · Fator(data_t → data_ref)
    fator_ate_ref: função date -> fator acumulado (ex.: lambda d: bcb_sgs.fator_acumulado(11, ...)).
    """
    deltas, ant = [], 0.0
    for d in difs:
        deltas.append(d - ant)
        ant = d
    out = {"deltas": deltas, "impacto_direcional": difs[-1] if difs else 0.0,
           "impacto_absoluto": sum(abs(x) for x in deltas)}
    if fator_ate_ref and datas:
        out["impacto_atualizado"] = sum(x * fator_ate_ref(dt) for x, dt in zip(deltas, datas))
    return out


def _meses_no_intervalo(d1: date, d2: date) -> list[tuple[str, float]]:
    """Lista (AAAA-MM, fração do mês) entre d1 (exclusive) e d2 (inclusive), pro rata por dias."""
    out, cur = [], d1
    while cur < d2:
        prox = _add_meses(date(cur.year, cur.month, 1), 1)
        fim = min(prox, d2)
        dias_mes = (prox - date(cur.year, cur.month, 1)).days
        out.append((f"{cur.year:04d}-{cur.month:02d}", (fim - cur).days / dias_mes))
        cur = fim
    return out


def mora_legal_art406(valor: float, d_ini: date, d_fim: date, selic_mensal: dict,
                      taxa_legal_mensal: dict, ipca_mensal: dict) -> dict:
    """Juros legais do art. 406 CC quando NÃO há mora pactuada, segmentados em 30/08/2024.

    - até 29/08/2024: Selic acumulada SEM correção separada (Tema 1.368/STJ; bis in idem);
    - desde 30/08/2024: taxa legal (Selic − IPCA-15, juros simples, piso 0 — Res. CMN 5.171/2024)
      + correção pelo IPCA em separado (art. 389 §ú).
    Séries: dict 'AAAA-MM' -> taxa decimal do mês (ex.: 0.0105). Selic somada (juros simples,
    padrão de cálculos judiciais) — declarar [PREMISSA] se o juízo adotar outra forma.
    Mês ausente na série => KeyError (não inventar dado).
    """
    corte = DATA_LEI_14905 - timedelta(days=1)     # 29/08/2024
    r = {"juros_selic_pre": 0.0, "juros_taxa_legal_pos": 0.0, "correcao_ipca_pos": 0.0, "segmentos": []}
    if d_ini < DATA_LEI_14905:
        fim_pre = min(d_fim, corte)
        soma = sum(selic_mensal[m] * fr for m, fr in _meses_no_intervalo(d_ini, fim_pre))
        r["juros_selic_pre"] = valor * soma
        r["segmentos"].append(("Selic integral (sem correção)", d_ini, fim_pre, soma))
    if d_fim >= DATA_LEI_14905:
        ini_pos = max(d_ini, corte)
        meses = _meses_no_intervalo(ini_pos, d_fim)
        fator_ipca = 1.0
        for m, fr in meses:
            fator_ipca *= (1 + ipca_mensal[m]) ** fr
        base_corrigida = valor * fator_ipca
        soma_tl = sum(max(0.0, taxa_legal_mensal[m]) * fr for m, fr in meses)
        r["correcao_ipca_pos"] = valor * (fator_ipca - 1)
        r["juros_taxa_legal_pos"] = base_corrigida * soma_tl
        r["segmentos"].append(("Taxa legal + IPCA", ini_pos, d_fim, soma_tl))
    r["total_encargos"] = r["juros_selic_pre"] + r["juros_taxa_legal_pos"] + r["correcao_ipca_pos"]
    return r


# ---------------------------------------------------------------------------
# Testes regulatórios parametrizados (§5-T1, §5-T2, §5-T3) e checagens rápidas
# ---------------------------------------------------------------------------
def verificar_teto_rotativo(valor_original: float, juros_encargos_sem_iof: float,
                            data_origem: date | None = None, tol: float | None = None) -> dict:
    """§5-T1 — juros + encargos financeiros (= multa e juros de mora; Res. 4.549 art. 2º-A, III, red.
    Res. 5.112/2023 — IOF e tarifas NÃO entram) ≤ 100% do valor original.

    Só para dívida de cartão (rotativo/parcelamento de fatura) com origem ≥ 03/01/2024.
    Origem anterior => 'nao_aplicavel' (nunca aplicar retroativamente).
    """
    tol = PARAMS["TOL_SALDO"] if tol is None else tol
    if data_origem is not None and data_origem < DATA_TETO_ROTATIVO:
        return {"aplicavel": False, "violacao": False,
                "motivo": f"origem {data_origem:%d/%m/%Y} < 03/01/2024 — teto não retroage"}
    excesso = juros_encargos_sem_iof - valor_original
    return {"aplicavel": True, "violacao": excesso > tol, "teto": valor_original,
            "cobrado_sem_iof": juros_encargos_sem_iof, "excesso": max(0.0, excesso),
            "data_origem_declarada": data_origem is not None}


def verificar_divida_perpetua_rmc(saldo: float, pgto_min: float, taxa_mensal: float,
                                  n_meses: int = 60) -> dict:
    """§5-T2 — o desconto mínimo amortiza o saldo em horizonte finito? (HC-29; Tema 1.414)."""
    s = saldo
    for k in range(1, n_meses + 1):
        juros = s * taxa_mensal
        amort = pgto_min - juros
        if amort <= 0:
            return {"perpetua": True, "motivo": f"desconto <= juros no mês {k}",
                    "meses_para_quitacao": None, "juros_mes1": saldo * taxa_mensal}
        s -= amort
        if s <= 0:
            return {"perpetua": False, "meses_para_quitacao": k}
    return {"perpetua": True, "motivo": f"saldo remanescente após {n_meses}m: {s:.2f}",
            "meses_para_quitacao": None}


def meses_para_quitar(saldo: float, pgto: float, taxa_mensal: float) -> float | None:
    """Prazo analítico (Price) para quitar com pagamento fixo; None se pgto <= juros."""
    if pgto <= saldo * taxa_mensal:
        return None
    if taxa_mensal == 0:
        return saldo / pgto
    return -math.log(1 - saldo * taxa_mensal / pgto) / math.log(1 + taxa_mensal)


def verificar_minimo_existencial(renda_liquida: float, parcelas: dict, piso: float | None = None,
                                 despesas_essenciais_provadas: float | None = None) -> dict:
    """§5-T3 — renda − TODAS as parcelas (consignado INCLUÍDO — STF ADPFs 1.005/1.006/1.097)
    deve preservar o mínimo existencial (R$ 600, salvo revisão do CMN ou piso provado)."""
    piso = PARAMS["MIN_EXISTENCIAL"] if piso is None else piso
    total = sum(parcelas.values())
    piso_ef = max(piso, despesas_essenciais_provadas or 0.0)
    sobra = renda_liquida - total
    return {"violacao": sobra < piso_ef, "renda_liquida": renda_liquida, "total_parcelas": total,
            "comprometimento_pct": total / renda_liquida * 100 if renda_liquida else None,
            "sobra": sobra, "piso_aplicado": piso_ef, "deficit": max(0.0, piso_ef - sobra)}


# Série temporal das margens consignáveis (aplicar a vigente na data da contratação).
# (inicio, fim_inclusivo, regime, emprestimo%, cartoes%, fonte)
MARGENS = [
    (date(2015, 11, 5), date(2022, 8, 3), "geral", 30, 5, "Lei 13.172/2015 (35%)"),
    (date(2022, 8, 4), date(2099, 12, 31), "geral", 35, 5, "Lei 14.431/2022 (40%) — inclui CLT (Lei 10.820 art. 1º §1º)"),
    (date(2022, 8, 4), date(2023, 6, 18), "inss", 35, 5, "Lei 14.431/2022 (40%)"),
    (date(2023, 6, 19), date(2026, 5, 3), "inss", 35, 10, "Lei 14.601/2023 (45% = 35 + 5 RMC + 5 RCC) [conferir data de vigência]"),
    (date(2026, 5, 4), date(2026, 8, 31), "inss", 30, 10, "MP 1.355/2026 — janela de eficácia (40%; distribuição 30+5+5 por fonte secundária) [CF art. 62 §11]"),
    (date(2026, 9, 1), date(2099, 12, 31), "inss", 35, 10, "Lei 14.601/2023 restabelecida (MP 1.355 sem eficácia desde 01/09/2026)"),
]


def margem_vigente(data_contratacao: date, regime: str = "inss") -> dict:
    """Margem consignável vigente na data da contratação. regime: 'inss' | 'geral' | 'clt'."""
    reg = "geral" if regime in ("geral", "clt", "servidor") else regime
    for ini, fim, r, emp, cart, fonte in MARGENS:
        if r == reg and ini <= data_contratacao <= fim:
            return {"emprestimo_pct": emp, "cartoes_pct": cart, "total_pct": emp + cart, "fonte": fonte}
    return {"emprestimo_pct": None, "cartoes_pct": None, "total_pct": None,
            "fonte": "data fora da série — pesquisar a norma vigente e declarar [PREMISSA]"}


def verificar_margem(renda_base: float, parcelas_emprestimo: float, parcelas_cartao: float,
                     data_contratacao: date, regime: str = "inss") -> dict:
    """HC-18 — margem excedida na data da contratação."""
    m = margem_vigente(data_contratacao, regime)
    if m["total_pct"] is None:
        return {"aplicavel": False, **m}
    lim_emp = renda_base * m["emprestimo_pct"] / 100
    lim_cart = renda_base * m["cartoes_pct"] / 100
    return {"aplicavel": True, **m, "limite_emprestimo": lim_emp, "limite_cartoes": lim_cart,
            "excesso_emprestimo": max(0.0, parcelas_emprestimo - lim_emp),
            "excesso_cartoes": max(0.0, parcelas_cartao - lim_cart),
            "violacao": parcelas_emprestimo > lim_emp + 0.005 or parcelas_cartao > lim_cart + 0.005}


def verificar_cheque_especial(taxa_mensal_efetiva: float, limite: float | None = None,
                              tarifa_limite: float = 0.0) -> dict:
    """HC-19 — teto 8% a.m.; tarifa só sobre a parcela do limite > R$ 500, máx. 0,25% a.m."""
    tarifa_max = max(0.0, (limite or 0) - 500) * 0.0025
    return {"acima_do_teto": taxa_mensal_efetiva > PARAMS["TETO_CHEQUE_ESPECIAL"] + 1e-12,
            "tarifa_maxima": tarifa_max, "tarifa_excedente": max(0.0, tarifa_limite - tarifa_max)}


def prescricao(data_fato: date, data_ref: date, anos: int | None = None) -> dict:
    """Art. 206 §5º I CC — cada lançamento é fato gerador autônomo."""
    anos = PARAMS["PRESC_ANOS"] if anos is None else anos
    try:
        limite = data_fato.replace(year=data_fato.year + anos)
    except ValueError:                       # 29/02
        limite = data_fato.replace(year=data_fato.year + anos, day=28)
    st = "[POSSIVELMENTE PRESCRITO]" if data_ref > limite else "[DENTRO DO PRAZO]"
    return {"status": st, "prazo_final": limite}


# ---------------------------------------------------------------------------
# Score de qualidade (§4.8)
# ---------------------------------------------------------------------------
def score_qualidade(obrig_ausente_pct: Sequence[float] = (), desej_ausente_pct: Sequence[float] = (),
                    testes_criticos_reprovados: int = 0, testes_compl_reprovados: int = 0,
                    anomalias_alta: int = 0, anomalias_media: int = 0,
                    extrato_parcial: bool = False, gaps_3m: int = 0) -> dict:
    pen = 0
    for p in obrig_ausente_pct:
        pen += 15 if p > 10 else 8 if p >= 5 else 0
    pen += sum(3 for p in desej_ausente_pct if p > 50)
    pen += 12 * testes_criticos_reprovados + 5 * testes_compl_reprovados
    pen += min(25, 5 * anomalias_alta) + min(10, 2 * anomalias_media)
    pen += (10 if extrato_parcial else 0) + 8 * gaps_3m
    s = max(0, 100 - pen)
    cls = ("ALTA" if s >= 80 else "MÉDIA" if s >= 60 else "BAIXA" if s >= 40 else "INSUFICIENTE")
    return {"score": s, "classificacao": cls}


# ---------------------------------------------------------------------------
# Exportação XLSX (tabelas do §8.C)
# ---------------------------------------------------------------------------
def exportar_xlsx(tabelas: dict, caminho: str, titulo: str | None = None) -> str:
    """tabelas: {'Tabela 2 - Evolucao': [dict, ...], ...} -> .xlsx formatado (openpyxl).

    Datas viram dd/mm/aaaa; floats com 2 casas; cabeçalho em negrito e congelado.
    """
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    wb.remove(wb.active)
    for nome, linhas in tabelas.items():
        ws = wb.create_sheet(title=str(nome)[:31])
        if not linhas:
            ws.append(["(sem dados)"])
            continue
        cols = list(dict.fromkeys(k for l in linhas for k in l))
        ws.append(cols)
        for c in ws[1]:
            c.font = Font(bold=True, color="FFFFFF")
            c.fill = PatternFill("solid", fgColor="1F3864")
            c.alignment = Alignment(wrap_text=True, vertical="center")
        for l in linhas:
            row = []
            for k in cols:
                v = l.get(k)
                if isinstance(v, date):
                    v = v.strftime("%d/%m/%Y")
                elif isinstance(v, (list, tuple, dict)):
                    v = str(v)
                row.append(v)
            ws.append(row)
        for j, k in enumerate(cols, 1):
            larg = max(len(str(k)), *(len(str(ws.cell(row=i, column=j).value or "")) for i in range(2, min(ws.max_row, 200) + 1)))
            ws.column_dimensions[get_column_letter(j)].width = min(60, max(10, larg + 2))
            for i in range(2, ws.max_row + 1):
                cell = ws.cell(row=i, column=j)
                if isinstance(cell.value, float):
                    cell.number_format = "#,##0.00"
        ws.freeze_panes = "A2"
    if titulo:
        wb.properties.title = titulo
    wb.save(caminho)
    return caminho


# ---------------------------------------------------------------------------
# Auto-teste (Anexo W) — rodar após qualquer alteração
# ---------------------------------------------------------------------------
def _selftest() -> int:
    falhas = []

    def ok(cond, nome):
        if not cond:
            falhas.append(nome)

    # Valores BR / OCR
    ok(parse_valor_br("1.234,56-") == -1234.56, "parse débito sufixo")
    ok(parse_valor_br("R$ 1.O00,00") == 1000.0, "parse OCR O->0")
    ok(parse_valor_br("(2.500,00)") == -2500.0, "parse parênteses")
    ok(parse_valor_br("350,00 D") == -350.0, "parse D")
    # 30/360
    ok(dias_30_360(date(2024, 1, 31), date(2024, 2, 29)) == 29, "30/360 fim de mês")
    ok(dias_30_360(date(2024, 1, 15), date(2024, 2, 15)) == 30, "30/360 mês cheio")
    # Price
    ok(abs(pmt_price(1000, 0.01, 12) - 88.84878867) < 1e-6, "PMT Price")
    tab = tabela_amortizacao(1000, 0.01, 12, "price")
    ok(abs(tab[-1]["saldo"]) < 1e-6, "Price zera saldo")
    sac = tabela_amortizacao(1200, 0.01, 12, "sac")
    ok(abs(sac[0]["parcela"] - 112.0) < 1e-9 and abs(sac[-1]["saldo"]) < 1e-6, "SAC")
    sam = tabela_amortizacao(1200, 0.01, 12, "sam")
    ok(abs(sam[0]["parcela"] - (pmt_price(1200, .01, 12) + 112.0) / 2) < 1e-9, "SAM parcela 1")
    # Newton-Raphson em meses-calendário (viés zerado)
    P, i, n = 1000.0, 0.01, 12
    pmt = pmt_price(P, i, n)
    datas = [date(2024, 1, 15)] + [_add_meses(date(2024, 1, 15), k) for k in range(1, n + 1)]
    r = taxa_contratual_mensal([-P] + [pmt] * n, datas)
    ok(r is not None and abs(r - 0.01) < 1e-9, "NR meses-calendário")
    # CET regulatório (Res. 4.881) vs (1+r)^12-1 — difere ligeiramente (≈ -0,008 p.p.)
    cet = cet_regulatorio(P, [pmt] * n, datas[1:], datas[0])["cet_anual"]
    ok(abs((cet - mensal_para_anual(0.01)) * 100 + 0.0078) < 0.002, "CET 4.881 reconciliação")
    # CET com IOF/tarifa financiados: CET > taxa
    cet2 = cet_regulatorio(P - 30, [pmt] * n, datas[1:], datas[0])["cet_anual"]
    ok(cet2 > mensal_para_anual(0.01), "CET > taxa quando há custos")
    # XIRR
    x = xirr([-1000, 1100], [date(2023, 1, 1), date(2024, 1, 1)])
    ok(abs(x - 0.10) < 1e-9, "XIRR 1 ano")
    # Waterfall
    w = aplicar_waterfall(50, {"juros_remun_correntes": 80, "principal": 1000}, ORDEM_WATERFALL_LEGAL)
    ok(w["amort_negativa"] and abs(w["juros_nao_cobertos"] - 30) < 1e-9, "waterfall amort. negativa")
    # Recalculo: Price pago em dia reproduz saldo da tabela
    evs = [{"data": datas[k], "valor": pmt} for k in range(1, n + 1)]
    rc = recalcular_saldo(P, datas[0], evs, 0.01, "30/360")
    ok(abs(rc[-1]["saldo_calc"]) < 1e-6, "recalculo Price 30/360")
    # Severidade dual
    ok(severidade(50, 6.0) == "ALTA" and severidade(0.5, 0.01) == "ARREDONDAMENTO", "severidade dual")
    ok(calcular_dif_pct(0.3, 0.2, 0.5) == 0.0, "dif_pct zero")
    # IOF
    io = iof_operacao(10000, 400)
    ok(abs(io["iof_total"] - 337.30) < 1e-6, "IOF teto 365d (0,38% + 2,993%)")
    # Teto rotativo (§5-T1)
    t = verificar_teto_rotativo(5000, 5800, date(2024, 5, 1))
    ok(t["violacao"] and abs(t["excesso"] - 800) < 1e-9, "teto violado")
    ok(not verificar_teto_rotativo(5000, 5800, date(2023, 12, 1))["aplicavel"], "teto não retroage")
    ok(not verificar_teto_rotativo(5000, 4900, date(2024, 5, 1))["violacao"], "teto respeitado")
    # Dívida perpétua (§5-T2)
    ok(verificar_divida_perpetua_rmc(3000, 300, 0.035)["meses_para_quitacao"] == 13, "RMC quita 13m")
    ok(verificar_divida_perpetua_rmc(5000, 150, 0.03)["perpetua"], "RMC perpétua")
    # Mínimo existencial (§5-T3)
    m = verificar_minimo_existencial(2000, {"consignado": 700, "cartao": 500, "cheque": 300})
    ok(m["violacao"] and abs(m["deficit"] - 100) < 1e-9, "mínimo existencial")
    # Margem
    ok(margem_vigente(date(2026, 6, 10), "inss")["total_pct"] == 40, "margem janela MP")
    ok(margem_vigente(date(2026, 9, 10), "inss")["total_pct"] == 45, "margem pós-MP")
    ok(margem_vigente(date(2025, 10, 1), "clt")["total_pct"] == 40, "margem CLT 40")
    # Cheque especial
    ok(verificar_cheque_especial(0.081)["acima_do_teto"], "cheque teto")
    # Duodécuplo
    ok(teste_duodecuplo(0.02, 0.2682)["capitalizacao_pactuada"], "Súmula 541")
    # Prescrição
    ok(prescricao(date(2020, 1, 10), date(2026, 10, 10))["status"] == "[POSSIVELMENTE PRESCRITO]", "prescrição")
    # Mora legal segmentada (séries fictícias só para o teste)
    sel = {f"2024-{m:02d}": 0.01 for m in range(1, 13)}
    tl = {f"2024-{m:02d}": 0.006 for m in range(8, 13)}
    ip = {f"2024-{m:02d}": 0.004 for m in range(8, 13)}
    ml = mora_legal_art406(1000, date(2024, 7, 31), date(2024, 9, 30), sel, tl, ip)
    ok(ml["juros_selic_pre"] > 0 and ml["juros_taxa_legal_pos"] > 0 and ml["correcao_ipca_pos"] > 0,
       "art. 406 segmentado")
    # Painel
    pn = inferir_taxa_painel([10000, 9800, 9595.2, 9385.0], 400, [1, 1, 1])
    ok(pn["taxa_mediana"] is not None and abs(pn["taxa_mediana"] - 0.02) < 0.001, "taxa via painel")
    # Score
    ok(score_qualidade(testes_criticos_reprovados=1)["score"] == 88, "score")

    # SAM: saldo = média dos saldos Price e SAC (identidade)
    pr, sc, sm = (tabela_amortizacao(1200, .01, 12, x) for x in ("price", "sac", "sam"))
    ok(all(abs(sm[t]["saldo"] - (pr[t]["saldo"] + sc[t]["saldo"]) / 2) < 1e-9 for t in range(12)), "SAM = média dos saldos")
    # Gauss: identidade Σ PMT(1+i(n−k)) = P(1+in)
    g = pmt_gauss(12000, 0.0249, 24)
    ok(abs(sum(g * (1 + 0.0249 * (24 - k)) for k in range(1, 25)) - 12000 * (1 + 0.0249 * 24)) < 1e-6, "Gauss")
    # Juros simples sobre capital remanescente: com parcelas que cobrem os juros do mês NÃO há
    # capitalização — o resultado coincide com o Price composto (saldo final 0).
    rs = recalcular_saldo(P, datas[0], evs, 0.01, "30/360", "simples")
    ok(abs(rs[-1]["saldo_calc"]) < 1e-6, "simples = Price quando os juros são pagos")
    # Com pagamento < juros (amortização negativa) a diferença aparece: simples < composta
    ev_baixo = [{"data": datas[k], "valor": 5.0} for k in range(1, n + 1)]
    sc_ = recalcular_saldo(P, datas[0], ev_baixo, 0.01, "30/360", "simples")[-1]["saldo_calc"]
    cp_ = recalcular_saldo(P, datas[0], ev_baixo, 0.01, "30/360", "composta")[-1]["saldo_calc"]
    ok(abs(sc_ - (1000 + 12 * 10 - 60)) < 1e-6 and cp_ > sc_, "anatocismo só com juros não pagos")
    # Mora simples (padrão) e composta (sensibilidade)
    ok(abs(juros_mora_contratual(1000, 30) - 10.0) < 1e-9, "mora simples 30d")
    ok(abs(juros_mora_contratual(1000, 365, convencao="actual/365") - 120.0) < 1e-9, "mora simples 365d")
    ok(juros_mora_contratual(1000, 365, convencao="actual/365", composta=True) > 120.0, "mora composta > simples")
    # Liquidação antecipada: VP das parcelas restantes à taxa pactuada = saldo Price após k parcelas
    k = 5
    la = liquidacao_antecipada([pmt] * (n - k), datas[k + 1:], datas[k], 0.01)
    ok(abs(la["valor_quitacao"] - tab[k - 1]["saldo"]) < 1e-6, "liquidação = saldo Price")
    # Impacto: Σδ = Dif final; somar Dif_t superestima
    im = impacto_divergencias([10, 25, 25, 40])
    ok(im["impacto_direcional"] == 40 and abs(sum(im["deltas"]) - 40) < 1e-12 and im["impacto_absoluto"] == 40, "impacto δ")

    total = 43
    if falhas:
        print(f"FALHOU {len(falhas)}/{total}: " + "; ".join(falhas))
        return 1
    print(f"pericia.py v{__version__}: {total}/{total} auto-testes aprovados")
    return 0


if __name__ == "__main__":
    import sys
    if "--selftest" in sys.argv:
        sys.exit(_selftest())
    print(__doc__)
