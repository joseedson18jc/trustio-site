#!/usr/bin/env python3
"""
gerar_peca.py — converte uma peça/parecer escrito em Markdown em DOCX + PDF
com formatação forense brasileira.

Uso:
    python3 gerar_peca.py entrada.md [--saida DIR] [--nome BASE]
                          [--cabecalho "Texto do cabeçalho"]
                          [--sem-aviso] [--aviso "texto"]

Gera BASE.docx e BASE.pdf na pasta de saída (padrão: pasta do .md).

Formatação: A4; margens sup/esq 3 cm, inf/dir 2 cm; Times New Roman 12;
entrelinha 1,5; recuo de 1ª linha 1,25 cm; texto justificado; citação longa
(linhas iniciadas por ">") com recuo de 4 cm, corpo 10, entrelinha simples;
rodapé com "Página X de Y" e aviso de validação humana (desligável).

Markdown aceito (subconjunto deliberado):
    # Título            -> título centralizado, negrito, caixa alta
    ## Seção / ### Sub  -> títulos à esquerda, negrito
    parágrafo           -> corpo justificado
    **negrito**, *itálico*
    - item / 1. item    -> listas
    > citação           -> citação recuada
    | a | b |           -> tabela (linha separadora |---| é ignorada)
    ---                 -> espaço vertical
    \\pagebreak         -> quebra de página
    [[ASSINATURA]]      -> bloco de local/data/assinatura (linhas seguintes até
                           linha em branco são centralizadas)

PDF: usa LibreOffice (soffice) para converter o próprio DOCX, garantindo que os
dois arquivos sejam idênticos. Sem LibreOffice, cai para um renderizador
ReportLab próprio. Dependências: python-docx, reportlab (pip install
python-docx reportlab --break-system-packages).
"""
import argparse
import os
import re
import shutil
import subprocess
import sys
import tempfile

AVISO_PADRAO = ("Documento elaborado com apoio de IA. Depende de revisão e "
                "validação por advogado habilitado antes de uso ou protocolo.")

# --------------------------------------------------------------------------
# Parser
# --------------------------------------------------------------------------

def parse_markdown(texto):
    """Retorna lista de blocos (tipo, conteúdo)."""
    linhas = texto.replace("\r\n", "\n").split("\n")
    blocos, i = [], 0
    while i < len(linhas):
        ln = linhas[i]
        s = ln.strip()
        if not s:
            i += 1
            continue
        if s == r"\pagebreak":
            blocos.append(("pagebreak", None)); i += 1; continue
        if s == "[[ASSINATURA]]":
            corpo = []
            i += 1
            while i < len(linhas) and linhas[i].strip():
                corpo.append(linhas[i].strip()); i += 1
            blocos.append(("assinatura", corpo)); continue
        if re.fullmatch(r"-{3,}|\*{3,}|_{3,}", s):
            blocos.append(("espaco", None)); i += 1; continue
        m = re.match(r"^(#{1,4})\s+(.*)$", s)
        if m:
            blocos.append((f"h{len(m.group(1))}", m.group(2).strip())); i += 1; continue
        if s.startswith(">"):
            buf = []
            while i < len(linhas) and linhas[i].strip().startswith(">"):
                buf.append(linhas[i].strip()[1:].strip()); i += 1
            blocos.append(("citacao", " ".join(b for b in buf if b))); continue
        if s.startswith("|"):
            rows = []
            while i < len(linhas) and linhas[i].strip().startswith("|"):
                r = linhas[i].strip().strip("|")
                cells = [c.strip() for c in r.split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c):
                    rows.append(cells)
                i += 1
            if rows:
                blocos.append(("tabela", rows))
            continue
        if re.match(r"^[-*•]\s+", s):
            itens = []
            while i < len(linhas) and re.match(r"^\s*[-*•]\s+", linhas[i]):
                itens.append(re.sub(r"^\s*[-*•]\s+", "", linhas[i])); i += 1
            blocos.append(("ul", itens)); continue
        if re.match(r"^\d+[.)]\s+", s):
            itens = []
            while i < len(linhas) and re.match(r"^\s*\d+[.)]\s+", linhas[i]):
                itens.append(re.sub(r"^\s*\d+[.)]\s+", "", linhas[i])); i += 1
            blocos.append(("ol", itens)); continue
        buf = [s]
        i += 1
        while i < len(linhas):
            nx = linhas[i].strip()
            if (not nx or nx.startswith(("#", ">", "|")) or nx == r"\pagebreak"
                    or re.match(r"^[-*•]\s+|^\d+[.)]\s+|^-{3,}$", nx)):
                break
            buf.append(nx); i += 1
        blocos.append(("p", " ".join(buf)))
    return blocos


def runs_inline(texto):
    """Divide texto em (trecho, negrito, itálico)."""
    out = []
    for parte in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*)", texto):
        if not parte:
            continue
        if parte.startswith("**") and parte.endswith("**"):
            out.append((parte[2:-2], True, False))
        elif parte.startswith("*") and parte.endswith("*") and len(parte) > 2:
            out.append((parte[1:-1], False, True))
        else:
            out.append((parte, False, False))
    return out

# --------------------------------------------------------------------------
# DOCX
# --------------------------------------------------------------------------

def gerar_docx(blocos, caminho, cabecalho=None, aviso=None):
    from docx import Document
    from docx.enum.section import WD_SECTION
    from docx.enum.table import WD_TABLE_ALIGNMENT
    from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Cm, Pt

    doc = Document()
    sec = doc.sections[0]
    sec.page_height, sec.page_width = Cm(29.7), Cm(21.0)
    sec.top_margin, sec.left_margin = Cm(3), Cm(3)
    sec.bottom_margin, sec.right_margin = Cm(2), Cm(2)

    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(12)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    pf = st.paragraph_format
    pf.line_spacing = 1.5
    pf.space_after = Pt(6)

    def add_runs(par, texto, size=None, bold_all=False):
        for t, b, it in runs_inline(texto):
            r = par.add_run(t)
            r.bold = b or bold_all
            r.italic = it
            if size:
                r.font.size = Pt(size)

    def campo(par, instr):
        r = par.add_run()
        f1 = OxmlElement("w:fldChar"); f1.set(qn("w:fldCharType"), "begin")
        it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = instr
        f2 = OxmlElement("w:fldChar"); f2.set(qn("w:fldCharType"), "end")
        r._r.append(f1); r._r.append(it); r._r.append(f2)
        r.font.size = Pt(9)

    # cabeçalho
    if cabecalho:
        hp = sec.header.paragraphs[0]
        hp.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = hp.add_run(cabecalho); r.font.size = Pt(9); r.italic = True

    # rodapé (estilo Footer em corpo 9 para o resultado dos campos PAGE/NUMPAGES)
    try:
        doc.styles["Footer"].font.size = Pt(9)
        doc.styles["Header"].font.size = Pt(9)
    except KeyError:
        pass
    fp = sec.footer.paragraphs[0]
    fp.style = doc.styles["Footer"] if "Footer" in [s.name for s in doc.styles] else fp.style
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = fp.add_run("Página "); r.font.size = Pt(9)
    campo(fp, "PAGE")
    r = fp.add_run(" de "); r.font.size = Pt(9)
    campo(fp, "NUMPAGES")
    if aviso:
        ap = sec.footer.add_paragraph()
        ap.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = ap.add_run(aviso); r.font.size = Pt(7.5); r.italic = True

    for tipo, c in blocos:
        if tipo == "h1":
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(18)
            add_runs(p, c.upper(), size=13, bold_all=True)
        elif tipo in ("h2", "h3", "h4"):
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.keep_with_next = True
            add_runs(p, c.upper() if tipo == "h2" else c, size=12, bold_all=True)
        elif tipo == "p":
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.first_line_indent = Cm(1.25)
            add_runs(p, c)
        elif tipo == "citacao":
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
            p.paragraph_format.left_indent = Cm(4)
            p.paragraph_format.line_spacing = 1.0
            p.paragraph_format.space_before = Pt(6)
            p.paragraph_format.space_after = Pt(12)
            add_runs(p, c, size=10)
        elif tipo in ("ul", "ol"):
            for n, item in enumerate(c, 1):
                p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                p.paragraph_format.left_indent = Cm(1.25)
                p.paragraph_format.first_line_indent = Cm(-0.6)
                p.paragraph_format.space_after = Pt(3)
                p.add_run(("• " if tipo == "ul" else f"{n}. "))
                add_runs(p, item)
        elif tipo == "tabela":
            ncol = max(len(r) for r in c)
            t = doc.add_table(rows=len(c), cols=ncol)
            t.style = "Table Grid"; t.alignment = WD_TABLE_ALIGNMENT.CENTER
            for ri, row in enumerate(c):
                for ci in range(ncol):
                    cell = t.cell(ri, ci)
                    cp = cell.paragraphs[0]
                    cp.paragraph_format.line_spacing = 1.0
                    cp.paragraph_format.space_after = Pt(0)
                    add_runs(cp, row[ci] if ci < len(row) else "", size=10,
                             bold_all=(ri == 0))
            doc.add_paragraph().paragraph_format.space_after = Pt(0)
        elif tipo == "espaco":
            doc.add_paragraph()
        elif tipo == "pagebreak":
            doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE)
        elif tipo == "assinatura":
            doc.add_paragraph()
            for k, linha in enumerate(c):
                p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                p.paragraph_format.space_after = Pt(0)
                if k == 1:
                    p.paragraph_format.space_before = Pt(36)
                    p.add_run("_" * 40 + "\n")
                add_runs(p, linha)
    doc.save(caminho)

# --------------------------------------------------------------------------
# PDF
# --------------------------------------------------------------------------

def pdf_via_libreoffice(docx_path, pdf_path):
    soffice = shutil.which("soffice") or shutil.which("libreoffice")
    if not soffice:
        return False
    with tempfile.TemporaryDirectory() as tmp:
        try:
            subprocess.run([soffice, "--headless", "--convert-to", "pdf",
                            "--outdir", tmp, docx_path],
                           check=True, capture_output=True, timeout=180)
        except Exception as e:  # noqa: BLE001
            print(f"[aviso] LibreOffice falhou ({e}); usando ReportLab.", file=sys.stderr)
            return False
        gerado = os.path.join(tmp, os.path.splitext(os.path.basename(docx_path))[0] + ".pdf")
        if not os.path.exists(gerado):
            return False
        shutil.move(gerado, pdf_path)
    return True


def pdf_via_reportlab(blocos, pdf_path, cabecalho=None, aviso=None):
    from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY, TA_LEFT
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.units import cm
    from reportlab.lib import colors
    from reportlab.platypus import (PageBreak, Paragraph, SimpleDocTemplate,
                                    Spacer, Table, TableStyle)

    def md(t):
        t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
        return re.sub(r"\*([^*]+)\*", r"<i>\1</i>", t)

    base = dict(fontName="Times-Roman", fontSize=12, leading=18)
    S = {
        "h1": ParagraphStyle("h1", **{**base, "fontName": "Times-Bold", "fontSize": 13},
                             alignment=TA_CENTER, spaceAfter=18),
        "h2": ParagraphStyle("h2", **{**base, "fontName": "Times-Bold"},
                             spaceBefore=12, spaceAfter=6, keepWithNext=1),
        "p": ParagraphStyle("p", **base, alignment=TA_JUSTIFY,
                            firstLineIndent=1.25 * cm, spaceAfter=6),
        "cit": ParagraphStyle("cit", fontName="Times-Roman", fontSize=10, leading=12,
                              leftIndent=4 * cm, alignment=TA_JUSTIFY,
                              spaceBefore=6, spaceAfter=12),
        "li": ParagraphStyle("li", **base, alignment=TA_JUSTIFY,
                             leftIndent=1.25 * cm, bulletIndent=0.65 * cm, spaceAfter=3),
        "cell": ParagraphStyle("cell", fontName="Times-Roman", fontSize=10, leading=12),
        "center": ParagraphStyle("center", **base, alignment=TA_CENTER),
    }
    story = []
    for tipo, c in blocos:
        if tipo == "h1":
            story.append(Paragraph(md(c.upper()), S["h1"]))
        elif tipo in ("h2", "h3", "h4"):
            story.append(Paragraph(md(c.upper() if tipo == "h2" else c), S["h2"]))
        elif tipo == "p":
            story.append(Paragraph(md(c), S["p"]))
        elif tipo == "citacao":
            story.append(Paragraph(md(c), S["cit"]))
        elif tipo in ("ul", "ol"):
            for n, item in enumerate(c, 1):
                story.append(Paragraph(md(item), S["li"],
                                       bulletText="•" if tipo == "ul" else f"{n}."))
        elif tipo == "tabela":
            ncol = max(len(r) for r in c)
            data = [[Paragraph(("<b>%s</b>" if ri == 0 else "%s") % md(r[ci] if ci < len(r) else ""),
                               S["cell"]) for ci in range(ncol)] for ri, r in enumerate(c)]
            t = Table(data, colWidths=[16 * cm / ncol] * ncol, repeatRows=1)
            t.setStyle(TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.black),
                                   ("VALIGN", (0, 0), (-1, -1), "TOP")]))
            story += [t, Spacer(1, 8)]
        elif tipo == "espaco":
            story.append(Spacer(1, 12))
        elif tipo == "pagebreak":
            story.append(PageBreak())
        elif tipo == "assinatura":
            story.append(Spacer(1, 12))
            for k, linha in enumerate(c):
                if k == 1:
                    story += [Spacer(1, 36), Paragraph("_" * 40, S["center"])]
                story.append(Paragraph(md(linha), S["center"]))

    class Doc(SimpleDocTemplate):
        pass

    total = {"n": 0}

    def rodape(canvas, doc_):
        canvas.saveState()
        canvas.setFont("Times-Roman", 9)
        w = A4[0]
        txt = f"Página {doc_.page}" + (f" de {total['n']}" if total["n"] else "")
        canvas.drawCentredString(w / 2, 1.3 * cm, txt)
        if aviso:
            canvas.setFont("Times-Italic", 7.5)
            canvas.drawCentredString(w / 2, 0.9 * cm, aviso)
        if cabecalho:
            canvas.setFont("Times-Italic", 9)
            canvas.drawCentredString(w / 2, A4[1] - 1.8 * cm, cabecalho)
        canvas.restoreState()

    def build(path):
        d = Doc(path, pagesize=A4, topMargin=3 * cm, leftMargin=3 * cm,
                bottomMargin=2 * cm, rightMargin=2 * cm)
        d.build(list(story), onFirstPage=rodape, onLaterPages=rodape)
        return d.page

    with tempfile.TemporaryDirectory() as tmp:
        total["n"] = build(os.path.join(tmp, "x.pdf"))  # 1ª passada conta páginas
    build(pdf_path)

# --------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[1])
    ap.add_argument("entrada")
    ap.add_argument("--saida")
    ap.add_argument("--nome")
    ap.add_argument("--cabecalho")
    ap.add_argument("--aviso", default=AVISO_PADRAO)
    ap.add_argument("--sem-aviso", action="store_true")
    a = ap.parse_args()

    with open(a.entrada, encoding="utf-8") as f:
        blocos = parse_markdown(f.read())
    saida = a.saida or os.path.dirname(os.path.abspath(a.entrada))
    os.makedirs(saida, exist_ok=True)
    nome = a.nome or os.path.splitext(os.path.basename(a.entrada))[0]
    aviso = None if a.sem_aviso else a.aviso
    docx_path = os.path.join(saida, nome + ".docx")
    pdf_path = os.path.join(saida, nome + ".pdf")

    gerar_docx(blocos, docx_path, a.cabecalho, aviso)
    via = "LibreOffice"
    if not pdf_via_libreoffice(docx_path, pdf_path):
        pdf_via_reportlab(blocos, pdf_path, a.cabecalho, aviso)
        via = "ReportLab"
    print(f"DOCX: {docx_path}")
    print(f"PDF:  {pdf_path}  (via {via})")


if __name__ == "__main__":
    main()
