# Component Patterns Reference

Ready-to-paste HTML/CSS patterns for common UI components. Each pattern is self-contained, accessible, responsive, and uses CSS custom properties for theming.

## Table of Contents
1. [Responsive Navigation](#responsive-navigation)
2. [Modal Dialog](#modal-dialog)
3. [Toast Notifications](#toast-notifications)
4. [Stat/KPI Cards](#statkpi-cards)
5. [Data Table](#data-table)
6. [Form Components](#form-components)
7. [Empty States](#empty-states)
8. [Hero Sections](#hero-sections)
9. [Footer](#footer)
10. [Skip Link & Focus Management](#skip-link--focus-management)

---

## Responsive Navigation

Collapses to hamburger on mobile. Includes active state, logo, and CTA button.

```html
<header class="site-header" role="banner">
  <nav class="nav" aria-label="Main navigation">
    <a href="/" class="nav-logo" aria-label="Home">
      <svg width="32" height="32" viewBox="0 0 32 32" fill="var(--color-primary)">
        <rect width="32" height="32" rx="8"/>
        <text x="16" y="22" text-anchor="middle" fill="white" font-size="16" font-weight="700">A</text>
      </svg>
      <span class="nav-brand">AppName</span>
    </a>
    <button class="nav-toggle" aria-expanded="false" aria-controls="nav-menu" aria-label="Toggle menu">
      <span class="hamburger"></span>
    </button>
    <ul id="nav-menu" class="nav-menu" role="list">
      <li><a href="#" class="nav-link active" aria-current="page">Dashboard</a></li>
      <li><a href="#" class="nav-link">Analytics</a></li>
      <li><a href="#" class="nav-link">Settings</a></li>
      <li><a href="#" class="nav-cta">Get Started</a></li>
    </ul>
  </nav>
</header>
```

```css
.site-header {
  position: sticky; top: 0; z-index: 100;
  background: rgba(255,255,255,0.85);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(0,0,0,0.06);
}
.nav { display: flex; align-items: center; justify-content: space-between;
  max-width: 1200px; margin: 0 auto; padding: var(--space-4) var(--space-6); }
.nav-logo { display: flex; align-items: center; gap: var(--space-3); text-decoration: none; }
.nav-brand { font-weight: 700; font-size: var(--text-lg); color: var(--color-text); }
.nav-menu { display: flex; align-items: center; gap: var(--space-2); list-style: none; margin: 0; padding: 0; }
.nav-link { padding: var(--space-2) var(--space-4); border-radius: var(--radius-md);
  text-decoration: none; color: var(--color-text-muted); font-weight: 500;
  transition: all var(--duration-fast) var(--ease-out); }
.nav-link:hover { color: var(--color-text); background: rgba(0,0,0,0.04); }
.nav-link.active { color: var(--color-primary); background: rgba(99,102,241,0.08); }
.nav-cta { padding: var(--space-2) var(--space-6); border-radius: var(--radius-full);
  background: var(--color-primary); color: white; text-decoration: none; font-weight: 600;
  transition: all var(--duration-fast) var(--ease-out); }
.nav-cta:hover { transform: translateY(-1px); box-shadow: var(--shadow-md); }
.nav-toggle { display: none; background: none; border: none; cursor: pointer; padding: var(--space-2); }
.hamburger, .hamburger::before, .hamburger::after {
  display: block; width: 24px; height: 2px; background: var(--color-text);
  border-radius: 2px; transition: all 0.3s ease; position: relative; }
.hamburger::before, .hamburger::after { content: ''; position: absolute; left: 0; }
.hamburger::before { top: -7px; } .hamburger::after { top: 7px; }
.nav-toggle[aria-expanded="true"] .hamburger { background: transparent; }
.nav-toggle[aria-expanded="true"] .hamburger::before { top: 0; transform: rotate(45deg); }
.nav-toggle[aria-expanded="true"] .hamburger::after { top: 0; transform: rotate(-45deg); }

@media (max-width: 48em) {
  .nav-toggle { display: block; }
  .nav-menu { position: absolute; top: 100%; left: 0; right: 0;
    flex-direction: column; background: white; padding: var(--space-4);
    box-shadow: var(--shadow-lg); border-radius: 0 0 var(--radius-lg) var(--radius-lg);
    display: none; }
  .nav-menu.open { display: flex; }
  .nav-link, .nav-cta { width: 100%; text-align: center; }
}
```

```javascript
document.querySelector('.nav-toggle')?.addEventListener('click', function() {
  const expanded = this.getAttribute('aria-expanded') === 'true';
  this.setAttribute('aria-expanded', !expanded);
  document.getElementById('nav-menu').classList.toggle('open');
});
```

---

## Modal Dialog

Accessible modal with focus trap, escape-to-close, and backdrop click close.

```html
<div class="modal-backdrop" id="modal-1" role="dialog" aria-modal="true"
  aria-labelledby="modal-title" hidden>
  <div class="modal-content">
    <div class="modal-header">
      <h2 id="modal-title" class="modal-title">Confirm Action</h2>
      <button class="modal-close" aria-label="Close dialog">&times;</button>
    </div>
    <div class="modal-body">
      <p>Are you sure you want to proceed? This action cannot be undone.</p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary" data-dismiss="modal">Cancel</button>
      <button class="btn btn-primary">Confirm</button>
    </div>
  </div>
</div>
```

```css
.modal-backdrop { position: fixed; inset: 0; z-index: 1000;
  background: rgba(0,0,0,0.5); backdrop-filter: blur(4px);
  display: flex; align-items: center; justify-content: center;
  padding: var(--space-4); opacity: 0; transition: opacity 0.2s ease; }
.modal-backdrop:not([hidden]) { opacity: 1; }
.modal-content { background: white; border-radius: var(--radius-xl);
  box-shadow: var(--shadow-xl); max-width: 480px; width: 100%;
  transform: scale(0.95); transition: transform 0.25s var(--ease-out); }
.modal-backdrop:not([hidden]) .modal-content { transform: scale(1); }
.modal-header { display: flex; justify-content: space-between; align-items: center;
  padding: var(--space-6) var(--space-6) 0; }
.modal-title { font-size: var(--text-xl); font-weight: 700; margin: 0; }
.modal-close { background: none; border: none; font-size: 24px; cursor: pointer;
  color: var(--color-text-muted); padding: var(--space-2);
  border-radius: var(--radius-md); transition: all var(--duration-fast) var(--ease-out); }
.modal-close:hover { background: rgba(0,0,0,0.05); color: var(--color-text); }
.modal-body { padding: var(--space-4) var(--space-6); color: var(--color-text-muted); }
.modal-footer { display: flex; justify-content: flex-end; gap: var(--space-3);
  padding: 0 var(--space-6) var(--space-6); }
```

---

## Toast Notifications

Auto-dismissing notifications with semantic variants.

```html
<div class="toast-container" aria-live="polite" aria-atomic="true">
  <!-- Toasts are injected here dynamically -->
</div>
```

```css
.toast-container { position: fixed; bottom: var(--space-6); right: var(--space-6);
  z-index: 2000; display: flex; flex-direction: column-reverse; gap: var(--space-3); }
.toast { display: flex; align-items: center; gap: var(--space-3);
  padding: var(--space-4) var(--space-6); border-radius: var(--radius-lg);
  background: var(--color-text); color: white; font-weight: 500;
  box-shadow: var(--shadow-xl); min-width: 300px; max-width: 420px;
  animation: slideInRight 0.3s var(--ease-out); }
.toast.success { background: #059669; }
.toast.error { background: #dc2626; }
.toast.warning { background: #d97706; }
.toast.info { background: #2563eb; }
.toast-dismiss { background: none; border: none; color: inherit;
  opacity: 0.7; cursor: pointer; margin-left: auto; padding: var(--space-1); }
.toast-dismiss:hover { opacity: 1; }
@keyframes slideInRight {
  from { transform: translateX(100%); opacity: 0; }
  to { transform: translateX(0); opacity: 1; }
}
```

```javascript
function showToast(message, type = 'info', duration = 4000) {
  const container = document.querySelector('.toast-container');
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.setAttribute('role', 'alert');
  toast.innerHTML = `<span>${message}</span>
    <button class="toast-dismiss" aria-label="Dismiss">&times;</button>`;
  container.appendChild(toast);
  toast.querySelector('.toast-dismiss').addEventListener('click', () => toast.remove());
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}
```

---

## Stat/KPI Cards

Metric cards with trend indicator and sparkline placeholder.

```html
<div class="stat-grid">
  <div class="stat-card">
    <div class="stat-header">
      <span class="stat-label">Revenue</span>
      <span class="stat-icon" aria-hidden="true">💰</span>
    </div>
    <div class="stat-value">R$ 48.200</div>
    <div class="stat-trend up">
      <svg width="12" height="12" viewBox="0 0 12 12" fill="currentColor">
        <path d="M6 2l4 4H8v4H4V6H2l4-4z"/>
      </svg>
      <span>12.5% vs último mês</span>
    </div>
  </div>
  <!-- Repeat for more stats -->
</div>
```

```css
.stat-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: var(--space-6); }
.stat-card { background: white; border-radius: var(--radius-xl);
  padding: var(--space-6); box-shadow: var(--shadow-sm);
  border: 1px solid rgba(0,0,0,0.06);
  transition: all var(--duration-base) var(--ease-out); }
.stat-card:hover { box-shadow: var(--shadow-md); transform: translateY(-2px); }
.stat-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--space-3); }
.stat-label { font-size: var(--text-sm); color: var(--color-text-muted); font-weight: 500; }
.stat-icon { font-size: 20px; }
.stat-value { font-size: var(--text-3xl); font-weight: 800; color: var(--color-text);
  letter-spacing: -0.02em; margin-bottom: var(--space-2); }
.stat-trend { display: flex; align-items: center; gap: var(--space-1);
  font-size: var(--text-xs); font-weight: 600; }
.stat-trend.up { color: #059669; }
.stat-trend.down { color: #dc2626; }
.stat-trend.neutral { color: var(--color-text-muted); }
```

---

## Data Table

Responsive table with hover rows, sort indicators, and mobile card fallback.

```html
<div class="table-wrapper" role="region" aria-label="User data" tabindex="0">
  <table class="data-table">
    <thead>
      <tr>
        <th scope="col"><button class="sort-btn">Name <span aria-hidden="true">↕</span></button></th>
        <th scope="col"><button class="sort-btn">Status <span aria-hidden="true">↕</span></button></th>
        <th scope="col"><button class="sort-btn">Amount <span aria-hidden="true">↕</span></button></th>
        <th scope="col">Actions</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td data-label="Name">Maria Silva</td>
        <td data-label="Status"><span class="badge badge-success">Active</span></td>
        <td data-label="Amount">R$ 1.200,00</td>
        <td data-label="Actions"><button class="btn-sm">View</button></td>
      </tr>
    </tbody>
  </table>
</div>
```

```css
.table-wrapper { overflow-x: auto; border-radius: var(--radius-lg);
  border: 1px solid rgba(0,0,0,0.08); }
.data-table { width: 100%; border-collapse: collapse; }
.data-table th { text-align: left; padding: var(--space-4) var(--space-4);
  font-size: var(--text-xs); font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.05em; color: var(--color-text-muted);
  background: rgba(0,0,0,0.02); border-bottom: 1px solid rgba(0,0,0,0.08); }
.data-table td { padding: var(--space-4); border-bottom: 1px solid rgba(0,0,0,0.04);
  font-size: var(--text-sm); }
.data-table tbody tr { transition: background var(--duration-fast) ease; }
.data-table tbody tr:hover { background: rgba(0,0,0,0.02); }
.sort-btn { background: none; border: none; cursor: pointer; font: inherit;
  color: inherit; display: flex; align-items: center; gap: var(--space-1); }
.badge { display: inline-flex; padding: 2px 10px; border-radius: var(--radius-full);
  font-size: var(--text-xs); font-weight: 600; }
.badge-success { background: #ecfdf5; color: #059669; }
.badge-warning { background: #fffbeb; color: #d97706; }
.badge-error { background: #fef2f2; color: #dc2626; }
.btn-sm { padding: var(--space-1) var(--space-3); border-radius: var(--radius-md);
  background: var(--color-primary); color: white; border: none; cursor: pointer;
  font-size: var(--text-xs); font-weight: 600;
  transition: all var(--duration-fast) var(--ease-out); }
.btn-sm:hover { opacity: 0.9; transform: translateY(-1px); }

@media (max-width: 48em) {
  .data-table thead { display: none; }
  .data-table tr { display: block; margin-bottom: var(--space-4);
    border: 1px solid rgba(0,0,0,0.08); border-radius: var(--radius-lg);
    overflow: hidden; }
  .data-table td { display: flex; justify-content: space-between;
    padding: var(--space-3) var(--space-4); }
  .data-table td::before { content: attr(data-label); font-weight: 600;
    color: var(--color-text-muted); font-size: var(--text-xs);
    text-transform: uppercase; letter-spacing: 0.05em; }
}
```

---

## Empty States

Friendly empty state with SVG illustration placeholder and action CTA.

```html
<div class="empty-state" role="status">
  <svg class="empty-illustration" width="120" height="120" viewBox="0 0 120 120" fill="none">
    <circle cx="60" cy="60" r="50" fill="rgba(99,102,241,0.08)"/>
    <circle cx="60" cy="60" r="30" fill="rgba(99,102,241,0.12)"/>
    <path d="M50 55 L55 65 L70 50" stroke="var(--color-primary)" stroke-width="3"
      stroke-linecap="round" stroke-linejoin="round" fill="none"/>
  </svg>
  <h3 class="empty-title">No data yet</h3>
  <p class="empty-description">Get started by creating your first item. It only takes a moment.</p>
  <button class="btn btn-primary">Create First Item</button>
</div>
```

```css
.empty-state { display: flex; flex-direction: column; align-items: center;
  justify-content: center; text-align: center; padding: var(--space-16) var(--space-6);
  min-height: 300px; }
.empty-illustration { margin-bottom: var(--space-6);
  animation: fadeInUp 0.6s var(--ease-out); }
.empty-title { font-size: var(--text-xl); font-weight: 700;
  color: var(--color-text); margin: 0 0 var(--space-2); }
.empty-description { font-size: var(--text-sm); color: var(--color-text-muted);
  max-width: 320px; margin: 0 0 var(--space-6); line-height: 1.6; }
```

---

## Hero Sections

### Gradient Hero (SaaS/Landing Page)
```html
<section class="hero">
  <div class="hero-bg" aria-hidden="true"></div>
  <div class="hero-content">
    <span class="hero-badge">Now in beta</span>
    <h1 class="hero-title">Build something<br><em>extraordinary</em></h1>
    <p class="hero-subtitle">The modern platform for teams that ship fast and iterate faster.</p>
    <div class="hero-actions">
      <a href="#" class="btn btn-primary btn-lg">Get Started Free</a>
      <a href="#" class="btn btn-ghost btn-lg">See Demo →</a>
    </div>
  </div>
</section>
```

```css
.hero { position: relative; overflow: hidden;
  padding: var(--space-24) var(--space-6); text-align: center; }
.hero-bg { position: absolute; inset: 0; z-index: -1;
  background: radial-gradient(ellipse at 30% 20%, rgba(99,102,241,0.15), transparent 60%),
              radial-gradient(ellipse at 70% 80%, rgba(236,72,153,0.1), transparent 60%),
              linear-gradient(180deg, rgba(249,250,251,1), rgba(255,255,255,1)); }
.hero-content { max-width: 680px; margin: 0 auto; }
.hero-badge { display: inline-block; padding: var(--space-1) var(--space-4);
  border-radius: var(--radius-full); background: rgba(99,102,241,0.1);
  color: var(--color-primary); font-size: var(--text-sm); font-weight: 600;
  margin-bottom: var(--space-6); }
.hero-title { font-size: var(--text-5xl); font-weight: 800; line-height: 1.1;
  letter-spacing: -0.03em; margin: 0 0 var(--space-6);
  animation: fadeInUp 0.8s var(--ease-out); }
.hero-title em { font-style: normal;
  background: linear-gradient(135deg, var(--color-primary), #ec4899);
  -webkit-background-clip: text; -webkit-text-fill-color: transparent;
  background-clip: text; }
.hero-subtitle { font-size: var(--text-lg); color: var(--color-text-muted);
  line-height: 1.6; margin: 0 0 var(--space-8); max-width: 500px; margin-inline: auto;
  animation: fadeInUp 0.8s var(--ease-out) 0.1s both; }
.hero-actions { display: flex; gap: var(--space-4); justify-content: center; flex-wrap: wrap;
  animation: fadeInUp 0.8s var(--ease-out) 0.2s both; }
.btn-lg { padding: var(--space-3) var(--space-8); font-size: var(--text-base); }
.btn-ghost { background: none; border: 1px solid rgba(0,0,0,0.15);
  color: var(--color-text); border-radius: var(--radius-full); }
.btn-ghost:hover { border-color: var(--color-primary); color: var(--color-primary); }
```

---

## Skip Link & Focus Management

Always include for accessibility.

```html
<a href="#main-content" class="skip-link">Skip to main content</a>
<!-- ... nav, header ... -->
<main id="main-content" tabindex="-1">
  <!-- page content -->
</main>
```

```css
.skip-link { position: absolute; top: -100%; left: var(--space-4);
  z-index: 9999; padding: var(--space-3) var(--space-6);
  background: var(--color-primary); color: white; font-weight: 600;
  border-radius: 0 0 var(--radius-md) var(--radius-md);
  text-decoration: none; transition: top 0.2s ease; }
.skip-link:focus { top: 0; }

/* Universal focus ring */
:focus-visible { outline: 2px solid var(--color-primary);
  outline-offset: 2px; border-radius: var(--radius-sm); }
```
