# Super Advogado BR. Justa Causa v1.0.0

Skill no padrão aberto Agent Skills para análise jurídica brasileira, com núcleo especializado em dispensa por justa causa.

## O que entrega

- auditoria estruturada da justa causa em 16 gates;
- pesquisa de legislação e jurisprudência em fontes oficiais;
- cronologia e matriz probatória;
- análise de ônus da prova e autenticidade documental;
- módulos para atestado médico, prova digital, EOR/tomadora, estabilidade e discriminação;
- parecer, estratégia, notificações, peças, audiência e revisão adversarial;
- scripts locais para hash de evidências, cronologia e validação do dossiê;
- casos de avaliação para testar o comportamento.

## Instalação no ChatGPT

No ChatGPT, abra **Plugins > Skills > Criar > Fazer upload do computador** e selecione o arquivo `.skill`. A disponibilidade depende do plano e das permissões do workspace.

## Instalação em agentes compatíveis

Descompacte a pasta no diretório de skills do agente. O arquivo obrigatório é `SKILL.md` na raiz da pasta `super-advogado-br-justa-causa`.

## Comandos opcionais

```bash
python scripts/validate_case.py assets/templates/intake-caso.json
python scripts/hash_evidence.py ./evidencias --output manifesto_evidencias.csv
python scripts/build_timeline.py assets/templates/cronologia.csv --output cronologia.md
python scripts/validate_skill.py .
```

## Limites

A skill não substitui advogado regularmente inscrito na OAB, não representa partes e não garante resultado. O direito pode mudar. Toda conclusão material exige validação atual em fonte oficial e revisão por profissional habilitado antes de protocolo ou ato irreversível.

## Verificação

Conteúdo jurídico-base verificado até 31/07/2026. A própria skill exige atualização na execução.
