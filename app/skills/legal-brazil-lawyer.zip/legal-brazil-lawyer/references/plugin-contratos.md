# Plugin: Revisão Contratual Avançada

## Ativar quando
Pedido envolver revisão, análise, redação ou negociação de qualquer tipo de contrato — empresarial, tecnologia, serviços, distribuição, M&A, imobiliário, financeiro ou consumerista.

## Raciocínio especializado

### Sequência obrigatória de revisão
1. Identificar tipo contratual e lei aplicável
2. Verificar partes, capacidade, representação e poderes
3. Revisar objeto, escopo e entregáveis
4. Analisar obrigações, prazos e condições
5. Checar cláusulas de risco: multa, limitação de responsabilidade, indenização
6. Verificar cláusulas regulatórias: LGPD, compliance, anticorrupção
7. Analisar rescisão, consequências e sobrevivência de cláusulas
8. Verificar foro, lei aplicável e mecanismo de resolução de disputas

### Cláusulas de alto risco — verificar sempre

#### Limitação de responsabilidade
- Cap em valor: verificar se cobre danos reais esperados
- Exclusões de dolo e culpa grave: inválidas (art. 393 CC)
- Danos indiretos/consequenciais: exclusão comum — avaliar impacto
- Danos emergentes vs. lucros cessantes: distinguir cobertura

#### Multa contratual (cláusula penal)
- Art. 412 CC: limite = valor da obrigação principal
- Art. 413 CC: juiz pode reduzir se obrigação parcialmente cumprida
- Multa moratória: cumulável com perdas e danos (art. 411 CC)
- Multa compensatória: substitui perdas e danos (salvo dolo)

#### Rescisão e resolução
- Rescisão por inadimplemento: prazo de cura (cure period) — padrão 30 dias
- Rescisão imotivada: aviso prévio + multa — verificar equilíbrio
- Resolução por força maior: definição contratual vs. art. 393 CC
- Hardship/revisão: cláusula de renegociação obrigatória
- Efeitos pós-rescisão: devolução, confidencialidade, não-concorrência, IP

#### Propriedade intelectual
- Titularidade de criações durante o contrato: cessão expressa vs. licença
- Work-for-hire: definição clara de escopo
- IP pré-existente: licença de uso vs. transferência
- Melhorias e derivações: quem é titular?
- Software: licença de uso ou cessão de código-fonte?

#### Proteção de dados (LGPD)
- Identificar papel de cada parte: controlador, operador ou controlador conjunto
- DPA (Data Processing Agreement) como anexo obrigatório quando há tratamento de dados pessoais
- Bases legais aplicáveis ao tratamento
- Obrigações de segurança e notificação de incidentes
- Transferência internacional: mecanismos adequados
- Retenção e descarte após término do contrato

#### Não-concorrência e não-aliciamento
- Prazo: máximo razoável = 2 anos (jurisprudência dominante)
- Território: deve ser geograficamente delimitado
- Contrapartida financeira: necessária para validade em alguns contextos
- Non-solicitation: funcionários e clientes — distinguir

#### Garantias e indenizações (M&A e contratos complexos)
- Representations & Warranties: escopo, knowledge qualifier, materiality threshold
- Indemnification: procedimento de claim, basket, cap, survival period
- Escrow: valor, prazo, condições de liberação
- Earn-out: métricas, período, não-interferência pós-fechamento

### Matriz de classificação de risco por cláusula

| Nível | Critério | Ação |
|---|---|---|
| 🔴 Alto | Ilegalidade, nulidade, exposição financeira não coberta, ausência de cap | Exigir alteração antes de assinar |
| 🟡 Médio | Desequilíbrio negocial, ambiguidade, lacuna relevante | Negociar alteração ou documentar entendimento |
| 🟢 Baixo | Redação imprecisa sem impacto prático, cláusulas ornamentais | Sugerir melhoria, não bloquear assinatura |

### Cláusulas essenciais que frequentemente faltam
- [ ] Definições (seção de interpretação)
- [ ] SLA e penalidades por descumprimento de nível de serviço
- [ ] Procedimento de aprovação/aceite de entregáveis
- [ ] Mecanismo de alteração de escopo (change order)
- [ ] Alocação de risco em caso de força maior
- [ ] Tratamento de dados pessoais (DPA)
- [ ] Política anticorrupção e compliance
- [ ] Procedimento de notificação formal entre as partes
- [ ] Ordem de precedência entre documentos contratuais
- [ ] Cláusula de integralidade (entire agreement)

### Contratos de tecnologia — pontos específicos
- **SaaS**: uptime SLA, exclusão de dados, portabilidade, disaster recovery
- **Desenvolvimento de software**: titularidade de código, versionamento, documentação, código-fonte em escrow
- **Cloud/hosting**: jurisdição dos dados, subprocessadores, auditoria
- **Licença de software**: perpetuidade vs. assinatura, número de usuários/instâncias, uso em produção vs. desenvolvimento
- **Integração/API**: rate limits, versionamento de API, breaking changes, SLA de disponibilidade

### Contratos de distribuição e agência
- **Representação comercial**: Lei 4.886/65 — indenização de 1/12 das comissões (art. 27 j)
- **Agência**: arts. 710-721 CC — aviso prévio de 90 dias; indenização
- **Distribuição**: arts. 710+ CC aplicados por analogia
- **Exclusividade territorial**: análise concorrencial (CADE) se market share relevante
- **Rescisão sem justa causa**: risco de indenização independentemente de cláusula

### Formato de saída preferencial
- Revisão comentada: cláusula → problema → risco → recomendação → redação sugerida
- Tabela de riscos: cláusula | nível | tipo | impacto | recomendação
- Redação alternativa: manter estrutura original + marcar alterações sugeridas em destaque
- Checklist de negociação: pontos inegociáveis vs. pontos de concessão possível
