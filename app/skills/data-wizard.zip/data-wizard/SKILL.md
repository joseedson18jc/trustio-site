---
name: data-wizard
description: |
  Data analysis and transformation toolkit for CSV, JSON, Excel files. Clean messy data, generate statistics, create visualizations, and export in various formats.
  TRIGGERS: CSV, JSON, Excel, data analysis, data cleaning, statistics, visualization, chart, graph, pandas, dataframe, transform data, aggregate, pivot
---

# Data Wizard

Analyze, clean, and visualize data files.

## Workflow

1. **Load & Inspect**: Read file, show shape and dtypes
2. **Clean**: Handle missing values, fix types, remove duplicates
3. **Analyze**: Statistics, correlations, groupings
4. **Visualize**: Charts appropriate to data type
5. **Export**: Save cleaned data or reports

## Loading Data

```python
import pandas as pd

# Auto-detect format
def load_data(path):
    if path.endswith('.csv'):
        return pd.read_csv(path)
    elif path.endswith('.json'):
        return pd.read_json(path)
    elif path.endswith(('.xlsx', '.xls')):
        return pd.read_excel(path)
    else:
        return pd.read_csv(path)  # Try CSV as default

df = load_data('data.csv')
print(f"Shape: {df.shape}")
print(df.dtypes)
print(df.head())
```

## Data Cleaning

```python
# Missing values
df.isnull().sum()
df.fillna(method='ffill')  # Forward fill
df.dropna(subset=['required_col'])  # Drop if missing required

# Duplicates
df.drop_duplicates()
df.drop_duplicates(subset=['key_col'])

# Type conversion
df['date'] = pd.to_datetime(df['date'])
df['amount'] = pd.to_numeric(df['amount'], errors='coerce')
df['category'] = df['category'].astype('category')

# String cleaning
df['name'] = df['name'].str.strip().str.lower()
```

## Analysis Patterns

```python
# Basic stats
df.describe()

# Grouping
df.groupby('category').agg({
    'value': ['sum', 'mean', 'count'],
    'date': ['min', 'max']
})

# Pivot tables
pd.pivot_table(df, values='amount', index='month', columns='category', aggfunc='sum')

# Correlations
df.select_dtypes(include='number').corr()
```

## Visualization

```python
import matplotlib.pyplot as plt

# Choose chart by data type
fig, ax = plt.subplots(figsize=(10, 6))

# Trends over time → Line chart
# Category comparison → Bar chart
# Distribution → Histogram
# Relationship → Scatter plot
# Composition → Pie chart (limited categories only)

plt.tight_layout()
plt.savefig('chart.png', dpi=150)
```

## Export Options

```python
# CSV
df.to_csv('output.csv', index=False)

# Excel with formatting
df.to_excel('output.xlsx', sheet_name='Data', index=False)

# JSON
df.to_json('output.json', orient='records', indent=2)

# Markdown table
print(df.to_markdown())
```

## Common Transformations

| Task | Code |
|------|------|
| Filter rows | `df[df['col'] > value]` |
| Select columns | `df[['col1', 'col2']]` |
| Rename columns | `df.rename(columns={'old': 'new'})` |
| Sort | `df.sort_values('col', ascending=False)` |
| Merge files | `pd.concat([df1, df2])` or `df1.merge(df2, on='key')` |
