#!/usr/bin/env bash
# PostToolUse: lint/typecheck changed files. Non-blocking by design —
# output returns to context so the agent sees and fixes its own violations.
# Matcher: Edit|Write
set -uo pipefail

git rev-parse --git-dir > /dev/null 2>&1 || exit 0
changed="$(git diff --name-only --diff-filter=ACM 2>/dev/null)"
[ -z "$changed" ] && exit 0

run() { command -v "$1" > /dev/null 2>&1; }

js="$(printf '%s\n' "$changed" | grep -E '\.(ts|tsx|js|jsx|mjs)$' || true)"
py="$(printf '%s\n' "$changed" | grep -E '\.py$' || true)"

if [ -n "$js" ]; then
  if [ -f package.json ] && grep -q '"lint"' package.json && run npm; then
    npm run --silent lint 2>&1 | tail -25
  elif run npx; then
    npx --no-install eslint $js 2>&1 | tail -25 || true
  fi
  if [ -f tsconfig.json ] && run npx; then
    npx --no-install tsc --noEmit 2>&1 | tail -20 || true
  fi
fi

if [ -n "$py" ]; then
  run ruff  && ruff check $py 2>&1 | tail -25
  run mypy  && mypy $py 2>&1 | tail -20 || true
fi

exit 0
