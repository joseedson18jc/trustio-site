#!/usr/bin/env python3
"""Valida campos essenciais do intake e aponta lacunas sem bloquear a análise."""
from __future__ import annotations
import argparse, json, sys
from datetime import datetime
from pathlib import Path

REQUIRED_PATHS = [
    ('lado_assistido',), ('objetivo',),
    ('partes','empregado','cargo'), ('partes','empregador_formal','nome'),
    ('datas','admissao'), ('datas','comunicacao'),
    ('justa_causa','alineas_art_482'), ('justa_causa','descricao_literal'),
    ('poder_decisorio','quem_decidiu'), ('provas',)
]
DATE_KEYS = ['admissao','fato_imputado','ciencia_empregador','inicio_investigacao','fim_investigacao','decisao','comunicacao','pagamento_rescisorio','baixa_ctps']

def get(obj, path):
    cur = obj
    for key in path:
        if not isinstance(cur, dict) or key not in cur:
            return None
        cur = cur[key]
    return cur

def parse_date(v):
    if not v: return None
    try: return datetime.fromisoformat(str(v).replace('Z','+00:00'))
    except ValueError: return False

def main() -> int:
    ap = argparse.ArgumentParser(description='Valida intake de caso trabalhista.')
    ap.add_argument('json_file')
    args = ap.parse_args()
    try:
        data = json.loads(Path(args.json_file).read_text(encoding='utf-8'))
    except (OSError, json.JSONDecodeError) as exc:
        print(f'Erro: {exc}', file=sys.stderr); return 2
    warnings = []
    for path in REQUIRED_PATHS:
        value = get(data, path)
        if value in (None, '', []): warnings.append('Campo ausente ou vazio: ' + '.'.join(path))
    dates = data.get('datas', {}) if isinstance(data.get('datas'), dict) else {}
    parsed = {}
    for key in DATE_KEYS:
        parsed[key] = parse_date(dates.get(key))
        if parsed[key] is False: warnings.append(f'Data inválida em datas.{key}: use ISO 8601')
    ordered = ['fato_imputado','ciencia_empregador','inicio_investigacao','fim_investigacao','decisao','comunicacao']
    valid = [(k, parsed[k]) for k in ordered if parsed[k] not in (None, False)]
    for (ka,a),(kb,b) in zip(valid, valid[1:]):
        try:
            if a > b: warnings.append(f'Ordem temporal suspeita: {ka} ocorre após {kb}')
        except TypeError:
            warnings.append(f'Fusos incompatíveis entre {ka} e {kb}')
    if not data.get('justa_causa',{}).get('carta_disponivel'):
        warnings.append('Carta/comunicação formal não marcada como disponível')
    if not data.get('regulamento_norma_coletiva'):
        warnings.append('Regulamento interno e norma coletiva não informados')
    if not data.get('provas'):
        warnings.append('Nenhuma prova cadastrada. Separar alegação de fato documentado')
    print(json.dumps({'valido_para_triagem': True, 'alertas': warnings, 'quantidade_alertas': len(warnings)}, ensure_ascii=False, indent=2))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
