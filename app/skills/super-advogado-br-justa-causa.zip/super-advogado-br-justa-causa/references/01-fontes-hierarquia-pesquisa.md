# Fontes, hierarquia e pesquisa jurídica

## Regra central

Nenhuma norma, súmula, OJ, tema ou precedente materialmente relevante deve ser apresentado como vigente sem consulta oficial na execução. O catálogo desta skill é semente, não substitui atualização.

## Hierarquia funcional

### Nível A. Obrigatório e potencialmente vinculante

- Constituição e legislação consolidada no Portal da Legislação/Planalto.
- STF: controle concentrado, súmulas vinculantes e repercussão geral.
- TST: IRR, IAC, incidentes vinculantes e precedentes qualificados, conforme status oficial.
- Normas coletivas aplicáveis ao contrato.

### Nível B. Uniformização trabalhista

- Súmulas e Orientações Jurisprudenciais vigentes do TST.
- Decisões do Tribunal Pleno, SBDI-1, SBDI-2 e SDC, conforme tema.

### Nível C. Persuasivo qualificado

- Acórdãos de Turmas do TST.
- Acórdãos do TRT territorialmente competente, preferindo órgão e período relevantes.
- Outros TRTs para comparação, nunca como se vinculassem o juízo.

### Nível D. Localização e contexto

- JusLaboris e revistas institucionais.
- Doutrina.
- Notícias de tribunais. Servem para localizar o processo e compreender o caso. Confirme no acórdão.

## Portais oficiais prioritários

- Legislação federal: `planalto.gov.br` e `in.gov.br`.
- STF: `portal.stf.jus.br`, pesquisa de jurisprudência e temas de repercussão geral.
- TST: `tst.jus.br`, consulta documental, NUGEP/precedentes qualificados, livro de jurisprudência e JusLaboris.
- TRTs: domínio oficial `trtN.jus.br` e PJe/consulta processual oficial.
- CNJ: `cnj.jus.br` para resoluções e protocolos.
- MTE/eSocial/FGTS/INSS/CFM/ANPD: somente domínios institucionais para regras técnicas.

## Protocolo de pesquisa em 9 passos

1. Defina a questão jurídica em uma frase.
2. Liste fatos que podem alterar a solução.
3. Consulte texto legal consolidado.
4. Verifique STF e TST em precedentes qualificados.
5. Verifique súmulas e OJs vigentes, inclusive cancelamento ou superação.
6. Pesquise TST por fato semelhante, favorável e desfavorável.
7. Pesquise TRT competente por recência e similitude.
8. Leia o acórdão ou trecho suficiente para entender fatos, tese e resultado.
9. Registre data de verificação e link oficial.

## Cartão obrigatório de autoridade

```text
AUTORIDADE:
TRIBUNAL/ÓRGÃO:
PROCESSO/TEMA/SÚMULA:
RELATOR(A):
JULGAMENTO/PUBLICAÇÃO:
STATUS:
QUESTÃO:
FATOS RELEVANTES:
TESE/RATIO:
RESULTADO:
SEMELHANÇAS:
DISTINÇÕES:
FORÇA NO CASO:
LINK OFICIAL:
VERIFICADO EM:
```

## Controle contra alucinação

Marque como `[NÃO CONFIRMADO]` qualquer item sem link oficial ou identificação suficiente. Não complete campos por padrão provável. Não use aspas para paráfrase. Quando reproduzir trecho, limite-o ao necessário e compare com o documento oficial.

## Divergência

Quando decisões divergem:

- identifique órgão, data e contexto;
- verifique se existe precedente posterior qualificado;
- explique se a divergência é jurídica ou apenas fática;
- mostre qual linha é dominante no TRT competente, sem declarar unanimidade sem amostra adequada;
- não “conte decisões” sem critérios de busca reproduzíveis.
