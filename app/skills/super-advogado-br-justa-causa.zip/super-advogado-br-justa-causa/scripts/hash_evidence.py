#!/usr/bin/env python3
"""Gera manifesto SHA-256 de evidências sem modificar os arquivos."""
from __future__ import annotations
import argparse, csv, hashlib, os, sys
from datetime import datetime, timezone
from pathlib import Path

CHUNK = 1024 * 1024

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        while True:
            chunk = f.read(CHUNK)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def iter_files(target: Path):
    if target.is_file():
        yield target
    elif target.is_dir():
        for p in sorted(target.rglob('*')):
            if p.is_file():
                yield p
    else:
        raise FileNotFoundError(f'Alvo não encontrado: {target}')

def main() -> int:
    ap = argparse.ArgumentParser(description='Gera manifesto SHA-256 de arquivo ou pasta.')
    ap.add_argument('target')
    ap.add_argument('--output', default='manifesto_evidencias.csv')
    args = ap.parse_args()
    target = Path(args.target).expanduser().resolve()
    out = Path(args.output).expanduser().resolve()
    rows = []
    try:
        for p in iter_files(target):
            st = p.stat()
            rows.append({
                'path': str(p),
                'size_bytes': st.st_size,
                'modified_utc': datetime.fromtimestamp(st.st_mtime, timezone.utc).isoformat(),
                'sha256': sha256_file(p),
                'hashed_utc': datetime.now(timezone.utc).isoformat(),
            })
    except (OSError, PermissionError) as exc:
        print(f'Erro: {exc}', file=sys.stderr)
        return 2
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=['path','size_bytes','modified_utc','sha256','hashed_utc'])
        w.writeheader(); w.writerows(rows)
    print(f'{len(rows)} arquivo(s) registrados em {out}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
