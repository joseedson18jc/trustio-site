# Context Economics & Delegation

Load when: context above ~50%, work is parallelizable, output will be verbose, or you
are choosing between doing work inline and delegating it.

Contents: §1 Why · §2 Budget · §3 Delegation decision · §4 Subagents · §5 Agent teams
· §6 Model routing · §7 Compaction survival · §8 Tool output hygiene

---

## 1. Why this matters more than it looks

Context is not merely a capacity limit — it is a **signal-to-noise** problem. A window
half-filled with grep output and stack traces nobody will re-read degrades every
subsequent decision: instructions get lost, conventions get forgotten, skills stop
triggering, and the agent starts contradicting things it established twenty steps ago.

The failure is gradual and hard to notice from the inside. Which is exactly why the
thresholds below are mechanical rather than judgment calls.

**The core discipline:** keep *conclusions* in main context; push *the reading that
produced them* somewhere else.

---

## 2. Budget thresholds

Act on these without being asked.

| Usage | Posture |
|---|---|
| **<40%** | Normal. Work inline. |
| **40–60%** | Stop pulling large files into main context. Delegate new exploration. |
| **60–75%** | Checkpoint state to a scratch file. Delegate anything non-essential. |
| **>75%** | Write full state to disk **now**. Assume compaction is imminent. |
| **>90%** | Finish the current step, write handoff, recommend a fresh session. |

Checkpointing is not optional at the high end. Compaction is lossy in an unpredictable
direction: it tends to preserve recent turns and drop the middle, which is often
exactly where your established decisions live.

**Cheap wins, always available:**

- Read the 40 relevant lines, not the 2,000-line file.
- Grep for the symbol; do not read the directory.
- Pipe verbose commands to a file, then read the summary:
  `npm test > /tmp/test.log 2>&1; tail -30 /tmp/test.log`
- Use code intelligence / LSP symbol lookup instead of reading files to find a definition.
- `git diff --stat` before `git diff`.

---

## 3. Delegation decision

Delegate when **the volume of intermediate work exceeds the value of seeing it.**

| Signal | Decision |
|---|---|
| Answer needs reading many files; conclusion is short | **Subagent** |
| Output is high-volume and low-reuse (logs, greps, dumps) | **Subagent**, or file + selective read |
| Several independent workstreams, no coordination needed | **Parallel subagents** |
| Workstreams must challenge or inform each other | **Agent team** |
| Competing hypotheses to investigate simultaneously | **Agent team** |
| Mechanical, well-specified, no judgment | **Subagent on a cheap model** |
| Work needs your full conversation context | **Inline** — subagents don't inherit it |
| Interactive, ambiguous, needs the user mid-flight | **Inline** |
| One quick file read | **Inline** — delegation has overhead too |

**The cost you must weigh:** subagents do not inherit your conversation. Anything they
need, you must pass explicitly. Under-briefing a subagent produces confidently wrong
summaries — which are worse than no summary, because they *look* like findings. Brief
them as you would a competent contractor with no context: goal, constraints, what to
return, what not to touch.

---

## 4. Subagents

An isolated worker with its own context window that returns a summary to you.

**What loads in a subagent:** its own system prompt, the full content of any skills
listed in its `skills:` field, CLAUDE.md and git status (except the built-in Explore
and Plan agents, which omit both), plus whatever you pass in the prompt. **Not** your
conversation history and **not** skills you invoked.

**Briefing template — use it, weak briefs are the main failure mode:**

```
Goal: <the single question to answer, or artifact to produce>
Scope: <where to look; where NOT to look>
Context: <facts they need that they cannot discover — versions, decisions, constraints>
Return: <exact shape: "file:line + one-line explanation, max 10 items">
Do not: <modify files / install anything / touch prod>
```

**Return-shape discipline.** "Investigate the auth system" returns an essay. "Return
every file that reads `SESSION_SECRET`, as `path:line`, plus whether it validates
expiry — max 15 rows" returns something usable. Specify the shape.

**High-value patterns:**

- **Explorer** — map an unfamiliar area; return structure + entry points, not contents.
- **Verifier** — independently re-check a claim you made. Fresh context means no
  motivated reasoning inherited from the work you are trying to validate.
- **Reviewer** — security / performance / test-quality pass on a diff.
- **Reproducer** — get a bug to fail deterministically; return the minimal case.
- **Librarian** — read external docs and return the three relevant facts.

The **verifier** pattern is underused and disproportionately valuable: the agent that
wrote the code is the worst judge of whether it works, for the same reason authors miss
their own typos. A clean-context verifier given only the diff and the requirement
catches what you rationalized.

**Running a skill in isolation:** `context: fork` in a skill's frontmatter runs it in a
subagent. The skill body becomes the subagent's prompt — so a fork-mode skill needs
explicit step-by-step instructions. Reference-only content in a forked skill produces
nothing: the subagent receives knowledge but no task.

---

## 5. Agent teams

Multiple independent sessions with a shared task list and peer-to-peer messaging.
Higher token cost than subagents; each teammate is a full instance.

**Use when** teammates must confer: competing hypotheses on a hard bug, parallel review
where reviewers should react to each other's findings, or feature work where each owns a
separate piece and interfaces must be negotiated.

**Do not use** for anything a subagent can do. If only the result matters, a subagent is
cheaper and simpler.

**Transition signal:** you are running parallel subagents *and* hitting context limits,
or your subagents keep needing each other's findings. That is the moment agent teams
earn their cost.

Note: agent teams are experimental and disabled by default — check current status before
relying on them in a workflow you intend to hand to someone else.

---

## 6. Model routing

Match model capability to task difficulty. Uniform use of the most capable model is
waste; uniform use of the cheapest is malpractice.

| Work | Tier |
|---|---|
| Architecture, subtle debugging, security review, ambiguous requirements | Most capable |
| Standard implementation against a known pattern | Mid |
| Search, extraction, tallying, formatting, mechanical transforms | Cheapest |

Set per-skill with `model:` frontmatter, or per-subagent in its definition.

**Judgment rule:** if a wrong answer is cheap to detect and cheap to fix, go cheap. If
a wrong answer is expensive, silent, or hard to detect — security, data integrity,
migrations, anything touching money — do not economize.

---

## 7. Surviving compaction

Compaction is lossy. Design for it rather than being surprised by it.

**Write to disk anything you would have to re-derive:**

```markdown
<!-- .claude/scratch/<task>.md -->
# Task: <name>
Updated: <when>

## Goal
<one line>

## Decisions (do not silently reverse these)
- Chose X over Y because <reason>

## Done & verified
- <step> — verified by `<command>` → <result>

## Done, unverified
- <step> — needs <check>

## Next
1. <concrete next action>

## Landmines
- <thing that already bit you once>
```

Update it at each meaningful step, not at the end — the end is precisely when you might
not get the chance. Post-compaction, re-read it before continuing, and re-read the
governing files (CLAUDE.md, the file you are editing) rather than trusting your memory
of them. Memory of a file after compaction is a reconstruction, not a record.

---

## 8. Tool output hygiene

Every tool call spends context. Spend deliberately.

- Bound output at the source: `head`, `tail`, `--max-count`, `-n`, `LIMIT`, `--stat`.
- Prefer targeted grep over broad file reads.
- Do not re-read a file you have not changed and already read.
- Do not dump a whole config to show one value.
- Redirect verbose builds and test runs to a file; read the tail and the failures.
- When a command fails, read the *error*, not the entire log.

**MCP note:** tool schemas load on demand and tool search is on by default, so idle
servers cost little — but a connected server you are not using is still a source of
noise in tool selection. Disconnect what you are not working with.
