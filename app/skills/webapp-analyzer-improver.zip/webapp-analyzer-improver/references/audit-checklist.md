# Audit Checklist Reference

200-point audit checklist with pass/fail criteria organized by the 8 audit dimensions.

## Scoring Guide

Each check is scored:
- **PASS** (✅): Meets the standard
- **WARN** (⚠️): Partially meets or could be improved
- **FAIL** (❌): Does not meet the standard

### Dimension scores:
- 90-100: A (Excellent)
- 80-89: B (Good)
- 70-79: C (Acceptable)
- 60-69: D (Needs Work)
- 0-59: F (Critical Issues)

### Overall score: Weighted average
- Visual Design: 15%
- UI/UX Patterns: 15%
- Data Visualization: 10%
- Accessibility: 20% (weighted highest — non-negotiable)
- Performance: 15%
- Responsiveness: 10%
- Modernity: 10%
- Content/IA: 5%

---

## Dimension 1: Visual Design & Aesthetics (25 checks)

### Typography (8)
- [ ] Uses a consistent type scale (not random sizes)
- [ ] Maximum 2 font families loaded
- [ ] Body text ≥ 16px on mobile
- [ ] Headings have clear visual hierarchy (size + weight)
- [ ] Line height 1.5-1.75 for body text
- [ ] Line length 60-75 characters max
- [ ] Font weights used purposefully (not random bold)
- [ ] No system-only fonts (has custom font loaded)

### Color System (8)
- [ ] Has a defined primary color
- [ ] Has semantic color roles (success, error, warning, info)
- [ ] Uses CSS custom properties for colors (not scattered hex)
- [ ] Background/foreground contrast ≥ 4.5:1
- [ ] No more than 5-6 total colors in palette
- [ ] Consistent use of opacity/tints (not random grays)
- [ ] Dark mode support (or light mode that works)
- [ ] No pure black (#000) text on pure white (#fff) (use near-black)

### Spacing & Layout (5)
- [ ] Consistent spacing system (multiples of 4px or 8px)
- [ ] Cards/sections have adequate padding
- [ ] Sufficient white space between sections
- [ ] No cramped elements (everything breathes)
- [ ] Visual rhythm maintained throughout

### Visual Polish (4)
- [ ] Consistent border-radius across components
- [ ] Shadows used purposefully (not random)
- [ ] No visual orphans (single words or elements stranded)
- [ ] At least one visually distinctive element (gradient, illustration, pattern)

---

## Dimension 2: UI/UX Patterns (30 checks)

### Navigation (6)
- [ ] Primary navigation is clearly identifiable
- [ ] Current page/section indicated in nav
- [ ] Navigation has ≤ 7 top-level items
- [ ] Logo/brand links to home
- [ ] Breadcrumbs for pages > 2 levels deep
- [ ] Mobile navigation pattern present (hamburger/bottom nav)

### Interactions (8)
- [ ] All clickable elements have cursor:pointer
- [ ] Buttons have hover state
- [ ] Buttons have active/pressed state
- [ ] Links are visually distinct from regular text
- [ ] Form inputs have focus state
- [ ] Disabled states are visually clear
- [ ] Transitions/animations on state changes (not instant)
- [ ] No hover-dependent content on touch devices

### Feedback (8)
- [ ] Loading states present for async operations
- [ ] Success feedback after completing actions
- [ ] Error messages are specific and helpful
- [ ] Errors appear near the relevant field/element
- [ ] Confirmation before destructive actions
- [ ] Toast/notification for background operations
- [ ] Empty states have helpful message + action
- [ ] Progress indicators for multi-step processes

### Forms (8)
- [ ] All inputs have visible labels (not placeholder-only)
- [ ] Required fields are marked
- [ ] Input types match content (email, tel, number)
- [ ] Validation messages appear inline
- [ ] Submit button shows loading state
- [ ] Helper text for complex fields
- [ ] Proper tab order for keyboard navigation
- [ ] Error recovery is clear (how to fix)

---

## Dimension 3: Data Visualization (20 checks)

### Chart Presence (5)
- [ ] Data is visualized (not just raw numbers/tables)
- [ ] Chart type matches data type (see selection guide)
- [ ] At least one chart/graph if data is present
- [ ] KPI/metric cards for key numbers
- [ ] Trend indicators (up/down arrows) for comparative metrics

### Chart Quality (8)
- [ ] Charts have clear titles
- [ ] Axes are labeled
- [ ] Legends present for multi-series
- [ ] Tooltips on hover/tap
- [ ] Responsive (works on mobile widths)
- [ ] Accessible colors (not color-only meaning)
- [ ] No 3D effects or excessive decoration
- [ ] Appropriate data density (not too sparse or cluttered)

### Visual Enhancement (7)
- [ ] Icons used throughout (not text-only interface)
- [ ] Progress indicators for status/completion
- [ ] Badges/pills for categorical data
- [ ] Sparklines or mini-charts in tables/cards
- [ ] Animated number counters for statistics
- [ ] Color-coded status indicators
- [ ] Visual section dividers or decorative elements

---

## Dimension 4: Accessibility (35 checks)

### Perceivable (12)
- [ ] All images have alt text
- [ ] Decorative images have alt=""
- [ ] Color contrast ≥ 4.5:1 for normal text
- [ ] Color contrast ≥ 3:1 for large text (>18px bold)
- [ ] Information not conveyed by color alone
- [ ] Text can be resized to 200% without breaking
- [ ] No autoplaying media without controls
- [ ] Captions/transcripts for audio/video
- [ ] Content adapts to portrait/landscape
- [ ] No text in images (unless logo)
- [ ] SVG graphics have title/desc or aria-label
- [ ] Focus indicators visible (2px+ ring)

### Operable (10)
- [ ] All interactive elements keyboard accessible
- [ ] Tab order matches visual order
- [ ] No keyboard traps
- [ ] Skip-to-content link present
- [ ] Focus never lost after interaction
- [ ] Touch targets ≥ 44×44px
- [ ] Touch target spacing ≥ 8px
- [ ] No time limits (or adjustable)
- [ ] Animations respect prefers-reduced-motion
- [ ] No content that flashes >3 times/second

### Understandable (8)
- [ ] Page language declared (lang attribute)
- [ ] Heading hierarchy sequential (h1→h2→h3)
- [ ] Form fields have associated labels
- [ ] Error messages describe the problem
- [ ] Error messages suggest fixes
- [ ] Consistent navigation across pages
- [ ] Predictable behavior (no unexpected changes)
- [ ] Abbreviations explained on first use

### Robust (5)
- [ ] Semantic HTML used throughout
- [ ] ARIA roles used correctly (not redundant)
- [ ] ARIA states updated dynamically
- [ ] Valid HTML (no duplicate IDs)
- [ ] Works without JavaScript (progressive enhancement)

---

## Dimension 5: Performance & Code Quality (25 checks)

### Loading Performance (8)
- [ ] Total page weight < 2MB
- [ ] Initial JS < 200KB (gzipped)
- [ ] Images lazy loaded (below fold)
- [ ] Images have explicit width/height
- [ ] Fonts use font-display: swap
- [ ] Critical CSS inlined or early-loaded
- [ ] No render-blocking resources
- [ ] Third-party scripts async/deferred

### Code Quality (10)
- [ ] Semantic HTML5 elements used
- [ ] No inline styles (or minimal)
- [ ] No !important in CSS (or rare/justified)
- [ ] CSS custom properties for theme values
- [ ] No deprecated HTML elements
- [ ] No inline event handlers
- [ ] JavaScript uses const/let (not var)
- [ ] No console.log statements in production
- [ ] No commented-out code blocks
- [ ] Clean, readable code structure

### Layout Stability (4)
- [ ] No Cumulative Layout Shift (CLS)
- [ ] Font loading doesn't cause reflow
- [ ] Async content has reserved space
- [ ] No "jumping" on page load

### Meta & SEO (3)
- [ ] Viewport meta tag present and correct
- [ ] Title tag present and descriptive
- [ ] Meta description present

---

## Dimension 6: Responsiveness (20 checks)

### Breakpoint Coverage (5)
- [ ] Works at 375px (small phone)
- [ ] Works at 768px (tablet portrait)
- [ ] Works at 1024px (tablet landscape)
- [ ] Works at 1440px (desktop)
- [ ] No horizontal scrollbar at any breakpoint

### Mobile Adaptations (8)
- [ ] Font sizes readable on mobile (≥ 16px body)
- [ ] Navigation adapts for mobile
- [ ] Images scale properly
- [ ] Tables scroll horizontally or reformat
- [ ] Forms usable on mobile
- [ ] Touch targets properly sized
- [ ] No fixed-width containers breaking layout
- [ ] Bottom navigation or FAB for key actions

### Layout Flexibility (4)
- [ ] Uses CSS Grid or Flexbox (not floats)
- [ ] Columns stack properly on narrow screens
- [ ] Sidebars collapse or hide on mobile
- [ ] Hero/header adapts layout per breakpoint

### Cross-Device (3)
- [ ] Text doesn't overflow containers
- [ ] Interactive elements accessible on touch
- [ ] Media (video/embeds) responsive

---

## Dimension 7: Modernity (20 checks)

### CSS (7)
- [ ] Uses CSS custom properties
- [ ] Uses CSS Grid or Flexbox for layout
- [ ] Uses modern selectors (:is, :where, :has if needed)
- [ ] Uses clamp() or min()/max() for fluid values
- [ ] No float-based layouts
- [ ] No table-based layouts
- [ ] Uses logical properties where appropriate (if i18n)

### HTML (5)
- [ ] HTML5 doctype
- [ ] Semantic elements (nav, main, section, article, aside, footer)
- [ ] Modern form attributes (autocomplete, inputmode)
- [ ] No deprecated elements (font, center, marquee)
- [ ] Picture/source for responsive images

### JavaScript (5)
- [ ] ES6+ syntax (arrow functions, template literals, destructuring)
- [ ] Async/await (not callback chains)
- [ ] Module imports (not global scripts where possible)
- [ ] No jQuery (or justified use)
- [ ] Modern APIs (Intersection Observer, Fetch, etc.)

### Patterns (3)
- [ ] Component-based structure (even if vanilla)
- [ ] State management approach (if interactive)
- [ ] Event delegation where appropriate

---

## Dimension 8: Content & IA (25 checks)

### Structure (8)
- [ ] Clear page title/heading
- [ ] Logical section order
- [ ] Content grouped into scannable blocks
- [ ] Headers describe section content
- [ ] No more than 3-4 levels of hierarchy
- [ ] Related items grouped together
- [ ] Important content above the fold
- [ ] Call-to-action visible without scrolling

### Scannability (7)
- [ ] Short paragraphs (3-5 sentences max)
- [ ] Headers every 2-3 paragraphs
- [ ] Lists/bullets for multiple items
- [ ] Bold/emphasis for key terms
- [ ] Visual breaks between sections
- [ ] White space prevents wall-of-text
- [ ] Key metrics/numbers visually highlighted

### States (6)
- [ ] Loading state defined
- [ ] Empty state defined
- [ ] Error state defined
- [ ] Success state defined
- [ ] Offline/disconnected state (if applicable)
- [ ] First-time/onboarding state (if applicable)

### User Guidance (4)
- [ ] Clear labels on all buttons/actions
- [ ] Tooltips or help text for complex features
- [ ] Search available (if > 10 items)
- [ ] Filter/sort available (if list/table > 5 items)
