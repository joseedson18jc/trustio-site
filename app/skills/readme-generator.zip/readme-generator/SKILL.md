---
name: readme-generator
description: |
  Auto-generate professional README.md files for projects. Analyzes codebase structure, detects tech stack, and creates comprehensive documentation with badges, installation, and usage sections.
  TRIGGERS: README, documentation, project docs, generate readme, document project, project documentation, markdown docs
---

# README Generator

Create professional README files by analyzing project structure.

## Analysis Steps

1. Detect project type and tech stack
2. Find existing docs, configs, and entry points
3. Extract key information (deps, scripts, structure)
4. Generate appropriate sections

## Project Detection

```bash
# Check for project indicators
ls -la

# Package managers
[ -f package.json ] && echo "Node.js"
[ -f requirements.txt ] && echo "Python (pip)"
[ -f pyproject.toml ] && echo "Python (poetry/modern)"
[ -f Cargo.toml ] && echo "Rust"
[ -f go.mod ] && echo "Go"
```

## README Structure

```markdown
# Project Name

Brief description (from package.json, pyproject.toml, or inferred)

## Features
- Key feature 1
- Key feature 2

## Installation
[Based on detected package manager]

## Usage
[From scripts, main entry point, or examples]

## Configuration
[If config files detected]

## License
[From LICENSE file]
```

## Badge Generation

```markdown
![Python](https://img.shields.io/badge/Python-3.9+-blue)
![Node](https://img.shields.io/badge/Node.js-18+-green)
![License](https://img.shields.io/badge/License-MIT-yellow)
```

## Section Templates

### Installation (by type)

**Node.js:**
```bash
npm install
# or
yarn install
```

**Python:**
```bash
pip install -r requirements.txt
# or with poetry
poetry install
```

### Usage (from scripts)

Extract from `package.json` scripts or Python entry points:

```bash
# Development
npm run dev

# Build
npm run build

# Test
npm test
```

### Project Structure

```
├── src/           # Source code
├── tests/         # Test files
├── docs/          # Documentation
└── config/        # Configuration files
```

## Information Sources

| Information | Source |
|-------------|--------|
| Project name | package.json, pyproject.toml, folder name |
| Description | package.json description, docstring |
| Dependencies | package.json, requirements.txt |
| Scripts | package.json scripts, Makefile |
| License | LICENSE file |

## Output

Write to `README.md` in project root. If one exists, offer to:
1. Replace entirely
2. Update specific sections
3. Create `README.new.md` for comparison
