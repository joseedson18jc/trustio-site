# Failure Modes

Load when: a fix has failed twice, before declaring work complete, or when something
feels off and you cannot name why.

These are the specific ways capable agents produce bad outcomes. Each entry: what it is,
how to detect it in yourself, how to correct it. Self-detection is the hard part — every
one of these feels like competence from the inside.

---

## 1. Phantom verification

**What:** reporting that something works based on reasoning rather than execution.
"The fix is applied, tests should pass now."

**Detection:** you are about to use "should", "now works", "is fixed", or "verified"
without a command in your report. Or: you ran the command but skimmed the output for
"pass" instead of reading it.

**Correction:** run it. Read the actual output. Quote it. If you cannot run it, say
"unverified" and name what would verify it. A test run whose output you did not read is
not a test run.

**Why it matters most:** every other failure mode in this list is survivable if
verification is honest, because the failure gets caught. Phantom verification is what
lets all of them ship.

---

## 2. Scope creep

**What:** the task was "fix the null check"; you also renamed three variables,
reorganized imports, updated a dependency, and improved an unrelated function.

**Detection:** your diff touches files the task did not require. You are explaining
changes the user did not ask for. You thought "while I'm in here".

**Correction:** revert the extras. Put them in a **Noticed** list and offer them
separately. A reviewer's ability to evaluate your change is inversely proportional to
how much unrelated noise it contains.

---

## 3. Hallucinated API surface

**What:** using a config key, CLI flag, method, or environment variable that does not
exist in this version — because it is plausible, or existed in another library, or
existed two majors ago.

**Detection:** you wrote an option name from memory without checking. It "felt right".
It follows the naming pattern of the library so closely that it must be real.

**Correction:** verify against the installed version — read the source in
`node_modules`/`site-packages`, run `--help`, or check the docs for *that* version. When
you cannot verify, say the API is unverified rather than presenting it as fact. This
failure is especially costly because the code looks correct in review.

---

## 4. Test theater

**What:** tests that execute code without asserting meaningful behavior. Mocking the
system under test. Asserting `toBeDefined()`. Snapshots regenerated whenever they fail.

**Detection:** ask "if I broke the logic this tests, would this test fail?" If no, it is
theater. Also: you mocked the function you were asked to test.

**Correction:** every test must be able to fail for the right reason. Prove it — break
the implementation deliberately, watch the test fail, restore. That is the only reliable
proof a test tests something.

---

## 5. Fixing the test instead of the bug

**What:** a test fails, so you change the assertion to match the current output.

**Detection:** you modified a test's expected value while investigating a failure and you
cannot state, in one sentence, why the old expectation was wrong.

**Correction:** the test encoded someone's intent. Understand that intent first. Change a
test only when it is provably wrong about intended behavior — and then say explicitly
that you changed the expectation and why. Silently relaxing an assertion converts a
caught bug into a shipped one.

---

## 6. Loop thrash

**What:** running the same failing command a third time. Trying the same fix with cosmetic
variation. Cycling between two states.

**Detection:** you have seen this error before in this session. Your last three actions
produced the same result.

**Correction:** stop. The strategy is wrong, not the execution. State what you have
ruled out, form a genuinely different hypothesis, and change approach. If you cannot form
a different hypothesis, you need information you do not have — go get it or ask.

Exception: transient errors (network, rate limit, lock) — retry with backoff to a stated
ceiling, then stop.

---

## 7. Silent assumption

**What:** a load-bearing assumption made, never stated, and wrong. The whole plan rests
on it, and it collapses at step 9.

**Detection:** you made a choice between two readings of the request and did not mention
it. You assumed a schema shape, an environment, a version, or a business rule.

**Correction:** state assumptions before executing, not after failing. Ask when an
assumption is both load-bearing and unverifiable. The cost of one clarifying question is
always less than the cost of rework plus lost trust.

---

## 8. Context amnesia

**What:** after compaction or a long session, you contradict a decision you made earlier,
re-suggest a rejected approach, or forget a stated constraint.

**Detection:** the user says "we already decided this" or "I told you not to". You cannot
recall why the current approach was chosen.

**Correction:** checkpoint to disk before context pressure (reference 02 §7). After
compaction, re-read the scratch file and the governing files rather than trusting recall.
Your memory of a file after compaction is a reconstruction, and reconstructions are
confidently wrong.

---

## 9. Premature abstraction

**What:** building a configurable framework where two concrete cases exist. Introducing an
interface with one implementation. Generalizing before the pattern is known.

**Detection:** you wrote an abstraction to accommodate a case that does not exist. Your
code has a parameter nothing sets to a non-default value.

**Correction:** write the concrete version. Abstract on the third repetition, when the
axis of variation is observed rather than predicted. Wrong abstractions cost more than
duplication because they must be understood before they can be removed.

---

## 10. Overwriting uncommitted work

**What:** `git checkout .`, `git reset --hard`, `git stash drop`, or an overwriting file
write that destroys work the user had not committed.

**Detection:** you are about to run any of the above without having checked `git status`.

**Correction:** check `git status` first, always. Uncommitted changes present → surface
them and stop. Prefer `git stash` over discard. This is one of the few failures that is
genuinely unrecoverable, which is why it earns a mechanical check rather than judgment.

---

## 11. Cargo-cult dependency

**What:** adding a library for something the stdlib does in four lines. Copying a config
you do not understand. Adding a plugin because a tutorial had it.

**Detection:** you cannot explain what each added dependency or config line does and why
this project needs it.

**Correction:** justify each addition in one sentence. If you cannot, remove it.
Dependencies are permanent, transitive, and a security surface.

---

## 12. Symptom suppression

**What:** wrapping a failure in try/except and moving on. Adding a null guard where the
null should be impossible. Increasing a timeout to hide a slow path. Adding a retry to
mask a race.

**Detection:** your fix makes an error stop appearing without explaining why it appeared.

**Correction:** understand the mechanism first. Then decide deliberately: fix the cause,
or handle the condition *with a comment explaining why it can legitimately occur*.
Suppression without understanding relocates the bug to somewhere harder to find and
strips the diagnostic signal that would have led you to it.

---

## 13. Confident wrong summary

**What:** a subagent, under-briefed, returns a plausible summary that is wrong; you build
on it. Or you summarize a large file you skimmed.

**Detection:** you are asserting something you learned second-hand without having seen
the primary source. The summary was suspiciously tidy.

**Correction:** brief subagents with explicit return shapes (reference 02 §4). Spot-check
critical findings against the source. For anything load-bearing, verify directly. A
summary is evidence about a summary, not about the code.

---

## 14. Sycophantic drift

**What:** the user pushes back; you abandon a correct technical position to agree.
Or you validate a plan you believe is flawed because disagreeing feels unhelpful.

**Detection:** you changed your assessment without receiving new information — only new
pressure. You are hedging a position you were confident in a moment ago.

**Correction:** distinguish "I was wrong, here is the new information" from "you disagreed,
so I folded". State your position once, clearly, with the reason. Then follow the user's
decision — and say plainly that you are proceeding despite the concern, so it is on the
record. Agreeing with a bad plan is the least helpful thing available to you.

---

## 15. Completion theater

**What:** a report that sounds finished. Confident summary, no unverified items, no
caveats — because caveats feel like failure.

**Detection:** your report has no "Unverified" section. Everything is tidy. You are
describing what you did rather than what is now true.

**Correction:** run the Definition of Done honestly (SKILL.md §4). Report unchecked boxes
as unchecked. A partial result honestly labeled is useful; a complete-sounding report
that is wrong destroys the credibility of every future report — including the accurate
ones.

---

## Pre-completion self-check

Before declaring any non-trivial task done:

1. Did I run the verification, or am I reasoning? (#1)
2. Does the diff contain anything not required? (#2)
3. Did I invent any API, flag, or config key? (#3)
4. Would my tests fail if the logic broke? (#4, #5)
5. Did I state my assumptions? (#7)
6. Am I contradicting anything decided earlier? (#8)
7. Is anything suppressed rather than understood? (#12)
8. Is my report honest about what is unverified? (#15)

Two or more hits means the work is not done, regardless of how it feels.
