---
name: firecrawl
description: |
  Search, scrape, crawl, and map the web at scale with Firecrawl's hosted API — returns clean Markdown or structured JSON for JS-heavy pages without running a local browser. Use for web search with content, scraping a URL, crawling a whole site, or mapping a site's URLs.
  TRIGGERS: firecrawl, scrape url, crawl site, web search with content, map site urls, get clean markdown from web, extract structured data from web, /scrape, /crawl, /search, /map
---

# Firecrawl — hosted search / scrape / crawl / map

Firecrawl is a hosted web-context API. No local browser needed; it renders JS, bypasses most anti-bot friction, and returns Markdown or structured JSON. Best when you want reliability without managing Playwright.

## When to use this vs. alternatives
- **Use firecrawl** for hosted, reliable scraping + built-in web **search**, or crawling many pages without local infra.
- Use `crawl4ai` when you want a free, local headless-browser crawl.
- Use `markitdown` for converting local files (PDF/DOCX) to Markdown.
- Use `scrapy` for fully custom, rule-based crawls you host yourself.

## Setup (once)
Get a key at firecrawl.dev, then:
```bash
export FIRECRAWL_API_KEY="fc-..."
pip install firecrawl-py        # Python SDK
# or CLI:  npm i -g @firecrawl/cli   (command: firecrawl)
```

## Fast path — CLI
```bash
firecrawl search "web scraping api" --limit 5
firecrawl scrape https://example.com
firecrawl crawl https://docs.example.com --limit 50
firecrawl map https://example.com          # list a site's URLs fast
```

## Runnable helper (recommended)
Two equivalent helpers wrap the four core endpoints — use whichever matches the project.

Python (`scripts/fc.py`):
```bash
python scripts/fc.py search "firecrawl alternatives" --limit 5
python scripts/fc.py scrape https://example.com -o page.md
python scripts/fc.py crawl  https://docs.example.com --limit 30 --out-dir crawl_out
python scripts/fc.py map    https://example.com
```

Node / TypeScript (`scripts/fc.mjs`, Node 18+, `npm i firecrawl`):
```bash
node scripts/fc.mjs search "firecrawl alternatives" --limit 5
node scripts/fc.mjs scrape https://example.com -o page.md
node scripts/fc.mjs crawl  https://docs.example.com --limit 30 --out-dir crawl_out
node scripts/fc.mjs map    https://example.com
```

## Python API
```python
from firecrawl import Firecrawl
app = Firecrawl(api_key="fc-...")           # or reads FIRECRAWL_API_KEY

app.search("firecrawl", limit=5)            # results + content
doc = app.scrape("firecrawl.dev")           # doc.markdown / doc.html / doc.json
app.crawl("https://docs.firecrawl.dev", limit=50)
app.map("https://firecrawl.dev")            # URL discovery
```

## Endpoint cheat-sheet
- **search** — query the web, optionally with page content. Start here when you don't have a URL.
- **scrape** — one URL -> Markdown / HTML / structured JSON (pass a schema to extract fields).
- **crawl** — follow links from a root URL up to `--limit`; returns many docs.
- **map** — cheaply enumerate a site's URLs before deciding what to scrape.

## Good practices
- Keep `FIRECRAWL_API_KEY` in the environment, never hardcode it.
- `map` first, then `scrape` the URLs you actually need — cheaper than a blind `crawl`.
- Set a `--limit` on crawls; watch credit usage.
- Prefer structured extraction (schema/prompt) over regex on Markdown.
