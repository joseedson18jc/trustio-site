<!-- pff-version: 21.0 -->
# Histórico de versões — perito-financeiro-forense

Leia só para auditar a evolução da skill ou interpretar laudos antigos (códigos HC e contagens mudaram ao longo
das versões). Durante a perícia, este arquivo é dispensável.

## v21.0 — 10/10/2026 (revisão com skill-creator)

| # | Severidade | Área | Mudança |
|---|---|---|---|
| 1 | **CRÍTICA** | Pacote | A instalação encontrada em 10/10/2026 era de novo uma **quimera**: `SKILL.md` "v20.0" (linhagem paralela de 08/09) + references e command **v18** (HC até 27, sem §5-T1/T2/T3, mínimo existencial = salário mínimo). A v20 auditada foi reconstituída (build de 06/09 + 2ª passada de 08/09, recuperada do histórico) e serve de base. Novo `scripts/verificar_integridade.py` detecta quimeras no início de cada perícia. |
| 2 | **CRÍTICA** | §5.4, HC-29, Tabela 9 | **Tema 1.328 CANCELADO (02/10/2026)** — REsp 2.145.244/SC incluído no Tema 1.414. **Tema 1.325 não trata de RMC** (Sisbajud/"teimosinha"; trânsito 02/07/2026) — retirado de HC-29 e da Tabela 9. |
| 3 | **ALTA** | §5.4, Etapa 5 | **Tema 1.414 ampliado (02/10/2026):** decadência (art. 178 × 169 CC), parâmetros, consequências e dano moral. Novo item 44 (risco de decadência) na Etapa 5. |
| 4 | **ALTA** | §2.1, §5.3, `MARGENS` | **MP 1.355/2026 sem eficácia desde 01/09/2026** (confirmado no Congresso): margem INSS volta a 45%; janela 04/05–31/08/2026 tratada à parte; prazo de decreto legislativo até 30/10/2026. |
| 5 | **ALTA** | §3, §2.1, HC-18 | **CLT = 40% (35% empréstimo + 5% cartão)**, não 35% (os 35% são sublimite; redação da Lei 14.431/2022). |
| 6 | **ALTA** | §5.4, Etapa 5 item 35 | **Tema 1.268 é desfavorável ao consumidor** (coisa julgada impede nova ação por juros sobre tarifas já declaradas ilegais) — antes apresentado de forma neutra. |
| 7 | **ALTA** | Anexo B/C, `bcb_sgs.py` | **Códigos SGS de taxa média estavam errados** (25433, 25435, 27788, 27789). Corretos e conferidos: 25464, 25470, 25463, 25477; Taxa Legal 29543. |
| 8 | MÉDIA | §5.5 | Acórdão TCU 1.094/2026: os R$ 6,5 bi são da "Operação Sem Desconto", **não** perdas com RMC; cautelar suspende novas averbações de cartão consignado (novo item 45). |
| 9 | MÉDIA | §5.3, §5-T1 | Teto do rotativo amarrado ao texto: art. 2º-A, III (Res. 4.549 red. 5.112) define encargos financeiros = **multa e juros de mora** — IOF **e tarifas** ficam fora; art. 2º-D (operações após 90 dias da Lei 14.690) e vigência dos arts. 2º-A–2º-D em 01/07/2024 registrados. Detectado nos evals (um agente tratou tarifas como dentro do teto). |
| 10 | MÉDIA | §3.8 | IOF PF: teto do diário = 2,993% (máximo efetivo 3,373%, não 3,38%); IOF de operação parcelada calculado por amortização. |
| 11 | MÉDIA | §5.3 | Novas normas: Lei 15.252/2025 regulamentada pelas Res. CMN 5.299/2026 e Res. BCB 564/2026 (vigência 01/07/2027); MP 1.373/2026 (Desenrola Adimplentes); Decreto 12.564/2025, Res. BCB 468/516/2025 e Res. CCFGTS 1.130/2025 descritos corretamente. |
| 12 | MÉDIA | Arquitetura | Todo o código saiu das references para `scripts/` (fonte única, testada): `pericia.py` (33 auto-testes), `extrair_pdfs.py` (catálogo, OCR, pré-parse, V1/V2), `bcb_sgs.py` (séries com cache e proveniência), `verificar_integridade.py`. |
| 13 | MÉDIA | SKILL.md | Reescrito enxuto: changelogs fora do caminho, fluxo de trabalho explícito, porquês das regras, estado das normas voláteis em uma tabela. Command reduzido a um invólucro (sem contagens duplicadas — eram a origem das divergências entre arquivos). |
| 15 | **ALTA** | §6.3, Tabela 3, `impacto_divergencias` | **Impacto em VP somava `Dif_t` (estoque) linha a linha** — contava a mesma divergência N vezes. Agora soma-se δ_t = Dif_t − Dif_{t−1}. |
| 16 | **ALTA** | §3.7, `liquidacao_antecipada` | **Liquidação antecipada descontava duas vezes** (`S_t − VP dos juros futuros`), dando quitação abaixo do saldo. Correto: VP das parcelas a vencer à taxa pactuada (Res. CMN 5.004/2022 art. 7º). |
| 17 | **ALTA** | §4.5, `juros_mora_contratual` | **Juros de mora são simples.** A v20 chamava a forma exponencial de "exata" e mandava usá-la acima de 90 dias (+5,7% em 1 ano). Exponencial agora só como sensibilidade. |
| 18 | **ALTA** | §3.2.1, Cenário E, `recalcular_saldo` | **Juros simples sobre P₀ (principal original) estava errado** — cobra juros sobre capital já amortizado. Agora: capital remanescente + juros pendentes não capitalizáveis; variante Gauss (`pmt_gauss`). Explicitado que, com juros pagos em dia, simples = Price. |
| 19 | MÉDIA | §3.4 | SAM: o saldo **é** a média dos saldos Price e SAC (a v20 afirmava o contrário); prova e teste incluídos. |
| 20 | MÉDIA | §5.3, Etapa 5 itens 12/29/42 | Res. CMN 5.004/2022 incluída (taxa pactuada na liquidação; despesas financiadas à mesma taxa; vedação de cobrança sem instrumento). |
| 21 | BAIXA | Biblioteca | `--selftest` de 33 → 43 testes (identidades SAM, Gauss, juros simples, mora, liquidação, impacto). |
| 14 | BAIXA | Contagens | Etapa 5: 43 → 45 itens; checklist final: 63 → 65 itens. Verificadas por script. |

## v6 → v16.1 (Anexos E–T)

**Anexo E:** v6→v6.1 — 11 modificações (6 correções súmulas, 1 waterfall, 1 fórmula, 2 aprimoramentos).

**Anexo F:** v6.1→v6.2 — 24 modificações (14 OCR, 5 lógica/fórmulas, 3 consistência, 2 adições).

**Anexo G:** v6.2→v7.0 — 12 modificações (3 fórmulas, 5 definições, 4 consistência). Juros simples corrigido para taxa proporcional. Cenários A–H definidos.

**Anexo H:** v7.0→v7.1 — 6 modificações. v7.1→v7.2: reformatação (tabelas left-align, code blocks, sem alteração de conteúdo).

**Anexo I:** v7.2→v7.3 — 233 underscores escapados. Zero alterações de conteúdo.

**Anexo J:** v7.3→v7.4 — 12 itens + ~26 tabelas corrigidas. IPCA-15, Art. 413, Cenário I, superendividamento.

**Anexo K:** v7.4/v9.0→v10.0 — Merge definitivo. 30 integrações/adições (12 do PDF v9.0, 12 do TXT v7.4, 6 exclusivas v10.0).

**Anexo L:** v10.0→v10.1 — 6 modificações (1 lógica, 1 matemática, 1 ref. cruzada, 1 consistência, 2 adições).

**Anexo M:** v10.1→v10.2 — 5 itens + 7 tabelas corrigidas (renderização markdown, ambiguidade fórmula mora, completude changelog).

**Anexo N:** v10.2→v11.0 — 28 adições substantivas (6 novas seções, 5 expansões, 4 HC codes, 8 referências legais, Cenário J).

**Anexo O:** v11.0→v12.0 — 4 modificações (§0 protocolo extração ~100 linhas, correção waterfall pseudocódigo, correção Res. 4.765 data, +1 checklist item). Versão final: §0–§12 + Anexos A–O, ~2.040 linhas, 42 itens checklist.

**Anexo P:** v12.0→v13.0 — 8 correções substantivas (scenario counting, conversão taxa, §11.3 adicionado, checklist expandido, cenário J clarificado, sistema americano detalhado, glossário atualizado Lei 14.601/2023 e Etapa 7).

**Anexo Q:** v13.0→v14.0 — 12 melhorias (§0-PRE ingestão multi-PDF com 5 subseções, extração dual parsing+OCR, reconciliação A∩B, consolidação multi-arquivo, filtragem para escopo, Etapa 7 tabelas alinhadas com §8.C, cenários Etapa 7 alinhados com §10.1, contagem cenários 15→14, auditoria-divida.md reescrito: Súmula 541→472, cenários A-G→A-J, checklist 10→14 itens, 5 estágios progressivos, T1-T6→T1-T9, §4.9→§4.8, checklist final 44→50 itens).

**Anexo R:** v14.0→v15.0 — 11 correções (1 CRÍTICA, 6 MÉDIA, 4 BAIXA):
1. **[CRÍTICA]** Fórmula SAC na seção SAM corrigida: `(P / n − Am × (t−1))` → `(P − Am × (t−1))` — erro produzia saldo SAC negativo a partir de t=3.
2. **[MÉDIA]** Typo "cumpula" → "cumula" em REsp 1.081.149/RS (regulatorio-formulas.md).
3. **[MÉDIA]** Referência normativa atualizada: Res. 3.919/2010 → Res. BCB 4.949/2021 (auditoria-divida.md).
4. **[MÉDIA]** Cross-reference corrigido: SKILL.md §4.6 apontava para regulatorio-formulas.md §4.6 (Pagamento Parcial) em vez de §2.1 (Módulos por Produto).
5. **[MÉDIA]** Seção "INTERAÇÃO PROGRESSIVA" numerada como §5 para consistência de navegação.
6. **[MÉDIA]** Resolução de portabilidade atualizada: Res. CMN 4.292/2013 → Res. CMN 5.057/2022 (protocolo-pipeline.md + marco regulatório).
7. **[MÉDIA]** Numeração §6.4 → §6.3 corrigida (gap de numeração em Etapa 6, regulatorio-formulas.md).
8. **[BAIXA]** "Mínimo 20 arquivos PDF" suavizado para "Tipicamente 20+" em auditoria-divida.md (evita rejeição de casos com menos arquivos).
9. **[BAIXA]** SAC fórmula na seção SAM agora inclui expressão do saldo explícita: `S_SAC_{t−1} = P − Am × (t−1)`.
10. **[BAIXA]** Res. CMN 5.057/2022 adicionada à tabela de marco regulatório §5.
11. **[BAIXA]** Version bump v14.0 → v15.0 em SKILL.md e auditoria-divida.md.

**Anexo S:** v15.0→v16.0 — 9 melhorias (3 ALTA, 4 MÉDIA, 2 BAIXA):
1. **[ALTA]** Adicionados HC-20 a HC-24: portabilidade com spread abusivo (Res. CMN 5.057/2022), superendividamento (Lei 14.181/2021, Art. 104-A CDC), tarifa avaliação duplicada (Res. BCB 4.949/2021), título capitalização vinculado (Circ. SUSEP 620/2020), amortização extraordinária sem desconto proporcional.
2. **[ALTA]** Cenário J — mora: corrigida regra ambígua `max(JMORA_MAX, Selic)` para regra explícita de aplicação contextual (Selic se contrato omisso; contratual se ≤1%; limitada a 1% se >1%; comparar ambas e adotar menor como mais favorável ao devedor).
3. **[ALTA]** Adicionado Anexo B — Consulta BACEN SGS API: tabela de séries (Selic 11, CDI 12, IPCA 433, IGP-M 189, taxas médias 25433/25435/27789/27788), endpoint REST, código Python para fator Selic acumulado.
4. **[MÉDIA]** Score de qualidade dos dados rebalanceado: penalidades mais granulares (5-10% vs >10% para campos obrigatórios), separação T1-T6 (críticos, -12) vs T7-T9 (complementares, -5), caps por categoria para anomalias (ALTA max -25, MÉDIA max -10), adicionada penalidade de gap temporal.
5. **[MÉDIA]** Checklist regulatório Etapa 5 ampliado de 14 para 18 itens (itens 15-18: portabilidade, superendividamento, tarifa avaliação, capitalização vinculada).
6. **[MÉDIA]** Adicionadas 3 referências normativas ao marco regulatório §5: Art. 104-A CDC, Circ. SUSEP 620/2020, Res. BCB 4.949/2021.
7. **[MÉDIA]** Cross-references atualizados: "HC-01 a HC-19" → "HC-01 a HC-24", "14 itens" → "18 itens" em SKILL.md, auditoria-divida.md, outputs-cenarios-anexos.md, regulatorio-formulas.md.
8. **[BAIXA]** Nota adicionada ao score de qualidade: pontuação MÉDIA não impede análise, apenas exige ressalvas documentadas.
9. **[BAIXA]** Version bump v15.0 → v16.0 em SKILL.md e auditoria-divida.md.

**Anexo T:** v16.0→v16.1 — 5 correções (1 ALTA, 3 MÉDIA, 1 BAIXA):
1. **[ALTA]** §4.5: Fórmula de juros moratórios exponencial actual/365 corrigida — agora converte taxa mensal para anual efetiva (`i_a = (1+i_m)^12 − 1`) antes de aplicar expoente `dias/365`. Versão anterior usava `(1+i_m)^(dias/30)`, misturando dias reais com base fixa de 30 — inconsistência dimensional em convenção actual/365. Divergência: ~0,03% a 90d, ~0,17% a 180d, ~0,7% a 365d.
2. **[MÉDIA]** §3.1: Convenção 30/360 atualizada para regra NASD/ISMA completa — fórmula agora inclui componente de ano `360×(a₂−a₁)` e ajuste de fim de mês (dia 31→30). Implementação Python incluída.
3. **[MÉDIA]** §3.6: Lógica de amortização negativa no waterfall corrigida — critério anterior (`principal==0 AND remanescente==0`) também flagrava casos onde pagamento cobria juros mas não principal. Novo critério: `pgto < juros_total_devido`, que detecta corretamente quando principal cresce. Adicionados parâmetro `tol` e campo `juros_nao_cobertos`.
4. **[MÉDIA]** §6.1: Cálculo de `dif_pct` com tratamento robusto de divisão por zero — cascading fallback `|saldo_calc|` → `|saldo_banco|` → `0.0` quando ambos saldos são próximos de zero. Implementação Python incluída.
5. **[BAIXA]** Anexo B: Função `fator_selic` reescrita com timeout, `raise_for_status()`, tratamento de exceções (`RequestException`, `ValueError`, `KeyError`), retorno `None` em caso de falha, e instrução de fallback (série 432 como proxy).


## ANEXO V — CHANGELOG v16.1→v18.0

v16.1→v18.0 — 7 adições de campo (validadas em caso real com 25 extratos mensais de conta corrente multiproduto; a v17 não foi publicada — numeração consolidada na v18.0):

1. **[ALTA]** §0-PRE.6 (protocolo-pipeline.md): protocolo para extratos mensais multiproduto — parser posicional com âncoras de coluna, recorte estrito da seção Movimentação, **validação quádrupla** (V1 fechamento em cadeia; V2 continuidade entre meses; V3 totais impressos da capa + totalizador "na conta corrente (1)"; V4 diff contra consolidado auditado) e catálogo de armadilhas (regex de "total" da capa aos pares/página 1, deltas ±(aplic_ent − aplic_sai) como assinatura de captura trocada, reimpressão de blocos, seed por "Saldo anterior").
2. **[ALTA]** §0-PRE.7 (protocolo-pipeline.md): painel "Crédito | Contratado" como série temporal auditável — T8-painel (Σ saldos = total impresso da seção Crédito), contrato que desaparece sem liquidação como evento de transição, `parcelas_pagas` congelado + saldo subindo como detector de mora, dívida que transita por fatura de cartão (fora do extrato da conta).
3. **[ALTA]** HC-25 (extinção de contrato sem lastro), HC-26 (rolagem em cadeia < 90 dias — Lei 14.181/2021), HC-27 (mora acruada sem decomposição) em §4.3.1.
4. **[MÉDIA]** Etapa 4.4 (regulatorio-formulas.md): inferência de taxa via painel — taxa implícita `i_t = (S_t + PMT − S_{t−1})/S_{t−1}`, taxa de acruamento sem pagamento, mediana como estimador robusto, TIR/XIRR do fluxo do painel, validação cruzada por REQM.
5. **[MÉDIA]** Checklist regulatório Etapa 5 ampliado de 18 para 20 itens (19: extinção sem lastro; 20: rolagem em cadeia).
6. **[MÉDIA]** Checklist final §10.4 ampliado de 50 para 53 itens; §11.2 documentos a solicitar: item 14 (faturas de cartão).
7. **[BAIXA]** Version bump v16.1 → v18.0 em SKILL.md e auditoria-divida.md; description do frontmatter ampliada (extratos mensais multiproduto, painel de crédito, "Sob Medida"/parcelamento de fatura).

---


## ANEXO Y — CHANGELOG v18.0 → v19.0

**Natureza:** consolidação de duas linhagens divergentes (v17 monolítica, não publicada;
v18 modular, publicada), com correção de três defeitos.

| # | Severidade | Área | Descrição |
|---|---|---|---|
| 1 | **CRÍTICA** | §4.3.1 | **Colisão de códigos HC.** v17 e v18 atribuíam significados diferentes a HC-25/26/27. Preservados os códigos publicados da v18; hipóteses da v17 remapeadas para HC-28–HC-38. Tabela de correspondência no Anexo X. |
| 2 | **ALTA** | Etapa 4, Método 4 | **Viés na inferência de taxa.** Prazo medido em dias corridos substituído por meses-calendário. Viés medido: `dias/30` −1,434% na taxa (−0,192 p.p. no CET); `dias/365` (v18) −0,058% (−0,008 p.p.). |
| 3 | **ALTA** | Etapa 5 | **Checklist incompleto.** 20 → 35 itens. HC-18 e HC-19 não tinham item disparador. (A alegação de "HC-completo" era falsa — corrigida na v20.0, Anexo Z item 14.) |
| 4 | MÉDIA | §5 | Marco regulatório reorganizado em 5 blocos e ampliado (~25 referências, 10 Temas STJ, 8 precedentes). |
| 5 | MÉDIA | §5 Nota 6 | Protocolo de revalidação obrigatório para referências voláteis. |
| 6 | MÉDIA | §5-T1 / §5-T2 | Testes computacionais parametrizados (teto do rotativo; dívida perpétua RMC/RCC). |
| 7 | MÉDIA | §1.2 | Arquitetura de agentes (ORQUESTRADOR + SA-1..SA-7). |
| 8 | MÉDIA | §3 | Parâmetros `MARG_CONSIGN_CLT`, `TETO_ROTATIVO`, `MIN_EXISTENCIAL`, `MARG_RMC_INSS`. |
| 9 | MÉDIA | §10 | Cenários K e L; sensibilidade 5 → 8 parâmetros / 21 cenários. |
| 10 | MÉDIA | §8 | Tabelas 8 e 9. |
| 11 | BAIXA | §10.4 | Checklist final 53 → 62 itens. |
| 12 | BAIXA | Anexo W | Suíte de 67 testes da v17 rebaixada a evidência histórica. |

> **Nota de auditoria (v20.0):** o pacote v19.0 efetivamente instalado continha apenas o
> `SKILL.md` da v19; as três references e o command permaneceram na v18.0. Os itens acima só
> passaram a existir nos arquivos de referência a partir da v20.0 (ver Anexo Z, item 1).

---

## ANEXO Z — CHANGELOG v19.0 → v20.0 (auditoria total, 06/09/2026)

| # | Severidade | Área | Descrição |
|---|---|---|---|
| 1 | **CRÍTICA** | Pacote | **Pacote v19.0 era uma quimera:** `SKILL.md` v19 + references e command v18 (HC só até 27; checklist Etapa 5 com 20 itens; sem §5-T1/T2, sem Newton-Raphson corrigido, sem Tabelas 8/9, sem Anexos W/X/Y; command declarava "v18.0"). Todo o conteúdo da v19 foi reconstruído a partir dos scripts de build originais e reinstalado; verificação de integridade cruzada entre os 5 arquivos. |
| 2 | **CRÍTICA** | §3, §5, §5-T3, Cenário K | **Mínimo existencial corrigido.** A v19 fixava `MIN_EXISTENCIAL = salário mínimo`. O Decreto 11.150/2022 (red. Dec. 11.567/2023) fixa **R$ 600,00**; o STF (ADPFs 1.005/1.006/1.097, abr/2026) manteve o valor sob revisão anual do CMN e declarou **inconstitucional excluir o consignado** do cômputo. Novo teste §5-T3; HC-37 e Cenário K reescritos. |
| 3 | **ALTA** | §4.5, §5.2, Cenário J | **Art. 406 CC pós-Lei 14.905/2024.** A v19 dizia "Selic (já inclui correção)". Correto: desde 30/08/2024 a taxa legal é **Selic − IPCA-15** (juros simples, piso zero — Res. CMN 5.171/2024) com correção **IPCA em separado** (art. 389 §ú). Até 29/08/2024: Selic integral (Tema 1.368/STJ, out/2025). Cálculo de mora legal passa a ser segmentado. |
| 4 | **ALTA** | §3, §2.1, §5.3, HC-18 | **MP 1.355/2026 revalidada em 06/09/2026:** prazo constitucional final 31/08/2026 sem comissão mista nem votação; sem lei de conversão localizada → **provavelmente caducada**. Cronograma 2027–2029 do RMC/RCC não se aplica se confirmada a caducidade; regras da MP só regem contratos da janela 04/05–31/08/2026 (CF art. 62 §11). `MARG_RMC_INSS` e `MARG_CONSIGN` passam a série temporal explícita. |
| 5 | MÉDIA | §2.1, §5.3, HC-18 | **Histórico da margem consignável corrigido:** Lei 13.172/2015 = 35% (30+5), não 40%; o patamar 40% (35+5) veio com a Lei 14.431/2022; 45% INSS com a Lei 14.601/2023. |
| 6 | MÉDIA | §5.3, HC-22, HC-34, Etapa 5 | **Res. 4.949/2021 é do CMN**, não do BCB; ela revogou a Res. CMN 3.919/2010 (que a v19 ainda citava como vigente em HC-34). Circ. BCB 3.872/2017 removida do item 22 (tarifa do cheque especial regulada pela própria Res. CMN 4.765/2019). |
| 7 | MÉDIA | §5.4 | Temas STJ revalidados em 06/09/2026: 1.414 (afetado 24/02/2026, suspensão 17/03/2026, paradigmas listados), 1.378 (instrução no REsp 2.227.280/PR) e 1.264 seguem pendentes; 1.325/1.328 marcados `[STATUS NÃO RECONFERIDO INDIVIDUALMENTE]` com remissão ao 1.414; Tema 1.368 (fixado) adicionado. STF ADPFs 1.005/1.006/1.097 e Acórdão TCU 1.094/2026 adicionados ao §5.5. |
| 8 | MÉDIA | Tabela 9 | Coluna obrigatória **"Checado em"** e linha para a MP 1.355/2026 (norma volátil). |
| 9 | MÉDIA | Etapa 7, §8.B | Referências obsoletas corrigidas: "7 tabelas" → 9; "20 itens" → 35; "14 cenários" → 21; Cenário J detalhado por regime. |
| 10 | BAIXA | SKILL.md, protocolo | Referência cruzada "§7, 2.7–2.10 triagem" corrigida para **§2.4** (a triagem foi inserida como 2.4.1–2.4.10). |
| 11 | BAIXA | §10.4 | Checklist final 62 → 63 itens (§5-T3 e triagem §2.4). |
| 12 | BAIXA | Anexo B | Nota sobre a série mensal da Taxa Legal (BCB) sem assumir código SGS de memória. |
| 14 | **ALTA** | Etapa 5 | **Alegação "HC-completo" da v19 era falsa.** HC-03, 07, 08, 11, 12, 13, 24 e 27 não tinham item disparador e as linhas 1–20 não citavam código HC. Adicionados itens 36–43 e coluna HC em todas as linhas; cobertura agora verificada por script (35 → 43 itens). |
| 13 | BAIXA | Todos | Version bump v19.0 → v20.0 em SKILL.md e command; data de revalidação 06/09/2026 em SKILL.md e §5. |

**Verificação executada na v20.0:** compilação de todos os blocos Python; execução de
`newton_raphson_taxa` (auto-verificação), `verificar_teto_rotativo`,
`verificar_divida_perpetua_rmc`, `verificar_minimo_existencial`; integridade HC-01..38+99
(definidos e citados); guarda de colisão HC-25/26/27; ausência de marcadores obsoletos
("A–J", "20 itens", "53 itens", "14 cenários", "v18/v19 corrente"); frontmatter válido com
description ≤ 1024 caracteres.
