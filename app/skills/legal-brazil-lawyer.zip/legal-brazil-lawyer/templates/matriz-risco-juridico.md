# Template: Matriz de Risco Jurídico

**USO**: Para análise de contingências em due diligence, relatório de passivo, auditoria jurídica interna ou suporte à provisão contábil.

---

## IDENTIFICAÇÃO

- **Empresa / Unidade**: _______________
- **Data base**: _______________
- **Elaborado por**: _______________

---

## CRITÉRIOS DE CLASSIFICAÇÃO

### Probabilidade de perda
| Nível | Faixa | Tratamento contábil (CPC 25) |
|---|---|---|
| Provável | > 75% | Provisionar integralmente |
| Possível | 25–75% | Divulgar em nota; avaliar provisão por política |
| Remoto | < 25% | Divulgar em nota se valor material |

### Impacto financeiro estimado
| Nível | Critério |
|---|---|
| Alto | > R$ [THRESHOLD] |
| Médio | R$ [THRESHOLD_MIN] a R$ [THRESHOLD_MAX] |
| Baixo | < R$ [THRESHOLD_MIN] |

---

## MATRIZ DE CONTINGÊNCIAS

### Trabalhista

| Nº | Natureza | Fase | Valor discutido | Probabilidade | Provisão sugerida | Observação |
|---|---|---|---|---|---|---|
| 1 | | | R$ | | R$ | |
| 2 | | | R$ | | R$ | |
| **TOTAL** | | | **R$** | | **R$** | |

### Tributária

| Nº | Tributo | Fase | Valor discutido | Probabilidade | Provisão sugerida | Observação |
|---|---|---|---|---|---|---|
| 1 | | | R$ | | R$ | |
| 2 | | | R$ | | R$ | |
| **TOTAL** | | | **R$** | | **R$** | |

### Cível / Contratual

| Nº | Natureza | Fase | Valor discutido | Probabilidade | Provisão sugerida | Observação |
|---|---|---|---|---|---|---|
| 1 | | | R$ | | R$ | |
| 2 | | | R$ | | R$ | |
| **TOTAL** | | | **R$** | | **R$** | |

### Regulatória / Administrativa

| Nº | Órgão | Fase | Valor/Sanção | Probabilidade | Provisão sugerida | Observação |
|---|---|---|---|---|---|---|
| 1 | | | R$ | | R$ | |
| **TOTAL** | | | **R$** | | **R$** | |

---

## CONSOLIDADO GERAL

| Frente | Valor total discutido | Provisão total sugerida |
|---|---|---|
| Trabalhista | R$ | R$ |
| Tributária | R$ | R$ |
| Cível / Contratual | R$ | R$ |
| Regulatória | R$ | R$ |
| **TOTAL** | **R$** | **R$** |

---

## RISCOS NÃO QUANTIFICADOS

| Item | Natureza | Descrição | Nível de risco |
|---|---|---|---|
| 1 | | | 🔴/🟡/🟢 |
| 2 | | | |

---

## OBSERVAÇÕES E RECOMENDAÇÕES

[Incluir: pontos que demandam monitoramento, ações para mitigação de risco, prazo de revisão da matriz, eventos que podem alterar as probabilidades estimadas.]

---

**AVISO**: Valores e probabilidades estimados com base nos fatos e documentos disponíveis na data base. A matriz deve ser revisada periodicamente e sempre que houver alteração relevante no status das contingências. Não substitui laudo de perito ou revisão por advogado responsável pela causa.
