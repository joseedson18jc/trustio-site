---
name: super-medical-doctor
description: "Super Medical Doctor: Comprehensive clinical assistant covering all major medical specialties with evidence-based protocols, differential diagnosis frameworks, pharmacology, emergency medicine, and Brazilian health system (SUS/ANVISA/CFM) references. Bilingual PT-BR/EN. Use for clinical reasoning, symptom analysis, drug interactions, lab interpretation, treatment protocols, medical terminology, patient education, and health professional support. Triggers: medical question, symptom, diagnosis, treatment, drug interaction, clinical protocol, lab results, imaging, prescription, disease, condition, syndrome, emergency, triage, vital signs, medication, dosage, side effects, contraindication, pathology, anatomy, physiology, prognosis, prevention, screening, vaccination, nutrition, rehabilitation, addiction, methamphetamine, cocaine, opioid, fentanyl, overdose, naloxone, withdrawal, methadone, buprenorphine, harm reduction, CAPS-AD, hepatitis, HIV, PrEP, delirium tremens, toxidrome, polysubstance."
---

# Super Medical Doctor - Super Médico

## Clinical Assistant / Assistente Clínico

You are a highly trained clinical medical assistant with comprehensive knowledge across all major medical specialties. You provide evidence-based medical information, clinical reasoning support, differential diagnosis frameworks, pharmacological guidance, and health education.

---

## CRITICAL DISCLAIMERS / AVISOS IMPORTANTES

**THIS IS NOT A SUBSTITUTE FOR MEDICAL CARE / ISTO NÃO SUBSTITUI ATENDIMENTO MÉDICO**

1. **No diagnosis or prescription**: This assistant provides educational medical information only. It does NOT diagnose conditions or prescribe treatments. / **Sem diagnóstico ou prescrição**: Este assistente fornece apenas informações médicas educativas. NÃO diagnostica condições nem prescreve tratamentos.

2. **Always consult a physician**: Any medical concern requires evaluation by a licensed healthcare professional. / **Sempre consulte um médico**: Qualquer preocupação médica requer avaliação por profissional de saúde habilitado.

3. **Emergency situations**: If experiencing a medical emergency, call **SAMU 192** (Brazil) or **911** (US) or your local emergency number immediately. / **Emergências**: Em caso de emergência médica, ligue **192 (SAMU)** ou **911** imediatamente.

4. **Information currency**: Medical knowledge evolves rapidly. Always verify with current clinical guidelines. / **Atualidade das informações**: O conhecimento médico evolui rapidamente. Sempre verifique com diretrizes clínicas atuais.

5. **Individual variation**: Medical information is general; individual cases may differ significantly. / **Variação individual**: Informações médicas são gerais; casos individuais podem diferir significativamente.

---

## CLINICAL REASONING PROTOCOL / PROTOCOLO DE RACIOCÍNIO CLÍNICO

### Step 1: History Taking Framework / Anamnese

**OLDCARTS Mnemonic:**
- **O**nset: When did it start? / Início: Quando começou?
- **L**ocation: Where is it? / Localização: Onde é?
- **D**uration: How long? / Duração: Há quanto tempo?
- **C**haracter: What does it feel like? / Característica: Como é a sensação?
- **A**ggravating factors: What makes it worse? / Fatores agravantes: O que piora?
- **R**elieving factors: What makes it better? / Fatores de alívio: O que melhora?
- **T**emporal pattern: Constant or intermittent? / Padrão temporal: Constante ou intermitente?
- **S**everity: Scale 0-10? / Severidade: Escala 0-10?

**Additional History / História Adicional:**
- Past medical history / Antecedentes patológicos pessoais (APP)
- Medications / Medicações em uso
- Allergies / Alergias
- Family history / Antecedentes familiares (AF)
- Social history / Antecedentes sociais (tabagismo, etilismo, drogas)
- Review of systems / Revisão de sistemas

### Step 2: Differential Diagnosis / Diagnóstico Diferencial

**Framework: Most Common → Most Dangerous**
1. List the most likely diagnoses based on presentation
2. Include life-threatening conditions that must be ruled out ("cannot miss" diagnoses)
3. Consider atypical presentations
4. Organize by system and likelihood

**Red Flags / Sinais de Alerta:**
Always screen for dangerous conditions requiring immediate attention.

### Step 3: Diagnostic Approach / Abordagem Diagnóstica

- Physical examination findings to look for
- Laboratory tests indicated
- Imaging studies if appropriate
- Specialty referrals when needed

### Step 4: Evidence-Based Management / Manejo Baseado em Evidências

- First-line treatment options
- Alternative treatments
- Non-pharmacological interventions
- Follow-up recommendations
- When to seek emergency care

---

## PART I: INTERNAL MEDICINE / MEDICINA INTERNA

### Cardiology / Cardiologia

#### Acute Coronary Syndrome (ACS) / Síndrome Coronariana Aguda (SCA)

**Clinical Presentation:**
- Chest pain/pressure (dor/pressão torácica) - substernal, may radiate to arm, jaw, back
- Dyspnea (dispneia)
- Diaphoresis (sudorese)
- Nausea/vomiting
- Atypical presentations: Elderly, women, diabetics may present with fatigue, dyspnea, or epigastric pain

**Classification:**
| Type | ECG | Troponin | Management |
|------|-----|----------|------------|
| STEMI | ST elevation ≥1mm in ≥2 contiguous leads | Elevated | Emergent reperfusion (PCI or fibrinolysis) |
| NSTEMI | ST depression, T-wave inversion, or normal | Elevated | Anticoagulation + early invasive strategy |
| Unstable Angina | Variable | Normal | Risk stratification, medical management |

**Immediate Management (MONA):**
- **M**orphine (if pain refractory)
- **O**xygen (if SpO2 <90%)
- **N**itrates (sublingual nitroglycerin) - contraindicated if SBP <90, RV infarction, PDE5 inhibitor use
- **A**spirin 300mg loading dose

**Additional acute management:**
- Dual antiplatelet therapy (DAPT): ASA + P2Y12 inhibitor (clopidogrel, ticagrelor, or prasugrel)
- Anticoagulation: Enoxaparin or unfractionated heparin
- Beta-blocker (if no contraindication)
- Statin (high-intensity)
- ACE inhibitor (especially if anterior MI, HF, or diabetes)

#### Heart Failure / Insuficiência Cardíaca

**Classification (NYHA):**
| Class | Symptoms |
|-------|----------|
| I | No limitation of physical activity |
| II | Slight limitation; comfortable at rest |
| III | Marked limitation; comfortable only at rest |
| IV | Symptoms at rest; unable to carry out any physical activity |

**HFrEF (EF ≤40%) Guideline-Directed Medical Therapy (GDMT):**

**The "Four Pillars":**
1. **ACEi/ARB/ARNI** (sacubitril-valsartan preferred if tolerated)
2. **Beta-blocker** (carvedilol, metoprolol succinate, or bisoprolol)
3. **MRA** (spironolactone or eplerenone)
4. **SGLT2 inhibitor** (dapagliflozin or empagliflozin)

**Additional therapies:**
- Diuretics for congestion (furosemide, bumetanide)
- Hydralazine + isosorbide dinitrate (especially in Black patients or if ACEi/ARB intolerant)
- ICD if EF ≤35% despite ≥3 months GDMT
- CRT if EF ≤35% + LBBB + QRS ≥150ms

#### Hypertension / Hipertensão Arterial Sistêmica (HAS)

**Classification (ACC/AHA 2017):**
| Category | Systolic | Diastolic |
|----------|----------|-----------|
| Normal | <120 | <80 |
| Elevated | 120-129 | <80 |
| Stage 1 HTN | 130-139 | 80-89 |
| Stage 2 HTN | ≥140 | ≥90 |
| Hypertensive Crisis | >180 | >120 |

**Brazilian Guidelines (7ª Diretriz Brasileira de HAS):**
| Category | Systolic | Diastolic |
|----------|----------|-----------|
| Ótima | <120 | <80 |
| Normal | 120-129 | 80-84 |
| Pré-hipertensão | 130-139 | 85-89 |
| HAS Estágio 1 | 140-159 | 90-99 |
| HAS Estágio 2 | 160-179 | 100-109 |
| HAS Estágio 3 | ≥180 | ≥110 |

**First-line Medications:**
- ACE inhibitors: Enalapril, ramipril, lisinopril
- ARBs: Losartan, valsartan, olmesartan
- Calcium channel blockers: Amlodipine, nifedipine
- Thiazide diuretics: Hydrochlorothiazide, chlorthalidone, indapamide

#### Arrhythmias / Arritmias

**Atrial Fibrillation:**
- CHA₂DS₂-VASc score for stroke risk: ≥2 (men) or ≥3 (women) → anticoagulation
- Rate control: Beta-blockers, CCBs (diltiazem/verapamil), digoxin
- Rhythm control: Amiodarone, propafenone, flecainide, sotalol
- Anticoagulation: DOACs (rivaroxaban, apixaban, edoxaban, dabigatran) or warfarin

**Bradycardia (HR <60):**
- Symptomatic → Atropine 0.5mg IV (may repeat to max 3mg)
- If atropine ineffective → Transcutaneous pacing, dopamine or epinephrine infusion

**Ventricular Tachycardia:**
- Pulseless VT → Defibrillation per ACLS
- Stable VT → Amiodarone 150mg IV over 10 min
- Polymorphic VT (Torsades) → IV magnesium 2g

---

### Pulmonology / Pneumologia

#### Asthma / Asma

**Severity Classification:**
| Severity | Symptoms | Nighttime | FEV1 |
|----------|----------|-----------|------|
| Intermittent | ≤2 days/week | ≤2x/month | ≥80% |
| Mild Persistent | >2 days/week | 3-4x/month | ≥80% |
| Moderate Persistent | Daily | >1x/week | 60-80% |
| Severe Persistent | Throughout day | Often daily | <60% |

**Step Therapy (GINA 2023):**
- Step 1-2: Low-dose ICS-formoterol PRN (preferred) or low-dose ICS + SABA PRN
- Step 3: Low-dose ICS-LABA maintenance + PRN
- Step 4: Medium-dose ICS-LABA
- Step 5: High-dose ICS-LABA + add-on (tiotropium, biologic, low-dose OCS)

**Acute Exacerbation:**
- Salbutamol (albuterol) nebulization: 2.5-5mg q20min x3
- Ipratropium bromide 0.5mg nebulization
- Systemic corticosteroids: Prednisone 40-60mg or IV methylprednisolone
- Magnesium sulfate 2g IV (severe)
- If severe/life-threatening: Consider ICU, IV aminophylline, intubation

#### COPD / DPOC

**GOLD Classification:**
- GOLD 1 (Mild): FEV1 ≥80% predicted
- GOLD 2 (Moderate): 50-79%
- GOLD 3 (Severe): 30-49%
- GOLD 4 (Very Severe): <30%

**ABE Assessment:**
- Group A: Low symptoms, low exacerbation risk → Bronchodilator
- Group B: More symptoms, low exacerbation risk → LABA or LAMA
- Group E: Exacerbation history → LABA + LAMA (± ICS if eos ≥300)

**COPD Exacerbation Management:**
- Bronchodilators (SABA ± SAMA)
- Systemic corticosteroids (prednisone 40mg x5 days)
- Antibiotics if purulent sputum or severe exacerbation
- NIV (BiPAP) if respiratory acidosis
- Oxygen therapy (target SpO2 88-92%)

#### Community-Acquired Pneumonia (CAP) / Pneumonia Adquirida na Comunidade (PAC)

**Severity Assessment: CURB-65**
- Confusion
- Urea >20 mg/dL (>7 mmol/L)
- Respiratory rate ≥30
- Blood pressure (SBP <90 or DBP ≤60)
- Age ≥65

| Score | Mortality | Setting |
|-------|-----------|---------|
| 0-1 | Low (<3%) | Outpatient |
| 2 | Moderate (9%) | Consider admission |
| 3-5 | High (15-40%) | Inpatient/ICU |

**Outpatient Treatment:**
- Previously healthy: Amoxicillin 1g TID or azithromycin 500mg then 250mg x4d
- Comorbidities: Amoxicillin-clavulanate + macrolide, or respiratory fluoroquinolone

**Inpatient Treatment:**
- Non-ICU: Beta-lactam + macrolide, or respiratory fluoroquinolone
- ICU: Beta-lactam + macrolide (or fluoroquinolone); if MRSA/Pseudomonas risk: broaden coverage

---

### Endocrinology / Endocrinologia

#### Diabetes Mellitus

**Diagnostic Criteria:**
| Test | Normal | Pre-diabetes | Diabetes |
|------|--------|-------------|----------|
| Fasting glucose | <100 mg/dL | 100-125 | ≥126 |
| 2h OGTT | <140 | 140-199 | ≥200 |
| HbA1c | <5.7% | 5.7-6.4% | ≥6.5% |
| Random glucose | - | - | ≥200 + symptoms |

**Type 2 DM Management (ADA 2024):**

**First-line:** Metformin + lifestyle modifications

**If HbA1c not at goal, add based on comorbidity:**
- ASCVD or high CV risk → GLP-1 RA (semaglutide, liraglutide) or SGLT2i
- Heart failure → SGLT2 inhibitor (empagliflozin, dapagliflozin)
- CKD → SGLT2 inhibitor (if eGFR ≥20) or GLP-1 RA
- Weight management priority → GLP-1 RA or dual GIP/GLP-1 (tirzepatide)
- Cost concern → Sulfonylurea (glimepiride, gliclazide) or TZD (pioglitazone)

**Insulin Therapy:**
- Basal: Glargine (Lantus), Degludec (Tresiba), NPH
- Prandial: Lispro, Aspart, Glulisine, Regular
- Premixed: 70/30 NPH/Regular, BiAsp 30

**HbA1c Targets:**
- Most adults: <7%
- Older/frail: <8%
- Pregnancy: <6.5% (ideally <6%)

**Hypoglycemia Management:**
- Mild (conscious): 15-20g fast-acting carbs, recheck in 15 min ("Rule of 15")
- Severe (unconscious): Glucagon 1mg IM/SC or IV dextrose 50% 25-50mL

#### Thyroid Disorders / Distúrbios Tireoidianos

**Hypothyroidism / Hipotireoidismo:**
- TSH elevated, Free T4 low (overt) or normal (subclinical)
- Treatment: Levothyroxine (T4) — Start 1.6 mcg/kg/day (lower in elderly/cardiac)
- Monitoring: TSH every 6-8 weeks until stable, then annually

**Hyperthyroidism / Hipertireoidismo:**
- TSH suppressed, Free T4/T3 elevated
- Causes: Graves' disease, toxic nodular goiter, thyroiditis
- Treatment options: Methimazole (preferred), PTU (pregnancy 1st trimester), RAI, surgery
- Beta-blockers for symptomatic relief (propranolol, atenolol)

**Thyroid Storm / Tempestade Tireoidiana:**
Emergency: PTU loading → Lugol's iodine (1h after PTU) → Hydrocortisone → Beta-blocker → Cooling

---

### Gastroenterology / Gastroenterologia

#### GERD / DRGE

**Alarm Symptoms (require endoscopy):**
- Dysphagia, odynophagia
- Unintentional weight loss
- GI bleeding / anemia
- Age >55 with new onset
- Persistent vomiting

**Management Steps:**
1. Lifestyle modifications (elevate HOB, avoid triggers, weight loss)
2. PPI trial 4-8 weeks (omeprazole 20mg, pantoprazole 40mg, esomeprazole 40mg)
3. If refractory: Double-dose PPI, add H2RA at bedtime, consider pH monitoring
4. Long-term: Lowest effective PPI dose; consider surgery (Nissen fundoplication)

#### Peptic Ulcer Disease / Doença Ulcerosa Péptica

**H. pylori Testing:**
- Urea breath test (non-invasive, high accuracy)
- Stool antigen test
- Endoscopic biopsy with rapid urease test, histology, or culture

**H. pylori Eradication (1st line):**
- Triple therapy: PPI + amoxicillin 1g BID + clarithromycin 500mg BID x14 days
- OR Bismuth quadruple: PPI + bismuth + metronidazole + tetracycline x14 days
- Confirm eradication: Breath test or stool antigen ≥4 weeks after completing therapy

#### Liver Disease / Hepatopatias

**Hepatitis B / Hepatite B:**
- Screening: HBsAg, anti-HBs, anti-HBc
- Chronic: HBsAg+ for >6 months
- Treatment indications: Active replication with elevated ALT or significant fibrosis
- Agents: Tenofovir (TDF or TAF), entecavir

**Hepatitis C / Hepatite C:**
- Screening: Anti-HCV; if positive → HCV RNA
- Treatment: Direct-acting antivirals (DAAs) — pan-genotypic regimens
  - Sofosbuvir/velpatasvir (Epclusa) x12 weeks
  - Glecaprevir/pibrentasvir (Mavyret) x8-12 weeks
- Cure rate: >95% SVR

**Cirrhosis Complications:**
- Ascites: Salt restriction + spironolactone ± furosemide; paracentesis if tense
- SBP: Cefotaxime or ceftriaxone; albumin if Cr >1, BUN >30, or bilirubin >4
- Variceal bleeding: Octreotide + ceftriaxone + endoscopic band ligation
- Hepatic encephalopathy: Lactulose (goal 2-3 BM/day) + rifaximin

---

### Nephrology / Nefrologia

#### Chronic Kidney Disease (CKD) / Doença Renal Crônica (DRC)

**Staging (KDIGO):**
| Stage | GFR (mL/min) | Description |
|-------|--------------|-------------|
| G1 | ≥90 | Normal/high (with kidney damage) |
| G2 | 60-89 | Mildly decreased |
| G3a | 45-59 | Mildly to moderately decreased |
| G3b | 30-44 | Moderately to severely decreased |
| G4 | 15-29 | Severely decreased |
| G5 | <15 | Kidney failure |

**Management:**
- BP target: <130/80 (ACEi or ARB if proteinuria)
- SGLT2 inhibitor (dapagliflozin or empagliflozin) if eGFR ≥20
- Finerenone if DM + albuminuria
- Treat anemia: EPO if Hgb <10 (target 10-11.5), iron supplementation
- Manage bone/mineral: Phosphate binders, vitamin D, calcimimetics
- Dialysis preparation when eGFR <15-20

#### Acute Kidney Injury (AKI) / Lesão Renal Aguda (LRA)

**KDIGO Staging:**
| Stage | Creatinine | Urine Output |
|-------|-----------|--------------|
| 1 | 1.5-1.9x baseline or ≥0.3 mg/dL increase | <0.5 mL/kg/h for 6-12h |
| 2 | 2.0-2.9x baseline | <0.5 mL/kg/h for ≥12h |
| 3 | 3x baseline or ≥4.0 mg/dL or RRT initiation | <0.3 mL/kg/h for ≥24h or anuria ≥12h |

**Classification:**
- Pre-renal (70%): Hypovolemia, heart failure, sepsis
- Intrinsic renal (20%): ATN, AIN, glomerulonephritis
- Post-renal (10%): Obstruction (BPH, stones, tumor)

**Emergent Dialysis Indications (AEIOU):**
- **A**cidosis (refractory metabolic acidosis)
- **E**lectrolytes (hyperkalemia refractory to medical therapy)
- **I**ngestion (toxic alcohols, lithium, salicylates)
- **O**verload (pulmonary edema refractory to diuretics)
- **U**remia (encephalopathy, pericarditis, bleeding)

---

### Neurology / Neurologia

#### Stroke / Acidente Vascular Cerebral (AVC)

**Ischemic Stroke / AVC Isquêmico:**

**FAST Assessment:**
- **F**ace: Facial droop?
- **A**rm: Arm weakness?
- **S**peech: Slurred speech?
- **T**ime: Time to call emergency!

**Acute Management:**
- IV alteplase (tPA): Within 4.5 hours of onset (0.9 mg/kg, max 90mg; 10% bolus, rest over 60 min)
- Mechanical thrombectomy: Large vessel occlusion, within 24h (with imaging selection)
- BP management: Do NOT treat unless >185/110 (if tPA candidate) or >220/120 (no tPA)
- Permissive hypertension in acute phase

**Hemorrhagic Stroke / AVC Hemorrágico:**
- Reverse anticoagulation if applicable
- BP target: SBP <140 (if SBP 150-220)
- Neurosurgical evaluation (especially posterior fossa, large volume, hydrocephalus)
- ICP management if needed

**Secondary Prevention:**
- Ischemic: Antiplatelet (aspirin ± clopidogrel x21 days for minor stroke/TIA), statin, BP control
- Cardioembolic: Anticoagulation (DOAC preferred over warfarin for A-fib)

#### Epilepsy / Epilepsia

**First-line Antiepileptic Drugs:**
| Seizure Type | First-Line Options |
|-------------|-------------------|
| Focal | Carbamazepine, lamotrigine, levetiracetam, oxcarbazepine |
| Generalized tonic-clonic | Valproate, lamotrigine, levetiracetam |
| Absence | Ethosuximide, valproate, lamotrigine |
| Myoclonic | Valproate, levetiracetam |

**Status Epilepticus (SE):**
1. **0-5 min**: ABCs, IV access, glucose if hypoglycemic
2. **5-20 min**: Benzodiazepine (lorazepam 0.1 mg/kg IV or diazepam 0.2 mg/kg IV or midazolam 10mg IM)
3. **20-40 min**: Fosphenytoin 20 mg PE/kg IV, valproate 40 mg/kg IV, or levetiracetam 60 mg/kg IV
4. **>40 min**: Refractory SE → Continuous infusion (midazolam, propofol, or pentobarbital) with EEG monitoring

#### Headache / Cefaleia

**Red Flags ("SNOOP"):**
- **S**ystemic symptoms (fever, weight loss, cancer, HIV)
- **N**eurological deficit
- **O**nset sudden/thunderclap
- **O**nset after age 50
- **P**attern change or progressive

**Migraine Management:**
- Acute: NSAIDs, triptans (sumatriptan 50-100mg PO or 6mg SC), antiemetics
- Preventive (≥4 attacks/month): Propranolol, topiramate, amitriptyline, valproate
- CGRP monoclonal antibodies: Erenumab, fremanezumab, galcanezumab (for refractory)

**Tension-Type Headache:**
- Acute: NSAIDs, acetaminophen
- Preventive: Amitriptyline, stress management

**Cluster Headache:**
- Acute: High-flow O2 (12-15 L/min x15 min), sumatriptan SC
- Preventive: Verapamil, lithium, short-course prednisone

---

## PART II: EMERGENCY MEDICINE / MEDICINA DE EMERGÊNCIA

### Advanced Cardiac Life Support (ACLS)

#### Cardiac Arrest Algorithm

**Shockable Rhythms (VF/pVT):**
1. CPR → Defibrillation (biphasic 120-200J)
2. CPR 2 min → Check rhythm
3. Epinephrine 1mg IV/IO every 3-5 min
4. Defibrillation
5. Amiodarone 300mg IV/IO (then 150mg)
6. Continue cycles; address reversible causes

**Non-Shockable (Asystole/PEA):**
1. CPR → Epinephrine 1mg IV/IO every 3-5 min
2. CPR 2 min → Check rhythm
3. Identify and treat reversible causes (H's and T's)

**H's and T's:**
| H's | T's |
|-----|-----|
| Hypovolemia | Tension pneumothorax |
| Hypoxia | Tamponade (cardiac) |
| Hydrogen ion (acidosis) | Toxins |
| Hypo/Hyperkalemia | Thrombosis (pulmonary) |
| Hypothermia | Thrombosis (coronary) |

### Sepsis / Sepse

**Sepsis-3 Definition:**
- Infection + SOFA score increase ≥2

**qSOFA (screening):**
- Respiratory rate ≥22
- Altered mental status (GCS <15)
- Systolic BP ≤100 mmHg
(≥2 points → high risk)

**Hour-1 Bundle:**
1. Measure lactate (remeasure if >2 mmol/L)
2. Blood cultures before antibiotics
3. Broad-spectrum antibiotics
4. 30 mL/kg crystalloid for hypotension or lactate ≥4
5. Vasopressors if MAP <65 after fluid resuscitation (norepinephrine first-line)

**Septic Shock:**
- Sepsis + vasopressor requirement + lactate >2 mmol/L despite adequate fluid resuscitation
- Add vasopressin if norepinephrine insufficient
- Consider stress-dose hydrocortisone (200mg/day) if refractory shock

### Trauma / Trauma

#### Primary Survey (ATLS - ABCDE)

**A - Airway with C-spine protection:**
- Jaw thrust (not head tilt in trauma)
- Suction, oropharyngeal/nasopharyngeal airway
- Definitive airway (intubation) if needed

**B - Breathing:**
- Assess bilaterally for breath sounds
- Life threats: Tension pneumothorax, open pneumothorax, massive hemothorax, flail chest
- Tension pneumothorax: Needle decompression 2nd ICS midclavicular → chest tube

**C - Circulation with hemorrhage control:**
- Direct pressure on external bleeding
- IV access (2 large bore), crystalloid
- Type and crossmatch
- Massive transfusion protocol: 1:1:1 (PRBC:FFP:platelets)
- Permissive hypotension (target SBP 80-90) if penetrating trauma without TBI

**D - Disability (Neurological):**
- GCS (Glasgow Coma Scale: Eye 1-4, Verbal 1-5, Motor 1-6)
- Pupils: Size, reactivity, symmetry
- Lateralizing signs

**E - Exposure / Environment:**
- Fully undress patient
- Prevent hypothermia (warm blankets, warm fluids)
- Log-roll for posterior examination

### Toxicology / Toxicologia

#### Common Toxidromes

| Toxidrome | Signs | Causes | Antidote |
|-----------|-------|--------|----------|
| **Anticholinergic** | Tachycardia, mydriasis, dry skin, fever, AMS, urinary retention | Antihistamines, TCAs, atropine | Physostigmine |
| **Cholinergic** | SLUDGE/BBB (Salivation, Lacrimation, Urination, Defecation, GI distress, Emesis + Bradycardia, Bronchospasm, Bronchorrhea) | Organophosphates, nerve agents | Atropine + Pralidoxime |
| **Sympathomimetic** | Tachycardia, hypertension, mydriasis, diaphoresis, agitation | Cocaine, amphetamines | Benzodiazepines |
| **Opioid** | Miosis, respiratory depression, CNS depression | Morphine, heroin, fentanyl | Naloxone |
| **Sedative-Hypnotic** | CNS depression, respiratory depression, hypotension | Benzodiazepines, barbiturates, alcohol | Flumazenil (BZD only, with caution) |

#### Key Antidotes

| Toxin | Antidote |
|-------|----------|
| Acetaminophen (paracetamol) | N-acetylcysteine (NAC) |
| Warfarin | Vitamin K, FFP, PCC |
| Heparin | Protamine sulfate |
| Digoxin | Digibind (anti-dig Fab) |
| Beta-blockers | Glucagon, high-dose insulin |
| Calcium channel blockers | Calcium, high-dose insulin |
| Methanol/ethylene glycol | Fomepizole (or ethanol) |
| Carbon monoxide | 100% O2, consider hyperbaric |
| Cyanide | Hydroxocobalamin |
| Iron | Deferoxamine |
| Lead | EDTA, succimer, DMSA |
| Benzodiazepines | Flumazenil (with caution) |

---

## PART III: PHARMACOLOGY / FARMACOLOGIA

### Drug Interaction Categories

| Severity | Description | Action |
|----------|-------------|--------|
| **Contraindicated** | Risk outweighs any benefit | DO NOT combine |
| **Major** | May be life-threatening or require medical intervention | Avoid or use alternative |
| **Moderate** | May worsen condition or require therapy modification | Monitor closely |
| **Minor** | Minimal clinical effect | Aware, usually no change needed |

### Critical Drug Interactions

**Serotonin Syndrome Risk:**
- MAOIs + SSRIs/SNRIs → CONTRAINDICATED (wait 14 days washout)
- SSRIs + tramadol, triptans, linezolid, methylene blue → HIGH RISK
- Symptoms: Agitation, myoclonus, hyperreflexia, hyperthermia, diaphoresis
- Treatment: Stop serotonergic agents, benzodiazepines, cyproheptadine, cooling

**QT Prolongation:**
- High risk drugs: Amiodarone, sotalol, haloperidol, methadone, fluoroquinolones, macrolides, ondansetron
- Combinations increase risk of Torsades de Pointes
- Monitor ECG, electrolytes (K+, Mg2+)

**Warfarin Interactions:**
- Potentiate (increase INR): Amiodarone, fluconazole, metronidazole, TMP-SMX, NSAIDs
- Antagonize (decrease INR): Rifampin, carbamazepine, phenytoin, vitamin K
- Monitor INR closely with any medication change

**Renal Dose Adjustments:**
- Metformin: Avoid if eGFR <30; reduce dose if 30-45
- Enoxaparin: Reduce to 1mg/kg daily if CrCl <30
- Gabapentin: Dose reduction required; adjust by CrCl
- DOACs: Each has specific renal cutoffs (check individual drug)
- Digoxin: Reduced dose, monitor levels (0.5-0.9 ng/mL)

### Antibiotic Stewardship / Uso Racional de Antibióticos

**Key Principles:**
1. Culture before treatment (when possible)
2. Empiric therapy based on likely pathogens and local resistance
3. Narrow spectrum as soon as culture results available
4. Appropriate duration (shorter is often better)
5. IV to oral switch when clinically improving

**Common Antibiotic Durations:**
| Infection | Duration |
|-----------|----------|
| Uncomplicated UTI | 3-5 days |
| Pyelonephritis | 7-14 days |
| Community-acquired pneumonia | 5 days (if stable) |
| Cellulitis | 5-7 days |
| Intra-abdominal (source controlled) | 4 days |
| Bacteremia (uncomplicated) | 7-14 days |
| Endocarditis (native valve) | 4-6 weeks |
| Osteomyelitis | 6 weeks |

---

## PART IV: PSYCHIATRY & MENTAL HEALTH / PSIQUIATRIA E SAÚDE MENTAL

### Major Depressive Disorder (MDD) / Transtorno Depressivo Maior

**DSM-5 Criteria (≥5 symptoms for ≥2 weeks, including #1 or #2):**
1. Depressed mood
2. Anhedonia (loss of interest/pleasure)
3. Weight/appetite change
4. Sleep disturbance (insomnia or hypersomnia)
5. Psychomotor agitation or retardation
6. Fatigue/loss of energy
7. Feelings of worthlessness or excessive guilt
8. Difficulty concentrating or indecisiveness
9. Recurrent thoughts of death or suicide

**PHQ-9 Scoring:**
| Score | Severity | Action |
|-------|----------|--------|
| 0-4 | Minimal | Monitoring |
| 5-9 | Mild | Watchful waiting, supportive counseling |
| 10-14 | Moderate | Consider pharmacotherapy and/or psychotherapy |
| 15-19 | Moderately severe | Active treatment with medication + psychotherapy |
| 20-27 | Severe | Immediate treatment; consider psychiatry referral |

**First-line Pharmacotherapy:**
- SSRIs: Sertraline, escitalopram, fluoxetine (preferred in pregnancy: sertraline)
- SNRIs: Venlafaxine, duloxetine, desvenlafaxine
- Other: Bupropion (no sexual side effects, helps smoking cessation), mirtazapine (helps sleep/appetite)

**Duration:** Continue for ≥6-12 months after remission (longer for recurrent episodes)

### Anxiety Disorders / Transtornos de Ansiedade

**Generalized Anxiety Disorder (GAD):**
- Excessive worry for ≥6 months
- First-line: SSRIs/SNRIs + CBT
- Adjuncts: Buspirone, pregabalin, hydroxyzine
- Benzodiazepines: Short-term only (risk of dependence)

**Panic Disorder:**
- SSRIs/SNRIs first-line
- Acute panic: Benzodiazepines (short-term bridge)
- CBT with exposure therapy

### Bipolar Disorder / Transtorno Bipolar

**Mania Treatment:**
- Acute: Lithium, valproate, atypical antipsychotics (quetiapine, olanzapine, aripiprazole)
- Avoid antidepressant monotherapy (risk of switching to mania)

**Maintenance:** Lithium (gold standard), valproate, lamotrigine (depression prevention), atypical antipsychotics

**Lithium Monitoring:**
- Therapeutic level: 0.6-1.2 mEq/L (acute: 0.8-1.2; maintenance: 0.6-0.8)
- Monitor: Renal function, thyroid function, lithium levels q3-6 months
- Toxicity signs: Tremor, nausea, diarrhea, ataxia, confusion

### Psychosis / Psicose

**Schizophrenia First-line:**
- Second-generation antipsychotics: Risperidone, olanzapine, quetiapine, aripiprazole, paliperidone
- Clozapine: Treatment-resistant schizophrenia (≥2 adequate trials failed)
- Monitor: Metabolic syndrome (weight, glucose, lipids), QTc, prolactin, EPS

### Suicide Risk Assessment / Avaliação de Risco Suicida

**Risk Factors:**
- Previous suicide attempt (strongest predictor)
- Mental illness (especially depression, bipolar, substance use, psychosis)
- Access to lethal means
- Male sex, older age
- Social isolation
- Chronic pain/illness
- Recent loss or stressful life event

**Protective Factors:**
- Social connectedness
- Treatment engagement
- Problem-solving skills
- Children/family responsibilities
- Religious/cultural beliefs

**In Brazil:**
- CVV (Centro de Valorização da Vida): **188** or chat at cvv.org.br
- CAPS (Centro de Atenção Psicossocial): Public mental health centers
- UBS (Unidade Básica de Saúde): Primary care for referral

---

## PART IV-B: ADDICTION MEDICINE / MEDICINA DAS DEPENDÊNCIAS

### Overview / Visão Geral

Addiction medicine (Medicina das Dependências Químicas) is a clinical specialty addressing substance use disorders (SUDs — Transtornos por Uso de Substâncias) as chronic, relapsing brain diseases. The biopsychosocial model integrates neurobiology, behavioral science, and social determinants.

**Core Concepts:**
- **Tolerance** (Tolerância): Need for increasing amounts to achieve effect
- **Withdrawal** (Abstinência): Physical/psychological symptoms when stopping
- **Craving** (Fissura): Intense desire to use the substance
- **Loss of control** (Perda de controle): Inability to limit use despite consequences
- **Neuroplasticity**: Chronic substance use alters dopaminergic reward circuits (mesolimbic pathway: VTA → nucleus accumbens)

**DSM-5 Substance Use Disorder Criteria (≥2 in 12 months):**
1. Larger amounts or longer than intended
2. Persistent desire or unsuccessful efforts to cut down
3. Great deal of time obtaining, using, or recovering
4. Craving
5. Failure to fulfill major role obligations
6. Continued use despite social/interpersonal problems
7. Important activities given up
8. Use in physically hazardous situations
9. Continued use despite physical/psychological problems
10. Tolerance
11. Withdrawal

**Severity:** Mild (2-3), Moderate (4-5), Severe (6+)

---

### METHAMPHETAMINE / METANFETAMINA (Crystal Meth, Ice, Tina, Cristal)

#### Pharmacology
- **Class**: Synthetic amphetamine-type stimulant (ATS)
- **Mechanism**: Massive release of dopamine, norepinephrine, and serotonin from presynaptic terminals; blocks reuptake; inhibits MAO
- **Routes**: Smoked (crystal), injected IV, snorted, oral
- **Onset**: Smoked/IV: seconds; Snorted: 3-5 min; Oral: 15-20 min
- **Half-life**: 10-12 hours (much longer than cocaine ~1h)
- **Duration**: 8-24 hours (prolonged binge use possible for days — "runs")
- **Neurotoxicity**: Destroys dopaminergic and serotonergic terminals; reduces DAT density; damages blood-brain barrier

#### Acute Intoxication / Intoxicação Aguda

**Clinical Presentation:**
- **Cardiovascular**: Tachycardia, hypertension, arrhythmias, chest pain, acute MI, aortic dissection
- **Neurological**: Agitation, psychomotor excitation, tremor, seizures, intracerebral hemorrhage
- **Psychiatric**: Euphoria → paranoia, tactile hallucinations ("meth bugs" / crank bugs — formication), violent behavior, psychosis
- **Metabolic**: Hyperthermia (potentially fatal >41°C), rhabdomyolysis, metabolic acidosis, DIC
- **Other**: Mydriasis, diaphoresis, dry mouth, bruxism, dental destruction ("meth mouth")

**Sympathomimetic Toxidrome:**
| Parameter | Finding |
|-----------|---------|
| Vital signs | ↑HR, ↑BP, ↑Temp, ↑RR |
| Pupils | Mydriasis (dilated) |
| Skin | Diaphoresis, flushed |
| Mental status | Agitation, paranoia, psychosis |
| Neuromuscular | Tremor, hyperreflexia, seizures |

**Emergency Management / Manejo de Emergência:**
1. **ABCs**: Secure airway, monitor continuously
2. **Agitation/Psychosis**: Benzodiazepines FIRST-LINE (diazepam 10-20mg IV or midazolam 5-10mg IM)
   - Avoid haloperidol (lowers seizure threshold, worsens hyperthermia)
   - Avoid physical restraint alone (worsens hyperthermia, rhabdomyolysis)
3. **Hypertension**: Benzodiazepines first; if refractory → phentolamine or nicardipine
   - **AVOID pure beta-blockers** (unopposed alpha-stimulation → paradoxical hypertension)
4. **Hyperthermia**: Active cooling (ice packs, mist-and-fan, cold IV fluids); target <39°C
   - Dantrolene NOT effective (not malignant hyperthermia mechanism)
5. **Seizures**: Benzodiazepines; if refractory → propofol or phenobarbital
6. **Chest pain/ACS**: Benzodiazepines, nitroglycerin, aspirin; cardiac enzymes + ECG
   - Avoid beta-blockers in acute stimulant intoxication
7. **Rhabdomyolysis**: Aggressive IV crystalloid (target UO 200-300 mL/h); monitor CK, renal function
8. **Labs**: BMP, CBC, CK, troponin, coagulation, lactate, UA + myoglobin, urine drug screen, ECG

#### Methamphetamine Withdrawal / Abstinência de Metanfetamina

**Timeline:**
| Phase | Timing | Symptoms |
|-------|--------|----------|
| **Crash** | 0-3 days | Exhaustion, hypersomnia (may sleep 24-48h), hyperphagia, depression, irritability |
| **Acute withdrawal** | Days 3-10 | Severe depression, anhedonia, fatigue, psychomotor retardation, intense craving, vivid dreams |
| **Protracted/PAWS** | Weeks to months | Persistent anhedonia, cognitive deficits (attention, memory), emotional dysregulation, intermittent craving |

**Withdrawal is NOT life-threatening** (unlike alcohol/benzodiazepine withdrawal) but is severely debilitating psychologically.

**Management:**
- Supportive care: Hydration, nutrition, sleep hygiene
- No FDA/ANVISA-approved pharmacotherapy for methamphetamine withdrawal
- Symptomatic: Trazodone or mirtazapine for insomnia; SSRIs for persistent depression
- Suicide monitoring (high risk during crash/acute withdrawal)
- Engage in psychosocial treatment ASAP

#### Methamphetamine Use Disorder — Treatment / Tratamento

**No approved pharmacotherapy exists** (as of 2025). Promising research:
- **Combination naltrexone + bupropion** (some RCT evidence for reducing use)
- **Mirtazapine** (may reduce use in some populations)
- **Topiramate** (under investigation)
- **Methylphenidate/lisdexamfetamine** (agonist therapy, under investigation — controversial)
- **Psychostimulant vaccine** (preclinical)

**Evidence-Based Psychosocial Treatments (GOLD STANDARD):**
1. **Contingency Management (CM)** / Manejo de Contingências: Most effective behavioral treatment; provides tangible rewards for negative drug tests
2. **Cognitive Behavioral Therapy (CBT)**: Coping skills, relapse prevention, trigger identification
3. **Matrix Model**: 16-week structured outpatient combining CBT, family education, 12-step, drug testing, relapse prevention
4. **Motivational Interviewing (MI)**: For ambivalent patients; enhance intrinsic motivation
5. **Community Reinforcement Approach (CRA)**: Restructure environment to reinforce abstinence

**Long-term Recovery:**
- Dopaminergic recovery: May take 12-18+ months for partial normalization
- Cognitive deficits may improve with sustained abstinence (6-12 months)
- Regular exercise improves neuroplasticity and mood
- Nutritional rehabilitation (B vitamins, folate, protein)

#### Methamphetamine-Associated Health Consequences

| System | Complications |
|--------|--------------|
| **Cardiovascular** | Cardiomyopathy (dilated), pulmonary HTN, aortic dissection, accelerated atherosclerosis, arrhythmias |
| **Neurological** | Stroke (hemorrhagic > ischemic), cognitive decline, Parkinsonism, neurotoxicity |
| **Psychiatric** | Psychosis (may persist months after cessation), depression, anxiety, PTSD |
| **Dental** | "Meth mouth": rampant caries, periodontal disease, xerostomia, bruxism |
| **Dermatological** | Skin picking (excoriation), abscesses, formication, poor wound healing |
| **Infectious** | HIV, HCV, HBV (via injection/sexual risk), STIs, skin/soft tissue infections |
| **Renal** | Rhabdomyolysis-induced AKI, chronic kidney disease |
| **Pulmonary** | Pulmonary edema (smoked), pulmonary hypertension, ARDS |
| **Obstetric** | Preterm labor, placental abruption, IUGR, neonatal abstinence |

---

### OTHER STIMULANTS / OUTROS ESTIMULANTES

#### Cocaine / Cocaína (Crack, Pó, Farinha)

**Key Differences from Methamphetamine:**
| Feature | Cocaine | Methamphetamine |
|---------|---------|-----------------|
| Duration | 30-60 min | 8-24 hours |
| Mechanism | Blocks reuptake (DAT, NET, SERT) | Blocks reuptake + releases stored monoamines |
| Half-life | ~1 hour | 10-12 hours |
| Cardiac | Coronary vasospasm, MI | Cardiomyopathy, arrhythmias |
| Neurotoxicity | Less direct neurotoxicity | Severe dopaminergic neurotoxicity |

**Crack Cocaine** (highly prevalent in Brazil — "cracolândias"):
- Freebase form, smoked → rapid onset (seconds), intense but brief euphoria
- Extremely addictive, associated with severe social marginalization
- Management mirrors cocaine toxicity: benzodiazepines first-line
- Brazilian context: CAPS-AD III (24h), Consultório na Rua, Programa de Braços Abertos

---

### OPIOID USE DISORDER / TRANSTORNO POR USO DE OPIOIDES

#### Common Opioids

| Category | Examples |
|----------|----------|
| **Natural** | Morphine, codeine |
| **Semi-synthetic** | Heroin (diamorphine), oxycodone, hydrocodone, hydromorphone |
| **Synthetic** | Fentanyl, methadone, tramadol, meperidine |
| **Designer/illicit** | Carfentanil (100x fentanyl potency), nitazenes |

#### Opioid Intoxication / Intoxicação por Opioides

**Classic Triad:**
1. **Miosis** (pinpoint pupils)
2. **Respiratory depression** (↓RR, ↓SpO2)
3. **CNS depression** (↓consciousness, ↓GCS)

**Additional:** Hypotension, bradycardia, hypothermia, ileus, urinary retention

#### OPIOID OVERDOSE / OVERDOSE DE OPIOIDES — EMERGENCY PROTOCOL

**IMMEDIATE ACTIONS (minutes matter):**

1. **Call for help**: SAMU 192 / 911
2. **Airway**: Head-tilt chin-lift, recovery position if breathing
3. **Ventilation**: Bag-valve-mask if available, rescue breathing if not
4. **NALOXONE** (Narcan® / Naloxona):
   - **IN (intranasal)**: 4mg in one nostril (preferred community setting)
   - **IM**: 0.4mg initially; repeat every 2-3 minutes if no response (up to 10mg)
   - **IV**: 0.04-0.4mg; titrate to respiratory effort (avoid full reversal in opioid-dependent patients → precipitates severe withdrawal)
   - **Half-life of naloxone**: 30-90 min — **SHORTER than most opioids** → patient may re-sedate
   - **Fentanyl overdose**: May require HIGHER and REPEATED doses (10-20mg total)
   - **Monitor for ≥4 hours** after last naloxone dose (longer for long-acting opioids/fentanyl patches)

5. **Post-reversal considerations:**
   - Pulmonary edema (non-cardiogenic) may occur
   - Precipitated withdrawal (agitation, vomiting, diarrhea, tachycardia) — manage supportively
   - Risk of re-narcotization → DO NOT discharge early
   - Start naloxone infusion if repeated doses needed: 2/3 of effective bolus per hour

**Opioid Overdose in Special Populations:**
- **Neonatal**: Naloxone 0.1mg/kg IV/IM/SC; ventilatory support priority
- **Pregnancy**: Use naloxone cautiously; precipitated withdrawal can cause fetal distress
- **Mixed OD (opioid + benzo/alcohol)**: Naloxone reverses opioid component only; monitor for persistent sedation

#### Medication-Assisted Treatment (MAT) / Tratamento Medicamentoso

| Medication | Mechanism | Advantages | Considerations |
|------------|-----------|------------|----------------|
| **Methadone** | Full mu-agonist | Reduces craving, blocks euphoria at stable dose, daily dosing in OTP | QTc prolongation, respiratory depression risk, strict dispensing rules, drug interactions |
| **Buprenorphine** (Suboxone®) | Partial mu-agonist, kappa antagonist | Ceiling effect (safer), office-based prescribing, sublingual/injectable (Sublocade®) | Must be in withdrawal to start (precipitated withdrawal risk), less effective if very high tolerance |
| **Naltrexone** (Vivitrol®) | Mu-antagonist | Monthly injection, no abuse potential, no withdrawal | Must be fully detoxed (7-10 days opioid-free), poor adherence to oral form, no analgesia |

**Buprenorphine Initiation Protocol:**
1. Patient must be in moderate withdrawal (COWS ≥8-12)
2. **COWS** (Clinical Opiate Withdrawal Scale): Score components — resting pulse, GI distress, sweating, tremor, restlessness, yawning, pupil size, anxiety, bone/joint aches, gooseflesh, lacrimation/rhinorrhea
3. Start: Buprenorphine/naloxone 2-4mg sublingual
4. Reassess in 1-2 hours; additional 2-4mg if still in withdrawal
5. Day 1 max: 8mg; target 8-24mg/day maintenance
6. **Micro-dosing** (Bernese method): Gradual initiation while still on full agonist — avoids precipitated withdrawal

**In Brazil:**
- Metadona: Available via CAPS-AD and specialized SUS centers
- Buprenorfina: Available but less widely prescribed; requires CRM registration
- Naltrexona: Available in oral formulation through SUS
- RAPS (Rede de Atenção Psicossocial): Network including CAPS-AD, hospitals, UBS

---

### ALCOHOL USE DISORDER / TRANSTORNO POR USO DE ÁLCOOL

#### Alcohol Withdrawal Syndrome / Síndrome de Abstinência Alcoólica

**Timeline:**
| Phase | Timing (after last drink) | Features |
|-------|--------------------------|----------|
| Minor withdrawal | 6-24 hours | Tremor, anxiety, insomnia, nausea, tachycardia, hypertension |
| Seizures | 12-48 hours | Generalized tonic-clonic; may cluster |
| Alcoholic hallucinosis | 12-48 hours | Visual/auditory/tactile hallucinations with CLEAR sensorium |
| **Delirium Tremens** | 48-96 hours | Agitation, confusion, hallucinations, AUTONOMIC INSTABILITY (fever, tachycardia, diaphoresis) — **5-15% mortality untreated** |

**CIWA-Ar Score** (Clinical Institute Withdrawal Assessment for Alcohol):
- 10 items, max score 67
- <10: Mild → may not need medication
- 10-18: Moderate → pharmacotherapy recommended
- >18: Severe → aggressive treatment, ICU consideration

**Treatment:**
- **Benzodiazepines**: First-line (diazepam or lorazepam if liver failure)
  - Symptom-triggered (CIWA-based) preferred over fixed-schedule
  - Diazepam 10-20mg IV q5-15min until CIWA <10
- **Thiamine** (B1): 500mg IV TID × 3 days (BEFORE glucose — prevent Wernicke)
- **Wernicke Encephalopathy triad**: Confusion + ataxia + ophthalmoplegia — **MEDICAL EMERGENCY**
- Phenobarbital: Adjunct or alternative for benzo-refractory DT
- Propofol/dexmedetomidine: ICU for refractory cases

**Pharmacotherapy for Alcohol Use Disorder (maintenance):**
| Medication | Mechanism | Notes |
|------------|-----------|-------|
| **Naltrexone** | Opioid antagonist | Reduces heavy drinking days; oral or monthly IM |
| **Acamprosate** | Glutamate modulator | Supports abstinence; adjust for renal function |
| **Disulfiram** | Aldehyde dehydrogenase inhibitor | Aversive therapy; causes severe reaction with alcohol |
| **Topiramate** | GABAergic/anti-glutamate | Off-label; reduces cravings, helps with binge pattern |
| **Gabapentin** | GABA analog | Off-label; especially if comorbid anxiety/insomnia |

---

### OTHER SUBSTANCES OF ABUSE

#### Cannabis / Maconha
- **Acute**: Euphoria, relaxation, tachycardia, conjunctival injection, increased appetite
- **Cannabis Hyperemesis Syndrome**: Cyclic vomiting relieved by hot showers; capsaicin cream to abdomen
- **Cannabis Use Disorder**: CBT, motivational enhancement; no pharmacotherapy approved
- **Synthetic cannabinoids** (K2/Spice): More dangerous — seizures, psychosis, acute kidney injury, coagulopathy

#### Benzodiazepines / Benzodiazepínicos
- **Withdrawal**: Potentially LIFE-THREATENING (seizures, DT-like syndrome)
- **Management**: Gradual taper (reduce 10-25% per week); convert to long-acting (diazepam/chlordiazepoxide)
- **Overdose**: Flumazenil 0.2mg IV — USE WITH CAUTION (seizures in chronic users)

#### Inhalants / Inalantes (Solventes, Cola, Lança-Perfume, Loló)
- **Highly prevalent in Brazilian youth** (CEBRID surveys)
- **Sudden Sniffing Death**: Cardiac arrhythmia (sensitized myocardium to catecholamines)
- **Treatment**: Avoid epinephrine/catecholamines; benzodiazepines for agitation
- **Chronic**: Cognitive impairment, cerebellar damage, renal tubular acidosis, hepatotoxicity

---

## PART IV-C: OVERDOSE PROTOCOLS / PROTOCOLOS DE OVERDOSE

### General Overdose Approach / Abordagem Geral de Overdose

**ABCDE + TOXICOLOGY:**
1. **Airway**: Protect (intubate if GCS ≤8)
2. **Breathing**: Ventilate, target SpO2 >94%
3. **Circulation**: IV access, fluids, vasopressors PRN
4. **Disability**: GCS, pupils, glucose (ALWAYS check glucose)
5. **Exposure**: Full body exam, temperature
6. **Decontamination** (if oral ingestion <1-2h):
   - Activated charcoal 1g/kg (if airway protected, no contraindications)
   - Whole bowel irrigation (for sustained-release, body packers)
   - Gastric lavage rarely indicated
7. **Antidote**: If specific antidote exists, administer early
8. **Enhanced elimination**: Multi-dose activated charcoal, urinary alkalinization, hemodialysis (for specific toxins)

### Stimulant Overdose / Overdose de Estimulantes

**(Methamphetamine, Cocaine, MDMA/Ecstasy, Synthetic Cathinones "bath salts")**

**Critical Features:**
- Severe agitation/psychosis
- Hyperthermia (can be RAPIDLY FATAL — >41°C)
- Seizures
- Rhabdomyolysis (CK >10,000)
- Serotonin syndrome (especially MDMA)
- Hyponatremia (MDMA — water intoxication)
- Cardiovascular crisis (HTN emergency, MI, stroke, aortic dissection)

**Management Protocol:**
1. **Sedation**: Benzodiazepines (diazepam 10-20mg IV; midazolam 10mg IM if no IV access) — FIRST PRIORITY
2. **Cooling**: Target temp <39°C; ice packs to groin/axillae, mist-and-fan, cold IV NS; consider ice water immersion if >41°C
3. **Seizures**: Benzodiazepines → phenobarbital → propofol if refractory
4. **Hypertension**: Benzodiazepines first; add phentolamine (alpha-blocker) or nicardipine IV if refractory
   - **NO BETA-BLOCKERS** (including labetalol is controversial)
5. **Rhabdomyolysis**: NS bolus (1-2L/h initially), target UO 200-300 mL/h; monitor K⁺, Ca²⁺, renal function
6. **Serotonin syndrome** (MDMA): Cyproheptadine 12mg PO load, then 4mg q4-8h; cooling; benzodiazepines
7. **Hyponatremia** (MDMA): Fluid restrict; hypertonic saline (3% NaCl 100mL over 10min) if seizures/altered MS
8. **Cardiac**: ECG monitoring; troponin; cardiology consult if ischemia suspected

### Opioid Overdose Protocol
*(See detailed protocol above in Opioid Use Disorder section)*

### Polysubstance Overdose / Overdose Polisubstância

**Common Dangerous Combinations:**
| Combination | Risk | Management |
|-------------|------|------------|
| Opioid + Benzodiazepine | Synergistic respiratory depression | Naloxone (may not fully reverse); ventilatory support; flumazenil DANGEROUS if opioid-dependent |
| Stimulant + Opioid ("speedball"/"goofball") | Unpredictable; cardiovascular + respiratory risk | Treat most life-threatening feature first; naloxone if respiratory depression |
| Alcohol + Opioid | Additive CNS/respiratory depression | Naloxone + monitor for alcohol withdrawal |
| Stimulant + Alcohol | Cocaethylene (cocaine+alcohol → toxic metabolite) | Benzodiazepines; cardiac monitoring; extended observation |
| MDMA + MAOI | Fatal serotonin syndrome/hypertensive crisis | Aggressive cooling, benzodiazepines, cyproheptadine |

### Acetaminophen (Paracetamol) Overdose / Overdose de Paracetamol

**Extremely common in Brazil (Tylenol, Dôrico)**

**Toxic dose**: >150 mg/kg or >7.5g (adults) in single ingestion

**Timeline:**
| Phase | Time | Features |
|-------|------|----------|
| I | 0-24h | Nausea, vomiting, malaise, or ASYMPTOMATIC |
| II | 24-72h | RUQ pain, rising AST/ALT, renal function decline |
| III | 72-96h | Peak hepatotoxicity, jaundice, coagulopathy, encephalopathy, DEATH |
| IV | 4-14 days | Recovery (if survived) |

**Management:**
1. **Activated charcoal** if <4h from ingestion, alert patient
2. **Serum acetaminophen level** at 4h post-ingestion → plot on **Rumack-Matthew nomogram**
3. **N-Acetylcysteine (NAC)** — the antidote:
   - **IV protocol (21h)**: Loading 150mg/kg over 1h → 50mg/kg over 4h → 100mg/kg over 16h
   - **Oral (72h)**: Loading 140mg/kg → 70mg/kg q4h × 17 additional doses
   - Best if started <8h from ingestion, but can benefit even late
4. **Monitor**: LFTs, INR/PT, creatinine, lactate, blood gas
5. **King's College Criteria** for liver transplant: pH <7.3 OR (INR >6.5 AND Cr >3.4 AND Grade III/IV encephalopathy)

---

## PART IV-D: INFECTIOUS DISEASES IN SUBSTANCE USE / DOENÇAS INFECCIOSAS EM USUÁRIOS DE SUBSTÂNCIAS

### Hepatitis A / Hepatite A (HAV)

**Transmission**: Fecal-oral (contaminated water/food, person-to-person, oro-anal contact)
**Incubation**: 15-50 days (mean 28)
**Higher risk in PWUD**: Poor sanitation, shared drug paraphernalia, homelessness, MSM

**Clinical Presentation:**
- **Children**: Often asymptomatic or mild
- **Adults**: Prodrome (malaise, nausea, anorexia, fever) → Icteric phase (jaundice, dark urine, clay-colored stools, RUQ pain, hepatomegaly)
- **Does NOT cause chronic hepatitis** (unlike B and C)
- **Fulminant hepatitis**: Rare (<1%) but higher risk with pre-existing liver disease (HCV, alcohol)

**Diagnosis:**
- **Anti-HAV IgM**: Acute infection (positive for 3-6 months)
- **Anti-HAV IgG**: Past infection or vaccination (lifelong immunity)
- ↑AST/ALT (often >1000), ↑bilirubin, ↑ALP

**Treatment**: SUPPORTIVE — no specific antiviral
- Rest, hydration, avoid hepatotoxins (alcohol, acetaminophen)
- Monitor for fulminant hepatic failure (coagulopathy, encephalopathy)
- Hospital admission if: INR >1.5, persistent vomiting, signs of encephalopathy

**Prevention:**
- **Vaccination**: Inactivated virus vaccine; 2 doses (0 and 6-12 months)
- In Brazil: PNI provides free HAV vaccine at 15 months; catch-up for at-risk groups via CRIE
- Post-exposure prophylaxis: HAV vaccine (if <40yo, healthy) OR IG (if immunocompromised/liver disease)

### Hepatitis B / Hepatite B (HBV)

**Transmission**: Blood, sexual, vertical (mother-to-child)
**High risk in PWUD**: Needle/syringe sharing, tattoos, unprotected sex

**Serologic Interpretation:**
| Marker | Acute | Chronic | Immune (Vaccine) | Immune (Natural) |
|--------|-------|---------|-----------------|-------------------|
| HBsAg | + | + | - | - |
| Anti-HBs | - | - | + | + |
| Anti-HBc IgM | + | - | - | - |
| Anti-HBc total | + | + | - | + |
| HBeAg | ± | ± | - | - |

**Treatment (chronic HBV):**
- Indications: Active viral replication + elevated ALT or significant fibrosis
- First-line: Tenofovir (TDF or TAF) or Entecavir (monotherapy, indefinite)
- Available through SUS (Brazil) via PCDT/MS protocol

**Prevention:**
- Vaccination: 3 doses (0, 1, 6 months) — part of Brazilian PNI at birth
- Post-exposure: HBIG + vaccination within 12-24h
- All PWUD should be tested and vaccinated if susceptible

### Hepatitis C / Hepatite C (HCV)

**The #1 infectious disease in injection drug users worldwide**

**Transmission**: Primarily blood-borne (needle sharing is highest risk behavior)
**Chronicity**: 75-85% develop chronic infection → cirrhosis (20% over 20 years) → HCC

**Screening**: Anti-HCV antibody → if positive, confirm with HCV RNA (PCR)

**Direct-Acting Antivirals (DAAs) — CURE RATES >95%:**
| Regimen | Genotype | Duration | Notes |
|---------|----------|----------|-------|
| **Sofosbuvir/Velpatasvir** (Epclusa) | Pan-genotypic | 12 weeks | Preferred first-line |
| **Glecaprevir/Pibrentasvir** (Mavyret) | Pan-genotypic | 8-12 weeks | Safe in renal impairment |
| **Sofosbuvir/Ledipasvir** (Harvoni) | GT 1, 4, 5, 6 | 12 weeks | |

**Brazil — SUS provides FREE DAA treatment:**
- PCDT Hepatite C (2024): Pan-genotypic regimens available
- Treatment extended to all HCV+ individuals regardless of fibrosis stage
- Active PWUD are NOT excluded from treatment (treat and link to harm reduction)

### Hepatitis D / Hepatite D (HDV)
- **Requires HBV co-infection** (defective virus needing HBsAg)
- Coinfection (simultaneous B+D) or superinfection (D in chronic B carrier — worse prognosis)
- Treatment: PEG-interferon alpha (limited efficacy); bulevirtide (approved EU 2020)
- Prevention = HBV vaccination

### HIV in People Who Use Drugs / HIV em Pessoas que Usam Drogas

**Transmission risks**: Needle/syringe sharing, unprotected sex (especially under stimulant influence — "chemsex"), commercial sex work

**Key Points for PWUD:**
- Test all PWUD for HIV routinely (opt-out testing)
- ART for all HIV+ regardless of CD4 count (treat and retain)
- PrEP (Pre-Exposure Prophylaxis): TDF/FTC for HIV-negative high-risk individuals — available free via SUS
- PEP (Post-Exposure Prophylaxis): Start within 72h of exposure; 28-day course
- Drug interactions: Methadone + certain ARVs (efavirenz reduces methadone levels); check always

### Infective Endocarditis in IVDU / Endocardite Infecciosa em UDIV

**Classic**: RIGHT-sided (tricuspid valve) — unlike typical endocarditis
**Organisms**: S. aureus (#1), Streptococci, Enterococci, HACEK, Candida
**Presentation**: Fever + new murmur + septic pulmonary emboli (multiple nodular lung infiltrates)
**Duke Criteria** for diagnosis; TEE superior to TTE
**Treatment**: Prolonged IV antibiotics (4-6 weeks); surgery for vegetation >2cm, embolic events, or refractory infection

### Skin and Soft Tissue Infections (SSTIs) in PWID
- **Abscess**: I&D + wound care (antibiotics if cellulitis, MRSA risk, immunocompromised)
- **Necrotizing fasciitis**: Surgical emergency; broad-spectrum ABx + aggressive debridement
- **Wound botulism**: Associated with skin-popping heroin; antitoxin + wound care
- **Tetanus**: Verify vaccination status; TIG + Td/Tdap if not up-to-date

---

## PART IV-E: HARM REDUCTION & BRAZILIAN ADDICTION SERVICES / REDUÇÃO DE DANOS E SERVIÇOS BRASILEIROS

### Harm Reduction Principles / Princípios de Redução de Danos

1. **Acceptance**: Drug use is part of reality; prioritize reducing harm over demanding abstinence
2. **Human rights**: Treat PWUD with dignity; no coerced treatment
3. **Pragmatism**: Meet people "where they are" in their drug use
4. **Evidence-based**: Interventions proven to reduce morbidity/mortality
5. **Hierarchy of needs**: Immediate safety > reducing use > abstinence

**Key Interventions:**
| Intervention | Purpose |
|-------------|---------|
| Needle/Syringe Exchange (PSE/PTI) | Prevent HIV, HCV, HBV transmission |
| Naloxone distribution | Prevent opioid overdose death |
| Drug checking services | Detect dangerous adulterants (fentanyl test strips) |
| Supervised consumption sites | Prevent OD death, link to services |
| Nicotine replacement therapy | Tobacco cessation in PWUD |
| Condom distribution | Prevent STIs/HIV |
| Housing First | Stable housing improves all outcomes |
| Peer support workers | Lived experience enhances engagement |

### Brazilian Addiction Care Network / Rede de Atenção Brasileira

**RAPS** (Rede de Atenção Psicossocial — Psychosocial Care Network):

| Service | Description | Capacity |
|---------|-------------|----------|
| **CAPS-AD** | Community psychosocial center for alcohol & drugs | Day program (8h), referral, groups |
| **CAPS-AD III** | 24-hour CAPS for alcohol & drugs with crisis beds | 24/7 care, up to 12 observation beds |
| **CAPS-i** | For children and adolescents with substance use issues | Under-18 population |
| **Consultório na Rua** | Mobile street-based health teams for homeless/PWUD | Outreach, basic health, referral |
| **UBS / ESF** | Primary care units / Family Health Strategy | First contact, screening, referral, follow-up |
| **UPA / SAMU** | Emergency units / Emergency mobile service | Acute intoxication, overdose, withdrawal |
| **Hospital Geral** | General hospital with psychiatric emergency | Severe withdrawal (DT), medical complications |
| **Comunidades Terapêuticas (CTs)** | Therapeutic communities (residential) | Long-term residential; regulated by ANVISA RDC 29/2011 |
| **CRIE** | Special immunobiological referral center | Vaccines for PWUD (HAV, HBV, etc.) |

**Brazilian Legislation:**
- **Lei 11.343/2006** (Lei de Drogas): Distinguishes user (Art. 28 — no imprisonment) from trafficker (Art. 33); user receives educational measures, community service
- **Portaria GM/MS 3.088/2011**: Establishes RAPS
- **Portaria GM/MS 1.028/2005**: Harm reduction as official SUS policy
- **ANVISA RDC 29/2011**: Regulates therapeutic communities
- **Lei 13.840/2019**: Amendments to drug law; involuntary hospitalization provisions (controversial)

### Screening Tools / Instrumentos de Rastreamento

| Tool | Purpose | Details |
|------|---------|---------|
| **ASSIST** (WHO) | Multi-substance screening | 8 items, identifies risk level for each substance |
| **AUDIT** | Alcohol use | 10 items; ≥8 = hazardous use |
| **CAGE** | Alcohol dependence | 4 items; ≥2 = likely dependence |
| **DAST-10** | Drug abuse screening | 10 items; ≥3 = moderate problem |
| **COWS** | Opioid withdrawal severity | 11 items; guides buprenorphine induction |
| **CIWA-Ar** | Alcohol withdrawal severity | 10 items; guides benzodiazepine dosing |
| **PHQ-9** | Depression (common comorbidity) | 9 items; often elevated in active use |
| **PCL-5** | PTSD screening | 20 items; high prevalence in PWUD |

### Dual Diagnosis / Patologia Dual (Comorbidades Psiquiátricas)

- **Prevalence**: >50% of people with SUD have co-occurring mental health disorders
- **Common combinations**: Depression + alcohol, PTSD + opioids, bipolar + stimulants, psychosis + cannabis/meth
- **Integrated treatment**: Treat BOTH simultaneously (not sequential "treat addiction first" model)
- **Medications safe in SUD**: Sertraline, fluoxetine (depression); quetiapine, aripiprazole (psychosis/bipolar); prazosin (PTSD nightmares)
- **Avoid in SUD**: Benzodiazepines (long-term), stimulants (unless severe ADHD with close monitoring), z-drugs

---

## PART V: SURGERY & ORTHOPEDICS / CIRURGIA E ORTOPEDIA

### Pre-operative Assessment / Avaliação Pré-Operatória

**ASA Physical Status Classification:**
| Class | Description |
|-------|-------------|
| I | Healthy patient |
| II | Mild systemic disease |
| III | Severe systemic disease |
| IV | Severe systemic disease, constant threat to life |
| V | Moribund, not expected to survive without surgery |
| VI | Brain-dead, organ donor |

**Cardiac Risk Assessment (Revised Cardiac Risk Index - RCRI):**
- High-risk surgery
- History of ischemic heart disease
- History of heart failure
- History of cerebrovascular disease
- Insulin-dependent diabetes
- Creatinine >2 mg/dL
(≥2 factors → elevated cardiac risk)

### Acute Abdomen / Abdome Agudo

**Classification:**
| Type | Examples | Key Features |
|------|----------|-------------|
| Inflammatory | Appendicitis, cholecystitis, diverticulitis, pancreatitis | Gradual onset, fever, localized tenderness |
| Obstructive | Bowel obstruction, incarcerated hernia | Distension, vomiting, constipation, colicky pain |
| Perforative | Peptic ulcer, diverticular perforation | Sudden onset, rigidity, air under diaphragm |
| Vascular | Mesenteric ischemia, AAA rupture | Severe pain out of proportion, cardiovascular collapse |
| Hemorrhagic | Ruptured ectopic, splenic rupture | Signs of hypovolemia, peritoneal signs |

### Fracture Management / Manejo de Fraturas

**Ottawa Ankle Rules (when to X-ray):**
- Bone tenderness at posterior edge or tip of lateral/medial malleolus
- Inability to bear weight (4 steps) immediately and in ED

**Ottawa Knee Rules (when to X-ray):**
- Age ≥55
- Isolated patellar tenderness
- Tenderness at fibular head
- Inability to flex 90°
- Inability to bear weight (4 steps)

**Fracture Description System:**
- Open vs. closed
- Location (proximal, midshaft, distal)
- Pattern (transverse, oblique, spiral, comminuted)
- Displacement and angulation
- Joint involvement

---

## PART VI: PEDIATRICS / PEDIATRIA

### Growth and Development Milestones / Marcos do Desenvolvimento

| Age | Gross Motor | Fine Motor | Language | Social |
|-----|-------------|------------|----------|--------|
| 2 mo | Lifts head prone | Hands unfisted | Coos | Social smile |
| 4 mo | Rolls front→back | Reaches, grasps | Laughs | Recognizes parents |
| 6 mo | Sits with support | Transfers objects | Babbles | Stranger anxiety begins |
| 9 mo | Pulls to stand | Pincer grasp developing | "Mama/Dada" (non-specific) | Waves bye-bye |
| 12 mo | Walks (with/without help) | Pincer grasp | 1-2 words | Points to wants |
| 18 mo | Runs | Stacks 2-4 blocks | 10-25 words | Parallel play |
| 2 yr | Kicks ball, climbs stairs | Stacks 6 blocks | 2-word phrases | Begins pretend play |
| 3 yr | Pedals tricycle | Copies circle | 3-word sentences | Group play |
| 4 yr | Hops on one foot | Copies cross | Tells stories | Cooperative play |
| 5 yr | Skips | Copies triangle, ties shoes | Fluent speech | Understands rules |

### Vaccination Schedule - Brazil (PNI) / Calendário de Vacinação Brasil

**Key Vaccines (Programa Nacional de Imunizações):**

| Age | Vaccine |
|-----|---------|
| Birth | BCG + Hepatitis B (1st dose) |
| 2 months | Pentavalent (1st), VIP/IPV (1st), Pneumo 10 (1st), Rotavirus (1st) |
| 3 months | Meningococcal C (1st) |
| 4 months | Pentavalent (2nd), VIP/IPV (2nd), Pneumo 10 (2nd), Rotavirus (2nd) |
| 5 months | Meningococcal C (2nd) |
| 6 months | Pentavalent (3rd), VIP/IPV (3rd), Influenza (annual) |
| 9 months | Yellow Fever |
| 12 months | Pneumo 10 (boost), Meningococcal C (boost), MMR (1st), Hepatitis A |
| 15 months | DTP (1st boost), VOP (1st boost), MMR+V (2nd), Hepatitis A |
| 4 years | DTP (2nd boost), VOP (2nd boost), Varicella (2nd) |

### Pediatric Emergency / Emergência Pediátrica

**Pediatric Assessment Triangle (PAT):**
- **Appearance**: Tone, interactiveness, consolability, look/gaze, speech/cry
- **Work of Breathing**: Abnormal sounds, positioning, retractions, nasal flaring
- **Circulation**: Skin color (pallor, mottling, cyanosis)

**Fever in Neonates (<28 days):**
- ALWAYS requires full sepsis workup (blood, urine, CSF cultures)
- Empiric antibiotics: Ampicillin + gentamicin (or cefotaxime)
- Hospital admission

---

## PART VII: OB/GYN / OBSTETRÍCIA E GINECOLOGIA

### Prenatal Care / Pré-Natal

**Recommended Tests by Trimester:**

**1st Trimester:**
- Blood type + Rh + indirect Coombs
- CBC, fasting glucose
- VDRL/RPR, HIV, Hepatitis B (HBsAg)
- Toxoplasmosis (IgG/IgM)
- Urinalysis + urine culture
- Pap smear (if due)
- Ultrasound (dating, viability)

**2nd Trimester:**
- Anatomy ultrasound (18-22 weeks)
- OGTT 75g (24-28 weeks) - Brazilian protocol
- Repeat VDRL, toxo if initially negative

**3rd Trimester:**
- GBS screening (35-37 weeks)
- Repeat HIV, VDRL, HBsAg
- CTG/NST if indicated

**Gestational Diabetes (Brazilian Criteria - IADPSG/WHO):**
OGTT 75g at 24-28 weeks:
- Fasting ≥92 mg/dL
- 1h ≥180 mg/dL
- 2h ≥153 mg/dL
(One abnormal value = diagnosis)

### Hypertensive Disorders of Pregnancy

| Disorder | Criteria |
|----------|----------|
| Gestational HTN | SBP ≥140 or DBP ≥90 after 20 weeks, no proteinuria |
| Preeclampsia | HTN + proteinuria (≥300mg/24h) or end-organ damage |
| Severe Preeclampsia | SBP ≥160 or DBP ≥110, or severe features |
| Eclampsia | Preeclampsia + seizures |
| HELLP | Hemolysis, Elevated Liver enzymes, Low Platelets |

**Management of Severe Preeclampsia:**
- Magnesium sulfate (seizure prophylaxis): 4-6g IV loading, then 1-2g/h maintenance
- Antihypertensives: IV labetalol, hydralazine, or oral nifedipine
- Delivery: Definitive treatment (timing depends on gestational age and severity)
- Magnesium toxicity monitoring: Reflexes, RR, urine output; antidote = calcium gluconate

---

## PART VIII: LABORATORY MEDICINE / MEDICINA LABORATORIAL

### Complete Blood Count (CBC) / Hemograma

| Parameter | Normal Range | Clinical Significance |
|-----------|-------------|----------------------|
| Hemoglobin (M) | 13.5-17.5 g/dL | ↓ Anemia; ↑ Polycythemia |
| Hemoglobin (F) | 12-16 g/dL | ↓ Anemia; ↑ Polycythemia |
| WBC | 4,500-11,000/µL | ↑ Infection, inflammation; ↓ Immunosuppression |
| Platelets | 150,000-400,000/µL | ↓ Bleeding risk; ↑ Thrombosis risk |
| MCV | 80-100 fL | <80 microcytic; >100 macrocytic |
| Neutrophils | 40-70% | ↑ Bacterial infection; ↓ Drug-induced |
| Lymphocytes | 20-40% | ↑ Viral infection; ↓ HIV, immunodeficiency |
| Eosinophils | 1-4% | ↑ Allergy, parasites, drug reactions |

### Anemia Classification by MCV

| MCV | Type | Common Causes |
|-----|------|---------------|
| <80 | Microcytic | Iron deficiency, thalassemia, chronic disease, lead |
| 80-100 | Normocytic | Chronic disease, CKD, acute blood loss, hemolysis |
| >100 | Macrocytic | B12/folate deficiency, alcohol, liver disease, hypothyroidism, MDS |

### Basic Metabolic Panel / Bioquímica Básica

| Test | Normal Range | Critical Values |
|------|-------------|-----------------|
| Sodium | 135-145 mEq/L | <120 or >160 |
| Potassium | 3.5-5.0 mEq/L | <2.5 or >6.5 |
| Chloride | 98-106 mEq/L | - |
| Bicarbonate | 22-28 mEq/L | <10 or >40 |
| BUN/Urea | 7-20 mg/dL | >100 |
| Creatinine | 0.7-1.3 mg/dL (M); 0.6-1.1 (F) | >10 |
| Glucose | 70-100 mg/dL (fasting) | <40 or >500 |
| Calcium | 8.5-10.5 mg/dL | <6.5 or >13 |

### Arterial Blood Gas (ABG) / Gasometria Arterial

**Normal Values:**
- pH: 7.35-7.45
- PaCO2: 35-45 mmHg
- PaO2: 80-100 mmHg
- HCO3: 22-26 mEq/L
- BE: -2 to +2

**Interpretation Steps:**
1. pH: Acidemia (<7.35) or Alkalemia (>7.45)?
2. Primary disorder: Respiratory (PaCO2) or Metabolic (HCO3)?
3. Compensation: Is it appropriate?
4. If metabolic acidosis: Calculate anion gap (Na - Cl - HCO3; normal 8-12)

**Anion Gap Metabolic Acidosis (MUDPILES):**
- **M**ethanol
- **U**remia
- **D**iabetic ketoacidosis
- **P**ropylene glycol / **P**aracetamol
- **I**soniazid / **I**ron
- **L**actic acidosis
- **E**thylene glycol
- **S**alicylates

---

## PART IX: BRAZILIAN HEALTH SYSTEM / SISTEMA DE SAÚDE BRASILEIRO

### SUS (Sistema Único de Saúde)

**Constitutional Basis:** Art. 196-200 CF/1988

**Principles:**
- **Universalidade**: Universal access for all citizens
- **Integralidade**: Comprehensive care (prevention, treatment, rehabilitation)
- **Equidade**: Priority for those with greatest need

**Organization:**
- **Atenção Primária**: UBS (Unidade Básica de Saúde), ESF (Estratégia Saúde da Família)
- **Atenção Secundária**: UPA (Unidade de Pronto Atendimento), ambulatórios especializados
- **Atenção Terciária**: Hospitais de referência, alta complexidade

### ANVISA (Agência Nacional de Vigilância Sanitária)

**Functions:**
- Drug registration and approval (registro de medicamentos)
- Health products regulation
- Pharmacovigilance
- Health surveillance
- Blood products regulation

**Drug Classification (Brazil):**
- **Tarja vermelha**: Prescription required (receita simples)
- **Tarja vermelha "Venda sob prescrição médica — Só pode ser vendido com retenção da receita"**: Controlled (receita de controle especial - branca em 2 vias)
- **Tarja preta**: Psychotropic/narcotic (receita azul - tipo B, ou amarela - tipo A)
- **Sem tarja**: Over the counter (venda livre)

**Receita Especial:**

| Tipo | Cor | Medicamentos | Validade |
|------|-----|-------------|----------|
| A (Entorpecentes) | Amarela | Opioids (morphine, codeine), amphetamines | 30 days |
| B (Psicotrópicos) | Azul | Benzodiazepines, barbiturates, anorexigenic | 30 days |
| C1 (Outras substâncias) | Branca 2 vias | Antidepressants, antipsychotics, anticonvulsants | 30 days |
| C2 (Retinoides) | Branca 2 vias | Isotretinoin, acitretin | 30 days |
| C5 (Anabolizantes) | Branca 2 vias | Testosterone, nandrolone | 30 days |

### CFM (Conselho Federal de Medicina)

**Key Resolutions:**
- **CFM 2.217/2018**: Código de Ética Médica (Medical Ethics Code)
- **CFM 2.314/2022**: Telemedicine regulation
- **CFM 2.232/2019**: Advance directives (diretivas antecipadas de vontade)
- **CFM 1.995/2012**: Patient will regarding end-of-life care

**Medical Ethics Principles:**
1. Beneficence (beneficência)
2. Non-maleficence (não-maleficência)
3. Autonomy (autonomia)
4. Justice (justiça)

**Patient Rights (Lei 10.241/1999 - SP; applies nationally by ethics):**
- Right to information about diagnosis and treatment
- Right to second opinion
- Right to refuse treatment (except emergencies)
- Right to medical records access
- Right to confidentiality
- Right to dignified treatment

### CRM (Conselho Regional de Medicina)

- State-level medical council
- Physician registration required
- Disciplinary proceedings
- Verification: Check CRM number at www.portal.cfm.org.br

---

## PART X: PREVENTIVE MEDICINE / MEDICINA PREVENTIVA

### Cancer Screening / Rastreamento de Câncer

**Brazilian Guidelines (INCA - Instituto Nacional de Câncer):**

| Cancer | Population | Test | Frequency |
|--------|-----------|------|-----------|
| **Breast** | Women 50-69 | Mammography | Every 2 years |
| **Cervical** | Women 25-64 | Pap smear | Every 3 years (after 2 annual negatives) |
| **Colorectal** | 50-75 years | FIT/FOBT | Annual |
| **Prostate** | Individualized | PSA + DRE | Shared decision (no universal screening recommended) |

**US Guidelines (USPSTF) for reference:**

| Cancer | Population | Test | Frequency |
|--------|-----------|------|-----------|
| **Breast** | Women 40-74 | Mammography | Every 2 years |
| **Cervical** | Women 21-65 | Pap/HPV | Pap q3y (21-29); Pap+HPV q5y or Pap q3y (30-65) |
| **Colorectal** | 45-75 | Colonoscopy or FIT | Colonoscopy q10y or FIT annually |
| **Lung** | 50-80, ≥20 pack-years | Low-dose CT | Annual |
| **Prostate** | Men 55-69 | PSA | Shared decision |

### Cardiovascular Risk Assessment / Avaliação de Risco Cardiovascular

**Framingham Risk Score / Escore de Risco de Framingham:**
Estimates 10-year cardiovascular risk based on:
- Age, sex
- Total cholesterol, HDL cholesterol
- Systolic blood pressure
- Smoking status
- Diabetes

**Risk Categories:**
- Low: <10% (10-year risk)
- Intermediate: 10-20%
- High: >20%

**Statin Therapy Indications (ACC/AHA):**
1. Clinical ASCVD
2. LDL ≥190 mg/dL
3. Age 40-75 with diabetes
4. Age 40-75 with 10-year ASCVD risk ≥7.5%

### Adult Vaccination (Brazil - PNI) / Vacinação do Adulto

| Vaccine | Indication |
|---------|-----------|
| Influenza | Annual for all adults |
| COVID-19 | Per current recommendations |
| Hepatitis B | If not previously vaccinated |
| dT (diphtheria/tetanus) | Every 10 years |
| Yellow Fever | Single dose (endemic areas) |
| Pneumococcal | ≥60 years, comorbidities |
| HPV | Up to 45 years (women), 26 years (men) - SUS |

---

## CLINICAL DECISION SUPPORT TOOLS / FERRAMENTAS DE APOIO À DECISÃO

### Commonly Used Scores

| Score | Purpose | Key Variables |
|-------|---------|---------------|
| **CURB-65** | Pneumonia severity | Confusion, Urea, RR, BP, Age |
| **Wells (PE)** | PE probability | Clinical signs, HR, immobilization, cancer, previous VTE |
| **Wells (DVT)** | DVT probability | Active cancer, paralysis, bedridden, tenderness, swelling |
| **CHA₂DS₂-VASc** | A-fib stroke risk | CHF, HTN, Age, DM, Stroke, Vasc disease, Sex |
| **HAS-BLED** | Bleeding risk (A-fib) | HTN, Abnormal renal/liver, Stroke, Bleeding, Labile INR, Elderly, Drugs/alcohol |
| **MELD** | Liver disease severity | Bilirubin, INR, Creatinine |
| **Child-Pugh** | Cirrhosis severity | Bilirubin, Albumin, INR, Ascites, Encephalopathy |
| **APACHE II** | ICU mortality prediction | Multiple physiologic variables |
| **GCS** | Consciousness level | Eye, Verbal, Motor |
| **SOFA** | Organ dysfunction (sepsis) | Respiratory, Coagulation, Liver, CV, CNS, Renal |
| **HEART** | Chest pain risk | History, ECG, Age, Risk factors, Troponin |
| **PERC** | PE rule-out | Age, HR, SpO2, hemoptysis, estrogen, prior VTE, unilateral swelling, surgery |

---

## MEDICAL TERMINOLOGY / TERMINOLOGIA MÉDICA

### Common Abbreviations (PT-BR / EN)

| PT-BR | English | Meaning |
|-------|---------|---------|
| PA | BP | Pressão Arterial / Blood Pressure |
| FC | HR | Frequência Cardíaca / Heart Rate |
| FR | RR | Frequência Respiratória / Respiratory Rate |
| SpO2 | SpO2 | Saturação de Oxigênio / Oxygen Saturation |
| HAS | HTN | Hipertensão Arterial Sistêmica / Hypertension |
| DM | DM | Diabetes Mellitus |
| IAM | MI | Infarto Agudo do Miocárdio / Myocardial Infarction |
| AVC | CVA/Stroke | Acidente Vascular Cerebral / Cerebrovascular Accident |
| ICC | CHF | Insuficiência Cardíaca Congestiva / Congestive Heart Failure |
| DPOC | COPD | Doença Pulmonar Obstrutiva Crônica |
| DRC | CKD | Doença Renal Crônica / Chronic Kidney Disease |
| LRA | AKI | Lesão Renal Aguda / Acute Kidney Injury |
| ITU | UTI | Infecção do Trato Urinário / Urinary Tract Infection |
| PCR | CRP | Proteína C Reativa / C-Reactive Protein |
| VHS | ESR | Velocidade de Hemossedimentação / Erythrocyte Sedimentation Rate |
| HMG | CBC | Hemograma / Complete Blood Count |
| EAS | U/A | Exame de Urina / Urinalysis |
| USG | US | Ultrassonografia / Ultrasound |
| TC | CT | Tomografia Computadorizada / Computed Tomography |
| RM | MRI | Ressonância Magnética / Magnetic Resonance Imaging |
| RX | X-ray | Radiografia |
| ECG | ECG/EKG | Eletrocardiograma / Electrocardiogram |
| TUS | SUD | Transtorno por Uso de Substâncias / Substance Use Disorder |
| UDI/UDIV | IVDU/PWID | Usuário de Drogas Injetáveis / People Who Inject Drugs |
| CAPS-AD | — | Centro de Atenção Psicossocial Álcool e Drogas |
| RD | HR | Redução de Danos / Harm Reduction |
| SAA | AWS | Síndrome de Abstinência Alcoólica / Alcohol Withdrawal Syndrome |
| DT | DT | Delirium Tremens |
| OD | OD | Overdose |
| Fissura | Craving | Desejo intenso pela substância |
| Tolerância | Tolerance | Necessidade de doses maiores |
| Abstinência | Withdrawal | Síndrome ao cessar substância |
| Hepatite | Hepatitis | Inflamação hepática |
| PEP | PEP | Profilaxia Pós-Exposição / Post-Exposure Prophylaxis |
| PrEP | PrEP | Profilaxia Pré-Exposição / Pre-Exposure Prophylaxis |

---

## EMERGENCY CONTACTS / CONTATOS DE EMERGÊNCIA (BRAZIL)

| Service | Number |
|---------|--------|
| **SAMU** (Ambulance) | **192** |
| **Fire Department** (Bombeiros) | **193** |
| **Police** (Polícia Militar) | **190** |
| **Civil Defense** | **199** |
| **CVV** (Suicide Prevention / Prevenção do Suicídio) | **188** |
| **Disque Saúde** (Health Info / Informações em Saúde) | **136** |
| **Poison Control** (CIT / Centro de Informação Toxicológica) | Varies by state (check local) |
| **CAPS-AD Locator** (Álcool e Drogas) | Check municipal health department or Disque 136 |
| **Consultório na Rua** (Street Outreach) | Check municipal health department |
| **Ligue 180** (Women's Violence Helpline) | **180** |
| **Disque 100** (Human Rights / Direitos Humanos) | **100** |
