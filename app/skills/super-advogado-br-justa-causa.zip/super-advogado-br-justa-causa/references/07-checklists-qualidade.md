# Checklists de qualidade

## Checklist rápido. Justa causa

- [ ] carta ou comunicação da justa causa disponível;
- [ ] alínea e fato concreto identificados;
- [ ] cronologia fato-ciência-apuração-decisão-comunicação;
- [ ] empregador e decisor real mapeados;
- [ ] materialidade e autoria separadas;
- [ ] dolo/culpa analisados;
- [ ] original e cadeia de custódia avaliados;
- [ ] imediatidade contextual analisada;
- [ ] dupla punição e perdão descartados;
- [ ] proporcionalidade/histórico/comparadores;
- [ ] regulamento e norma coletiva obtidos;
- [ ] estabilidade e discriminação verificadas;
- [ ] jurisprudência favorável e contrária oficial;
- [ ] remédios e riscos sucumbenciais separados;
- [ ] dados sensíveis minimizados.

## Checklist de citação

- [ ] link oficial;
- [ ] número exato;
- [ ] órgão julgador;
- [ ] relator;
- [ ] julgamento/publicação;
- [ ] status vinculante ou persuasivo;
- [ ] leitura além da ementa quando decisivo;
- [ ] fatos semelhantes;
- [ ] distinção relevante;
- [ ] sem aspas inventadas.

## Checklist de peça

- [ ] cada pedido tem fatos e fundamento;
- [ ] cada fato relevante aponta prova;
- [ ] inferências estão qualificadas;
- [ ] pedidos compatíveis entre si;
- [ ] valores e premissas explícitos;
- [ ] prazo e competência revisados;
- [ ] tese adversa enfrentada;
- [ ] não há acusação criminal gratuita;
- [ ] tutela tem perigo concreto;
- [ ] linguagem sóbria e profissional.

## Sinais de alerta

- carta genérica e defesa judicial detalhada demais;
- alínea muda ao longo do tempo;
- empresa não apresenta original;
- investigação sem datas ou responsáveis;
- decisão pela tomadora e mera execução pelo empregador;
- negativa informal de autenticidade sem método;
- documento criado após a dispensa;
- testemunha ouviu de terceiros;
- print recortado sem exportação;
- manutenção normal do contrato após ciência plena;
- punição anterior pelo mesmo fato;
- comparadores tratados de modo diferente;
- doença ou denúncia antecedendo investigação repentina.
