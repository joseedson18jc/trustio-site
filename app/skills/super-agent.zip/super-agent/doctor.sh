#!/usr/bin/env bash
# doctor.sh — verify a super-agent install and audit the surrounding setup.
#
#   bash doctor.sh            # check ./.claude/
#   bash doctor.sh --user     # check ~/.claude/

set -uo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NAME="super-agent"
if [ "${1:-}" = "--user" ]; then ROOT="$HOME/.claude"; else ROOT="$PWD/.claude"; fi
SKILL_DIR="$ROOT/skills/$NAME"

pass=0; warn=0; fail=0
ok()   { printf '  \033[32mOK\033[0m    %s\n' "$1"; pass=$((pass+1)); }
wn()   { printf '  \033[33mWARN\033[0m  %s\n' "$1"; warn=$((warn+1)); }
er()   { printf '  \033[31mFAIL\033[0m  %s\n' "$1"; fail=$((fail+1)); }
head_() { printf '\n%s\n' "$1"; }

printf 'super-agent doctor — checking %s\n' "$ROOT"

# ------------------------------------------------------------------ skill
head_ "Skill"
if [ -f "$SKILL_DIR/SKILL.md" ]; then
  ok "SKILL.md present"
  if head -1 "$SKILL_DIR/SKILL.md" | grep -q '^---'; then ok "frontmatter delimiter present"
  else er "SKILL.md does not start with '---' — it will not load"; fi
  if command -v python3 >/dev/null 2>&1; then
    python3 - "$SKILL_DIR/SKILL.md" << 'PY' 2>/dev/null || echo "  WARN  could not parse frontmatter (pyyaml missing?)"
import sys
try: import yaml
except ImportError: sys.exit(1)
t = open(sys.argv[1]).read()
d = yaml.safe_load(t.split('---')[1])
n = d.get('name','')
assert n and n.islower() and len(n) <= 64, f"bad name: {n}"
assert d.get('description'), "missing description"
print(f"  \033[32mOK\033[0m    frontmatter valid (name={n}, description={len(d['description'])} chars)")
PY
  fi
  lines=$(wc -l < "$SKILL_DIR/SKILL.md")
  if [ "$lines" -le 500 ]; then ok "SKILL.md is $lines lines (≤500 target)"
  else wn "SKILL.md is $lines lines — over the 500-line guideline"; fi
else
  er "SKILL.md missing at $SKILL_DIR — skill is not installed"
fi

n_ref=$(ls "$SKILL_DIR/references/"*.md 2>/dev/null | wc -l | tr -d ' ')
[ "$n_ref" = "6" ] && ok "6 reference files present" || wn "$n_ref reference files (expected 6)"

# ----------------------------------------------------------------- agents
head_ "Subagents"
for a in verifier explorer security-reviewer; do
  if [ -f "$ROOT/agents/$a.md" ]; then ok "agents/$a.md"
  else wn "agents/$a.md missing — run install.sh without --skill-only"; fi
done

# ------------------------------------------------------------------ hooks
head_ "Hook scripts"
for h in block-secrets block-dangerous guard-uncommitted lint-changed; do
  f="$ROOT/hooks/$h.sh"
  if [ ! -f "$f" ]; then wn "hooks/$h.sh missing"; continue; fi
  if [ ! -x "$f" ]; then er "hooks/$h.sh not executable — run: chmod +x $f"; continue; fi
  if bash -n "$f" 2>/dev/null; then ok "hooks/$h.sh present, executable, syntax clean"
  else er "hooks/$h.sh has a syntax error"; fi
done

# ------------------------------------------------------- functional probes
head_ "Hook behavior (live probes)"
if [ -x "$ROOT/hooks/block-secrets.sh" ]; then
  printf 'cat .env' | "$ROOT/hooks/block-secrets.sh" >/dev/null 2>&1
  [ $? -eq 2 ] && ok "block-secrets blocks 'cat .env'" || er "block-secrets did NOT block 'cat .env'"
  printf 'cat src/app.ts' | "$ROOT/hooks/block-secrets.sh" >/dev/null 2>&1
  [ $? -eq 0 ] && ok "block-secrets allows a normal read" || er "block-secrets false-positives on normal reads"
fi
if [ -x "$ROOT/hooks/block-dangerous.sh" ]; then
  printf 'rm -rf /' | "$ROOT/hooks/block-dangerous.sh" >/dev/null 2>&1
  [ $? -eq 2 ] && ok "block-dangerous blocks 'rm -rf /'" || er "block-dangerous did NOT block 'rm -rf /'"
  printf 'npm test' | "$ROOT/hooks/block-dangerous.sh" >/dev/null 2>&1
  [ $? -eq 0 ] && ok "block-dangerous allows 'npm test'" || er "block-dangerous false-positives on 'npm test'"
fi

# --------------------------------------------------------------- settings
head_ "settings.json"
S="$ROOT/settings.json"
if [ ! -f "$S" ]; then
  wn "settings.json absent — hooks are installed but never fire"
elif command -v python3 >/dev/null 2>&1; then
  python3 - "$S" << 'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except json.JSONDecodeError as e:
    print(f"  \033[31mFAIL\033[0m  settings.json is invalid JSON: {e}"); sys.exit(0)
hooks = d.get("hooks", {})
if not hooks:
    print("  \033[33mWARN\033[0m  no 'hooks' key — guards are installed but not wired")
    sys.exit(0)
wired = {h.get("command","").split("/")[-1]
         for entries in hooks.values() for e in entries for h in e.get("hooks",[])}
for want in ["block-secrets.sh","block-dangerous.sh","guard-uncommitted.sh","lint-changed.sh"]:
    mark = "\033[32mOK\033[0m   " if want in wired else "\033[33mWARN\033[0m "
    state = "wired" if want in wired else "NOT wired in settings.json"
    print(f"  {mark} {want} {state}")
PY
fi

# ------------------------------------------------------------- setup audit
head_ "Surrounding setup (advisory)"
if [ -f "$PWD/CLAUDE.md" ]; then
  cl=$(wc -l < "$PWD/CLAUDE.md")
  [ "$cl" -le 200 ] && ok "CLAUDE.md is $cl lines (≤200 target)" \
                    || wn "CLAUDE.md is $cl lines — move reference content into skills"
  grep -q '<.*>' "$PWD/CLAUDE.md" 2>/dev/null && \
    wn "CLAUDE.md still contains <placeholders> — an unfilled template is worse than none"
else
  wn "no CLAUDE.md in $PWD — copy assets/CLAUDE.md.template and fill it in"
fi
[ -d "$ROOT/rules" ] && ok "using .claude/rules/ for path-scoped guidance" \
                     || wn "no .claude/rules/ — consider it for path-specific conventions"

# ----------------------------------------------------------------- verdict
printf '\n%s\n' "-------------------------------------------"
printf 'pass %d   warn %d   fail %d\n\n' "$pass" "$warn" "$fail"
if [ "$fail" -gt 0 ]; then
  echo "Install is BROKEN — fix the FAIL lines above."; exit 1
elif [ "$warn" -gt 0 ]; then
  echo "Install works, with gaps. WARN lines are optional hardening."; exit 0
else
  echo "Fully installed and verified."; exit 0
fi
