# Template: Parecer Jurídico

**INSTRUÇÕES DE USO**: Estrutura padrão de parecer. Adaptar nível de linguagem ao destinatário (técnico-formal para advogados/diretores; técnico-objetivo para área de negócios).

---

**PARECER JURÍDICO Nº [XX/AAAA]**

**Interessado(a)**: [Nome / Empresa]
**Assunto**: [Título objetivo do tema]
**Data**: [Data]
**Elaborado por**: [Nome / Qualificação]

---

## EMENTA

[Resumo de 3–5 linhas do objeto, conclusão principal e recomendação. Escrito após o parecer, mas posicionado no início.]

---

## I — OBJETO DA CONSULTA

[Descrever o que foi solicitado. Quem consulta, sobre o quê, com qual finalidade. Delimitar o escopo do parecer.]

---

## II — FATOS RELEVANTES

[Narrar os fatos fornecidos pelo consulente que são relevantes para a análise. Não incluir fatos não informados. Marcar explicitamente lacunas com: "Não foram fornecidas informações sobre [X]. A análise pressupõe que [hipótese]."]

---

## III — QUESTÃO JURÍDICA

[Formular a pergunta central em 1–2 frases precisas. Exemplo: "A questão a ser analisada é se [X] configura [Y] à luz de [norma/contrato]."]

---

## IV — ANÁLISE JURÍDICA

### 4.1 [Subtítulo da primeira frente de análise]

[Norma aplicável → interpretação → aplicação aos fatos → conclusão parcial]

### 4.2 [Subtítulo da segunda frente de análise]

[Idem]

### 4.3 Jurisprudência aplicável

[Precedentes relevantes com metadados: tribunal, número, data, tese. Diferenciar vinculante de persuasivo.]

### 4.4 Riscos e pontos de atenção

[Incertezas, controvérsias, pontos dependentes de prova ou de fatos não confirmados.]

---

## V — CONCLUSÃO

[Resposta direta à questão jurídica. Sem rodeios. Indicar o entendimento adotado e por quê.]

---

## VI — RECOMENDAÇÕES

[Medidas práticas sugeridas. Pode ser lista numerada. Incluir urgência e responsável quando relevante.]

1. [Ação recomendada 1]
2. [Ação recomendada 2]
3. [Ação recomendada 3]

---

**AVISO**: Este parecer é informativo, baseado nos fatos fornecidos, e não substitui orientação jurídica formal por advogado habilitado para o caso específico. Recomenda-se validação antes de qualquer decisão de alto impacto.

[Local], [Data].

[Nome]
[Qualificação]
