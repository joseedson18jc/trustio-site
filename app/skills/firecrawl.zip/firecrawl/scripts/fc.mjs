#!/usr/bin/env node
/**
 * fc.mjs — Node/TypeScript-friendly wrapper around the Firecrawl JS SDK.
 *
 * Examples:
 *   export FIRECRAWL_API_KEY=fc-...
 *   node fc.mjs search "firecrawl alternatives" --limit 5
 *   node fc.mjs scrape https://example.com -o page.md
 *   node fc.mjs crawl  https://docs.example.com --limit 30 --out-dir crawl_out
 *   node fc.mjs map    https://example.com
 *
 * Requires: npm i firecrawl   (Node 18+)
 */
import { writeFile, mkdir } from "node:fs/promises";
import { join } from "node:path";

function parseArgs(argv) {
  const [cmd, positional, ...rest] = argv;
  const opts = { limit: undefined, out: undefined, outDir: "crawl_out" };
  for (let i = 0; i < rest.length; i++) {
    const a = rest[i];
    if (a === "--limit") opts.limit = Number(rest[++i]);
    else if (a === "-o" || a === "--out") opts.out = rest[++i];
    else if (a === "--out-dir") opts.outDir = rest[++i];
  }
  return { cmd, arg: positional, opts };
}

const slug = (u) => u.replace(/[^a-zA-Z0-9]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 80) || "page";
const md = (d) => d?.markdown ?? d?.content ?? d?.html ?? JSON.stringify(d, null, 2);

async function main() {
  const { cmd, arg, opts } = parseArgs(process.argv.slice(2));
  if (!cmd) {
    console.error("usage: node fc.mjs <search|scrape|crawl|map> ARG [--limit N] [-o file] [--out-dir dir]");
    process.exit(1);
  }
  const apiKey = process.env.FIRECRAWL_API_KEY;
  if (!apiKey) {
    console.error("Set FIRECRAWL_API_KEY in your environment.");
    process.exit(1);
  }

  let Firecrawl;
  try {
    ({ Firecrawl } = await import("firecrawl"));
  } catch {
    console.error("Install the SDK first: npm i firecrawl");
    process.exit(1);
  }
  const app = new Firecrawl({ apiKey });

  switch (cmd) {
    case "search": {
      const res = await app.search(arg, { limit: opts.limit ?? 5 });
      console.log(JSON.stringify(res, null, 2));
      break;
    }
    case "scrape": {
      const doc = await app.scrape(arg);
      const text = md(doc);
      if (opts.out) { await writeFile(opts.out, text); console.log(`Wrote ${text.length} chars -> ${opts.out}`); }
      else console.log(text);
      break;
    }
    case "crawl": {
      const res = await app.crawl(arg, { limit: opts.limit ?? 30 });
      const docs = res?.data ?? res ?? [];
      await mkdir(opts.outDir, { recursive: true });
      let n = 0;
      for (const d of docs) {
        const url = d?.url ?? `doc${n}`;
        await writeFile(join(opts.outDir, `${slug(url)}.md`), md(d));
        n++;
      }
      console.log(`Saved ${n} page(s) -> ${opts.outDir}/`);
      break;
    }
    case "map": {
      console.log(JSON.stringify(await app.map(arg), null, 2));
      break;
    }
    default:
      console.error(`unknown command: ${cmd}`);
      process.exit(1);
  }
}

main().catch((e) => { console.error(e?.message ?? e); process.exit(1); });
