# Animation Library Reference

CSS animation keyframes, transition patterns, scroll-triggered reveals, and micro-interaction recipes.

## Table of Contents
1. [Entrance Animations](#entrance-animations)
2. [Micro-Interactions](#micro-interactions)
3. [Loading States](#loading-states)
4. [Scroll-Triggered Reveals](#scroll-triggered-reveals)
5. [Page Transitions](#page-transitions)
6. [Data Animations](#data-animations)
7. [Easing Functions](#easing-functions)

---

## Entrance Animations

### Fade In Up (Primary entrance — use for cards, sections, content blocks)
```css
@keyframes fadeInUp {
  from { opacity: 0; transform: translateY(20px); }
  to { opacity: 1; transform: translateY(0); }
}
.fade-in-up {
  animation: fadeInUp 0.6s cubic-bezier(0.16, 1, 0.3, 1) forwards;
  opacity: 0;
}
```

### Fade In Scale (For modals, popups, floating elements)
```css
@keyframes fadeInScale {
  from { opacity: 0; transform: scale(0.95); }
  to { opacity: 1; transform: scale(1); }
}
.fade-in-scale {
  animation: fadeInScale 0.3s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
```

### Slide In Left (For side panels, navigation)
```css
@keyframes slideInLeft {
  from { opacity: 0; transform: translateX(-30px); }
  to { opacity: 1; transform: translateX(0); }
}
```

### Stagger Children (For lists, grids, card groups)
```css
.stagger-children > * {
  opacity: 0;
  animation: fadeInUp 0.5s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
.stagger-children > *:nth-child(1) { animation-delay: 0ms; }
.stagger-children > *:nth-child(2) { animation-delay: 60ms; }
.stagger-children > *:nth-child(3) { animation-delay: 120ms; }
.stagger-children > *:nth-child(4) { animation-delay: 180ms; }
.stagger-children > *:nth-child(5) { animation-delay: 240ms; }
.stagger-children > *:nth-child(6) { animation-delay: 300ms; }
/* Pattern: N × 60ms — use 40-80ms gap per item */
```

### Pop In (For notification badges, toast, floating actions)
```css
@keyframes popIn {
  0% { opacity: 0; transform: scale(0.5); }
  70% { transform: scale(1.05); }
  100% { opacity: 1; transform: scale(1); }
}
```

---

## Micro-Interactions

### Button Hover — Lift + Shadow
```css
.btn-hover {
  transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
}
.btn-hover:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(99, 102, 241, 0.25);
}
.btn-hover:active {
  transform: translateY(0);
  box-shadow: 0 1px 3px rgba(99, 102, 241, 0.15);
}
```

### Button Hover — Scale Press
```css
.btn-press {
  transition: transform 0.15s ease;
}
.btn-press:hover { transform: scale(1.02); }
.btn-press:active { transform: scale(0.98); }
```

### Card Hover — Lift + Border Glow
```css
.card-hover {
  transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1);
  border: 1px solid transparent;
}
.card-hover:hover {
  transform: translateY(-4px);
  box-shadow: 0 12px 24px rgba(0, 0, 0, 0.08);
  border-color: rgba(99, 102, 241, 0.2);
}
```

### Link Underline Grow
```css
.link-grow {
  position: relative;
  text-decoration: none;
}
.link-grow::after {
  content: '';
  position: absolute;
  bottom: -2px; left: 0;
  width: 0; height: 2px;
  background: currentColor;
  transition: width 0.25s ease;
}
.link-grow:hover::after { width: 100%; }
```

### Icon Rotate on Hover
```css
.icon-rotate {
  transition: transform 0.3s cubic-bezier(0.16, 1, 0.3, 1);
}
.icon-rotate:hover { transform: rotate(15deg); }
```

### Checkbox Check Animation
```css
@keyframes checkmark {
  0% { stroke-dashoffset: 24; }
  100% { stroke-dashoffset: 0; }
}
.checkbox-anim svg path {
  stroke-dasharray: 24;
  stroke-dashoffset: 24;
}
.checkbox-anim.checked svg path {
  animation: checkmark 0.3s ease forwards;
}
```

### Toggle Switch
```css
.toggle-track {
  width: 48px; height: 26px;
  background: #cbd5e1;
  border-radius: 13px;
  position: relative;
  transition: background 0.2s ease;
  cursor: pointer;
}
.toggle-track.active { background: #6366f1; }
.toggle-thumb {
  width: 22px; height: 22px;
  background: white;
  border-radius: 50%;
  position: absolute;
  top: 2px; left: 2px;
  transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);
  box-shadow: 0 1px 3px rgba(0,0,0,0.2);
}
.toggle-track.active .toggle-thumb {
  transform: translateX(22px);
}
```

---

## Loading States

### Skeleton Loader
```css
@keyframes shimmer {
  0% { background-position: -200% 0; }
  100% { background-position: 200% 0; }
}
.skeleton {
  background: linear-gradient(90deg,
    #e2e8f0 25%, #f1f5f9 50%, #e2e8f0 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite linear;
  border-radius: 6px;
}
.skeleton-text { height: 14px; margin-bottom: 8px; }
.skeleton-title { height: 20px; width: 60%; margin-bottom: 12px; }
.skeleton-avatar { width: 40px; height: 40px; border-radius: 50%; }
```

### Spinner
```css
@keyframes spin {
  to { transform: rotate(360deg); }
}
.spinner {
  width: 24px; height: 24px;
  border: 3px solid #e2e8f0;
  border-top-color: #6366f1;
  border-radius: 50%;
  animation: spin 0.6s linear infinite;
}
```

### Pulse Dot (Loading indicator)
```css
@keyframes pulse {
  0%, 80%, 100% { transform: scale(0.6); opacity: 0.4; }
  40% { transform: scale(1); opacity: 1; }
}
.pulse-dots span {
  display: inline-block;
  width: 8px; height: 8px;
  margin: 0 3px;
  background: #6366f1;
  border-radius: 50%;
  animation: pulse 1.4s infinite ease-in-out;
}
.pulse-dots span:nth-child(2) { animation-delay: 0.16s; }
.pulse-dots span:nth-child(3) { animation-delay: 0.32s; }
```

### Progress Bar
```css
@keyframes progressFill {
  from { width: 0; }
}
.progress-bar {
  height: 6px;
  background: linear-gradient(90deg, #6366f1, #8b5cf6);
  border-radius: 3px;
  animation: progressFill 2s cubic-bezier(0.16, 1, 0.3, 1) forwards;
}
```

---

## Scroll-Triggered Reveals

### CSS-only with Intersection Observer (Vanilla JS)
```javascript
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      observer.unobserve(entry.target);
    }
  });
}, { threshold: 0.15 });

document.querySelectorAll('.reveal').forEach(el => observer.observe(el));
```

```css
.reveal {
  opacity: 0;
  transform: translateY(30px);
  transition: opacity 0.6s cubic-bezier(0.16, 1, 0.3, 1),
              transform 0.6s cubic-bezier(0.16, 1, 0.3, 1);
}
.reveal.visible {
  opacity: 1;
  transform: translateY(0);
}
/* Stagger children within a reveal container */
.reveal.visible > *:nth-child(1) { transition-delay: 0ms; }
.reveal.visible > *:nth-child(2) { transition-delay: 100ms; }
.reveal.visible > *:nth-child(3) { transition-delay: 200ms; }
```

### CSS-only scroll-driven (modern browsers, 2024+)
```css
@supports (animation-timeline: view()) {
  .scroll-reveal {
    animation: fadeInUp linear both;
    animation-timeline: view();
    animation-range: entry 0% entry 100%;
  }
}
```

---

## Page Transitions

### Fade Between Views
```css
.page-enter { opacity: 0; }
.page-enter-active {
  opacity: 1;
  transition: opacity 0.3s ease;
}
.page-exit { opacity: 1; }
.page-exit-active {
  opacity: 0;
  transition: opacity 0.2s ease;
}
```

### Slide Transition
```css
.slide-enter { transform: translateX(100%); }
.slide-enter-active {
  transform: translateX(0);
  transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}
.slide-exit-active {
  transform: translateX(-30%);
  transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1);
}
```

---

## Data Animations

### Counter Animation (Vanilla JS)
```javascript
function animateCounter(element, target, duration = 1500) {
  let start = 0;
  const startTime = performance.now();
  function update(currentTime) {
    const elapsed = currentTime - startTime;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3); // easeOutCubic
    const current = Math.round(start + (target - start) * eased);
    element.textContent = current.toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
  }
  requestAnimationFrame(update);
}
```

### Chart Entrance (CSS for Chart.js canvas)
```css
canvas {
  animation: fadeInUp 0.8s cubic-bezier(0.16, 1, 0.3, 1) 0.2s both;
}
```

---

## Easing Functions

| Name | CSS Value | Use For |
|------|-----------|---------|
| Ease Out (default) | `cubic-bezier(0.16, 1, 0.3, 1)` | Most UI transitions |
| Ease In | `cubic-bezier(0.55, 0, 1, 0.45)` | Exit animations |
| Spring | `cubic-bezier(0.34, 1.56, 0.64, 1)` | Playful bounce, toggles |
| Smooth | `cubic-bezier(0.4, 0, 0.2, 1)` | Background changes, fades |
| Snappy | `cubic-bezier(0.2, 0, 0, 1)` | Quick micro-interactions |

### Reduced Motion Support (ALWAYS include)
```css
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
    scroll-behavior: auto !important;
  }
}
```
