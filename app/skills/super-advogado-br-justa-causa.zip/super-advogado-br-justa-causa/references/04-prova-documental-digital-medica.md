# Prova documental, digital e médica

## Objetivo

Transformar arquivos e registros em prova verificável, preservando integridade, contexto, origem e licitude.

## Quatro perguntas para qualquer documento

1. **Existência:** este arquivo/documento existia na data alegada?
2. **Autoria/origem:** quem o criou, assinou, enviou ou registrou?
3. **Integridade:** o conteúdo permaneceu inalterado?
4. **Contexto:** o fragmento representa a conversa, evento ou sistema completo?

## CPC e ônus documental

Na aplicação subsidiária, verifique especialmente:

- meios de prova e valoração;
- autenticidade e fé documental;
- falsidade material versus impugnação de autenticidade;
- art. 429 do CPC: quem alega falsidade prova a falsidade; quem produziu documento cuja autenticidade é impugnada prova sua autenticidade, observadas as particularidades do processo do trabalho.

Não confunda:

- **falsidade:** formar documento não verdadeiro ou alterar documento verdadeiro;
- **inautenticidade:** dúvida sobre autoria/assinatura/origem;
- **erro material:** conteúdo equivocado sem fraude;
- **irregularidade formal:** documento verdadeiro que não cumpre requisito específico.

## Preservação digital

- manter o arquivo original e uma cópia de trabalho;
- não reenviar por aplicativos que recomprimem ou removem metadados;
- exportar e-mail em formato nativo quando possível;
- guardar cabeçalhos completos;
- exportar conversa integral, não apenas prints;
- registrar aparelho, conta, data, método de coleta e responsável;
- gerar SHA-256;
- manter manifesto de evidências e histórico de cópias;
- documentar fuso horário e relógio do sistema;
- preservar URLs, IDs e logs de acesso.

Print é útil, mas pode ser insuficiente sozinho. Combine com exportação nativa, testemunha, ata notarial, dados do provedor, perícia ou confirmação da contraparte conforme proporcionalidade.

## Licitude

Não orientar:

- invasão de conta ou dispositivo;
- uso de credencial de terceiro;
- instalação de spyware;
- interceptação sem base legal;
- alteração de arquivo;
- gravação em ambiente onde a pessoa não participa sem análise jurídica específica.

Gravação por um dos interlocutores tem tratamento próprio na jurisprudência. Verifique fatos, finalidade, expectativa de privacidade e precedentes atuais.

## Documentos médicos e saúde

Dados de saúde são sensíveis. Limite coleta e divulgação ao necessário.

Checklist:

- atendimento ocorreu?
- profissional e estabelecimento confirmam a emissão?
- existe prontuário ou registro de consulta?
- documento original, PDF, QR, código e assinatura estão disponíveis?
- assinatura é qualificada, avançada, simples, manuscrita ou imagem?
- houve erro de cadastro, horário, fuso, modelo ou sistema?
- quem baixou, recebeu, converteu ou editou o arquivo?
- a empresa consultou documento idêntico ao entregue?
- a negativa veio de canal competente e identificou o objeto exato?
- o empregado teve oportunidade de apresentar original ou esclarecer?
- existe prova técnica de alteração e de autoria?

O fato de um hospital “não reconhecer” um documento pode ser indício, não conclusão automática. Preserve a resposta, identifique o atendente, o método consultado e peça confirmação formal do emissor.

## Matriz para alegação de fraude documental

```text
Documento:
Versão entregue:
Original disponível:
Emissor confirmado:
Assinatura validada:
Alteração identificada:
Campo alterado:
Momento provável:
Pessoa com acesso:
Autoria provada:
Conhecimento do empregado:
Vantagem pretendida:
Explicação alternativa:
Perícia necessária:
Conclusão provisória:
```

## Cadeia de custódia prática

Embora a disciplina penal não seja transplantada automaticamente, princípios de rastreabilidade fortalecem a prova civil/trabalhista:

`coleta -> identificação -> hash -> armazenamento -> cópia de trabalho -> análise -> produção em juízo`

Cada etapa deve registrar data, pessoa, ferramenta e alteração realizada.
