# Plugin: Consumidor, Bancário, Banco Central e Fintechs

> **Base de conhecimento fechada em 03/08/2026; itens marcados "(atualizado 07/10/2026)" foram revistos nessa data — ver `radar-normativo.md`.** 🔄 = volátil, confirmar em fonte oficial antes de usar. ⛔ = erro comum a não repetir. 🔴 = há suspensão nacional ativa ou julgamento marcado.

## Ativar quando
Relação de consumo com banco, instituição de pagamento, fintech, adquirente, seguradora ou plataforma financeira; fraude/golpe bancário; revisional; consignado; RMC; superendividamento; negativação; tarifas e juros; Pix; open finance; criptoativos; autorização e conduta de instituições reguladas pelo BCB.

---

## 1. Sequência obrigatória de análise

1. **Há relação de consumo?** Teoria finalista **mitigada** — destinatário final fático + prova de vulnerabilidade. CDC aplicável às instituições financeiras: **art. 3º, §2º, do CDC + ADI 2591/STF** e **Súmula 297 do STJ**.
2. **Quem é o fornecedor na cadeia?** banco emissor, credenciadora/subadquirente, instituição de pagamento (IP), fintech de crédito (SCD/SEP), BaaS, marketplace, correspondente bancário (**Resolução CMN 4.935/2021** e Súmula 479).
3. **Qual o defeito alegado?** vício de informação, cobrança indevida, falha de segurança, negativação, assédio de crédito, venda casada, prática abusiva.
4. **Regime de responsabilidade**: art. 14 do CDC (objetiva, com excludentes do §3º) x art. 12 x responsabilidade contratual civil.
5. **O tema está suspenso ou afetado?** (§5) — isso muda estratégia processual antes de mudar o mérito.
6. **Regime de juros e correção aplicável ao período** (§3.3).
7. **Camada regulatória incidente** (BCB/CMN/Susep) — dever de conduta e prova (§6 a §9).

---

## 2. Base legal do consumidor financeiro

- **CDC (Lei 8.078/1990)** — ⛔ **nenhuma lei alterou o CDC entre 2023 e ago/2026**; a última alteração relevante é a Lei 14.181/2021.
- **Superendividamento**: arts. **54-A a 54-G** (CET, vedação ao assédio de crédito, crédito responsável, contratos conexos) e **104-A a 104-C** (repactuação judicial, plano com prazo máximo de **5 anos**).
- **Mínimo existencial**: Decreto 11.150/2022, art. 3º, com a redação do **Decreto 11.567/2023** — **R$ 600,00**.
  - 🔴 **STF, ADPFs 1.005, 1.006 e 1.097, Rel. Min. André Mendonça, j. 23/04/2026 (procedência parcial)**: (i) é constitucional fixar valor de mínimo existencial; (ii) o **CMN deve avaliar e revisar anualmente os parâmetros** do mínimo existencial, com base em estudos técnicos — **não há reajuste automático do valor**; (iii) **é inconstitucional excluir o crédito consignado** da proteção do mínimo existencial. Efeito prático: **o consignado passa a ser computado** na repactuação. 🔄 Conferir o teor literal do acórdão e eventual decreto novo antes de citar em peça.
- **SAC — Decreto 11.034/2022**: 24/7 em ao menos um canal, atendimento humano mínimo de 8h/dia, resposta em **7 dias corridos**, cancelamento imediato por qualquer canal. 🔄 A extensão do decreto a instituições financeiras é controvertida (regulação própria do CMN/BCB) — verificar antes de fundamentar.
- **Marco Legal das Garantias — Lei 14.711/2023**: execução extrajudicial de hipoteca, consolidação da propriedade fiduciária (Lei 9.514/97), **busca e apreensão extrajudicial** de bens móveis (arts. 8º-B a 8º-E do DL 911/69). Desloca contencioso bancário para a via extrajudicial.
- **Seguros — Lei 15.040/2024**, vigente desde **11/12/2025**: novo marco do contrato de seguro; prescrição de **1 ano** para o segurado (contado da **recusa expressa**), **3 anos** para beneficiários e terceiros prejudicados; suspensão **única** pelo pedido de reconsideração (art. 127). ⛔ A lei **não contém remissão expressa ao CDC** — a incidência consumerista (ex.: prestamista) segue por CDC + jurisprudência.
- **Lei 15.252, de 04/11/2025 — direitos da pessoa natural usuária de serviços financeiros**: portabilidade salarial automática, débito automático entre instituições, informação e **modalidade especial de crédito com juros reduzidos**. 🔄 Regulamentação do BCB (**Resoluções BCB 564, 565, 566 e 567, de 04/05/2026**) só **entra em vigor em 01/07/2027** — hoje não é obrigação exigível.
- **Lei 15.327, de 07/01/2026 — descontos associativos em benefícios do INSS**: veda descontos de mensalidades associativas **mesmo com autorização**; proíbe contratação de consignado por procuração ou telefone; **bloqueio automático** do benefício para novas operações, com desbloqueio por biometria ou assinatura eletrônica qualificada e **autorização prévia, pessoal e específica por contratação**; ressarcimento em até **30 dias**. Houve vetos (busca ativa pelo INSS, ressarcimento direto pelo INSS, taxas máximas pelo CMN).
- **Lei 15.179/2025 — Crédito do Trabalhador** (consignado privado): altera a Lei 10.820/2003; exige **verificação biométrica** e assinatura eletrônica qualificada; portabilidade condicionada a taxa inferior; limite de 30% dos repasses para autônomos de transporte/entrega.
- **Lei 15.397, de 30/04/2026**: endurece o Código Penal em **fraude eletrônica** (art. 171 — 4 a 8 anos quando praticada por redes sociais, telefone ou e-mail fraudulento), furto eletrônico e cessão de conta bancária ("conta laranja"). ⛔ **Não cria** obrigação civil de ressarcimento pelo banco — é norma penal.
- **Apostas**: Lei 14.790/2023 (interface consumo/publicidade/vulnerabilidade). 🔄 (atualizado 07/10/2026) **MP 1.394, de 25/09/2026**, proíbe a exploração e a oferta de apostas de quota fixa e veda que IFs/IPs processem pagamentos a apostas (art. 14), regulamentada pelas **Res. BCB 590 e 595–597/2026**. É MP: acompanhar conversão.
- ⛔ **Não é lei** (atualizado 07/10/2026): PL 2.616/2025 (CadÚnico Telefônico, telemarketing/cobrança — aprovado **terminativamente na CTFC** do Senado em 08/07/2026; na Câmara desde 10/08/2026, aguardando despacho) e projetos de restituição em 48h a idosos vítimas de golpe.

---

## 3. Juros, tarifas, revisional e cálculo

### 3.1 Rotativo do cartão
**Lei 14.690/2023, art. 28** + **Resolução CMN 5.112, de 21/12/2023**: o total de **juros e encargos** do rotativo e do parcelamento da fatura **não pode exceder 100% do valor original da dívida**; limite vigente desde **01/01/2024**; demais dispositivos (renegociação, **portabilidade do rotativo**, documento descritivo) desde 01/07/2024. Complemento: **Resolução BCB 365/2023** (datas de vencimento, conteúdo da fatura, limite compatível com o perfil de risco).

### 3.2 Abusividade de juros remuneratórios 🔴
- Regra consolidada: **não há limitação constitucional** de juros para instituições financeiras (Súmula Vinculante 7; Súmula 596 do STF); a abusividade se afere caso a caso, com referência à **taxa média de mercado do BCB** (Súmula 530 do STJ).
- 🔴 **Tema 1.378/STJ** (REsp 2.227.844/RS e outros, Rel. Min. Antonio Carlos Ferreira, 2ª Seção; sessão eletrônica encerrada em **02/09/2025**, afetação publicada em **09/09/2025** — usar esta data em peça): definirá se a **taxa média de mercado pode ser critério objetivo único** de abusividade e se cabe REsp para rever a conclusão (Súmula 7). **Suspensão de REsp/AREsp na origem e no STJ.**
- **Capitalização**: lícita em periodicidade inferior a um ano em contratos posteriores a 31/03/2000, se **expressamente pactuada** (REsp 973.827, repetitivo). **REsp 2.227.062**, 4ª Turma, **31/07/2026**: *a falta de indicação da taxa diária equivalente não justifica, por si só, substituir a capitalização pactuada por juros simples*, bastando valor, número/valor das prestações, taxas mensal e anual e previsão expressa.
- **Tema 1.268/STJ** (REsp 2.145.391, j. 17/09/2025): a **eficácia preclusiva da coisa julgada** impede nova ação para restituir juros remuneratórios incidentes sobre tarifas já declaradas ilegais em ação anterior.

### 3.3 Juros de mora e correção nas dívidas civis ⚠️ crítico para cálculo
- **Antes da Lei 14.905/2024**: **Tema 1.368/STJ** (REsp 2.199.164, **Corte Especial, j. 29/10/2025**) — o art. 406 do CC deve ser interpretado no sentido de que **a Selic é a taxa de juros de mora** das dívidas civis.
- **A partir de 30/08/2024** (60 dias da Lei 14.905/2024): **correção pelo IPCA** (art. 389, parágrafo único) + **taxa legal = Selic − IPCA** (art. 406, §1º), com **resultado negativo igual a zero**.
- Sempre **dividir o cálculo por período**.

### 3.4 Cartão consignado / RMC 🔴
- 🔴 **Tema 1.414/STJ** (REsp 2.224.599/PE e outros, Rel. Min. Raul Araújo, afetado em 09/03/2026, **suspensão nacional desde 17/03/2026**): parâmetros objetivos de validade e abusividade dos contratos de **cartão de crédito consignado**, inclusive informação ao consumidor e prolongamento indeterminado da dívida.
- ⛔ **Tema 1.328/STJ foi CANCELADO em 02/10/2026** (atualizado 07/10/2026): o REsp 2.145.244/SC (dano moral *in re ipsa* na RMC) foi incorporado ao **Tema 1.414**, que agora concentra também a questão do dano moral. Não citar o 1.328 como tema ativo.
- **Tema 1.286/STJ** (1ª Seção): limite de desconto no consignado de **militar** das Forças Armadas (art. 14, §3º, da MP 2.215-10/2001) — **julgado em 12/03/2025, transitado** (atualizado 07/10/2026). Conferir a tese literal na página de repetitivos antes de citar.

### 3.5 Outros repetitivos relevantes
- **Tema 1.156** (REsp 1.962.275, j. 17/05/2024): *"O simples descumprimento do prazo fixado em legislação específica para a prestação de serviço bancário não gera dano moral presumido (in re ipsa)."*
- **Tema 1.279**: na busca e apreensão de bem alienado fiduciariamente, o prazo de **5 dias** para pagamento integral corre **da execução da liminar**.
- **Tema 1.288**: consolidada a propriedade **antes** da Lei 13.465/2017 com purga da mora (art. 34 do DL 70/66), desfaz-se a consolidação; **após** a Lei 13.465/2017, sem purga, resta apenas o **direito de preferência** do art. 27, §2º-B, da Lei 9.514/97.
- 🔄 **Tema 1.396**: é ou não prescindível a prévia tentativa extrajudicial para o interesse de agir em ações prestacionais de consumo.
- **Tema 1.198/STJ** (Corte Especial, 1º sem./2026): o juiz pode exigir, fundamentadamente, emenda da inicial para demonstrar **interesse de agir e autenticidade da postulação** (litigância predatória). ⛔ Não confundir com o Tema 1.198 **do STF**, que é tributário (IPVA de locadoras).

---

## 4. Fraudes e golpes — matriz de decisão

**Regra-base**: **Súmula 479 do STJ** (Tema 466) — *"As instituições financeiras respondem objetivamente pelos danos gerados por fortuito interno relativo a fraudes e delitos praticados por terceiros no âmbito de operações bancárias."*

**A responsabilidade não decorre do golpe em si, mas de falha de segurança demonstrável.** Verificar, nesta ordem:

| # | Pergunta | Precedente |
|---|---|---|
| 1 | Houve **vazamento de dados sob custódia** do banco? | **REsp 2.077.278** (3ª T., 24/10/2023) — "golpe do boleto": dados vinculados a operações bancárias estão sob custódia exclusiva do banco; vazamento é defeito do serviço. |
| 2 | As operações **destoavam do perfil** (valor, horário, local, sequência) e o banco não agiu? | **REsp 2.052.228/DF** (3ª T., 12/09/2023) — operações sequenciais, em curto intervalo e de valor elevado "podem e devem ser identificadas pelos bancos". |
| 3 | O réu é **instituição de pagamento/fintech**? | **REsp 2.222.059/SP e REsp 2.229.519** (3ª T., **07/10/2025**) — "falsa central de atendimento": **bancos E instituições de pagamento** respondem objetivamente por falha na proteção de dados ou na identificação de transações suspeitas. Estende a Súmula 479 às IPs. |
| 4 | Alega-se **culpa concorrente** da vítima? | **REsp 2.220.333** (3ª T., 13/11/2025) — só há culpa concorrente quando a vítima "conscientemente assume e potencializa o risco"; instalar app de acesso remoto sob engano **não** é isso. Restituição integral. |
| 5 | **Não havia** transação incompatível com o histórico? | **REsp 2.209.868** (3ª T., **15/07/2026**) — a responsabilidade "não é automática"; sem operações destoantes e havendo ato presencial sem busca de esclarecimento, configura-se culpa exclusiva da vítima e de terceiro. |
| 6 | O réu é o **banco digital recebedor** dos valores? | **REsp 2.124.423** (3ª T., 27/01/2025) — cumprido o dever de **verificar e validar a identidade** conforme normas do BCB, não há defeito; exigir documentação adicional contrariaria o objetivo de inclusão financeira. |
| 7 | Há **regresso** na cadeia? | 3ª T., 05/11/2025 — banco emissor tem direito de regresso contra a **credenciadora** que forneceu maquininha usada em fraude. 🔄 **REsp 2.210.737** ("golpe do motoboy", Itaucard × PagSeguro) pendente. |

**Ônus da prova**: as excludentes do **art. 14, §3º, do CDC** (inexistência de defeito, culpa exclusiva do consumidor ou de terceiro) são do **fornecedor**. A autenticidade de assinatura em contrato impugnado também é ônus da instituição.

⛔ **Não afirmar** que existe tema repetitivo do STJ sobre golpe do Pix/engenharia social — **não há afetação** até 03/08/2026.

---

## 5. Estado dos precedentes — o que está travado (checar sempre antes de peticionar) 🔴

| Tema/STJ | Objeto | Situação em 07/10/2026 |
|---|---|---|
| **1.378** | Taxa média do BCB como critério de abusividade de juros | Afetado (sessão 02/09/2025; publicação 09/09/2025) — **REsp/AREsp suspensos** |
| **1.414** | Cartão de crédito consignado (RMC), **incluindo dano moral** (absorveu o Tema 1.328 em 02/10/2026) | Afetado 09/03/2026 — **suspensão nacional** (referendada em 08/04/2026) |
| **1.396** | Prévia tentativa extrajudicial e interesse de agir | Afetado 25/11/2025 — REsp/AREsp suspensos |

**Saíram da lista (atualizado 07/10/2026):** 1.328 (cancelado, absorvido pelo 1.414); 1.286 (consignado militar — julgado 12/03/2025, transitado); 1.387 (PASEP — julgado 10/12/2025, transitado; o saque integral inicia a prescrição). Estes dois últimos já são precedentes citáveis, conferida a tese.

**Consequência prática**: em revisional bancária e RMC, a estratégia hoje é de **preservação de prazo e de tese**, não de expectativa de julgamento rápido. Informar isso ao cliente é parte da resposta.

---

## 6. Negativação, dano moral e litigância

- **Tema 1.315/STJ** (REsp 2.171.177 e outros, Rel. Min.ª Nancy Andrighi, acórdão publicado **12/03/2026**): *"Para os fins do art. 43, §2º, do CDC, é válida a comunicação ao consumidor realizada por meio eletrônico, desde que comprovados o envio da notificação e a respectiva entrega ao destinatário."* — **supera** os julgados de 2023 que vedavam notificação exclusiva por e-mail/SMS. Exige prova de **envio E entrega**.
- **Súmula 359 do STJ**: cabe ao órgão mantenedor do cadastro comunicar. **Súmula 385**: preexistência de inscrição legítima afasta dano moral (sem alteração no período).
- **Teoria do desvio produtivo**: aplicável **apenas** em relação de consumo (**REsp 2.017.194/SP**, 3ª T., 25/10/2022); precedente-base de dano moral coletivo bancário: **REsp 1.929.288/TO** (3ª T., 22/02/2022 — caixas inoperantes, filas acima do limite legal, conduta reiterada).
- **Tema 1.365/STJ** (1º sem./2026): a simples recusa indevida de cobertura por plano de saúde **não** gera dano moral presumido — vetor argumentativo de contenção do dano *in re ipsa* em falhas contratuais de massa.
- **Súmula 675 do STJ** (1ª Seção, 27/11/2024): é **legítima a atuação dos Procons** na aplicação de sanções administrativas do CDC quando a conduta ofende direito consumerista — **mesmo havendo regulador setorial**. Relevante contra a tese de competência exclusiva do BCB.

---

## 7. Superendividamento na prática

- Requisitos: consumidor **pessoa natural de boa-fé**, impossibilidade manifesta de pagar a totalidade das dívidas de consumo **sem comprometer o mínimo existencial**; excluídas dívidas de luxo, contraídas com fraude ou má-fé (art. 54-A, §3º).
- Fase conciliatória (art. 104-A) → plano judicial compulsório (art. 104-B), prazo máximo de **5 anos**.
- **REsp 2.188.689** (4ª T., 23/06/2025): as sanções do art. 104-A, §2º, incidem **só** por ausência injustificada do credor ou comparecimento de representante **sem poderes**. **Recusar o plano e não apresentar contraproposta não gera sanção** — a lei não compele o credor a concessões.
- **CC 193.066/DF** (2ª Seção, 22/03/2023): a repactuação com concurso de credores é de competência da **Justiça estadual**, ainda que haja interesse de ente federal.
- Após **23/04/2026** (ADPFs 1.005/1.006/1.097), o **consignado entra no cômputo** do mínimo existencial.
- **Assédio de crédito** (art. 54-C): oferta a idoso, analfabeto ou vulnerável sem informação de custo total; publicidade de "sem juros" ou "sem consulta a SPC/Serasa" — base para pedido autônomo.

---

## 8. Regulação do BCB e CMN — o que o advogado precisa saber

### 8.1 Pix e antifraude
- Base: **Resolução BCB 1/2020** (arranjo + regulamento) e **Resolução BCB 195/2022** (SPI/Conta PI).
- **MED / MED 2.0 — Resolução BCB 493, de 28/08/2025**: cria o Grupo Estratégico de Segurança do Pix; **bloqueio imediato** na conta do recebedor após notificação de infração (art. 41-D); **funcionalidade de recuperação de valores** com rastreamento em cadeia. Implementação **facultativa desde 23/11/2025** e **obrigatória desde 02/02/2026**.
- **Resolução BCB 457/2025**: validação de posse de chave, consentimento e **validação do nome conforme CPF/CNPJ**; efeitos escalonados em 01/04, 01/07 e 01/10/2025.
- **Resolução BCB 501, de 11/09/2025**: altera a Res. BCB 142/2021 — **rejeição obrigatória** de transações destinadas a contas com **fundada suspeita** de fraude.
- **Resolução BCB 506, de 26/09/2025**: critérios de limite por mitigação de fraude, **marcação de fraude transacional** (art. 78-HA), rejeição de registro/portabilidade de chave para usuário marcado, e nova seção sobre **perda da condição de participante**. **Resolução BCB 507/2025**: Manual de Penalidades do Pix.
- **Limite de R$ 15.000** para instituições que acessam a RSFN via **PSTI** ou IPs não autorizadas: **Resolução BCB 496/2025** (Pix) e **Resolução BCB 497/2025** (TED), com exceções mediante credenciamento do PSTI e **asseguração razoável** de auditoria; **Resolução BCB 503/2025** excepcionou pagamentos à STN e da **Guia do FGTS Digital**. **Resolução BCB 498/2025** (alterada pela **547/2026**) disciplina o **credenciamento de PSTI**.
- **BC Protege+**: **Resolução BCB 475, de 26/05/2025** (Sistema de Comunicação de Restrição a Contratações) + **IN BCB 661/2025**.
- **Resolução BCB 559, de 23/04/2026**: Pix Saque/Pix Troco, novas hipóteses de perda da condição de participante e verificação de aderência — efeitos a partir de **01/07/2026**.
- **IN BCB 746, de 16/06/2026**: **em vigor desde 01/10/2026** (atualizado 07/10/2026) — acabou o teto próprio de R$ 500 por transação do Pix por aproximação (passam a valer os limites gerais da conta) e mudaram as regras de limite do Pix Automático.
- ⛔ **Não citar número de resolução para "Pix parcelado"** — o BCB anunciou que **não editará norma específica** (dez/2025, C2).

### 8.2 Fraude, KYC e responsabilidade regulatória
- **Resolução Conjunta CMN/BCB nº 6, de 23/05/2023** + **Resolução BCB 343/2023** (alterada pela **Resolução BCB 569/2026**): **compartilhamento obrigatório de dados sobre indícios de fraude**.
- **Resolução BCB 142/2021**: controles de prevenção a fraudes em serviços de pagamento.
- **Circular BCB 3.978/2020**: PLD/FT, KYC e monitoramento.
- **Resolução BCB 518, de 03/11/2025** (vigente 01/12/2025): **encerramento obrigatório** de conta de pagamento em caso de irregularidade grave nos dados do titular ou quando o cliente presta serviços financeiros **sem previsão legal** — combate a "contas-bolsão"/subadquirência irregular; documentação guardada por **10 anos**.
- **Resolução Conjunta nº 16, de 28/11/2025**: disciplina **Banking as a Service (BaaS)** — mapa de responsabilidades entre a instituição autorizada e o parceiro não autorizado.
- **Uso argumentativo**: o descumprimento desses deveres regulatórios é **prova de defeito do serviço** no art. 14 do CDC; o cumprimento documentado é a principal defesa (ver REsp 2.124.423).

### 8.3 Criptoativos e PSAVs
- **Lei 14.478/2022** + **Decreto 11.563/2023** (BCB como regulador).
- **Resolução BCB 519/2025** — processos de **autorização** de corretoras de câmbio, SCTVM, SDTVM e **PSAVs**; vigente desde **02/02/2026**.
- **Resolução BCB 520/2025** — **constituição e funcionamento** de PSAVs e prestação de serviços de ativos virtuais por outras instituições; define **stablecoin**, ativos de reserva, carteiras fria/morna/quente, custódia, staking. Vigente desde **02/02/2026**; 🔴 (atualizado 07/10/2026) a **Res. BCB 589/2026** alterou o art. 91: **a partir de 06/11/2026** é vedado a instituições autorizadas operar com contrapartes PSAV **não autorizadas a funcionar** — a ressalva para quem tinha "processo de autorização em curso" saiu do caput (ler o texto integral antes de afirmar); o prazo do art. 88, I para pedir autorização segue vencendo em **30/10/2026**; a **Res. BCB 584/2026** estende a prevenção a fraudes (Res. BCB 142/2021) às PSAVs a partir de 01/01/2027; regras do art. 44 exigíveis de todas as PSAVs a partir de **02/02/2028**.
- **Resolução BCB 521/2025** — integra as operações de PSAVs ao arcabouço **cambial** (Lei 14.286/2021; Res. BCB 277/278/279).
- **Resolução BCB 580/2026** — PSAVs classificadas como **Tipo 3**; vedada a opção pelo Segmento S5.
- ⛔ As **Resoluções BCB 517 e 518/2025 não são normas de criptoativos** (são, respectivamente, capital mínimo e contas de pagamento).

### 8.4 Fintechs de crédito, capital e autorização
- **SCD e SEP**: **Resolução CMN 5.050, de 25/11/2022** (substituiu a Res. CMN 4.656/2018). ⛔ A base **não** é a LC 182/2021 (Marco Legal das Startups).
- **Capital mínimo**: **Resolução Conjunta nº 14, de 03/11/2025** (metodologia por categorias de atividades) + **Resolução BCB 517/2025** (apuração), alterada pela **Resolução Conjunta nº 19, de 23/04/2026**.
- **Instituições de pagamento**: **Resolução BCB 80/2021** (constituição/funcionamento, alterada pelas Res. 407/2024 e 494/2025) e **Resolução BCB 81/2021** (processos de autorização, alterada pela Res. 495/2025). Regime prudencial proporcional (Tipos 1/2/3) das Resoluções BCB 197 a 202/2022, com implementação faseada até 2025; **Resolução BCB 436/2024** para segmentação.
- **Prazo-chave**: IPs não autorizadas participantes do Pix deveriam pedir autorização **entre 01/01/2026 e 01/05/2026**; a omissão é causa de **perda da condição de participante**.
- **Resoluções BCB 548 e 549, de 19/02/2026**: prazos de decisão em atos públicos de liberação — impactam o *time-to-license*.
- ⛔ **Resolução BCB 132/2021 não trata de autorização** (é sobre Estatísticas Bancárias Internacionais). ⛔ Não citar "Resolução CMN 4.970".

### 8.5 Open Finance
**Resolução Conjunta nº 1, de 04/05/2020** (norma-quadro), alterada pelas **RC 7/2023**, **RC 10/2024** e **RC 15, de 28/11/2025** — esta última **incluiu a portabilidade de operações de crédito** no escopo, com participação obrigatória como **instituição credora original** e voluntária como proponente. Consentimento específico e revogável; supervisão do arranjo pelo BCB e de proteção de dados pela **ANPD** (LGPD).

### 8.6 Conduta, nomenclatura e educação financeira
- **Resolução CMN 4.949/2021** — princípios e procedimentos no relacionamento com clientes e usuários (base de qualquer alegação de falha de conduta).
- **Resolução Conjunta nº 17, de 28/11/2025** — **nomenclatura e forma de apresentação ao público** das instituições autorizadas; revogou o art. 8º da Res. CMN 4.935/2021. Impacto direto no uso do termo "banco" por fintechs e IPs (publicidade enganosa por indução de segurança).
- **Resolução Conjunta nº 8/2023** (educação financeira), alterada pela **Resolução Conjunta nº 20, de 04/05/2026**.
- **Resolução BCB 505, de 25/09/2025** — autorização e cancelamento de **débitos em conta** (Res. BCB 51/2020).
- 🔄 Números de normas de **ouvidoria, tarifas e CET** não estão verificados nesta base — **confirmar no BCB antes de citar**.

---

## 9. Interfaces obrigatórias

- **Arranjos de pagamento**: **REsp 2.212.357** (3ª T., out/2025) — *"o CDC não é aplicável aos contratos interempresariais celebrados entre os sujeitos integrantes do arranjo de pagamentos com cartões"* (emissor, credenciador, subcredenciador, bandeira). Consumidor final: CDC. Entre players: direito civil/empresarial.
- **Plataformas e anúncios fraudulentos**: STF, **Temas 987 e 533** (tese de 26/06/2025, com ED julgados em jun/2026) — responsabilidade **subjetiva com presunção relativa de culpa** em **anúncios pagos, impulsionamento pago e redes artificiais**, o que alcança anúncios fraudulentos de investimento. 🔄 Conferir o texto consolidado antes de citar.
- **LGPD**: vazamento de dados bancários = incidente com dever de comunicação à ANPD + fundamento autônomo de responsabilidade (arts. 42 a 45 da Lei 13.709/2018), cumulável com o CDC.
- **Senacon/Procons**: atuação sancionatória validada pela Súmula 675; medidas preventivas recentes contra débitos automáticos sem consentimento válido; mutirões anuais de renegociação.

---

## 10. Formatos de saída preferenciais

- **Parecer de fraude bancária**: fatos → cadeia de fornecedores → defeito alegado → matriz do §4 → excludentes → precedentes com status → estimativa de dano moral e material → recomendação.
- **Análise de revisional**: contrato → cláusulas questionadas → teses disponíveis → **quais estão suspensas (§5)** → cenário de êxito → recomendação processual.
- **Nota regulatória para fintech**: atividade pretendida → licença/figura regulatória aplicável → normas incidentes → prazos e datas de vigência → gaps → plano.
- **Defesa de instituição financeira**: prova de conformidade regulatória documentada (KYC, monitoramento, MED, validação de identidade) → excludente do art. 14, §3º → precedentes restritivos (REsp 2.124.423, 2.209.868, Temas 1.156 e 1.365).

---

## 11. Erros que este plugin existe para impedir

1. Afirmar que **o CDC foi alterado** entre 2023 e 2026 (não foi).
2. Dizer que existe **tema repetitivo sobre golpe do Pix** (não existe).
3. Ignorar a **suspensão** dos Temas 1.378 e 1.414 (este com suspensão nacional e já absorvendo o antigo 1.328) ao propor revisional/RMC.
4. Aplicar **Selic isolada** como juros de mora a período posterior a 30/08/2024.
5. Manter a exclusão do **consignado** do mínimo existencial após 23/04/2026.
6. Tratar a **Lei 15.252/2025** como obrigação já exigível (regulamentação vigora em 01/07/2027).
7. Citar **Resolução BCB 132/2021** como norma de autorização, ou **LC 182/2021** como base de SCD/SEP.
8. Confundir **Tema 1.198 do STJ** (litigância predatória) com o **Tema 1.198 do STF** (IPVA).
9. Afirmar que o **Decreto do SAC** se aplica pacificamente a bancos.
10. Aplicar CDC a **relações interempresariais dentro do arranjo de pagamentos**.
