#!/usr/bin/env bash
# PreToolUse guard: block access to secret-bearing files.
# Matcher: Read|Bash|Grep|Edit
# Exit 2 = block. Verify blocking protocol against code.claude.com/docs/en/hooks.
set -uo pipefail

payload="$(cat)"

# Paths that must never be read into context or echoed into output.
SECRET_RE='(^|["'"'"'[:space:]/=])\.env([.[:alnum:]-]*)?($|["'"'"'[:space:]/])|secrets?\.(ya?ml|json|toml)|\.pem($|["'"'"'[:space:]])|\.p12($|["'"'"'[:space:]])|id_(rsa|ed25519)|\.pgpass|credentials(\.json)?($|["'"'"'[:space:]])|service-account.*\.json|\.npmrc|\.pypirc'

# Allow explicitly safe presence checks: test -n "$VAR", [ -f .env ], ls .env
SAFE_RE='test[[:space:]]+-[nzef]|\[[[:space:]]+-[nzef]|ls[[:space:]]|stat[[:space:]]|--help'

if printf '%s' "$payload" | grep -qiE "$SECRET_RE"; then
  if ! printf '%s' "$payload" | grep -qiE "$SAFE_RE"; then
    cat >&2 << 'MSG'
BLOCKED: operation targets a secret-bearing file.

Secrets must never enter context, logs, output, or commit history.
To check whether a key is set without revealing it:
    test -n "$MY_KEY" && echo "set"
To read a value at runtime, load it from the environment or a secret manager.

If you believe this block is wrong, tell the user what you need and why.
MSG
    exit 2
  fi
fi
exit 0
