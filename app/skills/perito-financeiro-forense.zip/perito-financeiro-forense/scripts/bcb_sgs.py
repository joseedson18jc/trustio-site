#!/usr/bin/env python3
# pff-version: 21.0
"""
bcb_sgs.py — séries do Banco Central (SGS) com cache local e registro de proveniência.

    python3 bcb_sgs.py serie 11 01/01/2024 31/12/2024        # imprime JSON
    python3 bcb_sgs.py mensal 4390 01/2024 12/2025           # dict AAAA-MM -> decimal
    python3 bcb_sgs.py titulo 25464                          # confere o título no catálogo
    python3 bcb_sgs.py catalogo                              # lista as séries conhecidas

Como biblioteca:
    import bcb_sgs; bcb_sgs.serie_mensal(4390, "01/2024", "12/2025")

Regras forenses:
- Toda série usada no laudo vira `[FATO — API BCB SGS série N, consultada em <data>]`.
  A função `proveniencia()` devolve exatamente essa frase.
- Sem rede (sandbox, proxy), a função LEVANTA erro. Nunca preencha meses faltantes com
  palpite: peça ao usuário a planilha do BCB/Calculadora do Cidadão ou declare [PREMISSA].
- Códigos marcados `verificado=False` devem ter o título conferido (`titulo N`) antes de usar.
"""
from __future__ import annotations

import json
import os
import sys
import urllib.parse
import urllib.request
from datetime import date, datetime

__version__ = "21.0"

API = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{n}/dados?formato=json&dataInicial={ini}&dataFinal={fim}"
CKAN = "https://dadosabertos.bcb.gov.br/api/3/action/package_search?q={q}&rows=3"
CACHE_DIR = os.environ.get("PFF_CACHE", os.path.join(os.path.expanduser("~"), ".cache", "perito-sgs"))

# codigo: (descricao, unidade, verificado_em)  — None = não reconferido nesta versão
CATALOGO = {
    11:    ("Selic diária (taxa efetiva do dia)", "% a.d.", "estável"),
    432:   ("Selic meta (Copom)", "% a.a.", "estável"),
    4390:  ("Selic acumulada no mês", "% a.m.", "estável"),
    12:    ("CDI diário", "% a.d.", "estável"),
    433:   ("IPCA mensal", "% a.m.", "estável"),
    7478:  ("IPCA-15 mensal", "% a.m.", "estável"),
    188:   ("INPC mensal", "% a.m.", "estável"),
    189:   ("IGP-M mensal", "% a.m.", "estável"),
    226:   ("TR mensal (1º dia do mês)", "% a.m.", "estável"),
    29543: ("Taxa Legal — art. 406 CC (Res. CMN 5.171/2024)", "% a.m.", "10/10/2026"),
    25463: ("Taxa média mensal PF — cheque especial", "% a.m.", "10/10/2026"),
    25464: ("Taxa média mensal PF — crédito pessoal não consignado", "% a.m.", "10/10/2026"),
    25470: ("Taxa média mensal PF — crédito pessoal total", "% a.m.", "10/10/2026"),
    25477: ("Taxa média mensal PF — cartão de crédito rotativo", "% a.m.", "10/10/2026"),
    25468: ("Taxa média mensal PF — consignado INSS (provável)", "% a.m.", None),
    25478: ("Taxa média mensal PF — cartão de crédito parcelado (provável)", "% a.m.", None),
}
# Códigos que circularam em versões antigas da skill e estão ERRADOS para o fim indicado:
CODIGOS_OBSOLETOS = {25433: "não é 'crédito pessoal não consignado' — usar 25464",
                     25435: "não é 'consignado' — conferir (25468 provável INSS)",
                     27789: "não é 'cheque especial' — usar 25463",
                     27788: "não é 'cartão rotativo' — usar 25477"}


def _get(url: str, timeout: int = 20):
    req = urllib.request.Request(url, headers={"Accept": "application/json", "User-Agent": "perito-sgs/21"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8"))


def serie(codigo: int, data_ini: str, data_fim: str, usar_cache: bool = True) -> list[dict]:
    """Retorna [{'data': 'dd/mm/aaaa', 'valor': float_em_%}, ...]. Datas 'dd/mm/aaaa'."""
    if codigo in CODIGOS_OBSOLETOS:
        print(f"[AVISO] série {codigo}: {CODIGOS_OBSOLETOS[codigo]}", file=sys.stderr)
    os.makedirs(CACHE_DIR, exist_ok=True)
    chave = os.path.join(CACHE_DIR, f"{codigo}_{data_ini.replace('/', '')}_{data_fim.replace('/', '')}.json")
    if usar_cache and os.path.exists(chave):
        with open(chave, encoding="utf-8") as f:
            return json.load(f)["dados"]
    url = API.format(n=codigo, ini=data_ini, fim=data_fim)
    try:
        bruto = _get(url)
    except Exception as e:  # noqa: BLE001
        raise RuntimeError(
            f"SGS {codigo} indisponível ({e.__class__.__name__}: {e}). Sem rede? Peça ao usuário a série "
            f"(Calculadora do Cidadão / SGS em planilha) ou declare [PREMISSA]. Não preencha de memória.") from e
    dados = [{"data": d["data"], "valor": float(d["valor"])} for d in bruto]
    with open(chave, "w", encoding="utf-8") as f:
        json.dump({"codigo": codigo, "consultado_em": datetime.now().isoformat(timespec="seconds"),
                   "url": url, "dados": dados}, f, ensure_ascii=False)
    return dados


def serie_mensal(codigo: int, mes_ini: str, mes_fim: str) -> dict:
    """{'AAAA-MM': taxa_decimal}. mes_* = 'mm/aaaa'. Para séries mensais (433, 4390, 29543…)."""
    mi, ai = mes_ini.split("/")
    mf, af = mes_fim.split("/")
    dados = serie(codigo, f"01/{mi}/{ai}", f"28/{mf}/{af}" if mf == "02" else f"30/{mf}/{af}")
    out = {}
    for d in dados:
        dd, mm, aa = d["data"].split("/")
        out[f"{aa}-{mm}"] = d["valor"] / 100
    return out


def fator_acumulado(codigo: int, data_ini: str, data_fim: str) -> float:
    """Produto (1 + v/100) — p.ex. Selic diária (11) para VP, CDI (12) para pós-fixadas."""
    f = 1.0
    for d in serie(codigo, data_ini, data_fim):
        f *= 1 + d["valor"] / 100
    return f


def titulo(codigo: int) -> str:
    """Confere o título da série no catálogo de dados abertos do BCB."""
    try:
        r = _get(CKAN.format(q=urllib.parse.quote(str(codigo))))
        for p in r.get("result", {}).get("results", []):
            if p.get("name", "").startswith(f"{codigo}-"):
                return p.get("title", "")
        return "(não encontrado no catálogo)"
    except Exception as e:  # noqa: BLE001
        return f"(catálogo indisponível: {e.__class__.__name__})"


def proveniencia(codigo: int, consultado_em: date | None = None) -> str:
    desc = CATALOGO.get(codigo, ("série sem descrição no catálogo",))[0]
    dt = (consultado_em or date.today()).strftime("%d/%m/%Y")
    return f"[FATO — API BCB SGS série {codigo} ({desc}), consultada em {dt}]"


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a or a[0] == "catalogo":
        for k, (d, u, v) in CATALOGO.items():
            print(f"{k:>6}  {d} [{u}]  verificado: {v or 'NÃO — conferir com `titulo`'}")
        for k, m in CODIGOS_OBSOLETOS.items():
            print(f"{k:>6}  OBSOLETO: {m}")
    elif a[0] == "serie":
        print(json.dumps(serie(int(a[1]), a[2], a[3]), ensure_ascii=False))
    elif a[0] == "mensal":
        print(json.dumps(serie_mensal(int(a[1]), a[2], a[3]), ensure_ascii=False))
    elif a[0] == "titulo":
        print(titulo(int(a[1])))
    else:
        print(__doc__)
