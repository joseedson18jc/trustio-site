# Módulos especiais

## Empregador formal, EOR e tomadora

### Mapa de poder real

Registre para cada ato:

`ato | empregador formal | tomadora | EOR/terceiro | pessoa | documento | poder contratual | prova`

Atos: seleção, salário, metas, jornada, ordens, avaliação, investigação, decisão, autorização, comunicação, TRCT, eSocial, pagamento e defesa judicial.

### Teses possíveis

- ausência de formação autônoma de juízo pelo empregador;
- ingerência direta e subordinação;
- inconsistência entre quem acusa e quem pune;
- terceirização/EOR e responsabilidade;
- grupo econômico, se presentes requisitos legais;
- fraude ou nulidade, somente após demonstrar fatos e norma violada;
- tratamento de dados e compartilhamento entre agentes.

### Limite

A participação da tomadora não torna a justa causa automaticamente inválida. O argumento ganha força quando há prova de que o empregador apenas executou ordem, não verificou fatos, não tinha acesso à prova ou criou justificativa posterior.

## Estabilidades

### Dirigente sindical

Verificar art. 543 da CLT, inquérito judicial e Súmula 379/TST.

### CIPA

Verificar proteção constitucional/transitória, Súmula 339/TST, mandato, candidatura e motivo disciplinar. Não presumir necessidade de inquérito judicial igual ao dirigente sindical.

### Gestante

Justa causa comprovada pode afastar estabilidade. A prova da falta deve ser analisada com rigor e sem estereótipos. Verificar Tema 497/STF e jurisprudência trabalhista atual quando relevante.

### Acidente/doença ocupacional

Verificar benefício, nexo, estabilidade do art. 118 da Lei 8.213/1991 e Súmula 378/TST. A estabilidade não impede justa causa comprovada, mas doença e discriminação podem alterar a análise.

## Dispensa discriminatória

Verificar Lei 9.029/1995, Súmula 443/TST e fatos indicativos. Em alegação de justa causa, pergunte se:

- a empresa conhecia a condição protegida;
- a investigação começou após o conhecimento;
- a falta foi tratada de forma diferente de casos equivalentes;
- existe documento contemporâneo ou apenas reconstrução posterior;
- a prova da falta é independente do fator protegido.

## Empresa pública e administração

Empregados públicos podem envolver dever de motivação, regulamentos, sindicância e precedentes do STF. Pesquisar natureza da entidade e tema atual. Não aplicar automaticamente regras de servidor estatutário.

## Regulamento e norma coletiva

Obtenha versão vigente na data do fato. Verifique:

- rito disciplinar;
- prazo de defesa;
- comissão ou alçada;
- gradação obrigatória;
- canal de recurso;
- incorporação contratual;
- alteração posterior.

A ausência de contraditório interno só é decisiva quando houver fonte jurídica ou normativa aplicável, estabilidade especial ou abuso probatório relevante.

## LGPD e investigação interna

Mapeie controlador, operador, finalidade, base legal, minimização, transparência, segurança, retenção e transferência. Dados de saúde exigem cuidado reforçado. Violação de LGPD não anula automaticamente a justa causa, mas pode afetar licitude da prova, dano, dever de informação e responsabilidade.
